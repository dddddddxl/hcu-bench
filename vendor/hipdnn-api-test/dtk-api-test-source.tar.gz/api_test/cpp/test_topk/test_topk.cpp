// Copyright © Advanced Micro Devices, Inc., or its affiliates.
// SPDX-License-Identifier: MIT

#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <memory>
#include <optional>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

#include <hip/hip_runtime.h>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;

// ==================== 工具宏定义 ====================
#define HIP_CHECK(status)                                                                      \
    do                                                                                         \
    {                                                                                          \
        if(status != hipSuccess)                                                               \
        {                                                                                      \
            std::cerr << "HIP Error: " << hipGetErrorString(status) << " in file " << __FILE__ \
                      << " at line " << __LINE__ << "\n";                                      \
            exit(EXIT_FAILURE);                                                                \
        }                                                                                      \
    } while(0)

#define HIPDNN_CHECK(status)                                                             \
    do                                                                                   \
    {                                                                                    \
        if(status != HIPDNN_STATUS_SUCCESS)                                              \
        {                                                                                \
            std::cerr << "hipDNN Error: " << hipdnnGetErrorString(status) << " in file " \
                      << __FILE__ << " at line " << __LINE__ << "\n";                    \
            exit(EXIT_FAILURE);                                                          \
        }                                                                                \
    } while(0)

#define HIPDNN_FE_CHECK(statusObj)                                                        \
    do                                                                                    \
    {                                                                                     \
        auto const& status = statusObj;                                                   \
        if(!status.is_good())                                                             \
        {                                                                                 \
            std::cerr << "hipDNN Frontend Error: " << status.get_message() << " in file " \
                      << __FILE__ << " at line " << __LINE__ << "\n";                     \
            exit(EXIT_FAILURE);                                                           \
        }                                                                                 \
    } while(0)

// ==================== 配置结构体 ====================
struct Config
{
    std::vector<int64_t> dims; // 输入张量维度，如 {4, 10}
    int64_t k = 3; // 选取的 top‑k 数量
    int64_t axis = -1; // 沿哪个轴选取（-1 表示最后一维）
    bool largest = true; // true: 取最大值；false: 取最小值
    bool sorted = true; // 是否排序（目前仅支持 true）
    std::string dataType = "fp32"; // 输入数据类型：fp32 / fp16 / bfp16
    bool cpuValidation = false; // 是否进行 CPU 参考验证
    int fileIndex = 0; // 文件索引，0 表示不使用文件
    std::string filePath = "."; // 文件路径
};

// ==================== 命令行解析 ====================
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-dims") == 0 && i + 1 < argc)
        {
            std::string dimsStr = argv[++i];
            std::replace(dimsStr.begin(), dimsStr.end(), ',', ' ');
            std::istringstream iss(dimsStr);
            int64_t d;
            config.dims.clear();
            while(iss >> d)
                config.dims.push_back(d);
        }
        else if(strcmp(argv[i], "-k") == 0 && i + 1 < argc)
        {
            config.k = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-axis") == 0 && i + 1 < argc)
        {
            config.axis = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--largest") == 0 && i + 1 < argc)
        {
            std::string val = argv[++i];
            std::transform(val.begin(), val.end(), val.begin(), ::tolower);
            config.largest = (val == "true" || val == "1");
        }
        else if(strcmp(argv[i], "--sorted") == 0 && i + 1 < argc)
        {
            std::string val = argv[++i];
            std::transform(val.begin(), val.end(), val.begin(), ::tolower);
            config.sorted = (val == "true" || val == "1");
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
                config.filePath += "/";
        }
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << "\n";
            std::cerr << "Usage: " << argv[0] << " -dims \"dim1,dim2,...\" -k <k> -axis <axis> "
                      << "--largest true|false --sorted true|false -d <fp32|fp16|bfp16> "
                      << "--cpu-validation -i <file_index> -path <path>\n";
            exit(1);
        }
    }

    // 如果未指定维度，使用默认值 {4, 10}
    if(config.dims.empty())
        config.dims = {4, 10};

    return config;
}

// ==================== TopkRunner 类 ====================
class TopkRunner
{
public:
    TopkRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    // 创建张量属性（按行连续布局）
    std::shared_ptr<graph::Tensor_attributes> createTensor(const std::vector<int64_t>& dims,
                                                           DataType data_type,
                                                           const std::string& name = "")
    {
        auto tensor = std::make_shared<graph::Tensor_attributes>();
        tensor->set_dim(dims).set_data_type(data_type);
        if(!name.empty())
            tensor->set_name(name);

        // 计算连续步长（行优先）
        std::vector<int64_t> strides(dims.size());
        int64_t stride = 1;
        for(int64_t i = static_cast<int64_t>(dims.size()) - 1; i >= 0; --i)
        {
            strides[static_cast<size_t>(i)] = stride;
            stride *= dims[static_cast<size_t>(i)];
        }
        tensor->set_stride(strides);
        return tensor;
    }

    // ---------- 前向传播 ----------
    template <typename InputType>
    void forward()
    {
        const auto dataType = getDataTypeEnumFromType<InputType>();
        const auto computeType = DataType::FLOAT; // 计算使用 FP32
        const auto indicesType = DataType::INT64; // 索引固定为 INT64

        std::cout << "Running TopK forward graph " << dataType
                  << " (dims=" << vecToString(config_.dims) << ", k=" << config_.k
                  << ", axis=" << config_.axis << ", largest=" << config_.largest
                  << ", sorted=" << config_.sorted
                  << (config_.cpuValidation ? " (with CPU validation)" : "") << "...\n";

        // 1. 构建图
        auto graph = std::make_shared<graph::Graph>();
        graph->set_name("topk_graph")
            .set_io_data_type(dataType)
            .set_intermediate_data_type(dataType)
            .set_compute_data_type(computeType);

        // 输入张量
        auto input = createTensor(config_.dims, dataType, "input");

        // k 张量（常量）
        auto kTensor = std::make_shared<graph::Tensor_attributes>();
        kTensor->set_name("k").set_value(config_.k);

        // TopK 属性
        auto topkAttrs = graph::TopKAttributes()
                             .set_axis(config_.axis)
                             .set_largest(config_.largest)
                             .set_sorted(config_.sorted)
                             .set_name("topk");

        auto [values, indices] = graph->topk(input, kTensor, topkAttrs);
        values->set_output(true);
        indices->set_output(true).set_data_type(indicesType); // 确保索引类型为 INT64

        // 构建图（使用简化 API）
        HIPDNN_FE_CHECK(graph->build(handle_));
        std::cout << "Graph build successful (TopK).\n";

        // 2. 分配张量内存
        // 计算输出维度：将 axis 维度替换为 k
        std::vector<int64_t> outDims = config_.dims;
        int64_t axis = config_.axis;
        if(axis < 0)
            axis += static_cast<int64_t>(config_.dims.size());
        if(axis < 0 || axis >= static_cast<int64_t>(config_.dims.size()))
        {
            std::cerr << "Invalid axis: " << config_.axis << "\n";
            exit(1);
        }
        outDims[static_cast<size_t>(axis)] = config_.k;

        size_t inputElems = 1;
        for(auto d : config_.dims)
            inputElems *= static_cast<size_t>(d);
        size_t outputElems = 1;
        for(auto d : outDims)
            outputElems *= static_cast<size_t>(d);

        Tensor<InputType> inputTensor(input->get_dim(), input->get_stride());
        Tensor<InputType> valuesTensor(values->get_dim(), values->get_stride());
        Tensor<int64_t> indicesTensor(indices->get_dim(), indices->get_stride());

        // 3. 填充输入数据
        bool readSuccess = false;
        std::vector<InputType> refXData;
        std::vector<InputType> refValuesData;
        std::vector<int64_t> refIndicesData;

        if(config_.fileIndex > 0)
        {
            const std::string xFile
                = config_.filePath + std::to_string(config_.fileIndex) + "_X.bin";
            const std::string valFile
                = config_.filePath + std::to_string(config_.fileIndex) + "_values.bin";
            const std::string idxFile
                = config_.filePath + std::to_string(config_.fileIndex) + "_indices.bin";

            readSuccess = readRawTensor<InputType>(xFile, refXData, inputElems)
                          && readRawTensor<InputType>(valFile, refValuesData, outputElems)
                          && readRawTensor<int64_t>(idxFile, refIndicesData, outputElems);
            if(readSuccess)
            {
                std::cout << "Successfully read TopK reference files.\n";
                std::copy(refXData.begin(), refXData.end(), inputTensor.memory().hostData());
                inputTensor.memory().markHostModified();
            }
            else
            {
                std::cerr << " [WARN] Failed to read reference files. Using random data.\n";
            }
        }

        if(!readSuccess || config_.fileIndex == 0)
        {
            // 随机填充输入
            inputTensor.fillWithRandomValues(static_cast<InputType>(-1.0f),
                                             static_cast<InputType>(1.0f));
        }

        // 4. 准备 variantPack
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[input->get_uid()] = inputTensor.memory().deviceData();
        variantPack[values->get_uid()] = valuesTensor.memory().deviceData();
        variantPack[indices->get_uid()] = indicesTensor.memory().deviceData();

        // 5. 工作空间
        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 首次执行（确保编译完成）
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        valuesTensor.memory().markDeviceModified();
        indicesTensor.memory().markDeviceModified();

        // 6. 性能计时
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));

        const int warmupRuns = 10;
        const int timedRuns = 100;

        for(int i = 0; i < warmupRuns; ++i)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipEventRecord(start, nullptr));
        for(int i = 0; i < timedRuns; ++i)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));

        std::cout << "TopK average execution time: " << time / timedRuns << " ms\n";
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // 同步数据到主机
        (void)valuesTensor.memory().hostData();
        (void)indicesTensor.memory().hostData();

        // 7. 文件验证（如果成功读取了参考数据）
        if(config_.fileIndex > 0 && readSuccess)
        {
            // 复制参考数据到 Tensor 以便比较
            Tensor<InputType> refValuesTensor(values->get_dim(), values->get_stride());
            Tensor<int64_t> refIndicesTensor(indices->get_dim(), indices->get_stride());
            std::copy(
                refValuesData.begin(), refValuesData.end(), refValuesTensor.memory().hostData());
            std::copy(
                refIndicesData.begin(), refIndicesData.end(), refIndicesTensor.memory().hostData());
            refValuesTensor.memory().markHostModified();
            refIndicesTensor.memory().markHostModified();

            bool valMatch = compareTensors(refValuesTensor, valuesTensor, outputElems);
            bool idxMatch = compareTensors(refIndicesTensor, indicesTensor, outputElems);

            std::cout << "File validation results:\n"
                      << "  values: " << (valMatch ? "PASS" : "FAIL") << "\n"
                      << "  indices: " << (idxMatch ? "PASS" : "FAIL") << "\n";
            printFirstElements(
                refValuesTensor, valuesTensor, outputElems, "Ref values", "GPU values");
            printFirstElements(
                refIndicesTensor, indicesTensor, outputElems, "Ref indices", "GPU indices");
        }

        // 8. CPU 参考验证
        if(config_.cpuValidation)
        {
            std::cout << "Running CPU reference validation...\n";
            std::vector<InputType> cpuValues(outputElems);
            std::vector<int64_t> cpuIndices(outputElems);

            cpuTopKReference<InputType>(inputTensor.memory().hostData(),
                                        config_.dims,
                                        config_.axis,
                                        config_.k,
                                        config_.largest,
                                        config_.sorted,
                                        cpuValues,
                                        cpuIndices);

            // 将 CPU 结果放入 Tensor 以复用比较函数
            Tensor<InputType> cpuValuesTensor(values->get_dim(), values->get_stride());
            Tensor<int64_t> cpuIndicesTensor(indices->get_dim(), indices->get_stride());
            std::copy(cpuValues.begin(), cpuValues.end(), cpuValuesTensor.memory().hostData());
            std::copy(cpuIndices.begin(), cpuIndices.end(), cpuIndicesTensor.memory().hostData());
            cpuValuesTensor.memory().markHostModified();
            cpuIndicesTensor.memory().markHostModified();

            float tolerance = getTolerance<InputType>();
            bool valValid
                = compareWithTolerance(cpuValuesTensor, valuesTensor, outputElems, tolerance);
            bool idxValid = compareTensors(cpuIndicesTensor, indicesTensor, outputElems);

            std::cout << "CPU reference validation results:\n"
                      << "  values: " << (valValid ? "PASS" : "FAIL") << "\n"
                      << "  indices: " << (idxValid ? "PASS" : "FAIL") << "\n";
            printFirstElements(
                cpuValuesTensor, valuesTensor, outputElems, "CPU values", "GPU values");
            printFirstElements(
                cpuIndicesTensor, indicesTensor, outputElems, "CPU indices", "GPU indices");
        }

        // 9. 打印部分输出
        std::cout << "First 10 values: ";
        auto valHost = valuesTensor.memory().hostData();
        for(int i = 0; i < 10 && i < static_cast<int>(outputElems); ++i)
        {
            printValue(valHost[i]);
            std::cout << " ";
        }
        std::cout << "\n";

        std::cout << "First 10 indices: ";
        auto idxHost = indicesTensor.memory().hostData();
        for(int i = 0; i < 10 && i < static_cast<int>(outputElems); ++i)
        {
            std::cout << idxHost[i] << " ";
        }
        std::cout << "\n";

        std::cout << "TopK graph execution complete.\n\n";
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    // ---------- 辅助函数 ----------

    // 将 vector 转为字符串（用于打印）
    std::string vecToString(const std::vector<int64_t>& v)
    {
        std::string s = "[";
        for(size_t i = 0; i < v.size(); ++i)
        {
            if(i)
                s += ",";
            s += std::to_string(v[i]);
        }
        s += "]";
        return s;
    }

    // 读取二进制文件
    template <typename T>
    bool readRawTensor(const std::string& filename, std::vector<T>& data, size_t totalElems)
    {
        std::ifstream file(filename, std::ios::binary);
        if(!file.is_open())
            return false;
        file.seekg(0, std::ios::end);
        std::streampos fileSize = file.tellg();
        file.seekg(0, std::ios::beg);
        size_t expectedBytes = totalElems * sizeof(T);
        if(static_cast<size_t>(fileSize) != expectedBytes)
            return false;
        data.resize(totalElems);
        file.read(reinterpret_cast<char*>(data.data()), static_cast<std::streamsize>(fileSize));
        file.close();
        return true;
    }

    // 比较两个张量是否完全相等（用于文件验证）
    template <typename T>
    bool compareTensors(const Tensor<T>& ref, const Tensor<T>& cur, size_t totalElems)
    {
        const T* refData = ref.memory().hostData();
        const T* curData = cur.memory().hostData();
        for(size_t i = 0; i < totalElems; ++i)
        {
            if(refData[i] != curData[i])
            {
                std::cout << "Mismatch at index " << i << ": ref=" << static_cast<float>(refData[i])
                          << ", cur=" << static_cast<float>(curData[i]) << "\n";
                return false;
            }
        }
        return true;
    }

    // 带容差的比较（用于浮点数 CPU 验证）
    template <typename T>
    bool compareWithTolerance(const Tensor<T>& cpu,
                              const Tensor<T>& gpu,
                              size_t totalElems,
                              float tolerance)
    {
        const T* cpuData = cpu.memory().hostData();
        const T* gpuData = gpu.memory().hostData();
        for(size_t i = 0; i < totalElems; ++i)
        {
            float diff = std::abs(static_cast<float>(cpuData[i]) - static_cast<float>(gpuData[i]));
            if(diff > tolerance)
            {
                std::cout << "Mismatch at index " << i << ": cpu=" << static_cast<float>(cpuData[i])
                          << ", gpu=" << static_cast<float>(gpuData[i]) << ", diff=" << diff
                          << "\n";
                return false;
            }
        }
        return true;
    }

    // 打印前若干元素
    template <typename T>
    void printFirstElements(const Tensor<T>& ref,
                            const Tensor<T>& cur,
                            size_t totalElems,
                            const std::string& refName = "Reference",
                            const std::string& curName = "Current")
    {
        size_t printCount = std::min(totalElems, static_cast<size_t>(10));
        std::cout << "First " << printCount << " elements comparison:\n";
        std::cout << refName << ": ";
        for(size_t i = 0; i < printCount; ++i)
        {
            printValue(ref.memory().hostData()[i]);
            std::cout << " ";
        }
        std::cout << "\n" << curName << ":   ";
        for(size_t i = 0; i < printCount; ++i)
        {
            printValue(cur.memory().hostData()[i]);
            std::cout << " ";
        }
        std::cout << std::endl;
    }

    template <typename T>
    void printValue(T val)
    {
        if constexpr(std::is_same_v<T, half> || std::is_same_v<T, bfloat16>)
            std::cout << static_cast<float>(val);
        else if constexpr(std::is_same_v<T, int64_t>)
            std::cout << val;
        else
            std::cout << val;
    }

    // 获取容差值
    template <typename InputType>
    float getTolerance()
    {
        if constexpr(std::is_same_v<InputType, float>)
            return 1e-5f;
        else if constexpr(std::is_same_v<InputType, half>)
            return 1e-2f;
        else if constexpr(std::is_same_v<InputType, bfloat16>)
            return 1e-2f;
        else
            return 1e-5f;
    }

    // ---------- CPU 参考实现 ----------
    template <typename InputType>
    void cpuTopKReference(const InputType* input,
                          const std::vector<int64_t>& dims,
                          int64_t axis,
                          int64_t k,
                          bool largest,
                          bool sorted,
                          std::vector<InputType>& outValues,
                          std::vector<int64_t>& outIndices)
    {
        int64_t ndim = static_cast<int64_t>(dims.size());
        if(axis < 0)
            axis += ndim;
        if(axis < 0 || axis >= ndim)
        {
            std::cerr << "Invalid axis in CPU reference.\n";
            exit(1);
        }

        int64_t dimAxis = dims[static_cast<size_t>(axis)];
        if(k > dimAxis)
        {
            std::cerr << "k exceeds dimension size.\n";
            exit(1);
        }

        // 计算输出维度
        std::vector<int64_t> outDims = dims;
        outDims[static_cast<size_t>(axis)] = k;

        // 计算 prod_before 和 prod_after
        int64_t prodBefore = 1;
        for(int64_t i = 0; i < axis; ++i)
            prodBefore *= dims[static_cast<size_t>(i)];
        int64_t prodAfter = 1;
        for(int64_t i = axis + 1; i < ndim; ++i)
            prodAfter *= dims[static_cast<size_t>(i)];

        size_t totalOut = static_cast<size_t>(prodBefore * k * prodAfter);
        outValues.resize(totalOut);
        outIndices.resize(totalOut);

        // 用于排序的 vector
        std::vector<std::pair<double, int64_t>> items;
        items.reserve(static_cast<size_t>(dimAxis));

        // 遍历所有 batch 组合
        for(int64_t i = 0; i < prodBefore; ++i)
        {
            for(int64_t j = 0; j < prodAfter; ++j)
            {
                items.clear();
                // 提取当前轴上的所有元素
                for(int64_t idx = 0; idx < dimAxis; ++idx)
                {
                    int64_t offset = (i * dimAxis + idx) * prodAfter + j;
                    double val = static_cast<double>(input[offset]);
                    items.emplace_back(val, idx);
                }

                // 排序：按值降序（如果 largest=true）或升序
                if(largest)
                {
                    std::sort(items.begin(), items.end(), [](const auto& a, const auto& b) {
                        return a.first > b.first;
                    });
                }
                else
                {
                    std::sort(items.begin(), items.end(), [](const auto& a, const auto& b) {
                        return a.first < b.first;
                    });
                }

                // 如果 sorted=false，则保持原顺序（但 API 目前要求 true，这里仅作兼容）
                if(!sorted)
                {
                    // 不排序，但 API 目前要求 true，这里忽略
                    // std::cerr << "Warning: sorted=false is not fully supported in CPU ref.\n";
                }

                // 将前 k 个写入输出
                for(int64_t t = 0; t < k; ++t)
                {
                    int64_t outOffset = (i * k + t) * prodAfter + j;
                    outValues[static_cast<size_t>(outOffset)]
                        = static_cast<InputType>(items[static_cast<size_t>(t)].first);
                    outIndices[static_cast<size_t>(outOffset)]
                        = items[static_cast<size_t>(t)].second;
                }
            }
        }
    }
};

// ==================== 根据数据类型选择执行 ====================
void run(hipdnnHandle_t handle, const Config& config)
{
    TopkRunner runner(handle, config);

    if(config.dataType == "fp32")
    {
        runner.forward<float>();
    }
    else if(config.dataType == "fp16")
    {
        runner.forward<half>();
    }
    else if(config.dataType == "bfp16")
    {
        runner.forward<bfloat16>();
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType
                  << " (supported: fp32, fp16, bfp16)\n";
        exit(1);
    }
}

// ==================== 主函数 ====================
int main(int argc, char* argv[])
{
    // 打印命令行
    for(int i = 0; i < argc; ++i)
        std::cout << argv[i] << " ";
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    // 初始化前端日志（可选）
    // initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));

    run(handle, config);

    HIPDNN_CHECK(hipdnnDestroy(handle));
    std::cout << "TopK test completed.\n";
    return 0;
}
