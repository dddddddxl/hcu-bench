#前向
test_rope_fwd -n 4 -c 64 -H 64 -W 256 -F 1 -d fp16 --cpu-validation
test_rope_fwd -n 2 -c 256 -H 12 -W 256 -F 1 -d fp16 --cpu-validation
test_rope_fwd -n 64 -c 512 -H 32 -W 512 -F 1 -d fp16 --cpu-validation
test_rope_fwd -n 1 -c 512 -H 8 -W 512 -F 1 -d fp16 --cpu-validation
test_rope_fwd -n 4 -c 512 -H 16 -W 256 -F 1 -d fp16 --cpu-validation
test_rope_fwd -n 1 -c 256 -H 64 -W 128 -F 1 -d fp16 --cpu-validation
test_rope_fwd -n 1 -c 128 -H 32 -W 512 -F 1 -d fp16 --cpu-validation
test_rope_fwd -n 32 -c 64 -H 16 -W 512 -F 1 -d fp16 --cpu-validation
test_rope_fwd -n 128 -c 256 -H 4 -W 128 -F 1 -d fp16 --cpu-validation
test_rope_fwd -n 16 -c 128 -H 24 -W 512 -F 1 -d fp16 --cpu-validation
test_rope_fwd -n 4 -c 512 -H 24 -W 128 -F 1 -d fp16 --cpu-validation

#反向
test_rope_bwd -n 16 -c 128 -H 12 -W 768 -F 2 -d fp32 --cpu-validation
test_rope_bwd -n 16 -c 128 -H 64 -W 512 -F 2 -d fp32 --cpu-validation
test_rope_bwd -n 1 -c 512 -H 32 -W 256 -F 2 -d fp32 --cpu-validation
test_rope_bwd -n 4 -c 64 -H 4 -W 256 -F 2 -d fp32 --cpu-validation
test_rope_bwd -n 2 -c 64 -H 24 -W 128 -F 2 -d fp32 --cpu-validation
test_rope_bwd -n 4 -c 512 -H 32 -W 128 -F 2 -d fp32 --cpu-validation
test_rope_bwd -n 1 -c 512 -H 64 -W 128 -F 2 -d fp32 --cpu-validation
test_rope_bwd -n 4 -c 128 -H 8 -W 128 -F 2 -d fp32 --cpu-validation
test_rope_bwd -n 1 -c 64 -H 64 -W 768 -F 2 -d fp32 --cpu-validation
test_rope_bwd -n 128 -c 512 -H 16 -W 512 -F 2 -d fp32 --cpu-validation
test_rope_bwd -n 128 -c 128 -H 4 -W 512 -F 2 -d fp32 --cpu-validation
test_rope_bwd -n 16 -c 256 -H 24 -W 512 -F 2 -d fp32 --cpu-validation
test_rope_bwd -n 4 -c 512 -H 16 -W 512 -F 2 -d fp32 --cpu-validation
test_rope_bwd -n 16 -c 128 -H 8 -W 256 -F 2 -d fp32 --cpu-validation
