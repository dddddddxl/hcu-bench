#!/bin/sh
#=============================================
# 环境变量参数
# GPU_LIST          显卡卡号列表，逗号分隔，支持不连续卡号 示例 GPU_LIST="2,3,5"
# PER_GPU_WORKERS   单张GPU最大并发测试任务数量
#
# 使用示例1：GPU 4、5、6、7，每张卡最多同时跑3个测试
export GPU_LIST="4,5,6,7"
export PER_GPU_WORKERS=3
#=============================================

PATH=../../build/bin:$PATH
export PATH

# 默认参数
GPU_LIST=${GPU_LIST:-"2"}
PER_GPU_WORKERS=${PER_GPU_WORKERS:-1}

ldd $(which test_conv)

# 解析卡号数组
IFS=',' read -r -a GPU_ARRAY <<< "$GPU_LIST"
GPU_COUNT=${#GPU_ARRAY[@]}

echo "========================================"
echo "Test Runner Config"
echo "GPU_LIST           = ${GPU_LIST}"
echo "GPU_ARRAY          = ${GPU_ARRAY[*]}"
echo "GPU count          = $GPU_COUNT"
echo "Max tasks per GPU  = $PER_GPU_WORKERS"
echo "Mode               = Dynamic parallel scheduler"
echo "========================================"

echo "Starting tests..."
echo "Current directory: $(pwd)"
echo ""

# 创建日志目录
LOG_DIR="logs"
mkdir -p "$LOG_DIR"

# 收集所有测试脚本
TEST_SCRIPTS=()
for test_script in test*.sh; do
    if [ -f "$test_script" ] && [ "$test_script" != "test_all.sh" ]; then
        TEST_SCRIPTS+=("$test_script")
    fi
done

total_tests=${#TEST_SCRIPTS[@]}
echo "Found total $total_tests test scripts"
if [ "$total_tests" -eq 0 ]; then
    echo "No test scripts found, exit"
    exit 0
fi

# 多进程安全统计临时目录
TMP_DIR=$(mktemp -d ./testrun.XXXXXX)
trap 'rm -rf "$TMP_DIR"' EXIT
touch "$TMP_DIR/passed"
touch "$TMP_DIR/failed"
touch "$TMP_DIR/errorcnt"
# 新增：保存异常任务清单（GPU,脚本名,日志路径）
touch "$TMP_DIR/error_list.txt"

# 单个测试执行函数
run_single_test() {
    local gpu_id="$1"
    local test_script="$2"

    export HIP_VISIBLE_DEVICES="$gpu_id"

    # 优化日志文件名：保留完整脚本名，避免名称冲突
    safe_name=$(echo "$test_script" | sed 's/\.sh$//')
    log_file="${LOG_DIR}/gpu${gpu_id}_${safe_name}.log"

    echo "========================================"
    echo "[GPU $gpu_id] RUN: $test_script"
    echo "Log file: $log_file"
    echo "Start time: $(date '+%Y-%m-%d %H:%M:%S')"
    echo "----------------------------------------"

    start_time=$(date +%s)
    bash "$test_script" > "$log_file" 2>&1
    ret=$?
    end_time=$(date +%s)
    duration=$((end_time - start_time))

    has_errors=0
    if grep -q -i "error\|failed\|segmentation fault\|abort\|core dumped" "$log_file"; then
        has_errors=1
    fi

    if [ $ret -eq 0 ]; then
        if [ $has_errors -eq 1 ]; then
            echo "⚠ [GPU $gpu_id] $test_script : Passed but contains error keywords (Duration: ${duration}s)"
            echo "Log: $log_file"
            echo "Matching error lines:"
            grep -i "error\|failed\|segmentation fault\|abort\|core dumped" "$log_file" | head -5 | sed 's/^/  > /'
            echo "$gpu_id | $test_script | $log_file | RETURN=0 (has error log)" >> "$TMP_DIR/error_list.txt"
            echo 1 >> "$TMP_DIR/errorcnt"
        else
            echo "✓ [GPU $gpu_id] $test_script : Passed (Duration: ${duration}s)"
        fi
        echo 1 >> "$TMP_DIR/passed"
    else
        echo "✗ [GPU $gpu_id] $test_script : Execution failed (Duration: ${duration}s)"
        echo "Log: $log_file"
        echo "Last 20 lines of log:"
        tail -20 "$log_file" | sed 's/^/    /'
        echo "$gpu_id | $test_script | $log_file | RETURN=$ret" >> "$TMP_DIR/error_list.txt"
        echo 1 >> "$TMP_DIR/failed"
        if [ $has_errors -eq 1 ]; then
            echo 1 >> "$TMP_DIR/errorcnt"
        fi
    fi
    echo ""
}

# 维护每张GPU后台进程集合
declare -A gpu_pids
for g in "${GPU_ARRAY[@]}"; do
    gpu_pids[$g]=""
done

# 循环派发所有测试任务
for scr in "${TEST_SCRIPTS[@]}"; do
    # 持续寻找存在空闲槽位的GPU
    while true; do
        free_gpu=""
        for g in "${GPU_ARRAY[@]}"; do
            # 清理已经结束的进程
            live_pids=""
            for pid in ${gpu_pids[$g]}; do
                if kill -0 "$pid" 2>/dev/null; then
                    live_pids+="$pid "
                fi
            done
            gpu_pids[$g]="$live_pids"
            running_num=$(echo ${gpu_pids[$g]} | wc -w)

            if [ "$running_num" -lt "$PER_GPU_WORKERS" ]; then
                free_gpu="$g"
                break
            fi
        done

        if [ -n "$free_gpu" ]; then
            run_single_test "$free_gpu" "$scr" &
            new_pid=$!
            gpu_pids[$free_gpu]+="$new_pid "
            break
        fi
        sleep 0.2
    done
done

# 等待所有后台任务执行完毕
echo "All tests dispatched, waiting for remaining running tasks..."
for g in "${GPU_ARRAY[@]}"; do
    for pid in ${gpu_pids[$g]}; do
        wait "$pid" 2>/dev/null
    done
done

# 汇总结果
passed_tests=$(wc -l < "$TMP_DIR/passed")
failed_tests=$(wc -l < "$TMP_DIR/failed")
error_tests=$(wc -l < "$TMP_DIR/errorcnt")

echo "========================================"
echo "Test Summary"
echo "========================================"
echo "Total tests: $total_tests"
echo "Passed:      $passed_tests"
echo "Failed:      $failed_tests"
echo "Tests with error keywords: $error_tests"
echo ""

# 重点：输出全部异常任务清单，一次性定位所有报错脚本
if [ -s "$TMP_DIR/error_list.txt" ]; then
    echo "========================================"
    echo "List of ALL abnormal test cases:"
    echo "Format: GPU | TestScript | LogFile | Status"
    echo "========================================"
    cat "$TMP_DIR/error_list.txt"
    echo ""
else
    echo "No abnormal test cases detected"
fi
