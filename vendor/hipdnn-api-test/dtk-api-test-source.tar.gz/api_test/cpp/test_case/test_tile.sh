test_tile -n 2 -c 3 -H 4 -W 4 -r 1,2,3,1 -d fp16 --cpu-validation
test_tile -n 2 -c 3 -H 4 -W 4 -r 1,2,3,1 -d fp32 --cpu-validation
test_tile -n 2 -c 3 -H 4 -W 4 -r 1,2,3,1 -d bfp16 --cpu-validation
test_tile -n 16 -c 32 -H 4 -W 4 -r 1,2,3,1 -d fp16 --cpu-validation
test_tile -n 16 -c 32 -H 4 -W 4 -r 1,2,3,1 -d fp32 --cpu-validation
test_tile -n 16 -c 32 -H 4 -W 4 -r 1,2,3,1 -d bfp16 --cpu-validation
