test_kthvalue -n 25 -c 512 -H 5 -W 2 --dim 1 -k 2 --is-contiguous 0 -d fp16 --cpu-validation
test_kthvalue -n 25 -c 512 -H 5 -W 2 --dim 1 -k 2 --is-contiguous 1 -d fp16 --cpu-validation
