test_conv_depth_to_space -n 1 -c 64 -H 256 -W 256 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -bs 2 -d fp16 -L NHWC -t crd -a conv_dts
test_conv_depth_to_space -n 1 -c 64 -H 256 -W 256 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -bs 2 -d fp16 -L NHWC -t crd -a conv_bias_dts
test_conv_depth_to_space -n 1 -c 128 -H 270 -W 480 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -bs 2 -d fp16 -L NHWC -t crd -a conv_bias_add_dts
test_conv_depth_to_space -n 1 -c 64 -H 224 -W 224 -k 64 -y 3 -x 3 -p 1 -q 1 -u 2 -v 2 -l 1 -j 1 -bs 2 -d fp16 -L NHWC -t crd -a conv_bias_dts_add
test_conv_depth_to_space -n 1 -c 32 -H 112 -W 112 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -bs 2 -d fp16 -L NHWC -t crd -a conv_bias_dts_relu
test_conv_depth_to_space -n 1 -c 32 -H 112 -W 112 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -bs 2 -d fp16 -L NHWC -t crd -a conv_bias_dts_leakyrelu --relu-alpha 0.2
test_conv_depth_to_space -n 1 -c 32 -H 112 -W 112 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -bs 2 -d fp16 -L NHWC -t crd -a conv_bias_dts_clippedrelu --relu-alpha 6.0
test_conv_depth_to_space -n 1 -c 128 -H 135 -W 240 -k 256 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -bs 2 -d fp16 -L NHWC -t crd -a conv_bias_dts_relu_add
test_conv_depth_to_space -n 1 -c 128 -H 135 -W 240 -k 256 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -bs 2 -d fp16 -L NHWC -t crd -a conv_bias_dts_leakyrelu_add --relu-alpha 0.1
test_conv_depth_to_space -n 1 -c 128 -H 135 -W 240 -k 256 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -bs 2 -d fp16 -L NHWC -t crd -a conv_bias_dts_clippedrelu_add --relu-alpha 5.0