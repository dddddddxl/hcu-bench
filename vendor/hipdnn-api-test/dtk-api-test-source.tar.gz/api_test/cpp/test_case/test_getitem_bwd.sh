test_getitem_bwd_indices --dyN0 512 --dyN1 25 --dxN0 5 --dxN1 2 --dim 0 -k 0 --is-contiguous 0 -d fp16 --cpu-validation
test_getitem_bwd_indices --dyN0 512 --dyN1 25 --dxN0 5 --dxN1 2 --dim 0 -k 0 --is-contiguous 0 -d fp32 --cpu-validation
test_getitem_bwd_indices --dyN0 512 --dyN1 25 --dxN0 5 --dxN1 2 --dim 1 -k 0 --is-contiguous 0 -d fp16 --cpu-validation
test_getitem_bwd_indices --dyN0 512 --dyN1 25 --dxN0 5 --dxN1 2 --dim 1 -k 0 --is-contiguous 0 -d fp32 --cpu-validation
test_getitem_bwd_indices --dyN0 4 --dyN1 3 --dxN0 4 --dxN1 3 --dim 1 -k 0 --is-contiguous 0 -d fp16 --cpu-validation
test_getitem_bwd_indices --dyN0 4 --dyN1 3 --dxN0 4 --dxN1 3 --dim 1 -k 0 --is-contiguous 0 -d fp32 --cpu-validation
test_getitem_bwd_indices --dyN0 64 --dyN1 128 --dxN0 4 --dxN1 3 --dim 1 -k 0 --is-contiguous 0 -d fp32 --cpu-validation
test_getitem_bwd_indices --dyN0 64 --dyN1 128 --dxN0 64 --dxN1 128 --dim 1 -k 0 --is-contiguous 0 -d fp16 --cpu-validation
