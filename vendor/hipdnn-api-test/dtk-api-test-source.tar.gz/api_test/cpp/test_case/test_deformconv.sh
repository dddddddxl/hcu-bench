export MIOPEN_PRECISION_FP32_FP32_FP32_TF32_FP32=0
test_deformconv --cpu-validation -n 16 -c 128 -H 28 -W 28 -k 32 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 -d fp32 -L NHWC -F 1 -M 0
test_deformconv --cpu-validation -n 16 -c 128 -H 28 -W 28 -k 32 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 -d fp32 -L NHWC -F 2 -M 12
test_deformconv --cpu-validation -n 16 -c 128 -H 28 -W 28 -k 32 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 -d fp32 -L NHWC -F 4 -M 0
test_deformconv --cpu-validation -n 16 -c 128 -H 28 -W 28 -k 32 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 -d fp32 -L NHWC -F 1 -M 1
test_deformconv --cpu-validation -n 16 -c 128 -H 28 -W 28 -k 32 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 -d fp32 -L NHWC -F 2 -M 15
test_deformconv --cpu-validation -n 16 -c 128 -H 28 -W 28 -k 32 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 -d fp32 -L NHWC -F 4 -M 1
export MIOPEN_PRECISION_FP32_FP32_FP32_TF32_FP32=1
test_deformconv --cpu-validation -n 16 -c 128 -H 28 -W 28 -k 32 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 -d tf32 -L NHWC -F 1 -M 0
test_deformconv --cpu-validation -n 16 -c 128 -H 28 -W 28 -k 32 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 -d tf32 -L NHWC -F 2 -M 12
test_deformconv --cpu-validation -n 16 -c 128 -H 28 -W 28 -k 32 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 -d tf32 -L NHWC -F 4 -M 0
test_deformconv --cpu-validation -n 16 -c 128 -H 28 -W 28 -k 32 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 -d tf32 -L NHWC -F 1 -M 1
test_deformconv --cpu-validation -n 16 -c 128 -H 28 -W 28 -k 32 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 -d tf32 -L NHWC -F 2 -M 15
test_deformconv --cpu-validation -n 16 -c 128 -H 28 -W 28 -k 32 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 -d tf32 -L NHWC -F 4 -M 1
