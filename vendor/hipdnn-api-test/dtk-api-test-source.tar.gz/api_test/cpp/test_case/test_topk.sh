test_topk -dims "4,10" -k 3 -axis 1 --largest true --sorted true -d fp32 --cpu-validation
test_topk -dims "4,10" -k 3 -axis 1 --largest true --sorted true -d fp16 --cpu-validation
test_topk -dims "4,10" -k 3 -axis 1 --largest true --sorted true -d bfp16 --cpu-validation
test_topk -dims "4,8" -k 3 -axis 1 --largest true --sorted true -d fp32 --cpu-validation
test_topk -dims "4,8" -k 3 -axis 1 --largest true --sorted true -d fp16 --cpu-validation
test_topk -dims "4,8" -k 3 -axis 1 --largest true --sorted true -d bfp16 --cpu-validation