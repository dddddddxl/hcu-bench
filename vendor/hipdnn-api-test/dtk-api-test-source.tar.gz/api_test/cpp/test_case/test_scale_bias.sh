test_scale_bias --cpu-validation -n 64 -c 256 -H 56 -W 56
test_scale_bias --cpu-validation -n 64 -c 512 -H 28 -W 28
test_scale_bias --cpu-validation -n 64 -c 64 -H 14 -W 14
test_scale_bias --cpu-validation -n 64 -c 2048 -H 7 -W 7
test_scale_bias -d fp16 -n 64 -c 256 -H 56 -W 56
test_scale_bias -d fp16 -n 64 -c 512 -H 28 -W 28
test_scale_bias -d fp16 -n 64 -c 64 -H 14 -W 14
test_scale_bias -d fp16 -n 64 -c 2048 -H 7 -W 7
test_scale_bias -d bf16 -n 64 -c 256 -H 56 -W 56
test_scale_bias -d bf16 -n 64 -c 512 -H 28 -W 28
test_scale_bias -d bf16 -n 64 -c 64 -H 14 -W 14
test_scale_bias -d bf16 -n 64 -c 2048 -H 7 -W 7