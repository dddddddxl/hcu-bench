test_cat -d fp32 -axis 2 --input1 2x128x150x128 --input2 2x128x172x128
test_cat -d fp32 -axis 3 --input1 8x79x67x36 --input2 8x79x67x158
test_cat -d fp32 -axis 0 --input1 88x64x32x47 --input2 41x64x32x47
test_cat -d fp32 -axis 1 --input1 128x100x32x32 --input2 128x157x32x32
test_cat -d fp32 -axis 2 --input1 32x53x128x105 --input2 32x53x26x105 --input3 32x53x41x105
test_cat -d fp32 -axis 1 --input1 47x85x29x7 --input2 47x106x29x7 --input3 47x114x29x7
test_cat -d fp32 -axis 3 --input1 64x47x4x41 --input2 64x47x4x181 --input3 64x47x4x199
test_cat -d fp32 -axis 1 --input1 16x195x51x53 --input2 16x101x51x53 --input3 16x27x51x53 --input4 16x73x51x53
test_cat -d fp32 -axis 3 --input1 8x128x11x68 --input2 8x128x11x180 --input3 8x128x11x139 --input4 8x128x11x96
test_cat -d fp32 -axis 0 --input1 115x128x11x11 --input2 24x128x11x11 --input3 178x128x11x11 --input4 128x128x11x11
test_cat -d fp32 -axis 2 --input1 128x34x146x29 --input2 128x34x18x29 --input3 128x34x28x29 --input4 128x34x188x29
test_cat -d fp32 -axis 2 --input1 15x28x14x72 --input2 15x28x18x72 --input3 15x28x45x72 --input4 15x28x16x72 --input5 15x28x15x72
test_cat -d fp32 -axis 1 --input1 53x142x1x250 --input2 53x41x1x250 --input3 53x49x1x250 --input4 53x193x1x250 --input5 53x124x1x250
test_cat -d fp32 -axis 1 --input1 10x111x22x80 --input2 10x132x22x80 --input3 10x144x22x80 --input4 10x48x22x80 --input5 10x132x22x80 --input6 10x43x22x80
test_cat -d fp32 -axis 2 --input1 11x128x173x39 --input2 11x128x188x39 --input3 11x128x130x39 --input4 11x128x36x39 --input5 11x128x198x39 --input6 11x128x40x39
test_cat -d fp32 -axis 3 --input1 9x1x217x140 --input2 9x1x217x165 --input3 9x1x217x184 --input4 9x1x217x11 --input5 9x1x217x85 --input6 9x1x217x169
test_cat -d fp32 -axis 1 --input1 8x56x81x127 --input2 8x156x81x127 --input3 8x190x81x127 --input4 8x132x81x127 --input5 8x53x81x127 --input6 8x114x81x127 --input7 8x189x81x127
test_cat -d fp32 -axis 2 --input1 2x128x112x19 --input2 2x128x147x19 --input3 2x128x120x19 --input4 2x128x53x19 --input5 2x128x192x19 --input6 2x128x107x19 --input7 2x128x77x19
test_cat -d fp32 -axis 3 --input1 1x64x72x19 --input2 1x64x72x19 --input3 1x64x72x41 --input4 1x64x72x71 --input5 1x64x72x16 --input6 1x64x72x40 --input7 1x64x72x20
test_cat -d fp32 -axis 0 --input1 67x384x19x24 --input2 43x384x19x24 --input3 33x384x19x24 --input4 107x384x19x24 --input5 17x384x19x24 --input6 35x384x19x24 --input7 163x384x19x24
test_cat -d fp32 -axis 3 --input1 128x1x102x11 --input2 128x1x102x118 --input3 128x1x102x38 --input4 128x1x102x104 --input5 128x1x102x47 --input6 128x1x102x97 --input7 128x1x102x191 --input8 128x1x102x191
test_cat -d fp32 -axis 1 --input1 2x56x128x56 --input2 2x177x128x56 --input3 2x103x128x56 --input4 2x179x128x56 --input5 2x130x128x56 --input6 2x162x128x56 --input7 2x84x128x56 --input8 2x179x128x56
test_cat -d fp32 -axis 2 --input1 2x32x127x128 --input2 2x32x84x128 --input3 2x32x18x128 --input4 2x32x28x128 --input5 2x32x23x128 --input6 2x32x165x128 --input7 2x32x61x128 --input8 2x32x151x128
test_cat -d fp32 -axis 1 --input1 4x114x34x32x32 --input2 4x187x34x32x32
test_cat -d fp32 -axis 0 --input1 32x79x16x16x16 --input2 119x79x16x16x16
test_cat -d fp32 -axis 3 --input1 128x47x2x85x2 --input2 128x47x2x26x2
test_cat -d fp32 -axis 1 --input1 19x56x23x17x27 --input2 19x50x23x17x27 --input3 19x113x23x17x27
test_cat -d fp32 -axis 3 --input1 11x13x15x16x63 --input2 11x13x15x14x63 --input3 11x13x15x157x63
test_cat -d fp32 -axis 0 --input1 60x32x4x128x4 --input2 84x32x4x128x4 --input3 16x32x4x128x4 --input4 15x32x4x128x4
test_cat -d fp32 -axis 1 --input1 128x48x26x4x20 --input2 128x35x26x4x20 --input3 128x130x26x4x20 --input4 128x58x26x4x20
test_cat -d fp32 -axis 0 --input1 116x128x4x2x64 --input2 109x128x4x2x64 --input3 57x128x4x2x64 --input4 192x128x4x2x64 --input5 134x128x4x2x64 --input6 85x128x4x2x64
test_cat -d fp32 -axis 1 --input1 16x116x2x51x51 --input2 16x151x2x51x51 --input3 16x184x2x51x51 --input4 16x96x2x51x51 --input5 16x17x2x51x51 --input6 16x112x2x51x51 --input7 16x71x2x51x51
test_cat -d fp32 -axis 3 --input1 4x128x2x13x51 --input2 4x128x2x17x51 --input3 4x128x2x18x51 --input4 4x128x2x16x51 --input5 4x128x2x79x51 --input6 4x128x2x33x51 --input7 4x128x2x185x51
test_cat -d fp32 -axis 3 --input1 2x64x16x153x16 --input2 2x64x16x11x16 --input3 2x64x16x64x16 --input4 2x64x16x33x16 --input5 2x64x16x38x16 --input6 2x64x16x37x16 --input7 2x64x16x134x16 --input8 2x64x16x179x16
test_cat -d fp32 -axis 1 --input1 128x129x8x4x4 --input2 128x107x8x4x4 --input3 128x27x8x4x4 --input4 128x120x8x4x4 --input5 128x182x8x4x4 --input6 128x178x8x4x4 --input7 128x24x8x4x4 --input8 128x120x8x4x4
test_cat -d fp32 -axis 2 --input1 128x2x40x4x8 --input2 128x2x148x4x8 --input3 128x2x33x4x8 --input4 128x2x24x4x8 --input5 128x2x155x4x8 --input6 128x2x160x4x8 --input7 128x2x184x4x8 --input8 128x2x199x4x8
test_cat -d int8 -axis 1 --input1 128x100x32x32 --input2 128x157x32x32
test_cat -d int8 -axis 2 --input1 32x53x128x105 --input2 32x53x26x105 --input3 32x53x41x105
test_cat -d int8 -axis 1 --input1 47x85x29x7 --input2 47x106x29x7 --input3 47x114x29x7
test_cat -d int8 -axis 3 --input1 64x47x4x41 --input2 64x47x4x181 --input3 64x47x4x199
test_cat -d int8 -axis 1 --input1 16x195x51x53 --input2 16x101x51x53 --input3 16x27x51x53 --input4 16x73x51x53
test_cat -d int8 -axis 3 --input1 8x128x11x68 --input2 8x128x11x180 --input3 8x128x11x139 --input4 8x128x11x96
test_cat -d int8 -axis 0 --input1 115x128x11x11 --input2 24x128x11x11 --input3 178x128x11x11 --input4 128x128x11x11
test_cat -d int8 -axis 2 --input1 128x34x146x29 --input2 128x34x18x29 --input3 128x34x28x29 --input4 128x34x188x29