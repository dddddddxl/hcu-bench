test_matmul --cpu-validation -d fp32 -m 351 -n 136 -k 92 -b 4
test_matmul --cpu-validation -d fp32 -m 92 -n 604 -k 98 -b 9
test_matmul --cpu-validation -d fp32 -m 37 -n 470 -k 68 -b 7 -fusion gelu
test_matmul --cpu-validation -d fp32 -m 433 -n 98 -k 356 -b 4 -fusion tanh
test_matmul --cpu-validation -d fp32 -m 398 -n 794 -k 80 -b 5 -fusion tanh
test_matmul --cpu-validation -d fp32 -m 659 -n 755 -k 48 -b 6
test_matmul --cpu-validation -d fp32 -m 71 -n 82 -k 65 -b 9 -fusion tanh
test_matmul --cpu-validation -d fp32 -m 271 -n 74 -k 719 -b 8
test_matmul --cpu-validation -d fp32 -m 374 -n 180 -k 607 -b 9 -fusion gelu
test_matmul --cpu-validation -d fp32 -m 90 -n 35 -k 714 -b 3
test_matmul --cpu-validation -d fp32 -m 98 -n 56 -k 131 -b 5 -fusion sigmoid
test_matmul --cpu-validation -d fp32 -m 594 -n 559 -k 26 -b 1
test_matmul --cpu-validation -d fp32 -m 16 -n 722 -k 448 -b 5 -fusion gelu
test_matmul --cpu-validation -d fp32 -m 72 -n 542 -k 56 -b 1
test_matmul --cpu-validation -d fp32 -m 71 -n 375 -k 78 -b 1 -fusion sigmoid
test_matmul --cpu-validation -d fp32 -m 228 -n 837 -k 48 -b 5 -fusion gelu
test_matmul --cpu-validation -d fp32 -m 42 -n 304 -k 92 -b 5
test_matmul --cpu-validation -d fp32 -m 37 -n 517 -k 88 -b 4 -fusion relu
test_matmul --cpu-validation -d fp32 -m 368 -n 739 -k 77 -b 9
# test_matmul --cpu-validation -d fp32 -m 3521 -n 1236 -k 9120 -b 4
# test_matmul --cpu-validation -d fp32 -m 9290 -n 604 -k 984 -b 9
# test_matmul --cpu-validation -d fp32 -m 37079 -n 470 -k 682 -b 7 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 433 -n 9088 -k 36256 -b 4 -fusion tanh
# test_matmul --cpu-validation -d fp32 -m 3982 -n 794 -k 8650 -b 5 -fusion tanh
# test_matmul --cpu-validation -d fp32 -m 659 -n 755 -k 4218 -b 6
# test_matmul --cpu-validation -d fp32 -m 7134 -n 820 -k 865 -b 9 -fusion tanh
# test_matmul --cpu-validation -d fp32 -m 2781 -n 704 -k 719 -b 8
# test_matmul --cpu-validation -d fp32 -m 37014 -n 180 -k 607 -b 9 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 930 -n 351 -k 7141 -b 3
# test_matmul --cpu-validation -d fp32 -m 998 -n 6056 -k 131 -b 5 -fusion sigmoid
# test_matmul --cpu-validation -d fp32 -m 5914 -n 559 -k 926 -b 1
# test_matmul --cpu-validation -d fp32 -m 1699 -n 722 -k 448 -b 5 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 752 -n 5402 -k 506 -b 1
# test_matmul --cpu-validation -d fp32 -m 7187 -n 375 -k 768 -b 1 -fusion sigmoid
# test_matmul --cpu-validation -d fp32 -m 228 -n 8337 -k 438 -b 5 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 942 -n 304 -k 928 -b 5
# test_matmul --cpu-validation -d fp32 -m 937 -n 517 -k 838 -b 4 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 368 -n 739 -k 767 -b 9
# test_matmul --cpu-validation -d fp32 -m 712 -n 307 -k 635 -b 9 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 507 -n 9636 -k 398 -b 5
# test_matmul --cpu-validation -d fp32 -m 477 -n 702 -k 3467 -b 1
# test_matmul --cpu-validation -d fp32 -m 4809 -n 174 -k 823 -b 9 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 362 -n 388 -k 927 -b 6
# test_matmul --cpu-validation -d fp32 -m 608 -n 824 -k 849 -b 7
# test_matmul --cpu-validation -d fp32 -m 2827 -n 316 -k 603 -b 1 -fusion sigmoid
# test_matmul --cpu-validation -d fp32 -m 584 -n 489 -k 7910 -b 1
# test_matmul --cpu-validation -d fp32 -m 974 -n 158 -k 658 -b 6 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 175 -n 474 -k 950 -b 7 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 4383 -n 880 -k 444 -b 1
# test_matmul --cpu-validation -d fp32 -m 903 -n 998 -k 250 -b 8 -fusion tanh
# test_matmul --cpu-validation -d fp32 -m 731 -n 426 -k 9356 -b 1 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 191 -n 786 -k 952 -b 9
# test_matmul --cpu-validation -d fp32 -m 2158 -n 129 -k 916 -b 2
# test_matmul --cpu-validation -d fp32 -m 964 -n 1064 -k 792 -b 1
# test_matmul --cpu-validation -d fp32 -m 374 -n 651 -k 381 -b 4
# test_matmul --cpu-validation -d fp32 -m 986 -n 574 -k 368 -b 1 -fusion tanh
# test_matmul --cpu-validation -d fp32 -m 29059 -n 169 -k 949 -b 8 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 871 -n 403 -k 636 -b 1 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 980 -n 707 -k 426 -b 1
# test_matmul --cpu-validation -d fp32 -m 2377 -n 275 -k 586 -b 2
# test_matmul --cpu-validation -d fp32 -m 914 -n 410 -k 873 -b 6 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 915 -n 863 -k 289 -b 1 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 965 -n 308 -k 708 -b 1
# test_matmul --cpu-validation -d fp32 -m 899 -n 3656 -k 329 -b 1
# test_matmul --cpu-validation -d fp32 -m 674 -n 661 -k 362 -b 1 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 27002 -n 995 -k 230 -b 6 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 305 -n 561 -k 237 -b 1 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 505 -n 9449 -k 626 -b 1 -fusion sigmoid
# test_matmul --cpu-validation -d fp32 -m 301 -n 2967 -k 575 -b 1
# test_matmul --cpu-validation -d fp32 -m 524 -n 205 -k 230 -b 6 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 352 -n 878 -k 387 -b 1 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 364 -n 270 -k 466 -b 2
# test_matmul --cpu-validation -d fp32 -m 920 -n 152 -k 766 -b 1 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 968 -n 189 -k 113 -b 1 -fusion sigmoid
# test_matmul --cpu-validation -d fp32 -m 647 -n 399 -k 323 -b 1
# test_matmul --cpu-validation -d fp32 -m 756 -n 118 -k 242 -b 1
# test_matmul --cpu-validation -d fp32 -m 425 -n 126 -k 447 -b 1
# test_matmul --cpu-validation -d fp32 -m 417 -n 905 -k 2806 -b 1 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 987 -n 371 -k 763 -b 1 -fusion sigmoid
# test_matmul --cpu-validation -d fp32 -m 370 -n 136 -k 912 -b 2 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 311 -n 138 -k 818 -b 1 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 128 -n 698 -k 826 -b 1 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 248 -n 133 -k 249 -b 1 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 141 -n 657 -k 928 -b 1 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 115 -n 851 -k 1232 -b 1 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 715 -n 259 -k 969 -b 1 -fusion sigmoid
# test_matmul --cpu-validation -d fp32 -m 555 -n 280 -k 917 -b 1 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 414 -n 4560 -k 953 -b 7 -fusion tanh
# test_matmul --cpu-validation -d fp32 -m 617 -n 303 -k 1155 -b 1
# test_matmul --cpu-validation -d fp32 -m 756 -n 428 -k 8637 -b 1 -fusion tanh
# test_matmul --cpu-validation -d fp32 -m 186 -n 2367 -k 339 -b 7 -fusion tanh
# test_matmul --cpu-validation -d fp32 -m 499 -n 15677 -k 722 -b 4 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 328 -n 525 -k 9661 -b 1 -fusion relu
# test_matmul --cpu-validation -d fp32 -m 142 -n 4861 -k 751 -b 8
# test_matmul --cpu-validation -d fp32 -m 30173 -n 373 -k 483 -b 8 -fusion sigmoid
# test_matmul --cpu-validation -d fp32 -m 997 -n 9856 -k 2111 -b 5 -fusion gelu
# test_matmul --cpu-validation -d fp32 -m 2547 -n 182 -k 33627 -b 1 -fusion gelu