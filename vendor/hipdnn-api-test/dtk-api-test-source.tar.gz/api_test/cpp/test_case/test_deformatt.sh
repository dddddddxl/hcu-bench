test_deformatt_fwd --cpu-validation -n 6 -H 8 -D 32 -V 30825 -q 9512 -L 4 -p 8
test_deformatt_fwd --cpu-validation -n 6 -H 8 -D 32 -V 30825 -q 9479 -L 4 -p 8
test_deformatt_fwd --cpu-validation -n 2 -H 8 -D 32 -V 40000 -q 4000 -L 1 -p 4
test_deformatt_fwd --cpu-validation -n 1 -H 8 -D 32 -V 40000 -q 900 -L 1 -p 4
test_deformatt_fwd --cpu-validation -d fp16 -n 6 -H 8 -D 32 -V 30825 -q 9698 -L 4 -p 8
test_deformatt_fwd --cpu-validation -d fp16 -n 6 -H 8 -D 32 -V 30825 -q 9544 -L 4 -p 8
test_deformatt_fwd --cpu-validation -d fp16 -n 6 -H 8 -D 32 -V 30825 -q 9684 -L 4 -p 8
test_deformatt_fwd --cpu-validation -d fp16 -n 1 -H 8 -D 32 -V 40000 -q 900 -L 1 -p 4
test_deformatt_bwd --cpu-validation -n 6 -H 8 -D 32 -V 30825 -q 9512 -L 4 -p 8
test_deformatt_bwd --cpu-validation -n 2 -H 8 -D 32 -V 40000 -q 4000 -L 1 -p 4
test_deformatt_bwd --cpu-validation -n 1 -H 8 -D 32 -V 40000 -q 900 -L 1 -p 4
test_deformatt_bwd --cpu-validation -d fp16 -n 6 -H 8 -D 32 -V 30825 -q 9479 -L 4 -p 8
test_deformatt_bwd --cpu-validation -d fp16 -n 6 -H 8 -D 32 -V 30825 -q 9684 -L 4 -p 8
test_deformatt_bwd --cpu-validation -d fp16 -n 1 -H 8 -D 32 -V 40000 -q 900 -L 1 -p 4
