test_gather -n 4 -c 8 -H 16 --axis 1 --indices "0,3,5" -d fp32 --cpu-validation
test_gather -n 2 -c 3 -H 10 --axis 2 --indices "0,2,5,8" -d fp32 --cpu-validation
test_gather -n 5 -c 4 -H 8 --axis 0 --indices "0,2,4" -d fp16 --cpu-validation
test_gather -n 2 -c 64 -H 32 --axis 1 --indices "0,10,20,30" -d bfp16 --cpu-validation
test_gather -n 256 -c 1024 -H 14 --axis 1 --indices "0,100,200,300" -d fp32 --cpu-validation
test_gather -n 8 -c 16 -H 32 --axis 1 --indices "0,5,10,15" -d fp16 --cpu-validation