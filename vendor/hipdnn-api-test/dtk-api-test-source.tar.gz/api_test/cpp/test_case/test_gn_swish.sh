test_gn_swish  --cpu-validation -L NCHW -d fp16 -n 16 -c 64 -H 80 -W 80 -g 4
test_gn_swish  --cpu-validation -L NCHW -d fp16 -n 16 -c 64 -H 160 -W 160 -g 2
test_gn_swish  --cpu-validation -L NCHW -d fp16 -n 16 -c 64 -H 160 -W 160 -g 4
test_gn_swish  --cpu-validation -L NCHW -d fp16 -n 16 -c 64 -H 320 -W 320 -g 2
test_gn_swish  --cpu-validation -L NCHW -d fp16 -n 64 -c 112 -H 14 -W 14 -g 2 --phase inference
test_gn_swish  --cpu-validation -L NCHW -d fp16 -n 64 -c 112 -H 14 -W 14 -g 4 --phase inference
test_gn_swish  --cpu-validation -L NCHW -d fp16 -n 64 -c 144 -H 28 -W 28 -g 4 --phase inference
test_gn_swish  --cpu-validation -L NCHW -d fp16 -n 64 -c 144 -H 56 -W 56 -g 4 --phase inference
test_gn_swish  --cpu-validation -L NCHW -d fp32 -n 16 -c 64 -H 160 -W 160 -g 4
test_gn_swish  --cpu-validation -L NHWC -d fp16 -n 16 -c 64 -H 80 -W 80 -g 4
test_gn_swish  --cpu-validation -L NHWC -d fp16 -n 64 -c 112 -H 14 -W 14 -g 2
test_gn_swish  --cpu-validation -L NHWC -d fp16 -n 64 -c 144 -H 28 -W 28 -g 4 --phase inference
test_gn_swish  --cpu-validation -L NHWC -d fp16 -n 64 -c 144 -H 56 -W 56 -g 4 --phase inference
test_gn_swish  --cpu-validation -L NHWC -d fp32 -n 16 -c 64 -H 80 -W 80 -g 4 --phase inference
test_gn_swish  --cpu-validation -L NHWC -d fp32 -n 64 -c 112 -H 14 -W 14 -g 4 --phase inference