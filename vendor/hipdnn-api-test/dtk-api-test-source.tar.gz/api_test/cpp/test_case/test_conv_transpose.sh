test_conv_transpose -n 1 -c 64 -H 480 -W 272 -k 32 -y 3 -x 3 -p 1 -q 1 -u 2 -v 2 --output-pad-h 1 --output-pad-w 1 -d fp16 -L NHWC
test_conv_transpose -n 1 -c 32 -H 960 -W 544 -k 16 -y 3 -x 3 -p 1 -q 1 -u 2 -v 2 --output-pad-h 1 --output-pad-w 1 -d fp16 -L NHWC
test_conv_transpose -n 1 -c 64 -H 270 -W 480 -k 32 -y 3 -x 3 -p 1 -q 1 -u 2 -v 2 -d fp16 -L NHWC
test_conv_transpose -n 1 -c 32 -H 540 -W 960 -k 16 -y 3 -x 3 -p 1 -q 1 -u 2 -v 2 -d fp16 -L NHWC