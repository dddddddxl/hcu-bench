test_scatternd --data-dims 4,4 --indices-dims 2,2 --updates-dims 2 --indices "0,0;2,3" --updates 1.5,2.5 -d fp32 --cpu-validation
test_scatternd --data-dims 5 --indices-dims 3,1 --updates-dims 3 --indices "0;2;4" --updates 10,30,50 -d fp32 --cpu-validation
test_scatternd --data-dims 2,3 --indices-dims 2,2 --updates-dims 2 --indices "0,1;1,2" --updates 100,600 -d fp32 --cpu-validation
test_scatternd --data-dims 3,4 --indices-dims 2,1 --updates-dims 2,4 --indices "2;0" --updates "7,7,7,7;9,9,9,9" -d fp32 --cpu-validation
test_scatternd --data-dims 4 --indices-dims 2,1 --updates-dims 2 --indices "1;3" --updates 10,20 --reduction add -d fp32 --cpu-validation
test_scatternd --data-dims 3,4 --indices-dims 2,1 --updates-dims 2,4 --indices "2;0" --updates "7,7,7,7;9,9,9,9" -d fp16 --cpu-validation
test_scatternd --data-dims 4 --indices-dims 2,1 --updates-dims 2 --indices "1;3" --updates 10,20 --reduction add -d fp16 --cpu-validation
test_scatternd --data-dims 3,4 --indices-dims 2,1 --updates-dims 2,4 --indices "2;0" --updates "7,7,7,7;9,9,9,9" -d bfp16 --cpu-validation
test_scatternd --data-dims 4 --indices-dims 2,1 --updates-dims 2 --indices "1;3" --updates 10,20 --reduction add -d bfp16 --cpu-validation