test_transform -n 2 -c 64 -H 4 -W 5 -d fp16 -permute 0,2,3,1 --cpu-validation
test_transform -n 2 -c 64 -H 4 -W 5 -d fp32 -permute 0,2,3,1 --cpu-validation
test_transform -n 1 -c 1 -H 1 -W 1 -d fp32 -permute 0,2,3,1 --cpu-validation
test_transform -n 3 -c 16 -H 8 -W 12 -d fp32 -permute 0,2,3,1 --cpu-validation
test_transform -n 1 -c 2 -H 1 -W 1 -d fp16 -permute 0,2,3,1 --cpu-validation
test_transform -n 3 -c 16 -H 8 -W 12 -d fp16 -permute 0,2,3,1 --cpu-validation