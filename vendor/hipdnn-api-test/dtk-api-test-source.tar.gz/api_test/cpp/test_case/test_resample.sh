# ============================================================================
# 插值测试 (NEAREST & BILINEAR, 仅 4D, 仅 fp16)
# ============================================================================

# ---------- NEAREST 扩展 ----------
test_resample -n 2 -c 3 -h 16 -w 16 -scale_h 2 -scale_w 1 -m 0 -r 0 -t 0 -d fp16 -L nchw
test_resample -n 2 -c 3 -h 16 -w 16 -scale_h 1 -scale_w 2 -m 0 -r 1 -t 1 -d fp16 -L nhwc
test_resample -n 1 -c 1 -h 8 -w 8 -scale_h 3 -scale_w 3 -m 0 -r 2 -t 2 -d fp16 -L nchw
test_resample -n 1 -c 3 -h 64 -w 64 -scale_h 1 -scale_w 1 -m 0 -r 3 -t 3 -d fp16 -L nhwc
test_resample -n 1 -c 3 -h 32 -w 32 -scale_h 2 -scale_w 2 -m 0 -r 0 -t 4 -d fp16 -L nchw
test_resample -n 1 -c 3 -h 32 -w 32 -scale_h 2 -scale_w 2 -m 0 -r 2 -t 1 -d fp16 -L nhwc
test_resample -n 1 -c 3 -h 32 -w 32 -scale_h 2 -scale_w 2 -m 0 -r 3 -t 0 -d fp16 -L nchw
test_resample -n 1 -c 3 -h 32 -w 32 -scale_h 2 -scale_w 2 -m 0 -r 0 -t 0 -d int8 -L nchw
test_resample -n 1 -c 3 -h 32 -w 32 -scale_h 2 -scale_w 2 -m 0 -r 0 -t 0 -d int8 -L nchw
test_resample -n 1 -c 3 -h 32 -w 32 -scale_h 2 -scale_w 2 -m 0 -r 0 -t 0 -d int8 -L nchw

# ---------- BILINEAR ----------
test_resample -n 2 -c 16 -h 16 -w 16 -scale_h 2 -scale_w 1 -m 1 -t 0 -d fp16 -L nchw
test_resample -n 2 -c 16 -h 16 -w 16 -scale_h 1 -scale_w 2 -m 1 -t 1 -d fp16 -L nhwc
test_resample -n 1 -c 1 -h 8 -w 8 -scale_h 3 -scale_w 3 -m 1 -t 2 -d fp16 -L nchw
test_resample -n 1 -c 3 -h 64 -w 64 -scale_h 1 -scale_w 1 -m 1 -t 3 -d fp16 -L nhwc
test_resample -n 1 -c 3 -h 32 -w 32 -scale_h 2 -scale_w 2 -m 1 -t 4 -d fp16 -L nchw

# ============================================================================
# 池化测试 (MAXPOOL, AVGPOOL_EXCLUDE, AVGPOOL_INCLUDE)
# ============================================================================

# ---------- MAXPOOL ----------
test_resample -n 1 -c 3 -h 32 -w 32 -m 2 -d fp32 -L nchw -window 1,1 -stride 1,1 -pre_pad 0,0 -post_pad 0,0 -pad_mode neg_inf_pad
test_resample -n 1 -c 3 -h 32 -w 32 -m 2 -d fp16 -L nhwc -window 2,3 -stride 1,1 -pre_pad 0,0 -post_pad 0,0 -pad_mode neg_inf_pad
test_resample -n 1 -c 3 -h 32 -w 32 -m 2 -d fp32 -L nchw -window 3,3 -stride 2,2 -pre_pad 1,1 -post_pad 1,1 -pad_mode neg_inf_pad
test_resample -n 1 -c 3 -depth 16 -h 32 -w 32 -m 2 -d fp16 -L ncdhw -window 2,2,2 -stride 1,2,1 -pre_pad 0,0,0 -post_pad 0,0,0 -pad_mode neg_inf_pad
test_resample -n 2 -c 16 -depth 8 -h 16 -w 16 -m 2 -d fp32 -L ndhwc -window 1,3,3 -stride 1,2,2 -pre_pad 0,1,1 -post_pad 0,1,1 -pad_mode neg_inf_pad

# ---------- AVGPOOL_EXCLUDE ----------
test_resample -n 1 -c 3 -h 32 -w 32 -m 3 -d fp32 -L nhwc -window 1,1 -stride 1,1 -pre_pad 0,0 -post_pad 0,0 -pad_mode zero_pad
test_resample -n 1 -c 3 -h 32 -w 32 -m 3 -d fp16 -L nchw -window 2,3 -stride 2,1 -pre_pad 0,0 -post_pad 0,0 -pad_mode neg_inf_pad
test_resample -n 1 -c 3 -h 32 -w 32 -m 3 -d fp32 -L nhwc -window 3,3 -stride 2,2 -pre_pad 1,1 -post_pad 1,1 -pad_mode zero_pad
test_resample -n 1 -c 3 -depth 8 -h 16 -w 16 -m 3 -d fp16 -L ncdhw -window 2,2,2 -stride 1,2,2 -pre_pad 0,0,0 -post_pad 0,0,0 -pad_mode neg_inf_pad
test_resample -n 2 -c 8 -depth 4 -h 32 -w 32 -m 3 -d fp32 -L ndhwc -window 1,3,3 -stride 1,1,1 -pre_pad 0,1,1 -post_pad 0,1,1 -pad_mode zero_pad

# ---------- AVGPOOL_INCLUDE ----------
test_resample -n 1 -c 3 -h 32 -w 32 -m 4 -d fp32 -L nchw -window 1,1 -stride 1,1 -pre_pad 0,0 -post_pad 0,0 -pad_mode zero_pad
test_resample -n 1 -c 3 -h 32 -w 32 -m 4 -d fp16 -L nhwc -window 2,3 -stride 1,2 -pre_pad 0,0 -post_pad 0,0 -pad_mode zero_pad
test_resample -n 1 -c 3 -h 32 -w 32 -m 4 -d fp32 -L nchw -window 3,3 -stride 2,2 -pre_pad 1,1 -post_pad 1,1 -pad_mode zero_pad
test_resample -n 1 -c 3 -depth 16 -h 32 -w 32 -m 4 -d fp16 -L ncdhw -window 2,2,2 -stride 2,2,2 -pre_pad 1,1,1 -post_pad 1,1,1 -pad_mode zero_pad
test_resample -n 2 -c 16 -depth 8 -h 16 -w 16 -m 4 -d fp32 -L ndhwc -window 1,2,2 -stride 1,2,2 -pre_pad 0,0,0 -post_pad 0,0,0 -pad_mode zero_pad