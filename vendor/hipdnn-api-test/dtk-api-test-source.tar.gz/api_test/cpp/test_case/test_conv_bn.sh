test_conv_bn -d fp32 -n 8 -c 64 -H 56 -W 56 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 --cpu-validation
test_conv_bn -d fp32 -n 8 -c 64 -H 56 -W 56 -k 256 -y 1 -x 1 -p 0 -q 0 -u 1 -v 1 -l 1 -j 1 -g 1 --cpu-validation
test_conv_bn -d fp32 -m cs -n 10 -c 64 -H 56 -W 56 -k 64 -y 1 -x 1 -p 0 -q 0 -u 1 -v 1 -l 1 -j 1 -g 1 --cpu-validation
test_conv_bn_bwd -d fp32 -n 8 -c 32 -H 56 -W 56 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 --cpu-validation
test_conv_bn_bwd -d fp32 -n 8 -c 64 -H 56 -W 56 -k 256 -y 1 -x 1 -p 0 -q 0 -u 1 -v 1 -l 1 -j 1 -g 1 --cpu-validation
test_conv_bn_bwd -d fp32 -n 8 -c 64 -H 56 -W 27 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 --cpu-validation
test_sbr_convwrw -d fp32 -n 8 -c 64 -H 56 -W 56 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 --cpu-validation
test_sbr_convwrw -d fp32 -n 8 -c 64 -H 56 -W 56 -k 256 -y 1 -x 1 -p 0 -q 0 -u 1 -v 1 -l 1 -j 1 -g 1 --cpu-validation
test_sbr_convwrw -d fp32 -n 8 -c 64 -H 56 -W 28 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1 --cpu-validation
test_mul_mul_add_add -d fp32 -n 8 -c 64 -H 56 -W 56 --cpu-validation
test_mul_mul_add_add -d fp32 -n 8 -c 64 -H 16 -W 15 --cpu-validation
test_mul_mul_add_add -d fp32 -n 8 -c 32 -H 16 -W 15 --cpu-validation
test_bn_finalize -d fp32 -n 8 -c 64 -H 56 -W 56 --cpu-validation
test_bn_finalize -d fp32 -n 8 -c 64 -H 16 -W 15 --cpu-validation
test_bn_finalize -d fp32 -n 8 -c 32 -H 16 -W 15 --cpu-validation
test_conv_bn -d fp16 -n 8 -c 64 -H 56 -W 56 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1
test_conv_bn -d fp16 -n 8 -c 64 -H 56 -W 56 -k 256 -y 1 -x 1 -p 0 -q 0 -u 1 -v 1 -l 1 -j 1 -g 1
test_conv_bn_bwd -d fp16 -n 8 -c 32 -H 56 -W 56 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1
test_conv_bn_bwd -d fp16 -n 8 -c 64 -H 56 -W 56 -k 256 -y 1 -x 1 -p 0 -q 0 -u 1 -v 1 -l 1 -j 1 -g 1
test_conv_bn_bwd -d fp16 -n 8 -c 64 -H 56 -W 27 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1
test_sbr_convwrw -d fp16 -n 8 -c 64 -H 56 -W 56 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1
test_sbr_convwrw -d fp16 -n 8 -c 64 -H 56 -W 56 -k 256 -y 1 -x 1 -p 0 -q 0 -u 1 -v 1 -l 1 -j 1 -g 1
test_sbr_convwrw -d fp16 -n 8 -c 64 -H 56 -W 28 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1
test_mul_mul_add_add -d fp16 -n 8 -c 64 -H 56 -W 56
test_mul_mul_add_add -d fp16 -n 8 -c 64 -H 16 -W 15
test_mul_mul_add_add -d fp16 -n 8 -c 32 -H 16 -W 15
test_bn_finalize -d fp16 -n 8 -c 64 -H 56 -W 56
test_bn_finalize -d fp16 -n 8 -c 64 -H 16 -W 15
test_bn_finalize -d fp16 -n 8 -c 32 -H 16 -W 15
test_conv_bn -d bf16 -n 8 -c 64 -H 56 -W 56 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1
test_conv_bn -d bf16 -n 8 -c 64 -H 56 -W 56 -k 256 -y 1 -x 1 -p 0 -q 0 -u 1 -v 1 -l 1 -j 1 -g 1
test_conv_bn -d bf16 -m cs -n 8 -c 64 -H 56 -W 56 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1
test_conv_bn -d bf16 -m cs -n 8 -c 64 -H 56 -W 56 -k 256 -y 1 -x 1 -p 0 -q 0 -u 1 -v 1 -l 1 -j 1 -g 1
test_conv_bn_bwd -d bf16 -n 8 -c 32 -H 56 -W 56 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1
test_conv_bn_bwd -d bf16 -n 8 -c 64 -H 56 -W 56 -k 256 -y 1 -x 1 -p 0 -q 0 -u 1 -v 1 -l 1 -j 1 -g 1
test_conv_bn_bwd -d bf16 -n 8 -c 64 -H 56 -W 27 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1
test_sbr_convwrw -d bf16 -n 8 -c 64 -H 56 -W 56 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1
test_sbr_convwrw -d bf16 -n 8 -c 64 -H 56 -W 56 -k 256 -y 1 -x 1 -p 0 -q 0 -u 1 -v 1 -l 1 -j 1 -g 1
test_sbr_convwrw -d bf16 -n 8 -c 64 -H 56 -W 28 -k 64 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -g 1
test_mul_mul_add_add -d bf16 -n 8 -c 64 -H 56 -W 56
test_mul_mul_add_add -d bf16 -n 8 -c 64 -H 16 -W 15
test_mul_mul_add_add -d bf16 -n 8 -c 32 -H 16 -W 15
test_bn_finalize -d bf16 -n 8 -c 64 -H 56 -W 56
test_bn_finalize -d bf16 -n 8 -c 64 -H 16 -W 15
test_bn_finalize -d bf16 -n 8 -c 32 -H 16 -W 15