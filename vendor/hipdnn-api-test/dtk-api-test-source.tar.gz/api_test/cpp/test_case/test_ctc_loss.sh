test_ctcloss -k 700 -n 4 -c 10 -d fp16 --cpu-validation
test_ctcloss -k 700 -n 4 -c 10 -d fp32 --cpu-validation
