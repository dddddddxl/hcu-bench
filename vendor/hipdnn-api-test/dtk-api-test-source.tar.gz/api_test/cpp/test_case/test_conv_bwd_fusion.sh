# ==================== 无激活模式 ====================
# conv + bias
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# conv + bias + add
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_add -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# ==================== 模式: conv + bias + activation ====================
# ReLU
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# PReLU
test_conv_bwd_fusion --op-mode conv_bwd_bias_act --activation prelu --relu-alpha 0.25 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# LeakyReLU
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act --activation leakyrelu --relu-alpha 0.2 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# ClippedReLU
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act --activation clippedrelu --relu-alpha 6.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Swish
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act --activation swish -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Sigmoid
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act --activation sigmoid -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Elu
test_conv_bwd_fusion --op-mode conv_bwd_bias_act --activation elu --relu-alpha 1.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Tanh
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act --activation tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Gelu
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act --activation gelu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# GeluApproxTanh
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act --activation gelu_approx_tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# ==================== 模式: conv + bias + activation + add ====================
# ReLU
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act_add --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# PReLU
test_conv_bwd_fusion --op-mode conv_bwd_bias_act_add --activation prelu --relu-alpha 0.25 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# LeakyReLU
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act_add --activation leakyrelu --relu-alpha 0.2 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# ClippedReLU
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act_add --activation clippedrelu --relu-alpha 6.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Swish
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act_add --activation swish -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Sigmoid
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act_add --activation sigmoid -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Elu
test_conv_bwd_fusion --op-mode conv_bwd_bias_act_add --activation elu --relu-alpha 1.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Tanh
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act_add --activation tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Gelu
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act_add --activation gelu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# GeluApproxTanh
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_act_add --activation gelu_approx_tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# ==================== 模式: conv + bias + add + activation ====================
# ReLU
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_add_act --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# PReLU
test_conv_bwd_fusion --op-mode conv_bwd_bias_add_act --activation prelu --relu-alpha 0.25 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# LeakyReLU
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_add_act --activation leakyrelu --relu-alpha 0.2 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# ClippedReLU
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_add_act --activation clippedrelu --relu-alpha 6.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Swish
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_add_act --activation swish -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Sigmoid
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_add_act --activation sigmoid -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Elu
test_conv_bwd_fusion --op-mode conv_bwd_bias_add_act --activation elu --relu-alpha 1.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Tanh
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_add_act --activation tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# Gelu
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_add_act --activation gelu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# GeluApproxTanh
test_conv_bwd_fusion --cpu-validation --op-mode conv_bwd_bias_add_act --activation gelu_approx_tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16