#前向
test_softmarginloss_fwd -n 16 -c 10 -H 16 -W 32 -d fp16 --cpu-validation
test_softmarginloss_fwd -n 16 -c 10 -H 16 -W 32 -d fp32 --cpu-validation

#反向
test_softmarginloss_bwd -n 16 -c 10 -H 16 -W 32 -d fp16 --cpu-validation
test_softmarginloss_bwd -n 16 -c 10 -H 16 -W 32 -d fp32 --cpu-validation
