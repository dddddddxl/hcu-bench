test_cumsum -n 2 -c 3 -H 4 -W 4 -axis 2 --cpu-validation -d fp32
test_cumsum -n 2 -c 3 -H 4 -W 4 -axis 2 --cpu-validation -d fp16
test_cumsum -n 2 -c 3 -H 4 -W 4 -axis 2 --cpu-validation -d bfp16
test_cumsum -n 16 -c 32 -H 4 -W 4 -axis 2 --cpu-validation -d fp32
test_cumsum -n 16 -c 32 -H 4 -W 4 -axis 2 --cpu-validation -d fp16
test_cumsum -n 16 -c 32 -H 4 -W 4 -axis 2 --cpu-validation -d bfp16
