test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m add
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m sub
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m mul
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m div
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m max
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m min
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m pow
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m cmp_eq
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m cmp_ge
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m cmp_gt
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m cmp_le
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m cmp_lt
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m cmp_neq
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m add_square
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m logical_and
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC -m logical_or
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m add
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m sub
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m mul
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m div
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m max
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m min
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m pow
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m cmp_eq
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m cmp_ge
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m cmp_gt
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m cmp_le
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m cmp_lt
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m cmp_neq
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m add_square
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m logical_and
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC -m logical_or
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m add
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m sub
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m mul
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m div
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m max
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m min
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m pow
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m cmp_eq
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m cmp_ge
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m cmp_gt
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m cmp_le
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m cmp_lt
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m cmp_neq
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m add_square
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m logical_and
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp32 -L NHWC --broadcast -m logical_or
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m add
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m sub
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m mul
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m div
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m max
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m min
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m pow
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m cmp_eq
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m cmp_ge
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m cmp_gt
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m cmp_le
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m cmp_lt
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m cmp_neq
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m add_square
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m logical_and
test_pointwise -n 1 -c 3 -H 108 -W 192 -d fp16 -L NHWC --broadcast -m logical_or