test_bn_training -n 16 -c 16 -H 16 -W 16 -m 1 -d fp16  -L NCHW --cpu-validation
test_bn_training -n 16 -c 16 -H 16 -W 16 -m 1 -d fp16  -L NHWC --cpu-validation
test_bn_training -n 1 -c 32 -H 16 -W 16 -m 0 -d fp32  -L NCHW --cpu-validation
test_bn_training -n 1 -c 32 -H 16 -W 16 -m 1 -d fp16  -L NCHW --cpu-validation
test_bn_training -n 1 -c 32 -H 16 -W 16 -m 0 -d fp32  -L NHWC --cpu-validation
test_bn_training -n 1 -c 32 -H 16 -W 16 -m 1 -d fp16  -L NHWC --cpu-validation
