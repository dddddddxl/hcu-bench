# fp16
test_softmax -a 1 -m 0 -n 16 -c 256 -H 16 -W 16 -F 1 -d fp16 --cpu-validation
test_softmax -a 1 -m 0 -n 16 -c 512 -H 16 -W 16 -F 1 -d fp16 --cpu-validation
test_softmax -a 1 -m 0 -n 16 -c 256 -H 40 -W 40 -F 1 -d fp16 --cpu-validation
test_softmax -a 1 -m 0 -n 16 -c 512 -H 20 -W 20 -F 1 -d fp16 --cpu-validation
test_softmax -a 2 -m 1 -n 512 -c 2 -H 1 -W 1 -F 2 -d fp16 --cpu-validation
test_softmax -a 2 -m 1 -n 512 -c 10 -H 1 -W 1 -F 2 -d fp16 --cpu-validation
test_softmax -a 2 -m 1 -n 512 -c 20 -H 1 -W 1 -F 2 -d fp16 --cpu-validation
# fp32
test_softmax -a 1 -m 0 -n 16 -c 256 -H 16 -W 16 -F 1 -d fp32 --cpu-validation
test_softmax -a 1 -m 0 -n 16 -c 512 -H 16 -W 16 -F 1 -d fp32 --cpu-validation
test_softmax -a 1 -m 0 -n 16 -c 256 -H 40 -W 40 -F 1 -d fp32 --cpu-validation
test_softmax -a 1 -m 0 -n 16 -c 512 -H 20 -W 20 -F 1 -d fp32 --cpu-validation
test_softmax -a 2 -m 1 -n 512 -c 2 -H 1 -W 1 -F 2 -d fp32 --cpu-validation
test_softmax -a 2 -m 1 -n 512 -c 10 -H 1 -W 1 -F 2 -d fp32 --cpu-validation
test_softmax -a 2 -m 1 -n 512 -c 20 -H 1 -W 1 -F 2 -d fp32 --cpu-validation