# ==================== 融合模式：concat_conv（无bias，无激活，无加法） ====================
test_cat_conv --op-mode concat_conv -L NHWC --cpu-validation

# ==================== 融合模式：concat_conv_bias（有bias，无激活，无加法） ====================
test_cat_conv --op-mode concat_conv_bias -L NHWC --cpu-validation

# ==================== 融合模式：concat_conv_bias_add（有bias，无激活，有加法） ====================
test_cat_conv --op-mode concat_conv_bias_add -L NHWC --cpu-validation

# ==================== 融合模式：concat_conv_bias_act（有bias，有激活，无加法） ====================
# ReLU
test_cat_conv --op-mode concat_conv_bias_act --activation relu -L NHWC --cpu-validation

# PReLU
test_cat_conv --op-mode concat_conv_bias_act --activation prelu --relu-alpha 0.25 -L NHWC

# LeakyReLU
test_cat_conv --op-mode concat_conv_bias_act --activation leakyrelu --relu-alpha 0.2 -L NHWC --cpu-validation

# ClippedReLU
test_cat_conv --op-mode concat_conv_bias_act --activation clippedrelu --relu-alpha 6.0 -L NHWC --cpu-validation

# Swish
test_cat_conv --op-mode concat_conv_bias_act --activation swish -L NHWC --cpu-validation

# Sigmoid
test_cat_conv --op-mode concat_conv_bias_act --activation sigmoid -L NHWC --cpu-validation

# ELU
test_cat_conv --op-mode concat_conv_bias_act --activation elu --relu-alpha 1.0 -L NHWC

# Tanh
test_cat_conv --op-mode concat_conv_bias_act --activation tanh -L NHWC --cpu-validation

# GELU
test_cat_conv --op-mode concat_conv_bias_act --activation gelu -L NHWC --cpu-validation

# GELU Approx Tanh
test_cat_conv --op-mode concat_conv_bias_act --activation gelu_approx_tanh -L NHWC --cpu-validation

# ==================== 融合模式：concat_conv_bias_act_add（有bias，有激活，有加法） ====================
# ReLU
test_cat_conv --op-mode concat_conv_bias_act_add --activation relu -L NHWC --cpu-validation

# PReLU
test_cat_conv --op-mode concat_conv_bias_act_add --activation prelu --relu-alpha 0.25 -L NHWC

# LeakyReLU
test_cat_conv --op-mode concat_conv_bias_act_add --activation leakyrelu --relu-alpha 0.2 -L NHWC --cpu-validation

# ClippedReLU
test_cat_conv --op-mode concat_conv_bias_act_add --activation clippedrelu --relu-alpha 6.0 -L NHWC --cpu-validation

# Swish
test_cat_conv --op-mode concat_conv_bias_act_add --activation swish -L NHWC --cpu-validation

# Sigmoid
test_cat_conv --op-mode concat_conv_bias_act_add --activation sigmoid -L NHWC --cpu-validation

# ELU
test_cat_conv --op-mode concat_conv_bias_act_add --activation elu --relu-alpha 1.0 -L NHWC

# Tanh
test_cat_conv --op-mode concat_conv_bias_act_add --activation tanh -L NHWC --cpu-validation

# GELU
test_cat_conv --op-mode concat_conv_bias_act_add --activation gelu -L NHWC --cpu-validation

# GELU Approx Tanh
test_cat_conv --op-mode concat_conv_bias_act_add --activation gelu_approx_tanh -L NHWC --cpu-validation

# ==================== 融合模式：concat_conv_bias_act_add（有bias，有激活，有加法） int8====================
# ReLU
test_concat_fusion_int8 --op-mode concat_conv_bias_add_act --activation relu -L NHWC

# PReLU
test_concat_fusion_int8 --op-mode concat_conv_bias_add_act --activation prelu --relu-alpha 0.25 -L NHWC

# LeakyReLU
test_concat_fusion_int8 --op-mode concat_conv_bias_add_act --activation leakyrelu --relu-alpha 0.2 -L NHWC

# ClippedReLU
test_concat_fusion_int8 --op-mode concat_conv_bias_add_act --activation clippedrelu --relu-alpha 6.0 -L NHWC

# Swish
test_concat_fusion_int8 --op-mode concat_conv_bias_add_act --activation swish -L NHWC 

# Sigmoid
test_concat_fusion_int8 --op-mode concat_conv_bias_add_act --activation sigmoid -L NHWC

# ELU
test_concat_fusion_int8 --op-mode concat_conv_bias_add_act --activation elu --relu-alpha 1.0 -L NHWC

# Tanh
test_concat_fusion_int8 --op-mode concat_conv_bias_add_act --activation tanh -L NHWC

# GELU
test_concat_fusion_int8 --op-mode concat_conv_bias_add_act --activation gelu -L NHWC 

# GELU Approx Tanh
test_concat_fusion_int8 --op-mode concat_conv_bias_add_act --activation gelu_approx_tanh -L NHWC