# fp16
# ========== conv_bias ==========
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias -n 2 -c 64 -H 64 -W 64 -k 64 -y 3 -x 3 -p 1 -q 1 -u 2 -v 2 -l 1 -j 1 -L NHWC -d fp16

# ========== conv_bias_add ==========
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_add -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# ========== conv_bias_act ==========
# ReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# PReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation prelu --relu-alpha 0.25 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# LeakyReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation leakyrelu --relu-alpha 0.2 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# ClippedReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation clippedrelu --relu-alpha 6.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Swish
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation swish -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Sigmoid
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation sigmoid -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Elu
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation elu --relu-alpha 1.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Tanh
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Gelu
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation gelu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# GeluApproxTanh
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation gelu_approx_tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# ========== conv_bias_act_add ==========
# ReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# PReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation prelu --relu-alpha 0.25 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# LeakyReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation leakyrelu --relu-alpha 0.2 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# ClippedReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation clippedrelu --relu-alpha 6.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Swish
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation swish -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Sigmoid
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation sigmoid -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Elu
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation elu --relu-alpha 1.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Tanh
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Gelu
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation gelu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# GeluApproxTanh
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation gelu_approx_tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# ========== conv_bias_add_act ==========
# ReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_add_act --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# ========== int8 ==========
# ========== conv_bias ==========
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias -n 2 -c 64 -H 64 -W 64 -k 64 -y 3 -x 3 -p 1 -q 1 -u 2 -v 2 -l 1 -j 1 -L NHWC -d int8

# ========== conv_bias_add ==========
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_add -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8

# ========== conv_bias_act ==========
# ReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# PReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation prelu --relu-alpha 0.25 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# LeakyReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation leakyrelu --relu-alpha 0.2 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# ClippedReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation clippedrelu --relu-alpha 6.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# Swish
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation swish -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# Sigmoid
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation sigmoid -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# Elu
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation elu --relu-alpha 1.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# Tanh
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# Gelu
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation gelu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# GeluApproxTanh
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation gelu_approx_tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8

# ========== conv_bias_act_add ==========
# ReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# PReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation prelu --relu-alpha 0.25 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# LeakyReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation leakyrelu --relu-alpha 0.2 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# ClippedReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation clippedrelu --relu-alpha 6.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# Swish
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation swish -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# Sigmoid
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation sigmoid -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# Elu
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation elu --relu-alpha 1.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# Tanh
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# Gelu
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation gelu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8
# GeluApproxTanh
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation gelu_approx_tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8

# ========== conv_bias_add_act ==========
# ReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_add_act --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d int8

# ========== int8 nchwc32 ==========
# ========== conv_bias ==========
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias -n 2 -c 64 -H 64 -W 64 -k 64 -y 3 -x 3 -p 1 -q 1 -u 2 -v 2 -l 1 -j 1 -L NCHWC32 -d int8

# ========== conv_bias_add ==========
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_add -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8

# ========== conv_bias_act ==========
# ReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# PReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation prelu --relu-alpha 0.25 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# LeakyReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation leakyrelu --relu-alpha 0.2 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# ClippedReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation clippedrelu --relu-alpha 6.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# Swish
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation swish -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# Sigmoid
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation sigmoid -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# Elu
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation elu --relu-alpha 1.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# Tanh
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# Gelu
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation gelu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# GeluApproxTanh
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation gelu_approx_tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8

# ========== conv_bias_act_add ==========
# ReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# PReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation prelu --relu-alpha 0.25 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# LeakyReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation leakyrelu --relu-alpha 0.2 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# ClippedReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation clippedrelu --relu-alpha 6.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# Swish
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation swish -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# Sigmoid
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation sigmoid -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# Elu
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation elu --relu-alpha 1.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# Tanh
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# Gelu
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation gelu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8
# GeluApproxTanh
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act_add --activation gelu_approx_tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8

# ========== conv_bias_add_act ==========
# ReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_add_act --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d int8

# NCHW-NCHW-NCHWc32
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation relu -n 1 -c 3 -H 736 -W 1280 -k 64 -y 7 -x 7 -p 3 -q 3 -u 2 -v 2 -l 1 -j 1 -L NCHW -d int8 --output-layout NCHWC32
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation relu -n 1 -c 3 -H 736 -W 1280 -k 64 -y 7 -x 7 -p 3 -q 3 -u 2 -v 2 -l 1 -j 1 -L NCHW -d fp16 --output-layout NCHWC32

# fp16 nchwc32
# ========== conv_bias ==========
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias -n 2 -c 64 -H 64 -W 64 -k 64 -y 3 -x 3 -p 1 -q 1 -u 2 -v 2 -l 1 -j 1 -L NCHWC32 -d fp16

# ========== conv_bias_add ==========
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_add -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d fp16

# ========== conv_bias_act ==========
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d fp16
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_add_act --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC32 -d fp16

# fp16 nchwc16
# ========== conv_bias ==========
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 2 -v 2 -l 1 -j 1 -L NCHWC16 -d fp16

# ========== conv_bias_add ==========
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_add -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC16 -d fp16

# ========== conv_bias_act ==========
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 -p 1 -q 1 -u 1 -v 1 -l 1 -j 1 -L NCHWC16 -d fp16

#asy
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias -n 2 -c 128 -H 64 -W 32 -k 128 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias -n 3 -c 1 -H 16 -W 16 -k 1 -y 4 -x 4 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias -n 3 -c 1 -H 32 -W 32 -k 1 -y 4 -x 4 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias -n 3 -c 1 -H 64 -W 64 -k 1 -y 4 -x 4 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# ========== conv_bias_act ==========
# ReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# PReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation prelu --relu-alpha 0.25 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# LeakyReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation leakyrelu --relu-alpha 0.2 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# ClippedReLU
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation clippedrelu --relu-alpha 6.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Swish
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation swish -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Sigmoid
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation sigmoid -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Elu
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation elu --relu-alpha 1.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Tanh
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# Gelu
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation gelu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16
# GeluApproxTanh
test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation gelu_approx_tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 1 -v 1 -l 1 -j 1 -L NHWC -d fp16

# # ========== int8 ==========
# # ========== conv_bias ==========
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias -n 2 -c 128 -H 64 -W 32 -k 128 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NHWC -d int8

# # ========== conv_bias_add ==========
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_add -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NHWC -d int8

# # ========== conv_bias_act ==========
# # ReLU
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation relu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NHWC -d int8
# # PReLU
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation prelu --relu-alpha 0.25 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NHWC -d int8
# # LeakyReLU
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation leakyrelu --relu-alpha 0.2 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NHWC -d int8
# # ClippedReLU
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation clippedrelu --relu-alpha 6.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NHWC -d int8
# # Swish
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation swish -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NHWC -d int8
# # Sigmoid
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation sigmoid -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NHWC -d int8
# # Elu
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation elu --relu-alpha 1.0 -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NHWC -d int8
# # Tanh
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NHWC -d int8
# # Gelu
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation gelu -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NHWC -d int8
# # GeluApproxTanh
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias_act --activation gelu_approx_tanh -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NHWC -d int8

# # ========== int8 nchwc32 ==========
# # ========== conv_bias ==========
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias -n 2 -c 128 -H 64 -W 32 -k 128 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NCHWC32 -d int8

# # fp16 nchwc32
# # ========== conv_bias ==========
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias -n 2 -c 128 -H 64 -W 32 -k 128 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NCHWC32 -d fp16
# # fp16 nchwc16
# # ========== conv_bias ==========
# test_conv_fwd_fusion --cpu-validation --op-mode conv_bias -n 2 -c 128 -H 64 -W 32 -k 128 -y 3 -x 3 --pre-pad-h 2 --post-pad-h 1 --pre-pad-w 2 --post-pad-w 1 -u 2 -v 2 -l 1 -j 1 -L NCHWC16 -d fp16