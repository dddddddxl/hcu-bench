test_gather_elements -d fp32
test_gather_elements --dim0 2 --dim1 5 --axis 1 --indices "0,2,4 1,3,0" -d fp32 --cpu-validation
test_gather_elements --dim0 4 --dim1 6 --axis 0 --indices "0,1,2;1,2,3;2,3,0;3,0,1" -d fp32 --cpu-validation
test_gather_elements --dim0 3 --dim1 4 --axis 1 --indices "0,2 1,3 2,0" -d fp32 --cpu-validation
test_gather_elements --dim0 2 --dim1 8 --axis 1 --indices "0,2,4,6,7 1,3,5,0,2" -d fp32 --cpu-validation
test_gather_elements --dim0 2 --dim1 5 --axis 1 --indices "0,2,4 1,3,0" -d fp16 --cpu-validation
test_gather_elements --dim0 3 --dim1 6 --axis 1 --indices "0,2,4 1,3,5 2,4,0" -d bfp16 --cpu-validation
test_gather_elements --dim0 256 --dim1 1024 --axis 1 --indices "0,100,200,300,400 500,600,700,800,900" -d fp32 --cpu-validation
test_gather_elements --dim0 128 --dim1 512 --axis 0 --indices "0,10,20,30 40,50,60,70 80,90,100,110" -d fp16 --cpu-validation
test_gather_elements --dim0 2 --dim1 4 --axis 1 --indices "0,2,2,0 1,3,1,3" -d fp32 --cpu-validation