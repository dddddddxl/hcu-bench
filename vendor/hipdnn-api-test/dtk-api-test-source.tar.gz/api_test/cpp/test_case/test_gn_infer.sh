test_gn_infer -n 1 -c 16 -H 224 -W 224 -g 4 -d fp32 -L NCHW --cpu-validation
test_gn_infer -n 1 -c 16 -H 224 -W 224 -g 4 -d fp32 -L NHWC --cpu-validation
test_gn_infer -n 1 -c 16 -H 224 -W 224 -g 4 -d fp16 -L NCHW --cpu-validation
test_gn_infer -n 1 -c 16 -H 224 -W 224 -g 4 -d fp16 -L NHWC --cpu-validation
test_gn_infer -n 3 -c 8 -H 512 -W 512 -g 2 -d fp16 -L NHWC --cpu-validation
test_gn_infer -n 12 -c 16 -H 128 -W 128 -g 8 -d fp32 -L NCHW --cpu-validation