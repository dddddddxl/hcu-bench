test_sdpa_infer -n 2 --headDimQ 20 --headDimK 20 --headDimV 20 --seqLenQ 16 --seqLenKV 16 --dQK 64 --dV 64 --layout BHSD --dataType fp16 --cpu-validation
test_sdpa_infer -n 2 --headDimQ 10 --headDimK 10 --headDimV 10 --seqLenQ 33 --seqLenKV 33 --dQK 64 --dV 64 --layout BHSD --dataType fp16 --cpu-validation
test_sdpa_infer -n 2 --headDimQ 10 --headDimK 10 --headDimV 10 --seqLenQ 128 --seqLenKV 128 --dQK 64 --dV 64 --layout BHSD --dataType fp16 --cpu-validation
test_sdpa_infer -n 2 --headDimQ 20 --headDimK 20 --headDimV 20 --seqLenQ 128 --seqLenKV 128 --dQK 64 --dV 64 --layout BHSD --dataType fp16 --cpu-validation
test_sdpa_infer -n 4 --headDimQ 20 --headDimK 20 --headDimV 20 --seqLenQ 16 --seqLenKV 16 --dQK 64 --dV 64 --layout BHSD --dataType fp16 --cpu-validation
test_sdpa_infer -n 4 --headDimQ 10 --headDimK 10 --headDimV 10 --seqLenQ 33 --seqLenKV 33 --dQK 64 --dV 64 --layout BHSD --dataType fp16 --cpu-validation
test_sdpa_infer -n 4 --headDimQ 10 --headDimK 10 --headDimV 10 --seqLenQ 128 --seqLenKV 128 --dQK 64 --dV 64 --layout BHSD --dataType fp16 --cpu-validation
test_sdpa_infer -n 4 --headDimQ 20 --headDimK 20 --headDimV 20 --seqLenQ 128 --seqLenKV 128 --dQK 64 --dV 64 --layout BHSD --dataType fp16 --cpu-validation

test_sdpa_infer -n 2 --headDimQ 20 --headDimK 20 --headDimV 20 --seqLenQ 16 --seqLenKV 16 --dQK 64 --dV 64 --layout BHSD --dataType bf16 --cpu-validation
test_sdpa_infer -n 2 --headDimQ 10 --headDimK 10 --headDimV 10 --seqLenQ 33 --seqLenKV 33 --dQK 64 --dV 64 --layout BHSD --dataType bf16 --cpu-validation
test_sdpa_infer -n 2 --headDimQ 10 --headDimK 10 --headDimV 10 --seqLenQ 128 --seqLenKV 128 --dQK 64 --dV 64 --layout BHSD --dataType bf16 --cpu-validation
test_sdpa_infer -n 2 --headDimQ 20 --headDimK 20 --headDimV 20 --seqLenQ 128 --seqLenKV 128 --dQK 64 --dV 64 --layout BHSD --dataType bf16 --cpu-validation
test_sdpa_infer -n 4 --headDimQ 20 --headDimK 20 --headDimV 20 --seqLenQ 16 --seqLenKV 16 --dQK 64 --dV 64 --layout BHSD --dataType bf16 --cpu-validation
test_sdpa_infer -n 4 --headDimQ 10 --headDimK 10 --headDimV 10 --seqLenQ 33 --seqLenKV 33 --dQK 64 --dV 64 --layout BHSD --dataType bf16 --cpu-validation
test_sdpa_infer -n 4 --headDimQ 10 --headDimK 10 --headDimV 10 --seqLenQ 128 --seqLenKV 128 --dQK 64 --dV 64 --layout BHSD --dataType bf16 --cpu-validation
test_sdpa_infer -n 4 --headDimQ 20 --headDimK 20 --headDimV 20 --seqLenQ 128 --seqLenKV 128 --dQK 64 --dV 64 --layout BHSD --dataType bf16 --cpu-validation
