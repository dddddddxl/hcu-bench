#include <algorithm>
#include <cstring>
#include <iostream>
#include <random>
#include <tuple>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>

#include "../utils.hpp"
#include <hipdnn_test_sdk/utilities/CpuFpReferenceDeformAttention.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// 配置结构体
struct Config
{
    int64_t n = 16;
    int64_t num_heads = 8;
    int64_t num_values = 32;
    int64_t head_dim = 4;
    int64_t num_queries = 9703;
    int64_t num_levels = 128;
    int64_t num_points = 128;
    std::string dataType = "fp32";
    bool cpuValidation = false;
};

// 命令行解析
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.num_heads = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-D") == 0 && i + 1 < argc)
        {
            config.head_dim = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.num_levels = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-p") == 0 && i + 1 < argc)
        {
            config.num_points = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc)
        {
            config.num_queries = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-V") == 0 && i + 1 < argc)
        {
            config.num_values = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }

    return config;
}

// 定义 ShapeIndexType
using ShapeIndexType = int64_t;

class DaRunner
{
private:
    Config config_;

public:
    DaRunner(const Config& config)
        : config_(config) {};

    template <typename InputType, typename ComputeType>
    void operator()()
    {
        // 生成 spatialShapesData 和 levelStartIndexData
        auto [nKeys, spatialShapesData, levelStartIndexData] = [=]() {
            int64_t nKeysLocal = 0;
            std::vector<ShapeIndexType> spatialShapesLocal(
                static_cast<size_t>(config_.num_levels * 2));
            std::vector<ShapeIndexType> levelStartIndexLocal(
                static_cast<size_t>(config_.num_levels));

            std::random_device rd;
            std::mt19937 gen(rd());
            std::uniform_int_distribution<int64_t> dist(1, 128);

            levelStartIndexLocal[0] = 0;
            for(size_t i = 0; i < static_cast<size_t>(config_.num_levels * 2); i += 2)
            {
                spatialShapesLocal[i] = dist(gen); // height
                spatialShapesLocal[i + 1] = dist(gen); // width

                if(i > 0)
                {
                    levelStartIndexLocal[i / 2] = nKeysLocal;
                }
                nKeysLocal += spatialShapesLocal[i] * spatialShapesLocal[i + 1];
            }

            return std::make_tuple(nKeysLocal, spatialShapesLocal, levelStartIndexLocal);
        }();

        auto buildDeformableAttnFwdGraph = [=](hipdnnHandle_t handle) {
            auto graph = std::make_shared<graph::Graph>();

            graph->set_name("DeformableAttentionForwardGraph")
                .set_io_data_type(getDataTypeEnumFromType<InputType>())
                .set_intermediate_data_type(getDataTypeEnumFromType<ComputeType>())
                .set_compute_data_type(getDataTypeEnumFromType<ComputeType>());

            auto value = std::make_shared<graph::TensorAttributes>(
                graph::Tensor_attributes()
                    .set_name("value")
                    .set_dim({config_.n, config_.num_values, config_.num_heads, config_.head_dim})
                    .set_stride({config_.num_values * config_.num_heads * config_.head_dim,
                                 config_.num_heads * config_.head_dim,
                                 config_.head_dim,
                                 1}));
            auto spatialShapes = std::make_shared<graph::TensorAttributes>(
                graph::Tensor_attributes()
                    .set_name("spatial_shapes")
                    .set_dim({config_.num_levels, 2})
                    .set_stride({2, 1})
                    .set_data_type(getDataTypeEnumFromType<ShapeIndexType>()));
            auto levelStartIndex = std::make_shared<graph::TensorAttributes>(
                graph::Tensor_attributes()
                    .set_name("level_start_index")
                    .set_dim({config_.num_levels})
                    .set_stride({1})
                    .set_data_type(getDataTypeEnumFromType<ShapeIndexType>()));
            auto samplingLocations = std::make_shared<graph::TensorAttributes>(
                graph::Tensor_attributes()
                    .set_name("sampling_locations")
                    .set_dim({config_.n,
                              config_.num_queries,
                              config_.num_heads,
                              config_.num_levels,
                              config_.num_points,
                              2})
                    .set_stride({config_.num_queries * config_.num_heads * config_.num_levels
                                     * config_.num_points * 2,
                                 config_.num_heads * config_.num_levels * config_.num_points * 2,
                                 config_.num_levels * config_.num_points * 2,
                                 config_.num_points * 2,
                                 2,
                                 1}));
            auto attentionWeights = std::make_shared<graph::TensorAttributes>(
                graph::Tensor_attributes()
                    .set_name("attention_weights")
                    .set_dim({config_.n,
                              config_.num_queries,
                              config_.num_heads,
                              config_.num_levels,
                              config_.num_points})
                    .set_stride({config_.num_queries * config_.num_heads * config_.num_levels
                                     * config_.num_points,
                                 config_.num_heads * config_.num_levels * config_.num_points,
                                 config_.num_levels * config_.num_points,
                                 config_.num_points,
                                 1}));

            auto deformAttnAttributes
                = graph::DeformAttnFpropAttributes().set_name("deform_attn_forward_node");
            auto output = graph->deform_attn_fprop(value,
                                                   spatialShapes,
                                                   levelStartIndex,
                                                   samplingLocations,
                                                   attentionWeights,
                                                   deformAttnAttributes);
            output->set_output(true);

            // build graph
            HIPDNN_FE_CHECK(graph->build(handle));

            return std::make_tuple(graph,
                                   value,
                                   spatialShapes,
                                   levelStartIndex,
                                   samplingLocations,
                                   attentionWeights,
                                   output);
        };

        auto backend = hipdnn_frontend::detail::hipdnnBackend();
        if(!backend)
        {
            std::cout << "Create backend failed. \n";
            return;
        }

        hipdnnHandle_t handle;
        HIPDNN_CHECK(backend->create(&handle));

        auto [graph,
              value,
              spatialShapes,
              levelStartIndex,
              samplingLocations,
              attentionWeights,
              output]
            = buildDeformableAttnFwdGraph(handle);

        // Allocate DCU memory
        Tensor<InputType> valueTensor(value->get_dim(), value->get_stride());
        Tensor<ShapeIndexType> spatialShapesTensor(spatialShapes->get_dim(),
                                                   spatialShapes->get_stride());
        Tensor<ShapeIndexType> levelStartIndexTensor(levelStartIndex->get_dim(),
                                                     levelStartIndex->get_stride());
        Tensor<InputType> samplingLocationsTensor(samplingLocations->get_dim(),
                                                  samplingLocations->get_stride());
        Tensor<InputType> attentionWeightsTensor(attentionWeights->get_dim(),
                                                 attentionWeights->get_stride());
        Tensor<InputType> outTensor(output->get_dim(), output->get_stride());

        // Fill tensors with data
        spatialShapesTensor.fillWithData(spatialShapesData.data(),
                                         spatialShapesData.size() * sizeof(ShapeIndexType));
        levelStartIndexTensor.fillWithData(levelStartIndexData.data(),
                                           levelStartIndexData.size() * sizeof(ShapeIndexType));

        // 填充随机数据
        valueTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                         static_cast<InputType>(1.0f));
        samplingLocationsTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                     static_cast<InputType>(1.0f));
        attentionWeightsTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                    static_cast<InputType>(1.0f));
        outTensor.fillWithValue(static_cast<InputType>(0.0f));

        std::unordered_map<int64_t, void*> variantPack;
        variantPack[value->get_uid()] = valueTensor.memory().deviceData();
        variantPack[spatialShapes->get_uid()] = spatialShapesTensor.memory().deviceData();
        variantPack[levelStartIndex->get_uid()] = levelStartIndexTensor.memory().deviceData();
        variantPack[samplingLocations->get_uid()] = samplingLocationsTensor.memory().deviceData();
        variantPack[attentionWeights->get_uid()] = attentionWeightsTensor.memory().deviceData();
        variantPack[output->get_uid()] = outTensor.memory().deviceData();

        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
        outTensor.memory().markDeviceModified();
        // 性能测试
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        // 执行多次以测量平均时间
        const int iterations = 100;
        for(int i = 0; i < iterations; i++)
        {
            HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "Deformable Attention Forward time: " << time / iterations << " ms"
                  << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));
        std::cout << "Deformable_attention_forward graph execution complete. \n";

        // CPU验证
        if(config_.cpuValidation)
        {
            std::cout << "Running CPU reference validation...\n";
            Tensor<InputType> yRefTensor(output->get_dim(), output->get_stride());
            CpuFpReferenceDeformAttention::fprop<InputType,
                                                 ShapeIndexType,
                                                 ShapeIndexType,
                                                 InputType,
                                                 InputType,
                                                 InputType,
                                                 ComputeType>(valueTensor,
                                                              spatialShapesTensor,
                                                              levelStartIndexTensor,
                                                              samplingLocationsTensor,
                                                              attentionWeightsTensor,
                                                              yRefTensor);

            auto tolerance = deform_attn::getToleranceFwd<InputType>();
            auto validator = CpuFpReferenceValidation<InputType>(tolerance, tolerance);
            bool yValid = validator.allClose(yRefTensor, outTensor);
            std::cout << "CPU reference validation:\n";
            std::cout << "  y: " << (yValid ? "successful" : "failed") << "\n";
        }

        HIPDNN_CHECK(backend->destroy(handle));
    }
};

void run(const Config& config)
{
    if(config.dataType == "fp32")
    {
        DaRunner runner(config);
        runner.template operator()<float, float>();
    }
    else if(config.dataType == "fp16")
    {
        DaRunner runner(config);
        runner.template operator()<half, float>();
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    // 打印命令行参数
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    run(config);

    return 0;
}
