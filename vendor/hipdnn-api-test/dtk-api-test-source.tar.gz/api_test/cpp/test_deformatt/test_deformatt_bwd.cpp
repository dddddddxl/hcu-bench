#include <algorithm>
#include <cstring>
#include <iostream>
#include <random>
#include <stdexcept>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <vector>

#include <hip/hip_fp16.h>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>

#include "../utils.hpp"
#include <hipdnn_test_sdk/utilities/CpuFpReferenceDeformAttention.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

struct Config
{
    int64_t n = 6;
    int64_t num_heads = 8;
    int64_t num_values = 32;
    int64_t head_dim = 30825;
    int64_t num_queries = 9512;
    int64_t num_levels = 4;
    int64_t num_points = 8;
    std::string dataType = "fp32";
    bool cpuValidation = false;
};

template <typename DstType, typename SrcType>
Tensor<DstType> convertTensor(const Tensor<SrcType>& src,
                              const std::vector<int64_t>& dim,
                              const std::vector<int64_t>& stride)
{
    // 创建目标类型张量（使用传入的dim和stride）
    Tensor<DstType> dst(dim, stride);

    // 获取源/目标数据的主机指针（hipdnn_data_sdk的Tensor通过memory().hostData()获取数据）
    const SrcType* srcData = static_cast<const SrcType*>(src.memory().hostData());
    DstType* dstData = static_cast<DstType*>(dst.memory().hostData());

    // 计算元素总数
    size_t elemCount = 1;
    for(auto d : dim)
    {
        elemCount *= static_cast<size_t>(d);
    }

    // 逐元素类型转换（处理FP16<->FP32的特殊转换）
    if constexpr(std::is_same_v<SrcType, ::half> && std::is_same_v<DstType, float>)
    {
        for(size_t i = 0; i < elemCount; ++i)
        {
            dstData[i] = __half2float(srcData[i]); // HIP FP16转FP32
        }
    }
    else if constexpr(std::is_same_v<SrcType, float> && std::is_same_v<DstType, ::half>)
    {
        for(size_t i = 0; i < elemCount; ++i)
        {
            dstData[i] = __float2half(srcData[i]); // HIP FP32转FP16
        }
    }
    else
    {
        // 其他类型（如int64_t）直接静态转换
        for(size_t i = 0; i < elemCount; ++i)
        {
            dstData[i] = static_cast<DstType>(srcData[i]);
        }
    }
    dst.memory().markHostModified();
    return dst;
}

Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.num_heads = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-D") == 0 && i + 1 < argc)
        {
            config.head_dim = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.num_levels = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-p") == 0 && i + 1 < argc)
        {
            config.num_points = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc)
        {
            config.num_queries = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-V") == 0 && i + 1 < argc)
        {
            config.num_values = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            std::cerr << "Usage: " << argv[0] << " [-n batch_size] [-H num_heads] [-D head_dim]"
                      << " [-L num_levels] [-p num_points] [-q num_queries] [-V num_values]"
                      << " [-d data_type] [--cpu-validation]" << std::endl;
            exit(1);
        }
    }
    return config;
}

class DaRunner
{
private:
    Config config_;

public:
    DaRunner(const Config& config)
        : config_(config) {};

    template <typename InputType, typename ComputeType>
    void operator()()
    {
        runBprop<InputType, ComputeType>();
    }

private:
    static std::vector<std::pair<int64_t, int64_t>> generate_spatial_shapes(int64_t num_values,
                                                                            int64_t num_levels)
    {
        std::vector<std::pair<int64_t, int64_t>> shapes;

        if(num_levels == 1)
        {
            int64_t sqrt_val = static_cast<int64_t>(std::sqrt(static_cast<double>(num_values)));
            for(int64_t i = sqrt_val; i >= 1; --i)
            {
                if(num_values % i == 0)
                {
                    shapes.emplace_back(i, num_values / i);
                    std::cout << "Generated spatial shape for level 0: (" << i << ", "
                              << num_values / i << ")" << std::endl;
                    return shapes;
                }
            }
            shapes.emplace_back(sqrt_val, sqrt_val);
            std::cout << "Fallback spatial shape for level 0: (" << sqrt_val << ", " << sqrt_val
                      << ")" << std::endl;
            return shapes;
        }

        // 多层级情况
        double geometric_sum = 0.0;
        for(int64_t i = 0; i < num_levels; ++i)
        {
            geometric_sum += 1.0 / std::pow(4.0, i);
        }

        int64_t h_est
            = static_cast<int64_t>(std::sqrt(static_cast<double>(num_values) / geometric_sum));
        h_est = std::max<int64_t>(1, h_est);

        int64_t best_diff = std::numeric_limits<int64_t>::max();
        std::vector<std::pair<int64_t, int64_t>> best_shapes;

        const int64_t search_range = 10;
        for(int64_t h = std::max<int64_t>(1, h_est - search_range); h <= h_est + search_range; ++h)
        {

            std::vector<std::pair<int64_t, int64_t>> candidate;
            int64_t total_pixels = 0;

            for(int64_t level = 0; level < num_levels; ++level)
            {
                int64_t scale_factor = static_cast<int64_t>(1) << level; // 2^level
                int64_t h_level = std::max<int64_t>(1, h / scale_factor);
                int64_t w_level = h_level;

                if(level == num_levels - 1)
                {
                    int64_t remaining_pixels = num_values - total_pixels;
                    if(remaining_pixels > 0)
                    {
                        w_level = std::max<int64_t>(
                            1,
                            static_cast<int64_t>(std::sqrt(static_cast<double>(remaining_pixels))));
                        h_level = std::max<int64_t>(1, remaining_pixels / w_level);

                        while(h_level * w_level < remaining_pixels)
                        {
                            w_level += 1;
                        }
                        while(h_level * w_level > remaining_pixels && w_level > 1)
                        {
                            w_level -= 1;
                        }
                        h_level = remaining_pixels / w_level;
                    }
                }

                candidate.emplace_back(h_level, w_level);
                total_pixels += h_level * w_level;
            }

            int64_t diff = std::llabs(total_pixels - num_values);
            if(diff < best_diff)
            {
                best_diff = diff;
                best_shapes = candidate;
            }
            if(diff == 0)
                break;
        }
        int64_t total_pixels = 0;
        for(const auto& shape : best_shapes)
        {
            total_pixels += shape.first * shape.second;
        }

        if(total_pixels != num_values && !best_shapes.empty())
        {
            auto& last_shape = best_shapes.back();
            int64_t h_last = last_shape.first;
            int64_t w_last = last_shape.second;
            int64_t adjustment = num_values - total_pixels;

            if(adjustment != 0)
            {
                int64_t new_w = w_last + adjustment / h_last;
                if(new_w > 0)
                {
                    w_last = new_w;
                    // 重新计算调整后的总像素数
                    int64_t new_total = 0;
                    for(size_t i = 0; i < best_shapes.size() - 1; ++i)
                    {
                        new_total += best_shapes[i].first * best_shapes[i].second;
                    }
                    new_total += h_last * w_last;
                    int64_t remaining = num_values - new_total;

                    if(remaining != 0)
                    {
                        h_last += (w_last > 0) ? (remaining / w_last) : 0;
                    }
                }
                // 更新最后一层的形状
                last_shape.first = std::max<int64_t>(1, h_last);
                last_shape.second = std::max<int64_t>(1, w_last);
            }
        }

        // 最终校验：确保所有形状都是正整数
        for(auto& shape : best_shapes)
        {
            shape.first = std::max<int64_t>(1, shape.first);
            shape.second = std::max<int64_t>(1, shape.second);
        }

        return best_shapes;
    }

    template <typename InputType, typename ComputeType>
    void runBprop()
    {
        auto buildDeformableAttnBwdGraph = [=](hipdnnHandle_t handle) {
            auto graph = std::make_shared<graph::Graph>();

            DataType inputDataType;
            if constexpr(std::is_same_v<InputType, float>)
            {
                inputDataType = getDataTypeEnumFromType<InputType>();
            }
            else if constexpr(std::is_same_v<InputType, ::half>)
            {
                inputDataType = static_cast<DataType>(HIPDNN_DATA_HALF);
            }
            graph->set_name("DeformableAttentionBackwardGraph")
                .set_io_data_type(inputDataType)
                .set_intermediate_data_type(getDataTypeEnumFromType<ComputeType>())
                .set_compute_data_type(getDataTypeEnumFromType<ComputeType>());

            auto value = std::make_shared<graph::TensorAttributes>(
                graph::Tensor_attributes()
                    .set_name("value")
                    .set_dim({config_.n, config_.num_values, config_.num_heads, config_.head_dim})
                    .set_stride({config_.num_values * config_.num_heads * config_.head_dim,
                                 config_.num_heads * config_.head_dim,
                                 config_.head_dim,
                                 1}));
            auto spatialShapes = std::make_shared<graph::TensorAttributes>(
                graph::Tensor_attributes()
                    .set_name("spatial_shapes")
                    .set_dim({config_.num_levels, 2})
                    .set_stride({2, 1})
                    .set_data_type(getDataTypeEnumFromType<int64_t>()));
            auto levelStartIndex = std::make_shared<graph::TensorAttributes>(
                graph::Tensor_attributes()
                    .set_name("level_start_index")
                    .set_dim({config_.num_levels})
                    .set_stride({1})
                    .set_data_type(getDataTypeEnumFromType<int64_t>()));
            auto samplingLocations = std::make_shared<graph::TensorAttributes>(
                graph::Tensor_attributes()
                    .set_name("sampling_locations")
                    .set_dim({config_.n,
                              config_.num_queries,
                              config_.num_heads,
                              config_.num_levels,
                              config_.num_points,
                              2})
                    .set_stride({config_.num_queries * config_.num_heads * config_.num_levels
                                     * config_.num_points * 2,
                                 config_.num_heads * config_.num_levels * config_.num_points * 2,
                                 config_.num_levels * config_.num_points * 2,
                                 config_.num_points * 2,
                                 2,
                                 1}));
            auto attentionWeights = std::make_shared<graph::TensorAttributes>(
                graph::Tensor_attributes()
                    .set_name("attention_weights")
                    .set_dim({config_.n,
                              config_.num_queries,
                              config_.num_heads,
                              config_.num_levels,
                              config_.num_points})
                    .set_stride({config_.num_queries * config_.num_heads * config_.num_levels
                                     * config_.num_points,
                                 config_.num_heads * config_.num_levels * config_.num_points,
                                 config_.num_levels * config_.num_points,
                                 config_.num_points,
                                 1}));
            auto gradOutput = std::make_shared<graph::TensorAttributes>(
                graph::Tensor_attributes()
                    .set_name("grad_output")
                    .set_dim({config_.n, config_.num_queries, config_.num_heads * config_.head_dim})
                    .set_stride({config_.num_queries * config_.num_heads * config_.head_dim,
                                 config_.num_heads * config_.head_dim,
                                 1}));

            auto deformAttnDgradAttributes
                = graph::DeformAttnDgradAttributes().set_name("deform_attn_backward_node");

            auto [gradValue, gradSamplingLoc, gradAttnWeight]
                = graph->deform_attn_dgrad(value,
                                           spatialShapes,
                                           levelStartIndex,
                                           samplingLocations,
                                           attentionWeights,
                                           gradOutput,
                                           deformAttnDgradAttributes);

            gradValue->set_output(true);
            gradSamplingLoc->set_output(true);
            gradAttnWeight->set_output(true);

            HIPDNN_FE_CHECK(graph->build(handle));

            return std::make_tuple(graph,
                                   value,
                                   spatialShapes,
                                   levelStartIndex,
                                   samplingLocations,
                                   attentionWeights,
                                   gradOutput,
                                   gradValue,
                                   gradSamplingLoc,
                                   gradAttnWeight);
        };

        auto backend = hipdnn_frontend::detail::hipdnnBackend();
        if(!backend)
        {
            std::cout << "Create backend failed." << std::endl;
            return;
        }

        hipdnnHandle_t handle;
        HIPDNN_CHECK(backend->create(&handle));

        auto [graph,
              value,
              spatialShapes,
              levelStartIndex,
              samplingLocations,
              attentionWeights,
              gradOutput,
              gradValue,
              gradSamplingLoc,
              gradAttnWeight]
            = buildDeformableAttnBwdGraph(handle);

        // Allocate tensors
        Tensor<InputType> valueTensor(value->get_dim(), value->get_stride());
        Tensor<int64_t> spatialShapesTensor(spatialShapes->get_dim(), spatialShapes->get_stride());
        Tensor<int64_t> levelStartIndexTensor(levelStartIndex->get_dim(),
                                              levelStartIndex->get_stride());
        Tensor<InputType> samplingLocationsTensor(samplingLocations->get_dim(),
                                                  samplingLocations->get_stride());
        Tensor<InputType> attentionWeightsTensor(attentionWeights->get_dim(),
                                                 attentionWeights->get_stride());
        Tensor<InputType> gradOutputTensor(gradOutput->get_dim(), gradOutput->get_stride());
        Tensor<InputType> gradValueTensor(gradValue->get_dim(), gradValue->get_stride());
        Tensor<InputType> gradSamplingLocTensor(gradSamplingLoc->get_dim(),
                                                gradSamplingLoc->get_stride());
        Tensor<InputType> gradAttnWeightTensor(gradAttnWeight->get_dim(),
                                               gradAttnWeight->get_stride());

        // 生成空间形状
        std::vector<std::pair<int64_t, int64_t>> shapes;
        if(config_.num_values == 30825)
        {
            shapes = {{116, 200}, {58, 100}, {29, 50}, {15, 25}};
        }
        else
        {
            shapes = generate_spatial_shapes(config_.num_values, config_.num_levels);
        }
        std::vector<int64_t> spatialShapesData;
        spatialShapesData.reserve(static_cast<size_t>(config_.num_levels) * 2);
        for(const auto& [h, w] : shapes)
        {
            spatialShapesData.push_back(h);
            spatialShapesData.push_back(w);
        }

        std::vector<int64_t> levelStartIndexData(static_cast<size_t>(config_.num_levels), 0);
        int64_t cumsum = 0;
        for(size_t i = 0; i < static_cast<size_t>(config_.num_levels); ++i)
        {
            levelStartIndexData[i] = cumsum;
            cumsum += shapes[i].first * shapes[i].second;
        }

        spatialShapesTensor.fillWithData(spatialShapesData.data(),
                                         spatialShapesData.size() * sizeof(int64_t));
        levelStartIndexTensor.fillWithData(levelStartIndexData.data(),
                                           levelStartIndexData.size() * sizeof(int64_t));

        // 填充随机数据
        unsigned int seed = 1;
        valueTensor.fillWithRandomValues(
            static_cast<InputType>(-1.0f), static_cast<InputType>(1.0f), seed);
        samplingLocationsTensor.fillWithRandomValues(
            static_cast<InputType>(-1.0f), static_cast<InputType>(1.0f), seed);
        attentionWeightsTensor.fillWithRandomValues(
            static_cast<InputType>(-1.0f), static_cast<InputType>(1.0f), seed);
        gradOutputTensor.fillWithRandomValues(
            static_cast<InputType>(-1.0f), static_cast<InputType>(1.0f), seed);

        // 初始化梯度张量为0
        gradValueTensor.fillWithValue(static_cast<InputType>(0.0f));
        gradSamplingLocTensor.fillWithValue(static_cast<InputType>(0.0f));
        gradAttnWeightTensor.fillWithValue(static_cast<InputType>(0.0f));

        std::unordered_map<int64_t, void*> variantPack;
        variantPack[value->get_uid()] = valueTensor.memory().deviceData();
        variantPack[spatialShapes->get_uid()] = spatialShapesTensor.memory().deviceData();
        variantPack[levelStartIndex->get_uid()] = levelStartIndexTensor.memory().deviceData();
        variantPack[samplingLocations->get_uid()] = samplingLocationsTensor.memory().deviceData();
        variantPack[attentionWeights->get_uid()] = attentionWeightsTensor.memory().deviceData();
        variantPack[gradOutput->get_uid()] = gradOutputTensor.memory().deviceData();
        variantPack[gradValue->get_uid()] = gradValueTensor.memory().deviceData();
        variantPack[gradSamplingLoc->get_uid()] = gradSamplingLocTensor.memory().deviceData();
        variantPack[gradAttnWeight->get_uid()] = gradAttnWeightTensor.memory().deviceData();

        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 预热
        HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));

        // 标记设备数据已修改
        gradValueTensor.memory().markDeviceModified();
        gradSamplingLocTensor.memory().markDeviceModified();
        gradAttnWeightTensor.memory().markDeviceModified();

        // CPU验证
        if(config_.cpuValidation)
        {
            std::cout << "Running CPU reference validation (Backward)..." << std::endl;

            bool gradValueValid = false;
            bool gradSamplingLocValid = false;
            bool gradAttnWeightValid = false;

            if constexpr(std::is_same_v<InputType, ::half>)
            {
                Tensor<float> valueTensorFP32
                    = convertTensor<float>(valueTensor, value->get_dim(), value->get_stride());
                Tensor<float> samplingLocationsTensorFP32
                    = convertTensor<float>(samplingLocationsTensor,
                                           samplingLocations->get_dim(),
                                           samplingLocations->get_stride());
                Tensor<float> attentionWeightsTensorFP32
                    = convertTensor<float>(attentionWeightsTensor,
                                           attentionWeights->get_dim(),
                                           attentionWeights->get_stride());
                Tensor<float> gradOutputTensorFP32 = convertTensor<float>(
                    gradOutputTensor, gradOutput->get_dim(), gradOutput->get_stride());

                Tensor<float> gradValueRefTensorFP32(gradValue->get_dim(), gradValue->get_stride());
                Tensor<float> gradSamplingLocRefTensorFP32(gradSamplingLoc->get_dim(),
                                                           gradSamplingLoc->get_stride());
                Tensor<float> gradAttnWeightRefTensorFP32(gradAttnWeight->get_dim(),
                                                          gradAttnWeight->get_stride());

                CpuFpReferenceDeformAttention::
                    dgrad<float, int64_t, int64_t, float, float, float, ComputeType>(
                        valueTensorFP32,
                        spatialShapesTensor,
                        levelStartIndexTensor,
                        samplingLocationsTensorFP32,
                        attentionWeightsTensorFP32,
                        gradOutputTensorFP32,
                        gradValueRefTensorFP32,
                        gradSamplingLocRefTensorFP32,
                        gradAttnWeightRefTensorFP32);

                // 将FP32参考结果转回FP16
                Tensor<InputType> gradValueRefTensor = convertTensor<InputType>(
                    gradValueRefTensorFP32, gradValue->get_dim(), gradValue->get_stride());
                Tensor<InputType> gradSamplingLocRefTensor
                    = convertTensor<InputType>(gradSamplingLocRefTensorFP32,
                                               gradSamplingLoc->get_dim(),
                                               gradSamplingLoc->get_stride());
                Tensor<InputType> gradAttnWeightRefTensor
                    = convertTensor<InputType>(gradAttnWeightRefTensorFP32,
                                               gradAttnWeight->get_dim(),
                                               gradAttnWeight->get_stride());

                // 验证（FP16张量对比）
                auto tolerance = 1e-2f;
                CpuFpReferenceValidation<InputType> validator(tolerance, tolerance);
                gradValueValid = validator.allClose(gradValueRefTensor, gradValueTensor);
                gradAttnWeightValid
                    = validator.allClose(gradAttnWeightRefTensor, gradAttnWeightTensor);
                gradSamplingLocValid
                    = validator.allClose(gradSamplingLocRefTensor, gradSamplingLocTensor);
            }
            else if constexpr(std::is_same_v<InputType, float>)
            {
                Tensor<InputType> gradValueRefTensor(gradValue->get_dim(), gradValue->get_stride());
                Tensor<InputType> gradSamplingLocRefTensor(gradSamplingLoc->get_dim(),
                                                           gradSamplingLoc->get_stride());
                Tensor<InputType> gradAttnWeightRefTensor(gradAttnWeight->get_dim(),
                                                          gradAttnWeight->get_stride());

                gradValueRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                gradSamplingLocRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                gradAttnWeightRefTensor.fillWithValue(static_cast<InputType>(0.0f));

                CpuFpReferenceDeformAttention::dgrad<InputType,
                                                     int64_t,
                                                     int64_t,
                                                     InputType,
                                                     InputType,
                                                     InputType,
                                                     ComputeType>(valueTensor,
                                                                  spatialShapesTensor,
                                                                  levelStartIndexTensor,
                                                                  samplingLocationsTensor,
                                                                  attentionWeightsTensor,
                                                                  gradOutputTensor,
                                                                  gradValueRefTensor,
                                                                  gradSamplingLocRefTensor,
                                                                  gradAttnWeightRefTensor);

                auto tolerance = 1e-4f;
                CpuFpReferenceValidation<InputType> validator(tolerance, tolerance);
                gradValueValid = validator.allClose(gradValueRefTensor, gradValueTensor);
                gradAttnWeightValid
                    = validator.allClose(gradAttnWeightRefTensor, gradAttnWeightTensor);
                CpuFpReferenceValidation<InputType> Loc_validator(1e-2f, 1e-2f);
                gradSamplingLocValid
                    = Loc_validator.allClose(gradSamplingLocRefTensor, gradSamplingLocTensor);
            }
            else
            {
                std::cerr << "Unsupported InputType for Backward CPU validation: "
                          << typeid(InputType).name() << std::endl;
            }
            std::cout << "CPU reference validation (Backward):" << std::endl;
            std::cout << "  grad_value: " << (gradValueValid ? "successful" : "failed")
                      << std::endl;
            std::cout << "  grad_sampling_locations: "
                      << (gradSamplingLocValid ? "successful" : "failed") << std::endl;
            std::cout << "  grad_attention_weights: "
                      << (gradAttnWeightValid ? "successful" : "failed") << std::endl;
        }
        HIPDNN_CHECK(backend->destroy(handle));
    }
};

void run(const Config& config)
{
    if(config.dataType == "fp32")
    {
        DaRunner runner(config);
        runner.template operator()<float, float>();
    }
    else if(config.dataType == "fp16")
    {
        DaRunner runner(config);
        runner.template operator()<::half, float>();
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    // 打印命令行参数
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << std::endl;

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    run(config);

    return 0;
}
