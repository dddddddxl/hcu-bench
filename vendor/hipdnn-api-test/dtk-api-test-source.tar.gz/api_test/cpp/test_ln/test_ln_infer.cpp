#include <fstream>
#include <iostream>
#include <string>
#include <typeinfo>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_frontend/Graph.hpp>
#include <hipdnn_frontend/attributes/LayernormAttributes.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceLayernorm.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>

#include "../utils.hpp"

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// 配置结构体
struct Config
{
    int64_t n = 1;
    int64_t c = 16;
    int64_t H = 16;
    int64_t W = 16;
    int64_t o = 3;
    std::string dataType = "fp32";
    std::string layout = "NCHW";
    bool cpuValidation = false;
    int fileIndex = 0;
    std::string filePath = ".";
};

// 命令行解析
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.H = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.W = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-o") == 0 && i + 1 < argc)
        {
            config.o = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        { // 解析路径参数
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else if(strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0)
        {
            std::cout << "LayerNorm 推理示例\n";
            std::cout << "选项:\n";
            std::cout << "  -n <batch>          批次大小 (默认: 1)\n";
            std::cout << "  -c <channels>       通道数 (默认: 16)\n";
            std::cout << "  -H <height>         高度 (默认: 16)\n";
            std::cout << "  -W <width>          宽度 (默认: 16)\n";
            std::cout << "  -o <dimension>      维度 (默认: 3)\n";
            std::cout << "  -d <data_type>      数据类型 (fp32, fp16, bfp16) (默认: fp32)\n";
            std::cout << "  -L <layout>         数据布局 (NCHW, NHWC) (默认: NCHW)\n";
            std::cout << "  -i <file_index>     文件索引\n";
            std::cout << "  -path <path>        文件路径\n";
            std::cout << "  --cpu-validation    启用CPU参考验证\n";
            std::cout << "  --help, -h          显示此帮助信息\n";
            std::cout << "\n";
            exit(1);
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            std::cerr << "使用 --help或-h 查看帮助信息\n";
            std::cerr
                << "LnInference -n <batch> -c <channels> -H <height> -W <width> -o <dimension>"
                << "-d <data_type> -L <layout> -i <file_index> [--cpu-validation] -path <path>\n";
            exit(1);
        }
    }

    return config;
}

class LnRunner
{
private:
    hipdnnHandle_t handle_;
    Config config_;

public:
    LnRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config) {};

    template <typename InputType, typename IntermediateType>
    void operator()(const TensorLayout& layout)
    {
        auto inputType = getDataTypeEnumFromType<InputType>();
        auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        std::cout << "Running layer normalization inference graph " << inputType << " [" << layout
                  << "]" << (config_.cpuValidation ? " (with CPU validation)" : "") << "...\n";

        const int64_t n = config_.n;
        const int64_t c = config_.c;
        const int64_t H = config_.H;
        const int64_t W = config_.W;
        const int64_t o = config_.o;
        std::cout << "user setting norm dim: " << o << std::endl;

        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_intermediate_data_type(intermediateType)
            .set_compute_data_type(DataType::FLOAT);

        auto x = createTensor({n, c, H, W}, inputType, layout.strideOrder);
        // 使用用户指定的归一化维度
        std::array<int64_t, 4> input_shape = {n, c, H, W};
        std::vector<int64_t> norm_dims;
        if(o >= 0 && o < 4)
        {
            for(size_t i = 0; i < static_cast<size_t>(o); ++i)
            {
                norm_dims.push_back(1);
            }
            for(size_t i = static_cast<size_t>(o); i < 4; ++i)
            {
                norm_dims.push_back(input_shape[i]);
            }
        }
        else
        {
            std::cerr << "Warning: invalid normalization dimension o=" << o << std::endl;
            exit(1);
        }
        std::cout << "Normalization dimensions: ";
        for(auto dim : norm_dims)
        {
            std::cout << dim << " ";
        }
        std::cout << std::endl;
        auto scale = createTensor(norm_dims, inputType, layout.strideOrder);
        auto bias = createTensor(norm_dims, inputType, layout.strideOrder);
        auto epsilon = createTensor({1}, DataType::FLOAT);
        epsilon->set_value(1e-5);
        auto layernormAttributes = graph::LayernormAttributes();
        layernormAttributes.set_name("layernorm_inference_node")
            .set_epsilon(epsilon)
            .set_forward_phase(NormFwdPhase_t::INFERENCE);

        auto [y, mean, inv_variance] = graph->layernorm(x, scale, bias, layernormAttributes);
        y->set_output(true).set_data_type(inputType);

        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful.\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        Tensor<InputType> xTensor(x->get_dim(), x->get_stride());
        Tensor<InputType> scaleTensor(scale->get_dim(), scale->get_stride());
        Tensor<InputType> biasTensor(bias->get_dim(), bias->get_stride());
        Tensor<InputType> yTensor(y->get_dim(), y->get_stride());

        xTensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));
        scaleTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                         static_cast<InputType>(1.0f));
        biasTensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));

        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        std::unordered_map<int64_t, void*> variantPack;

        variantPack[x->get_uid()] = xTensor.memory().deviceData();
        variantPack[scale->get_uid()] = scaleTensor.memory().deviceData();
        variantPack[bias->get_uid()] = biasTensor.memory().deviceData();
        variantPack[y->get_uid()] = yTensor.memory().deviceData();

        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

        yTensor.memory().markDeviceModified();
        auto yHostPtr = yTensor.memory().hostData();

        // 计时运行
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        // 迭代100次，统计LayerNorm()接口的执行耗时
        for(int i = 0; i < 100; i++)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "LayerNorm Inference time: " << time / 100 << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // 执行CPU验证
        if(config_.cpuValidation)
        {
            std::cout << "Running CPU reference validation...\n";

            Tensor<InputType> yRefTensor(y->get_dim(), y->get_stride());

            const double cpuEpsilon = 1e-5;

            CpuFpReferenceLayernorm::forward(
                xTensor, &scaleTensor, &biasTensor, yRefTensor, cpuEpsilon, 1);
            float tolerance;
            if(config_.dataType == "fp32")
            {
                tolerance = static_cast<float>(1e-5f);
            }
            else
            {
                tolerance = static_cast<float>(1e-2f);
            }

            auto validator = CpuFpReferenceValidation<InputType>(tolerance, tolerance);
            bool yValid = validator.allClose(yRefTensor, yTensor);

            std::cout << "CPU reference validation:\n";
            std::cout << "  y: " << (yValid ? "successful" : "failed") << "\n";
        }

        std::cout << "First 10 y values: ";
        for(int i = 0; i < 10; ++i)
        {
            std::cout << static_cast<float>(yHostPtr[i]) << " ";
        }

        std::cout << "\nLayernorm normalization inference graph execution complete for "
                  << inputType << ".\n\n";
    }
};

void run(hipdnnHandle_t handle, const Config& config)
{
    TensorLayout layout = (config.layout == "NCHW") ? TensorLayout::NCHW : TensorLayout::NHWC;
    if(config.dataType == "fp32")
    {
        LnRunner runner(handle, config);
        runner.template operator()<float, float>(layout);
    }
    else if(config.dataType == "fp16")
    {
        LnRunner runner(handle, config);
        runner.template operator()<half, float>(layout);
    }
    else if(config.dataType == "bfp16")
    {
        LnRunner runner(handle, config);
        runner.template operator()<bfloat16, float>(layout);
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " "; // 按输入顺序拼接所有参数
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));
    run(handle, config);
    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
