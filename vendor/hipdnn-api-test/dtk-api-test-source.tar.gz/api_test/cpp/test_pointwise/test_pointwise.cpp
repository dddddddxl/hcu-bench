#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <tuple>
#include <unordered_map>
#include <vector>

#include "../utils.hpp"
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// ===================== 配置结构体 =====================
struct Config
{
    int64_t n = 1;
    int64_t c = 3;
    int64_t h = 1080;
    int64_t w = 1920;
    std::string layout = "NCHW";
    std::string dataType = "fp32";
    std::string mode = "add"; // pointwise mode
    bool broadcast = false; // if true, second input shape = [1,c,1,1]
    int file_index = 0;
    std::string file_path = "";
    bool cpuValidation = false;
};

// ===================== 命令行解析 =====================
Config parse_config(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
            config.n = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
            config.c = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
            config.h = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
            config.w = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-m") == 0 && i + 1 < argc)
        {
            config.mode = argv[++i];
            std::transform(config.mode.begin(), config.mode.end(), config.mode.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "--broadcast") == 0)
            config.broadcast = true;
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
            config.file_index = std::stoi(argv[++i]);
        else if(strcmp(argv[i], "-o") == 0 && i + 1 < argc)
            config.file_path = argv[++i];
        else if(strcmp(argv[i], "--cpu-validation") == 0)
            config.cpuValidation = true;
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

// ===================== 配置合法性校验 =====================
void validate_config(const Config& config)
{
    if(config.layout != "NHWC" && config.layout != "NCHW")
    {
        std::cerr << "Unsupported layout: " << config.layout << ", use NHWC/NCHW" << std::endl;
        exit(1);
    }
    if(config.dataType != "fp16" && config.dataType != "fp32")
    {
        std::cerr << "Unsupported data type: " << config.dataType << ", use fp16/fp32" << std::endl;
        exit(1);
    }
}

// ===================== 数据类型映射 =====================
DataType getDataTypeEnum(const std::string& dtype)
{
    if(dtype == "fp16")
        return DataType::HALF;
    if(dtype == "fp32")
        return DataType::FLOAT;
    std::cerr << "Unsupported data type: " << dtype << std::endl;
    exit(1);
}

// ===================== PointwiseMode 字符串转枚举 =====================
PointwiseMode stringToPointwiseMode(const std::string& mode)
{
    if(mode == "add")
        return PointwiseMode::ADD;
    if(mode == "sub")
        return PointwiseMode::SUB;
    if(mode == "mul")
        return PointwiseMode::MUL;
    if(mode == "div")
        return PointwiseMode::DIV;
    if(mode == "max")
        return PointwiseMode::MAX;
    if(mode == "min")
        return PointwiseMode::MIN;
    if(mode == "pow")
        return PointwiseMode::POW;
    if(mode == "cmp_eq")
        return PointwiseMode::CMP_EQ;
    if(mode == "cmp_ge")
        return PointwiseMode::CMP_GE;
    if(mode == "cmp_gt")
        return PointwiseMode::CMP_GT;
    if(mode == "cmp_le")
        return PointwiseMode::CMP_LE;
    if(mode == "cmp_lt")
        return PointwiseMode::CMP_LT;
    if(mode == "cmp_neq")
        return PointwiseMode::CMP_NEQ;
    if(mode == "add_square")
        return PointwiseMode::ADD_SQUARE;
    if(mode == "logical_and")
        return PointwiseMode::LOGICAL_AND;
    if(mode == "logical_or")
        return PointwiseMode::LOGICAL_OR;
    std::cerr << "Unsupported pointwise mode: " << mode << std::endl;
    exit(1);
}

// ===================== 根据布局和维度计算连续步长 =====================
std::vector<int64_t> compute_stride(const std::vector<int64_t>& dims, const std::string& layout)
{
    if(dims.size() != 4)
        throw std::runtime_error("Only 4D tensors are supported");
    int64_t n = dims[0], c = dims[1], h = dims[2], w = dims[3];
    if(layout == "NCHW")
        return {c * h * w, h * w, w, 1};
    else if(layout == "NHWC")
        return {c * h * w, 1, c * w, c};
    else
        throw std::runtime_error("Unsupported layout");
}

// ===================== 主模板函数 =====================
template <typename T>
void run_with_type(const Config& config)
{
    int64_t n = config.n, c = config.c, h = config.h, w = config.w;
    std::string layout = config.layout;
    bool broadcast = config.broadcast;
    PointwiseMode mode = stringToPointwiseMode(config.mode);

    // 定义两个输入的维度
    std::vector<int64_t> x_dim = {n, c, h, w};
    std::vector<int64_t> y_dim
        = broadcast ? std::vector<int64_t>{1, c, 1, 1} : std::vector<int64_t>{n, c, h, w};
    // 输出维度与广播后的结果相同，即 x_dim
    std::vector<int64_t> out_dim = x_dim;

    // 计算步长
    std::vector<int64_t> x_stride = compute_stride(x_dim, layout);
    std::vector<int64_t> y_stride = compute_stride(y_dim, layout);
    std::vector<int64_t> out_stride = compute_stride(out_dim, layout);

    // ---------- 构建计算图 ----------
    auto build_graph = [=](hipdnnHandle_t handle) {
        auto graph = std::make_shared<graph::Graph>();
        graph->set_name(config.mode + "_graph")
            .set_io_data_type(getDataTypeEnum(config.dataType))
            .set_intermediate_data_type(DataType::FLOAT)
            .set_compute_data_type(DataType::FLOAT);

        auto x = graph->tensor(
            graph::Tensor_attributes().set_name("x").set_dim(x_dim).set_stride(x_stride));
        auto y = graph->tensor(
            graph::Tensor_attributes().set_name("y").set_dim(y_dim).set_stride(y_stride));

        auto out = graph->pointwise(
            x, y, graph::Pointwise_attributes().set_mode(mode).set_name("pointwise"));
        out->set_output(true);

        graph->build(handle);
        return std::make_tuple(graph, x, y, out);
    };

    // 初始化 hipDNN 后端和句柄
    auto backend = hipdnn_frontend::detail::hipdnnBackend();
    if(!backend)
    {
        std::cerr << "Backend create failed!" << std::endl;
        return;
    }
    hipdnnHandle_t handle;
    backend->create(&handle);

    auto [graph, x, y, out] = build_graph(handle);

    // ---------- 分配主机/设备内存 ----------
    Tensor<T> x_tensor(x_dim, x_stride);
    Tensor<T> y_tensor(y_dim, y_stride);
    Tensor<T> out_tensor(out_dim, out_stride);

    size_t x_elem = static_cast<size_t>(n * c * h * w);
    size_t y_elem = broadcast ? static_cast<size_t>(c) : x_elem;

    // ---------- 初始化数据（随机或从文件读取）----------
    bool readSuccess = false;
    if(config.file_index > 0 && !config.file_path.empty())
    {
        std::string base = config.file_path + "/" + std::to_string(config.file_index);
        std::vector<T> ref_x, ref_y;

        bool x_ok = readRawTensor<T>(base + "_x.bin", ref_x, x_elem);
        bool y_ok = readRawTensor<T>(base + "_y.bin", ref_y, y_elem);
        readSuccess = x_ok && y_ok;

        if(readSuccess)
        {
            std::cout << "Successfully read input reference files!" << std::endl;
            std::copy(ref_x.begin(), ref_x.end(), x_tensor.memory().hostData());
            std::copy(ref_y.begin(), ref_y.end(), y_tensor.memory().hostData());
            x_tensor.memory().markHostModified();
            y_tensor.memory().markHostModified();
        }
        else
        {
            std::cerr << "[WARN] Read input files failed, use random values!" << std::endl;
        }
    }

    if(!readSuccess)
    {
        x_tensor.fillWithRandomValues(static_cast<T>(0.1f), static_cast<T>(1.0f));
        y_tensor.fillWithRandomValues(static_cast<T>(0.1f), static_cast<T>(1.0f));
    }

    // ---------- 准备 variant pack ----------
    std::unordered_map<int64_t, void*> variantPack;
    variantPack[x->get_uid()] = x_tensor.memory().deviceData();
    variantPack[y->get_uid()] = y_tensor.memory().deviceData();
    variantPack[out->get_uid()] = out_tensor.memory().deviceData();

    // ---------- 工作空间 ----------
    int64_t workspace_size = 0;
    graph->get_workspace_size(workspace_size);
    Workspace workspace(static_cast<size_t>(workspace_size));

    // ---------- 第一次执行（预热） ----------
    graph->execute(handle, variantPack, workspace.get());
    out_tensor.memory().markDeviceModified();
    std::cout << "Graph execution successful! Mode: " << config.mode
              << (broadcast ? " (broadcast)" : " (elementwise)") << std::endl;

    // ---------- 文件参考验证 ----------
    if(config.file_index > 0 && !config.file_path.empty())
    {
        std::cout << "\n=== File Reference Validation ===" << std::endl;
        std::string base = config.file_path + "/" + std::to_string(config.file_index);
        Tensor<T> ref_out(out_dim, out_stride);
        std::vector<T> ref_out_data;
        bool out_ok = readRawTensor<T>(base + "_out.bin", ref_out_data, x_elem);
        if(out_ok)
        {
            std::copy(ref_out_data.begin(), ref_out_data.end(), ref_out.memory().hostData());
            auto validator = CpuFpReferenceValidation<T>(1e-5f, 1e-5f);
            std::cout << "Output: "
                      << (validator.allClose(ref_out, out_tensor) ? "successful" : "failed")
                      << std::endl;
        }
        else
        {
            std::cerr << "[WARN] Reference output file not found, skip file validation."
                      << std::endl;
        }
    }

    // ---------- 性能测量 ----------
    hipEvent_t start, stop;
    float total_time;
    HIP_CHECK(hipEventCreate(&start));
    HIP_CHECK(hipEventCreate(&stop));
    HIP_CHECK(hipDeviceSynchronize());
    HIP_CHECK(hipEventRecord(start));

    const int iterations = 100;
    for(int i = 0; i < iterations; ++i)
    {
        graph->execute(handle, variantPack, workspace.get());
    }

    HIP_CHECK(hipEventRecord(stop));
    HIP_CHECK(hipEventSynchronize(stop));
    HIP_CHECK(hipEventElapsedTime(&total_time, start, stop));

    std::cout << "\n========== Performance ==========" << std::endl;
    std::cout << "Avg time: " << total_time / iterations << " ms" << std::endl;

    // ---------- CPU 参考验证 ----------
    if(config.cpuValidation)
    {
        std::cout << "\n=== CPU Reference Validation ===" << std::endl;
        Tensor<T> cpu_out(out_dim, out_stride);

        std::unordered_map<int64_t, void*> cpu_variant;
        cpu_variant[x->get_uid()] = x_tensor.memory().hostData();
        cpu_variant[y->get_uid()] = y_tensor.memory().hostData();
        cpu_variant[out->get_uid()] = cpu_out.memory().hostData();

        auto [graph_buf, buf_size] = graph->to_binary();
        CpuReferenceGraphExecutor cpu_exec;
        cpu_exec.execute(graph_buf.data(), graph_buf.size(), cpu_variant);

        float tolerance = (config.dataType == "fp32") ? 1e-5f : 1e-2f;
        CpuFpReferenceValidation<float> validator(tolerance, tolerance);
        std::cout << "Output: "
                  << (validator.allClose(cpu_out, out_tensor) ? "successful" : "failed")
                  << std::endl;
    }

    // ---------- 清理 ----------
    HIP_CHECK(hipEventDestroy(start));
    HIP_CHECK(hipEventDestroy(stop));
    backend->destroy(handle);
}

// ===================== 主函数 =====================
int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
        std::cout << argv[i] << " ";
    std::cout << std::endl;

    Config config = parse_config(argc, argv);
    validate_config(config);

    if(config.dataType == "fp16")
        run_with_type<half>(config);
    else if(config.dataType == "fp32")
        run_with_type<float>(config);
    else
    {
        std::cerr << "Unsupported dtype!" << std::endl;
        return 1;
    }

    return 0;
}
