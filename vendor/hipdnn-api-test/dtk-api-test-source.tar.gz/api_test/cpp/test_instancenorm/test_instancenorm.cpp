// Copyright © Advanced Micro Devices, Inc., or its affiliates.
// SPDX-License-Identifier: MIT

#include <algorithm>
#include <cmath>
#include <cstring>
#include <iostream>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

#include <hip/hip_runtime.h>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;

// ==================== 工具宏定义 ====================
#define HIP_CHECK(status)                                                                      \
    do                                                                                         \
    {                                                                                          \
        if(status != hipSuccess)                                                               \
        {                                                                                      \
            std::cerr << "HIP Error: " << hipGetErrorString(status) << " in file " << __FILE__ \
                      << " at line " << __LINE__ << "\n";                                      \
            exit(EXIT_FAILURE);                                                                \
        }                                                                                      \
    } while(0)

#define HIPDNN_CHECK(status)                                                             \
    do                                                                                   \
    {                                                                                    \
        if(status != HIPDNN_STATUS_SUCCESS)                                              \
        {                                                                                \
            std::cerr << "hipDNN Error: " << hipdnnGetErrorString(status) << " in file " \
                      << __FILE__ << " at line " << __LINE__ << "\n";                    \
            exit(EXIT_FAILURE);                                                          \
        }                                                                                \
    } while(0)

#define HIPDNN_FE_CHECK(statusObj)                                                        \
    do                                                                                    \
    {                                                                                     \
        auto const& status = statusObj;                                                   \
        if(!status.is_good())                                                             \
        {                                                                                 \
            std::cerr << "hipDNN Frontend Error: " << status.get_message() << " in file " \
                      << __FILE__ << " at line " << __LINE__ << "\n";                     \
            exit(EXIT_FAILURE);                                                           \
        }                                                                                 \
    } while(0)

// ==================== 配置结构体 ====================
struct Config
{
    int64_t n = 2;
    int64_t c = 64;
    int64_t h = 4;
    int64_t w = 5;
    std::string dataType = "fp16";
    std::string layout = "NCHW";
    float epsilon = 1e-5f;
    bool useScale = true;
    bool useBias = true;
    std::string phase = "training";
};

// ==================== 命令行解析 ====================
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
            if(config.layout != "NCHW" && config.layout != "NHWC")
            {
                std::cerr << "Layout must be 'NCHW' or 'NHWC'" << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "-e") == 0 && i + 1 < argc)
        {
            config.epsilon = std::stof(argv[++i]);
        }
        else if(strcmp(argv[i], "--no-scale") == 0)
        {
            config.useScale = false;
        }
        else if(strcmp(argv[i], "--no-bias") == 0)
        {
            config.useBias = false;
        }
        else if(strcmp(argv[i], "-phase") == 0 && i + 1 < argc)
        {
            config.phase = argv[++i];
            std::transform(
                config.phase.begin(), config.phase.end(), config.phase.begin(), ::tolower);
            if(config.phase != "training" && config.phase != "inference"
               && config.phase != "backward")
            {
                std::cerr << "phase must be 'training', 'inference' or 'backward'" << std::endl;
                exit(1);
            }
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            std::cerr << "Usage: " << argv[0] << " -n <batch> -c <channels> -H <height> -W <width> "
                      << "-d <data_type> -L <NCHW|NHWC> -e <epsilon> [--no-scale] [--no-bias] "
                      << "-phase <training|inference|backward>\n";
            exit(1);
        }
    }

    return config;
}

// ==================== InstanceNormRunner 类 ====================
class InstanceNormRunner
{
public:
    InstanceNormRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    // 创建张量属性 (支持 NCHW/NHWC 布局)
    std::shared_ptr<graph::Tensor_attributes> createTensor(const std::vector<int64_t>& dims,
                                                           DataType data_type,
                                                           const std::string& name = "")
    {
        auto tensor = std::make_shared<graph::Tensor_attributes>();
        tensor->set_dim(dims).set_data_type(data_type);
        if(!name.empty())
            tensor->set_name(name);

        // 根据布局计算步长
        std::vector<int64_t> strides(4);
        if(config_.layout == "NHWC")
        {
            // NHWC 布局: 内存排列为 [N, H, W, C]
            int64_t c = dims[1];
            int64_t h = dims[2];
            int64_t w = dims[3];
            strides[0] = h * w * c; // N stride
            strides[1] = 1; // C stride
            strides[2] = w * c; // H stride
            strides[3] = c; // W stride
        }
        else // NCHW
        {
            // NCHW 布局: 内存排列为 [N, C, H, W]
            int64_t c = dims[1];
            int64_t h = dims[2];
            int64_t w = dims[3];
            strides[0] = c * h * w; // N stride
            strides[1] = h * w; // C stride
            strides[2] = w; // H stride
            strides[3] = 1; // W stride
        }
        tensor->set_stride(strides);
        return tensor;
    }

    // ---------- 前向传播 ----------
    template <typename InputType, typename ComputeType = float>
    void forward()
    {
        const auto dataType = getDataTypeEnumFromType<InputType>();
        const auto computeType = getDataTypeEnumFromType<ComputeType>();
        const auto floatDataType = getDataTypeEnumFromType<float>();

        std::cout << "Running InstanceNorm forward graph " << dataType
                  << " (layout=" << config_.layout << ", phase=" << config_.phase
                  << ", epsilon=" << config_.epsilon << ", scale=" << config_.useScale
                  << ", bias=" << config_.useBias << "...\n";

        // 张量维度
        std::vector<int64_t> inputDims = {config_.n, config_.c, config_.h, config_.w};
        std::vector<int64_t> paramDims = {1, config_.c, 1, 1};

        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(dataType)
            .set_intermediate_data_type(floatDataType)
            .set_compute_data_type(computeType);

        // 输入张量
        auto x = createTensor(inputDims, dataType, "input");
        std::shared_ptr<graph::Tensor_attributes> scale = nullptr;
        std::shared_ptr<graph::Tensor_attributes> bias = nullptr;
        if(config_.useScale)
        {
            scale = createTensor(paramDims, floatDataType, "scale");
        }
        if(config_.useBias)
        {
            bias = createTensor(paramDims, floatDataType, "bias");
        }

        // epsilon 标量张量
        auto epsilonTensor = std::make_shared<graph::Tensor_attributes>();
        epsilonTensor->set_name("epsilon").set_value(config_.epsilon);

        // 配置 InstanceNorm 属性
        auto normFwdPhase
            = (config_.phase == "training") ? NormFwdPhase_t::TRAINING : NormFwdPhase_t::INFERENCE;

        auto instancenormAttrs = graph::InstancenormAttributes()
                                     .set_name("instancenorm_node")
                                     .set_epsilon(epsilonTensor)
                                     .set_forward_phase(normFwdPhase);

        auto result = graph->instancenorm(x, scale, bias, instancenormAttrs);
        auto y = std::get<0>(result);
        auto mean = std::get<1>(result);
        auto invVariance = std::get<2>(result);

        y->set_output(true);
        if(config_.phase == "training")
        {
            mean->set_data_type(floatDataType);
            invVariance->set_data_type(floatDataType);
            mean->set_output(true);
            invVariance->set_output(true);
        }

        // 构建图
        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful (InstanceNorm forward).\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful (InstanceNorm forward).\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully (InstanceNorm forward).\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful (InstanceNorm forward).\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful (InstanceNorm forward).\n";

        // 初始化张量
        Tensor<InputType> xTensor(x->get_dim(), x->get_stride());
        Tensor<InputType> yTensor(y->get_dim(), y->get_stride());
        std::optional<Tensor<float>> meanTensorFloatOpt;
        std::optional<Tensor<float>> invVarianceTensorFloatOpt;
        if(config_.phase == "training")
        {
            meanTensorFloatOpt.emplace(mean->get_dim(), mean->get_stride());
            invVarianceTensorFloatOpt.emplace(invVariance->get_dim(), invVariance->get_stride());
        }

        // 随机填充输入
        xTensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));

        // 填充 scale/bias
        std::optional<Tensor<float>> scaleTensorOpt;
        std::optional<Tensor<float>> biasTensorOpt;
        if(config_.useScale)
        {
            scaleTensorOpt.emplace(scale->get_dim(), scale->get_stride());
            scaleTensorOpt->fillWithRandomValues(0.5f, 1.5f);
            scaleTensorOpt->memory().markHostModified();
        }
        if(config_.useBias)
        {
            biasTensorOpt.emplace(bias->get_dim(), bias->get_stride());
            biasTensorOpt->fillWithRandomValues(-0.5f, 0.5f);
            biasTensorOpt->memory().markHostModified();
        }

        // 准备执行数据包
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[x->get_uid()] = xTensor.memory().deviceData();
        variantPack[y->get_uid()] = yTensor.memory().deviceData();
        if(config_.useScale)
            variantPack[scale->get_uid()] = scaleTensorOpt->memory().deviceData();
        if(config_.useBias)
            variantPack[bias->get_uid()] = biasTensorOpt->memory().deviceData();
        if(config_.phase == "training")
        {
            variantPack[mean->get_uid()] = meanTensorFloatOpt->memory().deviceData();
            variantPack[invVariance->get_uid()] = invVarianceTensorFloatOpt->memory().deviceData();
        }

        // 工作空间
        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 首次执行
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        yTensor.memory().markDeviceModified();

        // 性能计时
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));

        const int warmupRuns = 10;
        const int timedRuns = 100;

        for(int i = 0; i < warmupRuns; ++i)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipEventRecord(start, nullptr));
        for(int i = 0; i < timedRuns; ++i)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));

        std::cout << "InstanceNorm forward average execution time: " << time / timedRuns << " ms\n";
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        std::cout << "InstanceNorm forward graph execution complete for " << dataType << ".\n\n";
    }

    // ---------- 反向传播 ----------
    template <typename InputType, typename ComputeType = float>
    void backward()
    {
        const auto dataType = getDataTypeEnumFromType<InputType>();
        const auto computeType = getDataTypeEnumFromType<ComputeType>();
        const auto floatDataType = getDataTypeEnumFromType<float>();

        std::cout << "Running InstanceNorm backward graph " << dataType
                  << " (layout=" << config_.layout << ", epsilon=" << config_.epsilon << "...\n";

        // 张量维度
        std::vector<int64_t> inputDims = {config_.n, config_.c, config_.h, config_.w};
        std::vector<int64_t> paramDims = {1, config_.c, 1, 1};
        std::vector<int64_t> statDims = {config_.n, config_.c, 1, 1};

        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(dataType)
            .set_intermediate_data_type(floatDataType)
            .set_compute_data_type(computeType);

        // x 和 dy 使用 InputType
        auto x = createTensor(inputDims, dataType, "input");
        auto dy = createTensor(inputDims, dataType, "dy");
        // scale, mean, invVariance
        auto scale = createTensor(paramDims, floatDataType, "scale");
        auto mean = createTensor(statDims, floatDataType, "mean");
        auto invVariance = createTensor(statDims, floatDataType, "inv_variance");

        // 配置反向属性
        auto backwardAttrs = graph::InstancenormBackwardAttributes()
                                 .set_saved_mean_and_inv_variance(mean, invVariance)
                                 .set_name("instancenorm_backward_node");

        auto [dx, dscale, dbias] = graph->instancenorm_backward(dy, x, scale, backwardAttrs);
        dx->set_output(true);
        dscale->set_output(true).set_data_type(floatDataType);
        dbias->set_output(true).set_data_type(floatDataType);

        // 构建图
        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful (InstanceNorm backward).\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful (InstanceNorm backward).\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully (InstanceNorm backward).\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful (InstanceNorm backward).\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful (InstanceNorm backward).\n";

        // 分配张量
        Tensor<InputType> xTensor(x->get_dim(), x->get_stride()); // InputType
        Tensor<InputType> dyTensor(dy->get_dim(), dy->get_stride()); // InputType
        Tensor<float> scaleTensor(scale->get_dim(), scale->get_stride()); // FLOAT
        Tensor<float> meanTensor(mean->get_dim(), mean->get_stride()); // FLOAT
        Tensor<float> invVarianceTensor(invVariance->get_dim(), invVariance->get_stride()); // FLOAT
        Tensor<InputType> dxTensor(dx->get_dim(), dx->get_stride()); // InputType
        Tensor<float> dscaleTensor(dscale->get_dim(), dscale->get_stride()); // FLOAT
        Tensor<float> dbiasTensor(dbias->get_dim(), dbias->get_stride()); // FLOAT

        // 随机填充数据
        xTensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));
        dyTensor.fillWithRandomValues(static_cast<InputType>(-0.5f), static_cast<InputType>(0.5f));
        scaleTensor.fillWithRandomValues(0.5f, 1.5f);
        scaleTensor.memory().markHostModified();

        // 填充 mean 和 invVariance
        fillPositiveRandomTensor(meanTensor, 0.1, 2.0, static_cast<size_t>(config_.n * config_.c));
        fillPositiveRandomTensor(
            invVarianceTensor, 0.1, 2.0, static_cast<size_t>(config_.n * config_.c));
        meanTensor.memory().markHostModified();
        invVarianceTensor.memory().markHostModified();

        // 准备执行数据包
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[x->get_uid()] = xTensor.memory().deviceData();
        variantPack[dy->get_uid()] = dyTensor.memory().deviceData();
        variantPack[scale->get_uid()] = scaleTensor.memory().deviceData();
        variantPack[mean->get_uid()] = meanTensor.memory().deviceData();
        variantPack[invVariance->get_uid()] = invVarianceTensor.memory().deviceData();
        variantPack[dx->get_uid()] = dxTensor.memory().deviceData();
        variantPack[dscale->get_uid()] = dscaleTensor.memory().deviceData();
        variantPack[dbias->get_uid()] = dbiasTensor.memory().deviceData();

        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 首次执行
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        dxTensor.memory().markDeviceModified();
        dscaleTensor.memory().markDeviceModified();
        dbiasTensor.memory().markDeviceModified();

        // 性能计时
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));

        const int warmupRuns = 10;
        const int timedRuns = 100;

        for(int i = 0; i < warmupRuns; ++i)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipEventRecord(start, nullptr));
        for(int i = 0; i < timedRuns; ++i)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));

        std::cout << "InstanceNorm backward average execution time: " << time / timedRuns
                  << " ms\n";
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        std::cout << "InstanceNorm backward graph execution complete for " << dataType << ".\n\n";
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    // 用正随机数填充张量
    template <typename T>
    void fillPositiveRandomTensor(Tensor<T>& tensor, double minVal, double maxVal, size_t numElems)
    {
        T* data = tensor.memory().hostData();
        for(size_t i = 0; i < numElems; ++i)
        {
            double randVal = static_cast<double>(rand()) / RAND_MAX;
            double val = minVal + randVal * (maxVal - minVal);
            data[i] = static_cast<T>(val);
        }
        tensor.memory().markHostModified();
    }
};

// ==================== 根据参数选择执行类型 ====================
void run(hipdnnHandle_t handle, const Config& config)
{
    std::cout << "Using layout: " << config.layout << std::endl;

    if(config.phase == "backward")
    {
        if(config.dataType == "fp32")
        {
            InstanceNormRunner runner(handle, config);
            runner.backward<float, float>();
        }
        else if(config.dataType == "fp16")
        {
            InstanceNormRunner runner(handle, config);
            runner.backward<half, float>();
        }
        else if(config.dataType == "bfp16")
        {
            InstanceNormRunner runner(handle, config);
            runner.backward<bfloat16, float>();
        }
        else
        {
            std::cerr << "Unsupported data type: " << config.dataType
                      << " (supported: fp32, fp16, bfp16)" << std::endl;
            exit(1);
        }
    }
    else // forward (training / inference)
    {
        if(config.dataType == "fp32")
        {
            InstanceNormRunner runner(handle, config);
            runner.forward<float, float>();
        }
        else if(config.dataType == "fp16")
        {
            InstanceNormRunner runner(handle, config);
            runner.forward<half, float>();
        }
        else if(config.dataType == "bfp16")
        {
            InstanceNormRunner runner(handle, config);
            runner.forward<bfloat16, float>();
        }
        else
        {
            std::cerr << "Unsupported data type: " << config.dataType
                      << " (supported: fp32, fp16, bfp16)" << std::endl;
            exit(1);
        }
    }
}

// ==================== 主函数 ====================
int main(int argc, char* argv[])
{
    // 打印命令行
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    // 初始化前端日志
    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));

    run(handle, config);

    HIPDNN_CHECK(hipdnnDestroy(handle));
    std::cout << "InstanceNorm test completed.\n";
    return 0;
}
