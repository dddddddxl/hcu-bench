// Copyright © Advanced Micro Devices, Inc., or its affiliates.
// SPDX-License-Identifier:  MIT

#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include "../utils.hpp"
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_frontend/Graph.hpp>
#include <hipdnn_frontend/attributes/SdpaAttributes.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceSdpa.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;
// 配置结构体
struct Config
{
    int64_t n = 2;
    int64_t headDimQ = 20;
    int64_t headDimK = 20;
    int64_t headDimV = 20;
    int64_t seqLenQ = 20;
    int64_t seqLenKV = 20;
    int64_t dQK = 64;
    int64_t dV = 64;
    bool generateStats = false;
    float attnScale = 1.0;
    bool causalMask = false;
    bool paddingMask = false;
    bool alibiMask = false;
    bool hasAttnBias = false;
    std::string dataType = "fp16"; // only support fp16
    std::string layout = "BHSD"; // layout
    int direct = 1; // 1:infer
    bool cpuValidation = false;
    int fileIndex = 0;
    std::string filePath = ".";
};

// 命令行解析
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--headDimQ") == 0 && i + 1 < argc)
        {
            config.headDimQ = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--headDimK") == 0 && i + 1 < argc)
        {
            config.headDimK = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--headDimV") == 0 && i + 1 < argc)
        {
            config.headDimV = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--seqLenQ") == 0 && i + 1 < argc)
        {
            config.seqLenQ = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--seqLenKV") == 0 && i + 1 < argc)
        {
            config.seqLenKV = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--dQK") == 0 && i + 1 < argc)
        {
            config.dQK = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--dV") == 0 && i + 1 < argc)
        {
            config.dV = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--generateStats") == 0 && i + 1 < argc)
        {
            config.generateStats = argv[++i];
        }
        else if(strcmp(argv[i], "--attnScale") == 0 && i + 1 < argc)
        {
            config.attnScale = std::stof(argv[++i]);
        }
        else if(strcmp(argv[i], "--causalMask") == 0 && i + 1 < argc)
        {
            config.causalMask = argv[++i];
        }
        else if(strcmp(argv[i], "--paddingMask") == 0 && i + 1 < argc)
        {
            config.paddingMask = argv[++i];
        }
        else if(strcmp(argv[i], "--alibiMask") == 0 && i + 1 < argc)
        {
            config.alibiMask = argv[++i];
        }
        else if(strcmp(argv[i], "--hasAttnBias") == 0 && i + 1 < argc)
        {
            config.hasAttnBias = argv[++i];
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "--dataType") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "--layout") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            if(config.layout != "BHSD" && config.layout != "BSHD")
            {
                std::cerr << "Unsupported layout: " << config.layout
                          << ", supported layout are BHSD and BSHD" << std::endl;
            }
        }

        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else if(strcmp(argv[i], "-F") == 0 && i + 1 < argc)
        {
            int type = std::stoi(argv[++i]);
            if(type != 1)
            {
                std::cerr << "Invalid SDPA type: " << type << std::endl;
                std::cerr << "Supported types: 1(infer)" << std::endl;
                exit(1);
            }
            config.direct = type;
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            std::cerr << "-n <batch> -c <channels> -H <height> -W <width> "
                      << "-k <filters> -y <filter_h> -x <filter_w> -p <pad_h> -q <pad_w> "
                      << "-u <stride_h> -v <stride_w> -l <dil_h> -j <dil_w> "
                      << "-d <data_type> -L <layout> -i <file_index> -F <1/2/4> "
                      << "[--cpu-validation] -path <path>\n";
            exit(1);
        }
    }

    return config;
}

class SdpaRunner
{
public:
    SdpaRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

public:
    template <typename InputType, typename IntermediateType>
    void run_sdpa_infer(const std::string& layout)
    {
        auto inputType = getDataTypeEnumFromType<InputType>();
        auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        std::cout << "Running sdpa inference graph " << inputType << " [" << layout << "]"
                  << (config_.cpuValidation ? " (with CPU validation)" : "") << "...\n";

        int64_t b = config_.n; // batch size
        int64_t headDimQ = config_.headDimQ; // head dim Q
        int64_t headDimK = config_.headDimK; // head dim K
        int64_t headDimV = config_.headDimV; // head dim V
        int64_t seqLenQ = config_.seqLenQ; // q tensor is padded to this seq length
        int64_t seqLenKV = config_.seqLenKV; // k and v tensor is padded to this seq length
        int64_t dQK = config_.dQK; // hidden dim
        int64_t dV = config_.dV; // hidden dim
        bool generateStats = config_.generateStats;
        // float attnScale = config_.attnScale;
        bool causalMask = config_.causalMask;
        bool paddingMask = config_.paddingMask;
        bool alibiMask = config_.alibiMask;
        bool hasAttnBias = config_.hasAttnBias;

        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_intermediate_data_type(intermediateType)
            .set_compute_data_type(intermediateType);

        // create tensor
        std::cout << "  b: " << b << "  headDimQ: " << headDimQ << "  headDimK: " << headDimK
                  << "  headDimV: " << headDimV << "  seqLenQ: " << seqLenQ
                  << "  seqLenKV: " << seqLenKV << "  dQK: " << dQK << "  dV: " << dV << " \n";
        auto q = createTensor({b, headDimQ, seqLenQ, dQK}, inputType);
        auto k = createTensor({b, headDimK, seqLenKV, dQK}, inputType);
        auto v = createTensor({b, headDimV, seqLenKV, dV}, inputType);
        auto bias = createTensor({b, 1, seqLenQ, seqLenKV}, inputType);
        auto seqLengthQ = createTensor({b, 1, 1, 1}, hipdnn_frontend::DataType_t::INT32);
        auto seqLengthKV = createTensor({b, 1, 1, 1}, hipdnn_frontend::DataType_t::INT32);

        std::vector<int64_t> Q_stride, K_stride, V_stride, bias_stride, dropout_stride,
            output_stride, oTensor_stride, statsTensor_stride;
        if(layout == "BHSD")
        {
            Q_stride = {headDimQ * seqLenQ * dQK, seqLenQ * dQK, dQK, 1};
            K_stride = {headDimK * seqLenKV * dQK, seqLenKV * dQK, dQK, 1};
            V_stride = {headDimV * seqLenKV * dV, seqLenKV * dV, dV, 1};
            bias_stride = {1 * seqLenQ * seqLenKV, seqLenQ * seqLenKV, seqLenKV, 1};
            output_stride = {headDimQ * dV, dV, b * headDimQ * dV, 1};
            dropout_stride = {headDimQ * seqLenQ * seqLenKV, seqLenQ * seqLenKV, seqLenKV, 1};
            oTensor_stride = {headDimQ * seqLenQ * dV, seqLenQ * dV, dV, 1};
            statsTensor_stride = {headDimQ * seqLenQ, seqLenQ, 1, 1};
        }
        else if(layout == "BSHD")
        {
            Q_stride = {seqLenQ * headDimQ * dQK, headDimQ * dQK, dQK, 1};
            K_stride = {seqLenKV * headDimK * dQK, headDimK * dQK, dQK, 1};
            V_stride = {seqLenKV * headDimV * dV, headDimV * dV, dV, 1};
            bias_stride = {seqLenQ * 1 * seqLenKV, 1 * seqLenKV, seqLenKV, 1};
            output_stride = {seqLenQ * headDimQ * dV, headDimQ * dV, dV, 1};
            dropout_stride = {seqLenQ * headDimQ * seqLenKV, headDimQ * seqLenKV, seqLenKV, 1};
            oTensor_stride = {seqLenQ * headDimQ * dV, headDimQ * dV, dV, 1};
            statsTensor_stride = {headDimQ * seqLenQ, headDimQ, 1, 1};
        }
        else
        {
            std::cerr << "Unsupported layout: " << config_.layout
                      << ", supported layout are BHSD and BSHD" << std::endl;
        }

        // create op and graph
        auto sdpaAttributes = graph::SdpaAttributes();
        sdpaAttributes.set_name("sdpa_inference_node")
            .set_generate_stats(generateStats)
            .set_alibi_mask(alibiMask);
        // .set_attn_scale_value(attnScale);
        if(causalMask)
        {
            sdpaAttributes.set_diagonal_alignment(DiagonalAlignment_t::TOP_LEFT)
                .set_diagonal_band_right_bound(0);
        }
        if(hasAttnBias)
        {
            sdpaAttributes.set_bias(bias);
        }
        if(paddingMask)
        {
            sdpaAttributes.set_padding_mask(paddingMask)
                .set_seq_len_q(seqLengthQ)
                .set_seq_len_kv(seqLengthKV);
        }
        auto [outO, outStats] = graph->sdpa(q, k, v, sdpaAttributes);
        outO->set_output(true).set_dim({b, headDimQ, seqLenQ, dV}).set_stride(oTensor_stride);
        if(generateStats)
        {
            outStats->set_output(true).set_data_type(hipdnn_frontend::DataType_t::FLOAT);
        }
        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful.\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        // run graph
        Tensor<InputType> qTensor(q->get_dim(), Q_stride);
        Tensor<InputType> kTensor(k->get_dim(), K_stride);
        Tensor<InputType> vTensor(v->get_dim(), V_stride);
        Tensor<InputType> oTensor({b, headDimQ, seqLenQ, dV}, oTensor_stride);
        Tensor<float> statsTensor({b, headDimQ, seqLenQ, 1}, statsTensor_stride);
        Tensor<InputType> biasTensor({b, 1, seqLenQ, seqLenKV}, bias_stride);
        Tensor<int32_t> seqLenQTensor({b}, std::vector<int64_t>{1});
        Tensor<int32_t> seqLenKVTensor({b}, std::vector<int64_t>{1});
        qTensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));
        kTensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));
        vTensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));
        biasTensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));
        seqLenQTensor.fillWithRandomValues(static_cast<int32_t>(0), static_cast<int32_t>(20));
        seqLenKVTensor.fillWithRandomValues(static_cast<int32_t>(0), static_cast<int32_t>(20));

        // workspace
        int64_t workspaceSize;
        graph->get_workspace_size(workspaceSize);
        std::cout << "workspaceSize : " << workspaceSize << "\n";
        Workspace workspaceTensor(static_cast<size_t>(workspaceSize));

        std::unordered_map<int64_t, void*> variantPack;
        variantPack[q->get_uid()] = qTensor.memory().deviceData();
        variantPack[k->get_uid()] = kTensor.memory().deviceData();
        variantPack[v->get_uid()] = vTensor.memory().deviceData();
        variantPack[outO->get_uid()] = oTensor.memory().deviceData();

        if(hasAttnBias)
        {
            variantPack[bias->get_uid()] = biasTensor.memory().deviceData();
        }
        if(generateStats)
        {
            variantPack[outStats->get_uid()] = statsTensor.memory().deviceData();
        }
        if(paddingMask)
        {
            variantPack[seqLengthQ->get_uid()] = seqLenQTensor.memory().deviceData();
            variantPack[seqLengthKV->get_uid()] = seqLenKVTensor.memory().deviceData();
        }

        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspaceTensor.get()));
        oTensor.memory().markDeviceModified();
        auto oHostPtr = oTensor.memory().hostData();

        // 性能测试
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspaceTensor.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "SDPA infer avg time: " << time / 100 << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // CPU 验证
        if(config_.cpuValidation)
        {
            std::cout << "Running CPU reference validation...\n";

            Tensor<InputType> oRefTensor(outO->get_dim(), oTensor_stride);
            CpuFpReferenceSdpa::forward<InputType, InputType, InputType, InputType, float>(
                qTensor,
                kTensor,
                vTensor,
                oRefTensor,
                std::nullopt, // 使用 optional 包装
                nullptr, // 无 attention mask
                config_.causalMask);

            auto tolerance = sdpa::getTolerance<InputType>();
            auto validator = CpuFpReferenceValidation<InputType>(tolerance, tolerance);

            bool yValid = validator.allClose(oRefTensor, oTensor);

            std::cout << "CPU reference validation:\n";
            std::cout << "  y: " << (yValid ? "successful" : "failed") << "\n";
        }

        std::cout << "First 10 y values: ";
        for(int i = 0; i < 10; ++i)
        {
            std::cout << static_cast<float>(oHostPtr[i]) << " ";
        }

        std::cout << "\nsdpa inference graph execution complete for " << inputType << ".\n\n";
    }
};

void run(hipdnnHandle_t handle, const Config& config)
{

    SdpaRunner runner(handle, config);

    std::string layout = config.layout;
    // datetype
    if(config.dataType == "fp16")
    {
        runner.template run_sdpa_infer<half, float>(layout);
    }
    else if(config.dataType == "bf16")
    {
        runner.template run_sdpa_infer<bfloat16, float>(layout);
    }
    else if(config.dataType == "fp32")
    {
        runner.template run_sdpa_infer<float, float>(layout);
    }
    else
    {
        std::cerr << "Unsupported datatype : " << config.dataType
                  << "  , only support [fp16],[bf16] and [fp32] " << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();
    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));

    run(handle, config);

    HIPDNN_CHECK(hipdnnDestroy(handle));
    std::cout << "All sdpa inference runs completed successfully.\n";
    return 0;
}
