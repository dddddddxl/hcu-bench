#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>

#include "../utils.hpp"

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// 融合模式枚举
enum class FusionType
{
    None, // matmul
    Bias, // matmul + bias
    Relu, // matmul + relu
    BiasRelu, // matmul + bias + relu
    Gelu, // matmul + gelu
    BiasGelu, // matmul + bias + gelu
    Sigmoid, // matmul + sigmoid
    BiasSigmoid, // matmul + bias + sigmoid
    Tanh, // matmul + tanh
    BiasTanh, // matmul + bias + tanh
    Silu, // matmul + silu
    BiasSilu // matmul + bias + silu
};

// 配置结构
struct Config
{
    int64_t b = 1; // batch size
    int64_t m = 32; // M 维度
    int64_t n = 32; // N 维度
    int64_t k = 32; // K 维度
    std::string dataType = "fp32";
    FusionType fusion = FusionType::None;
    bool cpuValidation = false;
    int fileIndex = 0;
    std::string filePath = "";
};

// 解析命令行参数
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-b") == 0 && i + 1 < argc)
        {
            config.b = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-m") == 0 && i + 1 < argc)
        {
            config.m = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-k") == 0 && i + 1 < argc)
        {
            config.k = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-fusion") == 0 && i + 1 < argc)
        {
            std::string fusionStr = argv[++i];
            std::transform(fusionStr.begin(), fusionStr.end(), fusionStr.begin(), ::tolower);
            if(fusionStr == "none")
            {
                config.fusion = FusionType::None;
            }
            else if(fusionStr == "bias")
            {
                config.fusion = FusionType::Bias;
            }
            else if(fusionStr == "relu")
            {
                config.fusion = FusionType::Relu;
            }
            else if(fusionStr == "biasrelu")
            {
                config.fusion = FusionType::BiasRelu;
            }
            else if(fusionStr == "gelu")
            {
                config.fusion = FusionType::Gelu;
            }
            else if(fusionStr == "biasgelu")
            {
                config.fusion = FusionType::BiasGelu;
            }
            else if(fusionStr == "sigmoid")
            {
                config.fusion = FusionType::Sigmoid;
            }
            else if(fusionStr == "biassigmoid")
            {
                config.fusion = FusionType::BiasSigmoid;
            }
            else if(fusionStr == "tanh")
            {
                config.fusion = FusionType::Tanh;
            }
            else if(fusionStr == "biastanh")
            {
                config.fusion = FusionType::BiasTanh;
            }
            else if(fusionStr == "silu")
            {
                config.fusion = FusionType::Silu;
            }
            else if(fusionStr == "biassilu")
            {
                config.fusion = FusionType::BiasSilu;
            }
            else
            {
                std::cerr << "Unknown fusion mode: " << fusionStr << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            std::cerr << "Usage: " << argv[0]
                      << " -b <batch> -m <M> -n <N> -k <K> -d <data_type> -fusion <mode> "
                      << "[--cpu-validation] [-i file_index] [-path path]\n";
            exit(1);
        }
    }
    return config;
}

// 主测试类
class MatmulRunner
{
public:
    MatmulRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType, typename IntermediateType>
    void run()
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        using OutputType = InputType;
        const auto outputType = getDataTypeEnumFromType<OutputType>();

        int64_t b = config_.b;
        int64_t m = config_.m;
        int64_t n = config_.n;
        int64_t k = config_.k;

        // 避免符号转换警告
        size_t aSize = static_cast<size_t>(b * m * k);
        size_t bSize = static_cast<size_t>(b * k * n);
        size_t cSize = static_cast<size_t>(b * m * n);
        size_t biasSize = static_cast<size_t>(n);

        // 定义维度和步长
        std::vector<int64_t> aDims = {b, m, k};
        std::vector<int64_t> aStride = {m * k, k, 1};
        std::vector<int64_t> bDims = {b, k, n};
        std::vector<int64_t> bStride = {k * n, n, 1};
        std::vector<int64_t> cDims = {b, m, n};
        std::vector<int64_t> cStride = {m * n, n, 1};

        std::vector<int64_t> biasDims = {1, 1, n};
        std::vector<int64_t> biasStride = {n, n, 1};

        // 创建计算图
        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_compute_data_type(DataType::FLOAT)
            .set_intermediate_data_type(DataType::FLOAT);

        // 定义 A 和 B 张量属性
        auto A = createTensor(aDims, inputType, aStride);
        A->set_name("A");
        auto B = createTensor(bDims, inputType, bStride);
        B->set_name("B");

        // 矩阵乘节点
        graph::MatmulAttributes matmulAttr;
        matmulAttr.set_name("matmul").set_compute_data_type(DataType::FLOAT);
        auto C = graph->matmul(A, B, matmulAttr);
        C->set_name("matmul_out");
        // 关键修复：强制矩阵乘输出类型与最终输出一致（避免混合类型加法）
        C->set_data_type(outputType);

        // 根据融合模式添加节点
        std::shared_ptr<graph::TensorAttributes> finalOutput = C;
        std::shared_ptr<graph::TensorAttributes> biasAttr = nullptr;

        if(config_.fusion == FusionType::Bias || config_.fusion == FusionType::BiasRelu
           || config_.fusion == FusionType::BiasGelu || config_.fusion == FusionType::BiasSigmoid
           || config_.fusion == FusionType::BiasTanh || config_.fusion == FusionType::BiasSilu)
        {
            biasAttr = createTensor(biasDims, inputType, biasStride);
            biasAttr->set_name("bias");

            graph::PointwiseAttributes addAttr;
            addAttr.set_name("add_bias").set_mode(PointwiseMode_t::ADD);
            auto biasOut = graph->pointwise(C, biasAttr, addAttr);
            biasOut->set_name("add_out");
            finalOutput = biasOut;
        }

        // 激活函数节点
        switch(config_.fusion)
        {
        case FusionType::Relu:
        case FusionType::BiasRelu:
        {
            graph::PointwiseAttributes reluAttr;
            reluAttr.set_name("relu").set_mode(PointwiseMode_t::RELU_FWD);
            reluAttr.set_relu_lower_clip(0.0);
            auto reluOut = graph->pointwise(finalOutput, reluAttr);
            reluOut->set_name("relu_out");
            finalOutput = reluOut;
            break;
        }
        case FusionType::Gelu:
        case FusionType::BiasGelu:
        {
            graph::PointwiseAttributes geluAttr;
            geluAttr.set_name("gelu").set_mode(PointwiseMode_t::GELU_FWD); // GELU_APPROX_TANH_FWD
            auto geluOut = graph->pointwise(finalOutput, geluAttr);
            geluOut->set_name("gelu_out");
            finalOutput = geluOut;
            break;
        }
        case FusionType::Sigmoid:
        case FusionType::BiasSigmoid:
        {
            graph::PointwiseAttributes sigmoidAttr;
            sigmoidAttr.set_name("sigmoid").set_mode(PointwiseMode_t::SIGMOID_FWD);
            auto sigmoidOut = graph->pointwise(finalOutput, sigmoidAttr);
            sigmoidOut->set_name("sigmoid_out");
            finalOutput = sigmoidOut;
            break;
        }
        case FusionType::Tanh:
        case FusionType::BiasTanh:
        {
            graph::PointwiseAttributes tanhAttr;
            tanhAttr.set_name("tanh").set_mode(PointwiseMode_t::TANH_FWD);
            auto tanhOut = graph->pointwise(finalOutput, tanhAttr);
            tanhOut->set_name("tanh_out");
            finalOutput = tanhOut;
            break;
        }
        case FusionType::Silu:
        case FusionType::BiasSilu:
        {
            graph::PointwiseAttributes siluAttr;
            siluAttr.set_name("silu").set_mode(PointwiseMode_t::SWISH_FWD);
            siluAttr.set_swish_beta(1.0);
            auto siluOut = graph->pointwise(finalOutput, siluAttr);
            siluOut->set_name("silu_out");
            finalOutput = siluOut;
            break;
        }
        default:
            break;
        }

        finalOutput->set_output(true).set_data_type(outputType);

        // 图验证与构建
        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful.\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        // 分配 GPU 内存
        Tensor<InputType> ATensor(aDims, aStride);
        Tensor<InputType> BTensor(bDims, bStride);
        Tensor<OutputType> CTensor(cDims, cStride);
        std::unique_ptr<Tensor<InputType>> biasTensor;
        if(biasAttr)
        {
            biasTensor = std::make_unique<Tensor<InputType>>(biasDims, biasStride);
        }

        // 初始化数据（随机或从文件读取）
        bool readSuccess = false; // 记录参考文件（C）是否成功读取
        std::vector<InputType> refAData, refBData, refBiasData;
        std::vector<OutputType> refCOutData;
        Tensor<OutputType> refCTensor(cDims, cStride);

        if(config_.fileIndex > 0)
        {
            std::string aFile = config_.filePath + std::to_string(config_.fileIndex) + "_A.bin";
            std::string bFile = config_.filePath + std::to_string(config_.fileIndex) + "_B.bin";
            std::string cFile = config_.filePath + std::to_string(config_.fileIndex) + "_C.bin";
            bool readABCSuccess = readRawTensor<InputType>(aFile, refAData, aSize)
                                  && readRawTensor<InputType>(bFile, refBData, bSize)
                                  && readRawTensor<OutputType>(cFile, refCOutData, cSize);
            bool biasReadSuccess = true;
            if(biasAttr)
            {
                std::string biasFile
                    = config_.filePath + std::to_string(config_.fileIndex) + "_bias.bin";
                biasReadSuccess = readRawTensor<InputType>(biasFile, refBiasData, biasSize);
                if(!biasReadSuccess)
                {
                    std::cerr << "[WARN] Bias file not found, will use random bias.\n";
                }
            }
            if(readABCSuccess)
            {
                std::cout << "Successfully read NV reference files (A, B, C).\n";
                readSuccess = true; // 标记 C 文件读取成功，用于后续验证
                std::copy(refAData.begin(), refAData.end(), ATensor.memory().hostData());
                ATensor.memory().markHostModified();
                std::copy(refBData.begin(), refBData.end(), BTensor.memory().hostData());
                BTensor.memory().markHostModified();
                std::copy(refCOutData.begin(), refCOutData.end(), refCTensor.memory().hostData());
                refCTensor.memory().markHostModified();
                if(biasTensor)
                {
                    if(biasReadSuccess)
                    {
                        std::copy(refBiasData.begin(),
                                  refBiasData.end(),
                                  biasTensor->memory().hostData());
                    }
                    else
                    {
                        fillRandom(*biasTensor);
                    }
                    biasTensor->memory().markHostModified();
                }
            }
            else
            {
                std::cerr << "[WARN] Failed to read A/B/C reference files. Using "
                             "random values.\n";
                fillRandom(ATensor, BTensor);
                if(biasTensor)
                    fillRandom(*biasTensor);
            }
        }
        else
        {
            fillRandom(ATensor, BTensor);
            if(biasTensor)
                fillRandom(*biasTensor);
        }

        // 将主机数据拷贝到设备（如果尚未同步）
        ATensor.memory().markHostModified();
        BTensor.memory().markHostModified();
        if(biasTensor)
            biasTensor->memory().markHostModified();

        // 绑定 variant pack
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[A->get_uid()] = ATensor.memory().deviceData();
        variantPack[B->get_uid()] = BTensor.memory().deviceData();
        variantPack[finalOutput->get_uid()] = CTensor.memory().deviceData();
        if(biasAttr)
        {
            variantPack[biasAttr->get_uid()] = biasTensor->memory().deviceData();
        }

        // 获取 workspace
        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 执行一次预热
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        CTensor.memory().markDeviceModified();

        // 计时
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        const int warmup = 10;
        const int iterations = 100;
        for(int i = 0; i < warmup; ++i)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipDeviceSynchronize());

        HIP_CHECK(hipEventRecord(start, nullptr));
        for(int i = 0; i < iterations; ++i)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "Average time: " << time / iterations << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // 可选：打印部分结果
        CTensor.memory().markDeviceModified(); // 确保设备数据最新
        const OutputType* gpuOut = CTensor.memory().hostData();
        std::cout << "First 10 GPU output values: ";
        for(int i = 0; i < std::min(10, static_cast<int>(cSize)); ++i)
        {
            std::cout << static_cast<float>(gpuOut[i]) << " ";
        }
        std::cout << std::endl;

        // CPU 验证：使用图执行器
        if(config_.cpuValidation)
        {
            // 准备 CPU 变体包（主机内存指针）
            std::unordered_map<int64_t, void*> cpuVariantPack;
            cpuVariantPack[A->get_uid()] = ATensor.memory().hostData();
            cpuVariantPack[B->get_uid()] = BTensor.memory().hostData();
            if(biasAttr)
            {
                cpuVariantPack[biasAttr->get_uid()] = biasTensor->memory().hostData();
            }
            // 创建 CPU 结果张量，与 GPU 输出相同的维度和步长
            Tensor<OutputType> cpuTensor(cDims, cStride);
            cpuVariantPack[finalOutput->get_uid()] = cpuTensor.memory().hostData();

            // 序列化图
            auto serializedGraph = graph->to_binary().first;
            // 创建 CPU 执行器并执行
            CpuReferenceGraphExecutor cpuExecutor;
            cpuExecutor.execute(serializedGraph.data(), serializedGraph.size(), cpuVariantPack);
            cpuTensor.memory().markHostModified();

            // 验证 CPU 与 GPU 结果
            float tolerance = getTolerance<OutputType>();
            // if (config_.fusion == FusionType::BiasGelu ){
            //         tolerance = 1e-2f;
            //     }
            if((config_.fusion == FusionType::BiasGelu || config_.fusion == FusionType::Gelu)
               && std::is_same_v<OutputType, float>)
            {
                tolerance = 5e-4f;
            }
            auto validator = createAllCloseValidator<OutputType>(tolerance, tolerance);
            bool pass = validator->allClose(cpuTensor, CTensor);
            std::cout << "CPU validation result: " << (pass ? "successful" : "failed") << std::endl;
        }

        // NV 文件参考验证（当 -i 参数有效且 C 文件读取成功时）
        // 使用 CpuFpReferenceValidation 进行验证，与 test_conv.cpp 风格一致
        if(config_.fileIndex > 0 && readSuccess)
        {
            // 确保 GPU 结果已同步到主机
            CTensor.memory().markDeviceModified();

            // 使用 CpuFpReferenceValidation 类进行验证
            // OutputType tolerance = getTolerance<OutputType>();
            float tolerance = 0.01f;
            CpuFpReferenceValidation<OutputType> fileValidator(tolerance, tolerance);
            bool isMatch = fileValidator.allClose(refCTensor, CTensor);
            std::cout << "NV validation result: " << (isMatch ? "successful" : "failed")
                      << std::endl;
        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    template <typename T>
    void fillRandom(Tensor<T>& tensor1, Tensor<T>& tensor2)
    {
        if constexpr(std::is_same_v<T, int8_t>)
        {
            tensor1.fillWithRandomValues(static_cast<T>(-127), static_cast<T>(127));
            tensor2.fillWithRandomValues(static_cast<T>(-127), static_cast<T>(127));
        }
        else
        {
            tensor1.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
            tensor2.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
        }
    }

    template <typename T>
    void fillRandom(Tensor<T>& tensor)
    {
        if constexpr(std::is_same_v<T, int8_t>)
        {
            tensor.fillWithRandomValues(static_cast<T>(-127), static_cast<T>(127));
        }
        else
        {
            tensor.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
        }
    }

    template <typename T>
    float getTolerance()
    {
        if constexpr(std::is_same_v<T, float>)
            return 1e-4f;
        else if constexpr(std::is_same_v<T, half>)
            return 1e-2f;
        else if constexpr(std::is_same_v<T, bfloat16>)
            return 1e-2f;
        else
            return 1.0f;
    }

    std::shared_ptr<graph::TensorAttributes> createTensor(const std::vector<int64_t>& dims,
                                                          DataType dataType,
                                                          const std::vector<int64_t>& stride)
    {
        auto attr = std::make_shared<graph::TensorAttributes>();
        attr->set_dim(dims);
        attr->set_stride(stride);
        attr->set_data_type(dataType);
        return attr;
    }
};

void runMatmul(hipdnnHandle_t handle, const Config& config)
{
    if(config.dataType == "fp32" || config.dataType == "tf32")
    {
        MatmulRunner runner(handle, config);
        runner.run<float, float>();
    }
    else if(config.dataType == "fp16")
    {
        MatmulRunner runner(handle, config);
        runner.run<half, float>();
    }
    else if(config.dataType == "bfp16")
    {
        MatmulRunner runner(handle, config);
        runner.run<bfloat16, float>();
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << std::endl;

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));
    runMatmul(handle, config);
    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
