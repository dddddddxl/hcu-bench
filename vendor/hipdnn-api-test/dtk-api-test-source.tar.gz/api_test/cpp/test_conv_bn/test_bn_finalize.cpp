#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <vector>

#include "../utils.hpp"
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>

#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// ===================== 配置结构体 =====================
struct Config
{
    int64_t n = 1; // Batch size
    int64_t c = 32; // channels
    int64_t h = 16; // Height
    int64_t w = 16; // Width
    std::string layout = "NHWC";
    std::string dataType = "fp32";
    double epsilon = 1e-5;
    float momentum = 0.001f;
    int file_index = 0;
    std::string file_path = "";
    bool cpuValidation = false;
};

// ===================== 命令行解析 =====================
Config parse_config(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
            config.n = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
            config.c = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
            config.h = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
            config.w = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "--epsilon") == 0 && i + 1 < argc)
            config.epsilon = std::stod(argv[++i]);
        else if(strcmp(argv[i], "--momentum") == 0 && i + 1 < argc)
            config.momentum = std::stof(argv[++i]);
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
            config.file_index = std::stoi(argv[++i]);
        else if(strcmp(argv[i], "-o") == 0 && i + 1 < argc)
            config.file_path = argv[++i];
        else if(strcmp(argv[i], "--cpu-validation") == 0)
            config.cpuValidation = true;
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

// ===================== 配置合法性校验 =====================
void validate_config(const Config& config)
{
    if(config.layout != "NHWC" && config.layout != "NCHW")
    {
        std::cerr << "Unsupported layout: " << config.layout << ", use NHWC/NCHW" << std::endl;
        exit(1);
    }
    if(config.dataType != "fp16" && config.dataType != "fp32" && config.dataType != "bf16")
    {
        std::cerr << "Unsupported data type: " << config.dataType << ", use fp16/fp32/bf16"
                  << std::endl;
        exit(1);
    }
}

// ===================== 数据类型映射 =====================
DataType getDataTypeEnum(const std::string& dtype)
{
    if(dtype == "fp16")
        return DataType::HALF;
    else if(dtype == "fp32")
        return DataType::FLOAT;
    else if(dtype == "bf16")
        return DataType::BFLOAT16;
    else
    {
        std::cerr << "Unsupported data type: " << dtype << std::endl;
        exit(1);
    }
}

template <typename T>
void run_with_type(const Config& config)
{
    int64_t n = config.n;
    int64_t c = config.c;
    int64_t h = config.h;
    int64_t w = config.w;
    std::string layout = config.layout;
    double epsilon = config.epsilon;
    float momentum = config.momentum;

    // ---------- 定义 BN Finalize 相关的张量维度和步长 ----------
    std::vector<int64_t> per_channel_dim = {1, c, 1, 1};
    std::vector<int64_t> per_channel_stride = {c, 1, c, c};
    std::vector<int64_t> scalar_dim = {1, 1, 1, 1};
    std::vector<int64_t> scalar_stride = {1, 1, 1, 1};

    // ---------- 构建 BN Finalize 图 ----------
    auto build_graph = [=](hipdnnHandle_t handle) {
        auto graph = std::make_shared<graph::Graph>();
        graph->set_name("bn_finalize_graph")
            .set_io_data_type(getDataTypeEnum(config.dataType))
            .set_intermediate_data_type(DataType::FLOAT)
            .set_compute_data_type(DataType::FLOAT);

        auto sum = graph->tensor(graph::Tensor_attributes()
                                     .set_name("sum")
                                     .set_dim(per_channel_dim)
                                     .set_stride(per_channel_stride)
                                     .set_data_type(DataType::FLOAT));
        auto sqSum = graph->tensor(graph::Tensor_attributes()
                                       .set_name("sq_sum")
                                       .set_dim(per_channel_dim)
                                       .set_stride(per_channel_stride)
                                       .set_data_type(DataType::FLOAT));

        auto scale = graph->tensor(graph::Tensor_attributes()
                                       .set_name("scale")
                                       .set_dim(per_channel_dim)
                                       .set_stride(per_channel_stride)
                                       .set_data_type(DataType::FLOAT));
        auto bias = graph->tensor(graph::Tensor_attributes()
                                      .set_name("bias")
                                      .set_dim(per_channel_dim)
                                      .set_stride(per_channel_stride)
                                      .set_data_type(DataType::FLOAT));

        auto prevRunningMean = graph->tensor(graph::Tensor_attributes()
                                                 .set_name("prev_running_mean")
                                                 .set_dim(per_channel_dim)
                                                 .set_stride(per_channel_stride)
                                                 .set_data_type(DataType::FLOAT));
        auto prevRunningVar = graph->tensor(graph::Tensor_attributes()
                                                .set_name("prev_running_var")
                                                .set_dim(per_channel_dim)
                                                .set_stride(per_channel_stride)
                                                .set_data_type(DataType::FLOAT));

        auto momentum_tensor = graph->tensor(graph::Tensor_attributes()
                                                 .set_name("momentum")
                                                 .set_dim(scalar_dim)
                                                 .set_stride(scalar_stride)
                                                 .set_data_type(DataType::FLOAT));
        momentum_tensor->set_value(momentum);

        auto epsilon_tensor = graph->tensor(graph::Tensor_attributes()
                                                .set_name("epsilon")
                                                .set_dim(scalar_dim)
                                                .set_stride(scalar_stride)
                                                .set_data_type(DataType::FLOAT));
        epsilon_tensor->set_value(static_cast<float>(epsilon));

        auto accumCount = graph->tensor(graph::Tensor_attributes()
                                            .set_name("accum_count")
                                            .set_dim(scalar_dim)
                                            .set_stride(scalar_stride)
                                            .set_data_type(DataType::INT32));
        accumCount->set_value(static_cast<int32_t>(n * h * w));

        // BN Finalize 操作
        auto bnFinalizeAttributes
            = graph::BatchnormFinalizeAttributes()
                  .set_name("bn_finalize_node")
                  .set_previous_running_stats(prevRunningMean, prevRunningVar, momentum_tensor);

        auto [eqScale, eqBias, mean, invVariance, nextRunningMean, nextRunningVar]
            = graph->bn_finalize(
                sum, sqSum, scale, bias, epsilon_tensor, accumCount, bnFinalizeAttributes);

        eqScale->set_output(true);
        eqBias->set_output(true);
        mean->set_output(true).set_data_type(DataType::FLOAT);
        invVariance->set_output(true).set_data_type(DataType::FLOAT);
        nextRunningMean->set_output(true).set_data_type(DataType::FLOAT);
        nextRunningVar->set_output(true).set_data_type(DataType::FLOAT);

        HIPDNN_FE_CHECK(graph->build(handle));
        return std::make_tuple(graph,
                               sum,
                               sqSum,
                               scale,
                               bias,
                               prevRunningMean,
                               prevRunningVar,
                               momentum_tensor,
                               epsilon_tensor,
                               accumCount,
                               eqScale,
                               eqBias,
                               mean,
                               invVariance,
                               nextRunningMean,
                               nextRunningVar);
    };

    // ---------- 初始化 hipDNN ----------
    auto backend = hipdnn_frontend::detail::hipdnnBackend();
    if(!backend)
    {
        std::cerr << "Backend create failed!" << std::endl;
        return;
    }
    hipdnnHandle_t handle;
    HIPDNN_CHECK(backend->create(&handle));

    auto [graph,
          sum,
          sqSum,
          scale,
          bias,
          prevRunningMean,
          prevRunningVar,
          momentum_tensor,
          epsilon_tensor,
          accumCount,
          eqScale,
          eqBias,
          mean,
          invVariance,
          nextRunningMean,
          nextRunningVar]
        = build_graph(handle);

    // ---------- 分配主机/设备内存 ----------
    Tensor<float> sum_tensor(per_channel_dim, per_channel_stride);
    Tensor<float> sqSum_tensor(per_channel_dim, per_channel_stride);
    Tensor<float> mean_tensor(per_channel_dim, per_channel_stride);
    Tensor<float> invVar_tensor(per_channel_dim, per_channel_stride);
    Tensor<float> nextMean_tensor(per_channel_dim, per_channel_stride);
    Tensor<float> nextVar_tensor(per_channel_dim, per_channel_stride);

    Tensor<float> scale_tensor(per_channel_dim, per_channel_stride);
    Tensor<float> bias_tensor(per_channel_dim, per_channel_stride);

    Tensor<T> eqScale_tensor(per_channel_dim, per_channel_stride);
    Tensor<T> eqBias_tensor(per_channel_dim, per_channel_stride);

    Tensor<float> prevMean_tensor(per_channel_dim, per_channel_stride);
    Tensor<float> prevVar_tensor(per_channel_dim, per_channel_stride);

    Tensor<float> momentum_host(scalar_dim, scalar_stride);
    Tensor<float> epsilon_host(scalar_dim, scalar_stride);
    Tensor<int32_t> accumCount_host(scalar_dim, scalar_stride);
    momentum_host.memory().hostData()[0] = momentum;
    epsilon_host.memory().hostData()[0] = static_cast<float>(epsilon);
    accumCount_host.memory().hostData()[0] = static_cast<int32_t>(n * h * w);

    // ---------- 初始化数据（随机或从文件读取）----------
    bool readSuccess = false;
    size_t per_channel_elem = static_cast<size_t>(c);

    if(config.file_index > 0 && !config.file_path.empty())
    {
        std::string base = config.file_path + "/" + std::to_string(config.file_index);
        std::vector<float> ref_sum, ref_sqSum, ref_mean, ref_invVar, ref_nextMean, ref_nextVar;
        std::vector<float> ref_scale, ref_bias;
        std::vector<float> ref_prevMean, ref_prevVar;

        bool sum_ok = readRawTensor<float>(base + "_sum.bin", ref_sum, per_channel_elem);
        bool sqSum_ok = readRawTensor<float>(base + "_sqsum.bin", ref_sqSum, per_channel_elem);
        bool scale_ok = readRawTensor<float>(base + "_scale.bin", ref_scale, per_channel_elem);
        bool bias_ok = readRawTensor<float>(base + "_bias.bin", ref_bias, per_channel_elem);
        bool prevMean_ok
            = readRawTensor<float>(base + "_prev_mean.bin", ref_prevMean, per_channel_elem);
        bool prevVar_ok
            = readRawTensor<float>(base + "_prev_var.bin", ref_prevVar, per_channel_elem);

        readSuccess = sum_ok && sqSum_ok && scale_ok && bias_ok && prevMean_ok && prevVar_ok;

        if(readSuccess)
        {
            std::cout << "Successfully read input reference files!" << std::endl;
            std::copy(ref_sum.begin(), ref_sum.end(), sum_tensor.memory().hostData());
            std::copy(ref_sqSum.begin(), ref_sqSum.end(), sqSum_tensor.memory().hostData());
            std::copy(ref_scale.begin(), ref_scale.end(), scale_tensor.memory().hostData());
            std::copy(ref_bias.begin(), ref_bias.end(), bias_tensor.memory().hostData());
            std::copy(
                ref_prevMean.begin(), ref_prevMean.end(), prevMean_tensor.memory().hostData());
            std::copy(ref_prevVar.begin(), ref_prevVar.end(), prevVar_tensor.memory().hostData());

            sum_tensor.memory().markHostModified();
            sqSum_tensor.memory().markHostModified();
            scale_tensor.memory().markHostModified();
            bias_tensor.memory().markHostModified();
            prevMean_tensor.memory().markHostModified();
            prevVar_tensor.memory().markHostModified();
        }
        else
        {
            std::cerr << "[WARN] Read input files failed, use random values!" << std::endl;
        }
    }

    if(!readSuccess)
    {
        sum_tensor.fillWithRandomValues(0.0f, 1.0f);
        sqSum_tensor.fillWithRandomValues(0.0f, 1.0f);
        scale_tensor.fillWithRandomValues(0.1f, 1.0f);
        bias_tensor.fillWithRandomValues(0.0f, 0.5f);
        prevMean_tensor.fillWithRandomValues(0.0f, 1.0f);
        prevVar_tensor.fillWithRandomValues(0.0f, 1.0f);
        eqScale_tensor.fillWithValue(static_cast<T>(0.0f));
        eqBias_tensor.fillWithValue(static_cast<T>(0.0f));
        mean_tensor.fillWithValue(0.0f);
        invVar_tensor.fillWithValue(0.0f);
        nextMean_tensor.fillWithValue(0.0f);
        nextVar_tensor.fillWithValue(0.0f);
    }

    std::unordered_map<int64_t, void*> variantPack;
    variantPack[sum->get_uid()] = sum_tensor.memory().deviceData();
    variantPack[sqSum->get_uid()] = sqSum_tensor.memory().deviceData();
    variantPack[scale->get_uid()] = scale_tensor.memory().deviceData();
    variantPack[bias->get_uid()] = bias_tensor.memory().deviceData();
    variantPack[prevRunningMean->get_uid()] = prevMean_tensor.memory().deviceData();
    variantPack[prevRunningVar->get_uid()] = prevVar_tensor.memory().deviceData();
    variantPack[momentum_tensor->get_uid()] = momentum_host.memory().hostData();
    variantPack[epsilon_tensor->get_uid()] = epsilon_host.memory().hostData();
    variantPack[accumCount->get_uid()] = accumCount_host.memory().hostData();
    variantPack[eqScale->get_uid()] = eqScale_tensor.memory().deviceData();
    variantPack[eqBias->get_uid()] = eqBias_tensor.memory().deviceData();
    variantPack[mean->get_uid()] = mean_tensor.memory().deviceData();
    variantPack[invVariance->get_uid()] = invVar_tensor.memory().deviceData();
    variantPack[nextRunningMean->get_uid()] = nextMean_tensor.memory().deviceData();
    variantPack[nextRunningVar->get_uid()] = nextVar_tensor.memory().deviceData();

    // ---------- 工作空间 ----------
    int64_t workspace_size = 0;
    HIPDNN_FE_CHECK(graph->get_workspace_size(workspace_size));
    Workspace workspace(static_cast<size_t>(workspace_size));

    // ---------- 首次执行 ----------
    HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));

    eqScale_tensor.memory().markDeviceModified();
    eqBias_tensor.memory().markDeviceModified();
    mean_tensor.memory().markDeviceModified();
    invVar_tensor.memory().markDeviceModified();
    nextMean_tensor.memory().markDeviceModified();
    nextVar_tensor.memory().markDeviceModified();

    std::cout << "Graph execution successful!" << std::endl;

    // ---------- 文件参考验证 ----------
    if(config.file_index > 0 && !config.file_path.empty())
    {
        std::cout << "\n=== File Reference Validation ===" << std::endl;
        std::string base = config.file_path + "/" + std::to_string(config.file_index);
        auto validate_tensor = [&](const std::string& name,
                                   Tensor<T>& tensor,
                                   const std::vector<int64_t>& dim,
                                   const std::vector<int64_t>& stride,
                                   size_t elem_count) {
            std::vector<float> ref_data;
            if(readRawTensor<float>(base + "_" + name + ".bin", ref_data, elem_count))
            {
                Tensor<float> float_tensor(dim, stride);
                T* src = tensor.memory().hostData();
                float* dst = float_tensor.memory().hostData();
                for(size_t i = 0; i < elem_count; ++i)
                {
                    dst[i] = static_cast<float>(src[i]);
                }
                Tensor<float> ref_tensor(dim, stride);
                std::copy(ref_data.begin(), ref_data.end(), ref_tensor.memory().hostData());
                auto validator = CpuFpReferenceValidation<float>(1e-3f, 1e-3f);
                bool passed = validator.allClose(float_tensor, ref_tensor);
                std::cout << name << ": " << (passed ? "successful" : "failed") << std::endl;
            }
            else
            {
                std::cout << name << ": reference file not found, skip validation" << std::endl;
            }
        };

        auto validate_float = [&](const std::string& name,
                                  Tensor<float>& tensor,
                                  const std::vector<int64_t>& dim,
                                  const std::vector<int64_t>& stride,
                                  size_t elem_count) {
            std::vector<float> ref_data;
            if(readRawTensor<float>(base + "_" + name + ".bin", ref_data, elem_count))
            {
                Tensor<float> ref_tensor(dim, stride);
                std::copy(ref_data.begin(), ref_data.end(), ref_tensor.memory().hostData());
                auto validator = CpuFpReferenceValidation<float>(1e-3f, 1e-3f);
                bool passed = validator.allClose(ref_tensor, tensor);
                std::cout << name << ": " << (passed ? "successful" : "failed") << std::endl;
            }
            else
            {
                std::cout << name << ": reference file not found, skip validation" << std::endl;
            }
        };

        validate_tensor(
            "eq_scale", eqScale_tensor, per_channel_dim, per_channel_stride, per_channel_elem);
        validate_tensor(
            "eq_bias", eqBias_tensor, per_channel_dim, per_channel_stride, per_channel_elem);
        validate_float("mean", mean_tensor, per_channel_dim, per_channel_stride, per_channel_elem);
        validate_float(
            "inv_variance", invVar_tensor, per_channel_dim, per_channel_stride, per_channel_elem);
        validate_float("next_running_mean",
                       nextMean_tensor,
                       per_channel_dim,
                       per_channel_stride,
                       per_channel_elem);
        validate_float("next_running_var",
                       nextVar_tensor,
                       per_channel_dim,
                       per_channel_stride,
                       per_channel_elem);
    }

    // ---------- CPU 参考验证 ----------
    if(config.cpuValidation)
    {
        std::cout << "\n=== CPU Reference Validation ===" << std::endl;

        Tensor<float> cpu_mean(per_channel_dim, per_channel_stride);
        Tensor<float> cpu_invVar(per_channel_dim, per_channel_stride);
        Tensor<float> cpu_nextMean(per_channel_dim, per_channel_stride);
        Tensor<float> cpu_nextVar(per_channel_dim, per_channel_stride);
        Tensor<T> cpu_eqScale(per_channel_dim, per_channel_stride);
        Tensor<T> cpu_eqBias(per_channel_dim, per_channel_stride);

        std::unordered_map<int64_t, void*> cpu_variant;
        cpu_variant[sum->get_uid()] = sum_tensor.memory().hostData();
        cpu_variant[sqSum->get_uid()] = sqSum_tensor.memory().hostData();
        cpu_variant[scale->get_uid()] = scale_tensor.memory().hostData();
        cpu_variant[bias->get_uid()] = bias_tensor.memory().hostData();
        cpu_variant[prevRunningMean->get_uid()] = prevMean_tensor.memory().hostData();
        cpu_variant[prevRunningVar->get_uid()] = prevVar_tensor.memory().hostData();
        cpu_variant[momentum_tensor->get_uid()] = momentum_host.memory().hostData();
        cpu_variant[epsilon_tensor->get_uid()] = epsilon_host.memory().hostData();
        cpu_variant[accumCount->get_uid()] = accumCount_host.memory().hostData();
        cpu_variant[eqScale->get_uid()] = cpu_eqScale.memory().hostData();
        cpu_variant[eqBias->get_uid()] = cpu_eqBias.memory().hostData();
        cpu_variant[mean->get_uid()] = cpu_mean.memory().hostData();
        cpu_variant[invVariance->get_uid()] = cpu_invVar.memory().hostData();
        cpu_variant[nextRunningMean->get_uid()] = cpu_nextMean.memory().hostData();
        cpu_variant[nextRunningVar->get_uid()] = cpu_nextVar.memory().hostData();

        auto graph_buf = graph->to_binary().first;
        CpuReferenceGraphExecutor cpu_exec;
        cpu_exec.execute(graph_buf.data(), graph_buf.size(), cpu_variant);

        // 根据数据类型选择合适的容差
        float rtol, atol;
        if(std::is_same<T, float>::value)
        {
            rtol = atol = 1e-2f;
        }
        else if(std::is_same<T, half>::value)
        {
            rtol = atol = 1e-2f;
        }
        else if(std::is_same<T, bfloat16>::value)
        {
            rtol = atol = 1e-2f;
        }
        else
        {
            rtol = atol = 1e-2f;
        }

        CpuFpReferenceValidation<T> validator_t(rtol, atol);
        CpuFpReferenceValidation<float> validator_float(1e-2f, 1e-2f);

        std::cout << "eqScale: "
                  << (validator_t.allClose(cpu_eqScale, eqScale_tensor) ? "successful" : "failed")
                  << std::endl;
        std::cout << "eqBias: "
                  << (validator_t.allClose(cpu_eqBias, eqBias_tensor) ? "successful" : "failed")
                  << std::endl;
        std::cout << "mean: "
                  << (validator_float.allClose(cpu_mean, mean_tensor) ? "successful" : "failed")
                  << std::endl;
        std::cout << "invVariance: "
                  << (validator_float.allClose(cpu_invVar, invVar_tensor) ? "successful" : "failed")
                  << std::endl;
        std::cout << "nextRunningMean: "
                  << (validator_float.allClose(cpu_nextMean, nextMean_tensor) ? "successful"
                                                                              : "failed")
                  << std::endl;
        std::cout << "nextRunningVar: "
                  << (validator_float.allClose(cpu_nextVar, nextVar_tensor) ? "successful"
                                                                            : "failed")
                  << std::endl;
    }

    // ---------- 性能测量 ----------
    hipEvent_t start, stop;
    float total_time;
    HIP_CHECK(hipEventCreate(&start));
    HIP_CHECK(hipEventCreate(&stop));
    HIP_CHECK(hipDeviceSynchronize());
    HIP_CHECK(hipEventRecord(start));

    const int iterations = 100;
    for(int i = 0; i < iterations; ++i)
    {
        HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
    }

    HIP_CHECK(hipEventRecord(stop));
    HIP_CHECK(hipEventSynchronize(stop));
    HIP_CHECK(hipEventElapsedTime(&total_time, start, stop));

    double avg_time_ms = static_cast<double>(total_time) / static_cast<double>(iterations);
    std::cout << "Avg time: " << avg_time_ms << " ms" << std::endl;

    // ---------- 清理 ----------
    HIP_CHECK(hipEventDestroy(start));
    HIP_CHECK(hipEventDestroy(stop));
    HIPDNN_CHECK(backend->destroy(handle));
}

// ===================== 主函数 =====================
int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
        std::cout << argv[i] << " ";
    std::cout << std::endl;

    Config config = parse_config(argc, argv);
    validate_config(config);

    if(config.dataType == "fp16")
    {
        run_with_type<half>(config);
    }
    else if(config.dataType == "fp32")
    {
        run_with_type<float>(config);
    }
    else if(config.dataType == "bf16")
    {
        run_with_type<bfloat16>(config);
    }
    else
    {
        std::cerr << "Unsupported dtype!" << std::endl;
        return 1;
    }

    return 0;
}
