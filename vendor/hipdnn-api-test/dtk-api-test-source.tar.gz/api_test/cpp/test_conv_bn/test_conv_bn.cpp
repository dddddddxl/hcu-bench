#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <vector>

#include "../utils.hpp"
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>

#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// 配置结构体
struct Config
{
    int64_t n = 4;
    int64_t c = 64;
    int64_t h = 16;
    int64_t w = 16;
    int64_t k = 32;
    int64_t r = 3;
    int64_t s = 3;
    int64_t padH = 1;
    int64_t padW = 1;
    int64_t strideH = 1;
    int64_t strideW = 1;
    int64_t dilH = 1;
    int64_t dilW = 1;
    int64_t groups = 1;
    std::string layout = "NHWC";
    std::string dataType = "fp16";
    std::string fusion_mode = "sbrcs"; // 融合模式: "sbrcs" 或 "cs"
    int file_index = 0; // 文件索引
    std::string file_path = ""; // 文件保存路径
    bool cpuValidation = false;
};

// 参数解析
Config parse_config(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
            config.n = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
            config.c = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
            config.h = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
            config.w = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-k") == 0 && i + 1 < argc)
            config.k = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-y") == 0 && i + 1 < argc)
            config.r = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-x") == 0 && i + 1 < argc)
            config.s = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-p") == 0 && i + 1 < argc)
            config.padH = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc)
            config.padW = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-u") == 0 && i + 1 < argc)
            config.strideH = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-v") == 0 && i + 1 < argc)
            config.strideW = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-l") == 0 && i + 1 < argc)
            config.dilH = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-j") == 0 && i + 1 < argc)
            config.dilW = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-g") == 0 && i + 1 < argc)
            config.groups = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-m") == 0 && i + 1 < argc)
        {
            config.fusion_mode = argv[++i];
            std::transform(config.fusion_mode.begin(),
                           config.fusion_mode.end(),
                           config.fusion_mode.begin(),
                           ::tolower);
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
            config.file_index = std::stoi(argv[++i]);
        else if(strcmp(argv[i], "-o") == 0 && i + 1 < argc)
            config.file_path = argv[++i];
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

// 获取数据类型枚举
DataType getDataTypeEnum(const std::string& dtype)
{
    if(dtype == "fp16")
        return DataType::HALF;
    else if(dtype == "fp32")
        return DataType::FLOAT;
    else if(dtype == "int8")
        return DataType::INT8;
    else if(dtype == "bf16")
        return DataType::BFLOAT16;
    else
    {
        std::cerr << "Unsupported data type: " << dtype << std::endl;
        exit(1);
    }
}

template <typename T>
void run_with_type(const Config& config)
{
    int64_t n = config.n;
    int64_t c = config.c;
    int64_t h = config.h;
    int64_t w = config.w;
    int64_t k = config.k;
    int64_t r = config.r;
    int64_t s = config.s;
    int64_t padH = config.padH;
    int64_t padW = config.padW;
    int64_t strideH = config.strideH;
    int64_t strideW = config.strideW;
    int64_t dilH = config.dilH;
    int64_t dilW = config.dilW;
    int64_t groups = config.groups;
    std::string layout = config.layout;
    std::string fusion_mode = config.fusion_mode;

    // 张量维度和步长设置
    std::vector<int64_t> x_dim, x_stride;
    std::vector<int64_t> w_dim, w_stride;
    std::vector<int64_t> s_dim, s_stride; // scale维度
    std::vector<int64_t> b_dim, b_stride; // bias维度

    // 输入张量维度
    x_dim = {n, c, h, w};
    w_dim = {k, c / groups, r, s};
    s_dim = {1, c, 1, 1};
    b_dim = {1, c, 1, 1};

    // 根据布局设置步长
    if(layout == "NHWC")
    {
        x_stride = {c * h * w, 1, c * w, c};
        w_stride = {(c / groups) * r * s, 1, (c / groups) * s, (c / groups)};
        s_stride = {c, 1, c, c};
        b_stride = {c, 1, c, c};
    }
    else
    { // NCHW
        x_stride = {c * h * w, h * w, w, 1};
        w_stride = {(c / groups) * r * s, r * s, s, 1};
        s_stride = {c, 1, 1, 1};
        b_stride = {c, 1, 1, 1};
    }

    // 构建计算图
    auto build_graph = [=](hipdnnHandle_t handle) {
        auto graph = std::make_shared<graph::Graph>();

        // 设置图属性
        graph->set_name("fusion_graph")
            .set_io_data_type(getDataTypeEnum(config.dataType))
            .set_intermediate_data_type(DataType::FLOAT)
            .set_compute_data_type(DataType::FLOAT);

        // 输入张量X
        auto X = std::make_shared<graph::TensorAttributes>(
            graph::Tensor_attributes().set_name("image").set_dim(x_dim).set_stride(x_stride));

        // 权重张量W - 分组卷积
        auto W = std::make_shared<graph::TensorAttributes>(
            graph::Tensor_attributes().set_name("filter").set_dim(w_dim).set_stride(w_stride));

        std::shared_ptr<graph::TensorAttributes> current_output = X;
        std::shared_ptr<graph::TensorAttributes> S = nullptr;
        std::shared_ptr<graph::TensorAttributes> B = nullptr;

        // 根据融合模式构建不同的图
        if(fusion_mode == "sbrcs")
        {
            // scale张量S
            S = std::make_shared<graph::TensorAttributes>(
                graph::Tensor_attributes().set_name("scale").set_dim(s_dim).set_stride(s_stride));

            // scale操作
            auto scale_options = graph::Pointwise_attributes().set_mode(PointwiseMode_t::MUL);
            auto scale_output = graph->pointwise(X, S, scale_options);

            // bias张量B
            B = std::make_shared<graph::TensorAttributes>(
                graph::Tensor_attributes().set_name("bias").set_dim(b_dim).set_stride(b_stride));

            // bias操作
            auto bias_options = graph::Pointwise_attributes().set_mode(PointwiseMode_t::ADD);
            auto bias_output = graph->pointwise(scale_output, B, bias_options);
            bias_output->set_data_type(getDataTypeEnum(config.dataType));

            // ReLU激活函数
            auto relu_options = graph::Pointwise_attributes().set_mode(PointwiseMode_t::RELU_FWD);
            current_output = graph->pointwise(bias_output, relu_options);
        }

        // 卷积操作
        auto conv_options = graph::Conv_fprop_attributes()
                                .set_padding({padH, padW})
                                .set_stride({strideH, strideW})
                                .set_dilation({dilH, dilW});

        auto conv_output = graph->conv_fprop(current_output, W, conv_options);
        auto Y = conv_output;
        Y->set_output(true);

        // 生成统计信息
        auto genstats_options = graph::Genstats_attributes();
        auto [SUM, SQ_SUM] = graph->genstats(Y, genstats_options);

        SUM->set_output(true).set_data_type(DataType::FLOAT);
        SQ_SUM->set_output(true).set_data_type(DataType::FLOAT);

        // 构建图
        HIPDNN_FE_CHECK(graph->build(handle));

        if(fusion_mode == "sbrcs")
        {
            return std::make_tuple(graph, X, W, S, B, Y, SUM, SQ_SUM);
        }
        else
        { // cs模式
            return std::make_tuple(graph,
                                   X,
                                   W,
                                   std::shared_ptr<graph::TensorAttributes>(nullptr),
                                   std::shared_ptr<graph::TensorAttributes>(nullptr),
                                   Y,
                                   SUM,
                                   SQ_SUM);
        }
    };

    // 创建HIPDNN后端
    auto backend = hipdnn_frontend::detail::hipdnnBackend();
    if(!backend)
    {
        std::cout << "Create backend failed. \n";
        return;
    }

    hipdnnHandle_t handle;
    HIPDNN_CHECK(backend->create(&handle));

    // 调用build_graph函数
    auto [graph, X, W, S, B, Y, SUM, SQ_SUM] = build_graph(handle);

    // 分配内存
    Tensor<T> x_tensor(x_dim, x_stride);
    Tensor<T> w_tensor(w_dim, w_stride);
    Tensor<T> y_tensor(Y->get_dim(), Y->get_stride());

    // ========== 读文件初始化逻辑 ==========
    bool readSuccess = false;

    if(config.file_index > 0 && !config.file_path.empty())
    {
        // 计算总元素数
        size_t xTotalElems = static_cast<size_t>(n * c * h * w);
        size_t wTotalElems = static_cast<size_t>(k * (c / groups) * r * s);

        std::vector<T> refXData, refWData;

        // 构建文件名
        const std::string xFilename
            = config.file_path + std::to_string(config.file_index) + "_input.bin";
        const std::string wFilename
            = config.file_path + std::to_string(config.file_index) + "_weight.bin";

        // 尝试读取文件
        readSuccess = readRawTensor<T>(xFilename, refXData, xTotalElems)
                      && readRawTensor<T>(wFilename, refWData, wTotalElems);

        if(readSuccess)
        {
            std::cout << "Successfully read reference files from: " << config.file_path << "\n";
            std::copy(refXData.begin(), refXData.end(), x_tensor.memory().hostData());
            x_tensor.memory().markHostModified();

            std::copy(refWData.begin(), refWData.end(), w_tensor.memory().hostData());
            w_tensor.memory().markHostModified();
        }
        else
        {
            std::cerr << "[WARN] Failed to read reference files. Using random values.\n";
        }
    }

    // 如果读文件失败或未指定文件，使用随机值
    if(!readSuccess)
    {
        std::cout << "Using random values for initialization.\n";
        x_tensor.fillWithRandomValues(static_cast<T>(1.0f), static_cast<T>(1.0f));
        w_tensor.fillWithRandomValues(static_cast<T>(1.0f), static_cast<T>(1.0f));
    }
    // ========== 读文件初始化结束 ==========

    y_tensor.fillWithValue(static_cast<T>(0.0f));

    // 只在sbrcs模式下分配scale和bias内存
    std::unique_ptr<Tensor<T>> s_tensor = nullptr;
    std::unique_ptr<Tensor<T>> b_tensor = nullptr;
    if(fusion_mode == "sbrcs")
    {
        s_tensor = std::make_unique<Tensor<T>>(s_dim, s_stride);
        b_tensor = std::make_unique<Tensor<T>>(b_dim, b_stride);

        // 读取scale和bias文件
        if(config.file_index > 0 && !config.file_path.empty())
        {
            size_t sTotalElems = static_cast<size_t>(c);
            size_t bTotalElems = static_cast<size_t>(c);

            std::vector<T> refSData, refBData;
            const std::string sFilename
                = config.file_path + std::to_string(config.file_index) + "_scale.bin";
            const std::string bFilename
                = config.file_path + std::to_string(config.file_index) + "_bias.bin";

            bool scaleReadSuccess = readRawTensor<T>(sFilename, refSData, sTotalElems);
            bool biasReadSuccess = readRawTensor<T>(bFilename, refBData, bTotalElems);

            if(scaleReadSuccess && refSData.size() >= sTotalElems)
            {
                std::copy(refSData.begin(), refSData.end(), s_tensor->memory().hostData());
                s_tensor->memory().markHostModified();
            }
            else
            {
                s_tensor->fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
            }

            if(biasReadSuccess && refBData.size() >= bTotalElems)
            {
                std::copy(refBData.begin(), refBData.end(), b_tensor->memory().hostData());
                b_tensor->memory().markHostModified();
            }
            else
            {
                b_tensor->fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
            }
        }
        else
        {
            // 如果没有文件，使用随机值
            s_tensor->fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
            b_tensor->fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
        }
    }

    // 统计信息内存分配
    Tensor<float> sum_tensor(SUM->get_dim(), SUM->get_stride());
    Tensor<float> sq_sum_tensor(SQ_SUM->get_dim(), SQ_SUM->get_stride());
    sum_tensor.fillWithValue(0.0f);
    sq_sum_tensor.fillWithValue(0.0f);

    // 绑定张量与设备内存
    std::unordered_map<int64_t, void*> variantPack;
    variantPack[X->get_uid()] = x_tensor.memory().deviceData();
    variantPack[W->get_uid()] = w_tensor.memory().deviceData();
    variantPack[Y->get_uid()] = y_tensor.memory().deviceData();
    variantPack[SUM->get_uid()] = sum_tensor.memory().deviceData();
    variantPack[SQ_SUM->get_uid()] = sq_sum_tensor.memory().deviceData();

    // 只在sbrcs模式下添加scale和bias绑定
    if(fusion_mode == "sbrcs")
    {
        variantPack[S->get_uid()] = s_tensor->memory().deviceData();
        variantPack[B->get_uid()] = b_tensor->memory().deviceData();
    }

    // 工作空间分配
    int64_t workspace_size = 0;
    HIPDNN_FE_CHECK(graph->get_workspace_size(workspace_size));
    Workspace workspace(static_cast<size_t>(workspace_size));

    // 首次执行
    HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
    std::cout << "Graph execution complete. \n";
    y_tensor.memory().markDeviceModified();
    sum_tensor.memory().markDeviceModified();
    sq_sum_tensor.memory().markDeviceModified();

    // ========== 文件验证 ==========
    if(config.file_index > 0 && !config.file_path.empty())
    {
        std::cout << "\n=== File Validation ===\n";

        // 为参考数据创建Tensor
        Tensor<T> refYTensor(Y->get_dim(), Y->get_stride());
        Tensor<float> refSumTensor(SUM->get_dim(), SUM->get_stride());
        Tensor<float> refSqSumTensor(SQ_SUM->get_dim(), SQ_SUM->get_stride());

        // 读取参考数据
        std::vector<T> refYData;
        const std::string yFilename
            = config.file_path + std::to_string(config.file_index) + "_output.bin";
        size_t yTotalElems = 1;
        for(int64_t dim : Y->get_dim())
            yTotalElems *= static_cast<size_t>(dim);

        const std::string sumFilename
            = config.file_path + std::to_string(config.file_index) + "_sum.bin";
        std::vector<float> refSumData;

        const std::string sqSumFilename
            = config.file_path + std::to_string(config.file_index) + "_sq_sum.bin";
        std::vector<float> refSqSumData;

        // 从文件读取参考数据
        readRawTensor<T>(yFilename, refYData, yTotalElems);
        readRawTensor<float>(sumFilename, refSumData, static_cast<size_t>(k));
        readRawTensor<float>(sqSumFilename, refSqSumData, static_cast<size_t>(k));

        // 将数据复制到Tensor中
        std::copy(refYData.begin(), refYData.end(), refYTensor.memory().hostData());
        refYTensor.memory().markHostModified();
        std::copy(refSumData.begin(), refSumData.end(), refSumTensor.memory().hostData());
        refSumTensor.memory().markHostModified();
        std::copy(refSqSumData.begin(), refSqSumData.end(), refSqSumTensor.memory().hostData());
        refSqSumTensor.memory().markHostModified();

        float tolerance = 1e-2f;
        auto validator = CpuFpReferenceValidation<T>(tolerance, tolerance);

        bool yMatch = validator.allClose(refYTensor, y_tensor);
        std::cout << "Y (output): " << (yMatch ? "successful" : "failed") << "\n";

        bool sumMatch = validator.allClose(refSumTensor, sum_tensor);
        std::cout << "Sum: " << (sumMatch ? "successful" : "failed") << "\n";

        bool sqSumMatch = validator.allClose(refSqSumTensor, sq_sum_tensor);
        std::cout << "SqSum: " << (sqSumMatch ? "successful" : "failed") << "\n";
    }

    if(config.cpuValidation)
    {
        // 为参考数据创建Tensor
        Tensor<T> refYTensor(Y->get_dim(), Y->get_stride());
        Tensor<float> refSumTensor(SUM->get_dim(), SUM->get_stride());
        Tensor<float> refSqSumTensor(SQ_SUM->get_dim(), SQ_SUM->get_stride());

        if constexpr(std::is_same_v<T, int8_t>)
        {
            std::cout << "CPU validation is not supported for int8 input type.\n";
        }
        else
        {
            std::unordered_map<int64_t, void*> cpuVariantPack;
            cpuVariantPack[X->get_uid()] = x_tensor.memory().hostData();
            cpuVariantPack[W->get_uid()] = w_tensor.memory().hostData();
            cpuVariantPack[Y->get_uid()] = refYTensor.memory().hostData();
            cpuVariantPack[SUM->get_uid()] = refSumTensor.memory().hostData();
            cpuVariantPack[SQ_SUM->get_uid()] = refSqSumTensor.memory().hostData();

            // 只在sbrcs模式下添加scale和bias绑定
            if(fusion_mode == "sbrcs")
            {
                cpuVariantPack[S->get_uid()] = s_tensor->memory().hostData();
                cpuVariantPack[B->get_uid()] = b_tensor->memory().hostData();
            }

            // Execute on CPU using graph executor
            auto serializedGraph = graph->to_binary().first;
            CpuReferenceGraphExecutor cpuExecutor;
            cpuExecutor.execute(serializedGraph.data(), serializedGraph.size(), cpuVariantPack);

            float tolerance = static_cast<float>(1e-2f);

            if constexpr(std::is_same_v<T, half> || std::is_same_v<T, bfloat16>)
            {
                tolerance = 1e-2f;
            }
            CpuFpReferenceValidation<T> validator(tolerance, tolerance);

            bool yMatch = validator.allClose(refYTensor, y_tensor);
            std::cout << "Y (output): " << (yMatch ? "successful" : "failed") << "\n";

            CpuFpReferenceValidation<float> sq_validator(1e-2f, 1e-2f);
            bool sumMatch = sq_validator.allClose(refSumTensor, sum_tensor);
            std::cout << "Sum: " << (sumMatch ? "successful" : "failed") << "\n";

            bool sqSumMatch = sq_validator.allClose(refSqSumTensor, sq_sum_tensor);
            std::cout << "SqSum: " << (sqSumMatch ? "successful" : "failed") << "\n";
        }
    }

    // 计时执行
    hipEvent_t start, stop;
    float time;
    HIP_CHECK(hipDeviceSynchronize());
    HIP_CHECK(hipEventCreate(&start));
    HIP_CHECK(hipEventCreate(&stop));
    HIP_CHECK(hipEventRecord(start, nullptr));

    for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
    {
        HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
    }

    HIP_CHECK(hipEventRecord(stop, nullptr));
    HIP_CHECK(hipEventSynchronize(stop));
    HIP_CHECK(hipEventElapsedTime(&time, start, stop));
    std::cout << "conv_bn avg time " << time / static_cast<float>(100) << " ms" << std::endl;

    HIP_CHECK(hipEventDestroy(start));
    HIP_CHECK(hipEventDestroy(stop));
    HIPDNN_CHECK(backend->destroy(handle));
}

int main(int argc, char* argv[])
{
    // 打印命令行参数
    for(int i = 0; i < argc; ++i)
        std::cout << argv[i] << " ";
    std::cout << std::endl;

    // 解析配置
    Config config = parse_config(argc, argv);

    // 初始化日志
    initializeFrontendLogging();

    // 根据数据类型选择运行
    if(config.dataType == "fp16")
    {
        run_with_type<half>(config);
    }
    else if(config.dataType == "fp32")
    {
        run_with_type<float>(config);
    }
    else if(config.dataType == "bf16")
    {
        run_with_type<bfloat16>(config);
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        return 1;
    }

    return 0;
}
