#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <vector>

#include "../utils.hpp"
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>

#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// dgrad + drelu + dbn_weight 融合算子
struct Config
{
    int64_t n = 4;
    int64_t h = 16;
    int64_t w = 16;
    int64_t k = 64;
    int64_t c = 32;
    int64_t r = 3;
    int64_t s = 3;
    int64_t padH = 1;
    int64_t padW = 1;
    int64_t strideH = 1;
    int64_t strideW = 1;
    int64_t dilH = 1;
    int64_t dilW = 1;
    int64_t groups = 1;
    std::string layout = "NHWC";
    std::string dataType = "fp16";
    int file_index = 0;
    std::string file_path = "";
    bool cpuValidation = false;
};

// 命令行参数解析
Config parse_config(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
            config.n = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
            config.c = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
            config.h = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
            config.w = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-k") == 0 && i + 1 < argc)
            config.k = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-y") == 0 && i + 1 < argc)
            config.r = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-x") == 0 && i + 1 < argc)
            config.s = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-p") == 0 && i + 1 < argc)
            config.padH = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc)
            config.padW = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-u") == 0 && i + 1 < argc)
            config.strideH = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-v") == 0 && i + 1 < argc)
            config.strideW = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-l") == 0 && i + 1 < argc)
            config.dilH = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-j") == 0 && i + 1 < argc)
            config.dilW = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-g") == 0 && i + 1 < argc)
            config.groups = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
            config.file_index = std::stoi(argv[++i]);
        else if(strcmp(argv[i], "-o") == 0 && i + 1 < argc)
            config.file_path = argv[++i];
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

// 配置合法性校验
void validate_config(const Config& config)
{
    if(config.layout != "NHWC" && config.layout != "NCHW")
    {
        std::cerr << "Unsupported layout: " << config.layout << ", use NHWC/NCHW" << std::endl;
        exit(1);
    }
    if(config.dataType != "fp16" && config.dataType != "fp32" && config.dataType != "bf16")
    {
        std::cerr << "Unsupported data type: " << config.dataType << ", use fp16/fp32/bf16"
                  << std::endl;
        exit(1);
    }
    if(config.c % config.groups != 0)
    {
        std::cerr << "Input channels must be divisible by groups" << std::endl;
        exit(1);
    }
    if(config.k % config.groups != 0)
    {
        std::cerr << "Output channels must be divisible by groups" << std::endl;
        exit(1);
    }
}

// hipDNN数据类型映射
DataType getDataTypeEnum(const std::string& dtype)
{
    if(dtype == "fp16")
        return DataType::HALF;
    else if(dtype == "fp32")
        return DataType::FLOAT;
    else if(dtype == "bf16")
        return DataType::BFLOAT16;
    else
    {
        std::cerr << "Unsupported data type: " << dtype << std::endl;
        exit(1);
    }
}

template <typename T>
void printFirstNElements(const Tensor<T>& tensor, size_t n, const std::string& name)
{
    std::cout << name << " first " << n << " elements: ";
    const T* data = tensor.memory().hostData();
    size_t total = tensor.get_dim().totalSize();
    for(size_t i = 0; i < std::min(n, total); ++i)
    {
        std::cout << data[i] << " ";
    }
    std::cout << std::endl;
}

template <typename T>
void run_with_type(const Config& config)
{
    int64_t n = config.n;
    int64_t c = config.c;
    int64_t h = config.h;
    int64_t w = config.w;
    int64_t k = config.k;
    int64_t r = config.r;
    int64_t s = config.s;
    int64_t padH = config.padH;
    int64_t padW = config.padW;
    int64_t strideH = config.strideH;
    int64_t strideW = config.strideW;
    int64_t dilH = config.dilH;
    int64_t dilW = config.dilW;
    int64_t groups = config.groups;
    std::string layout = config.layout;

    int64_t h_out = (h + 2 * padH - dilH * (r - 1) - 1) / strideH + 1;
    int64_t w_out = (w + 2 * padW - dilW * (s - 1) - 1) / strideW + 1;

    // 张量维度/步长定义
    std::vector<int64_t> dy_dim, dy_stride;
    std::vector<int64_t> w_dim, w_stride;
    std::vector<int64_t> x_dim, x_stride;
    std::vector<int64_t> bn_param_dim;
    std::vector<int64_t> bn_param_stride;

    dy_dim = {n, k, h_out, w_out};
    w_dim = {k, c / groups, r, s};
    x_dim = {n, c, h, w};
    bn_param_dim = {1, c, 1, 1};

    if(layout == "NHWC")
    {
        dy_stride = {k * h_out * w_out, 1, k * w_out, k};
        w_stride = {(c / groups) * r * s, 1, (c / groups) * s, (c / groups)};
        x_stride = {c * h * w, 1, c * w, c};
        bn_param_stride = {c, 1, c, c};
    }
    else
    {
        dy_stride = {k * h_out * w_out, h_out * w_out, w_out, 1};
        w_stride = {(c / groups) * r * s, r * s, s, 1};
        x_stride = {c * h * w, h * w, w, 1};
        bn_param_stride = {c, 1, 1, 1};
    }

    // 构建计算图：dgrad + drelu + dbn_weight
    auto build_backward_graph = [=](hipdnnHandle_t handle) {
        auto graph = std::make_shared<graph::Graph>();
        graph->set_name("dgrad_drelu_dbn_weight")
            .set_io_data_type(getDataTypeEnum(config.dataType))
            .set_intermediate_data_type(DataType::FLOAT)
            .set_compute_data_type(DataType::FLOAT);

        auto DY = graph->tensor(
            graph::Tensor_attributes().set_name("grad").set_dim(dy_dim).set_stride(dy_stride));
        auto W = graph->tensor(
            graph::Tensor_attributes().set_name("weight").set_dim(w_dim).set_stride(w_stride));
        auto X = graph->tensor(
            graph::Tensor_attributes().set_name("image").set_dim(x_dim).set_stride(x_stride));
        auto M = graph->tensor(graph::Tensor_attributes()
                                   .set_name("mean")
                                   .set_dim(bn_param_dim)
                                   .set_stride(bn_param_stride)
                                   .set_data_type(DataType::FLOAT));
        auto V = graph->tensor(graph::Tensor_attributes()
                                   .set_name("inv_var")
                                   .set_dim(bn_param_dim)
                                   .set_stride(bn_param_stride)
                                   .set_data_type(DataType::FLOAT));
        auto S = graph->tensor(graph::Tensor_attributes()
                                   .set_name("scale")
                                   .set_dim(bn_param_dim)
                                   .set_stride(bn_param_stride)
                                   .set_data_type(DataType::FLOAT));
        auto B = graph->tensor(graph::Tensor_attributes()
                                   .set_name("bias")
                                   .set_dim(bn_param_dim)
                                   .set_stride(bn_param_stride)
                                   .set_data_type(DataType::FLOAT));

        // dgrad
        auto dgrad_options = graph::Conv_dgrad_attributes()
                                 .set_padding({padH, padW})
                                 .set_stride({strideH, strideW})
                                 .set_dilation({dilH, dilW});
        auto dgrad_output = graph->conv_dgrad(DY, W, dgrad_options);
        dgrad_output->set_dim(x_dim);

        // BN反向逐点运算
        auto sub_out
            = graph->pointwise(X, M, graph::Pointwise_attributes().set_mode(PointwiseMode_t::SUB));
        auto mulv_out = graph->pointwise(
            sub_out, V, graph::Pointwise_attributes().set_mode(PointwiseMode_t::MUL));
        auto muls_out = graph->pointwise(
            mulv_out, S, graph::Pointwise_attributes().set_mode(PointwiseMode_t::MUL));
        auto addb_out = graph->pointwise(
            muls_out, B, graph::Pointwise_attributes().set_mode(PointwiseMode_t::ADD));

        // drelu
        auto drelu_output
            = graph->pointwise(dgrad_output,
                               addb_out,
                               graph::Pointwise_attributes().set_mode(PointwiseMode_t::RELU_BWD));
        drelu_output->set_output(true);

        // dbn_weight 5个输出
        auto [dscale, dbias, eq_scale_dy, eq_scale_x, eq_bias] = graph->dbn_weight(
            drelu_output, X, M, V, S, graph::BatchnormBackwardWeightAttributes());

        dscale->set_output(true).set_data_type(DataType::FLOAT);
        dbias->set_output(true).set_data_type(DataType::FLOAT);
        eq_scale_dy->set_output(true).set_data_type(DataType::FLOAT);
        eq_scale_x->set_output(true).set_data_type(DataType::FLOAT);
        eq_bias->set_output(true).set_data_type(DataType::FLOAT);

        HIPDNN_FE_CHECK(graph->build(handle));
        return std::make_tuple(graph,
                               DY,
                               W,
                               X,
                               M,
                               V,
                               S,
                               B,
                               drelu_output,
                               dscale,
                               dbias,
                               eq_scale_dy,
                               eq_scale_x,
                               eq_bias);
    };

    // 初始化hipDNN
    auto backend = hipdnn_frontend::detail::hipdnnBackend();
    if(!backend)
    {
        std::cerr << "Backend create failed!" << std::endl;
        return;
    }
    hipdnnHandle_t handle;
    HIPDNN_CHECK(backend->create(&handle));

    // 构建图
    auto [graph, DY, W, X, M, V, S, B, drelu_out, dscale, dbias, eq_scale_dy, eq_scale_x, eq_bias]
        = build_backward_graph(handle);

    // ===================== 内存分配 =====================
    Tensor<T> dy_tensor(dy_dim, dy_stride);
    Tensor<T> w_tensor(w_dim, w_stride);
    Tensor<T> x_tensor(x_dim, x_stride);
    Tensor<float> m_tensor(bn_param_dim, bn_param_stride);
    Tensor<float> v_tensor(bn_param_dim, bn_param_stride);
    Tensor<float> s_tensor(bn_param_dim, bn_param_stride);
    Tensor<float> b_tensor(bn_param_dim, bn_param_stride);

    Tensor<T> drelu_tensor(drelu_out->get_dim(), drelu_out->get_stride());
    Tensor<float> dscale_tensor(dscale->get_dim(), dscale->get_stride());
    Tensor<float> dbias_tensor(dbias->get_dim(), dbias->get_stride());
    Tensor<float> eq_dy_tensor(eq_scale_dy->get_dim(), eq_scale_dy->get_stride());
    Tensor<float> eq_x_tensor(eq_scale_x->get_dim(), eq_scale_x->get_stride());
    Tensor<float> eq_bias_tensor(eq_bias->get_dim(), eq_bias->get_stride());

    // ===================== 读取参考文件初始化 =====================
    bool readSuccess = false;
    size_t dy_elem = static_cast<size_t>(n * k * h_out * w_out);
    size_t w_elem = static_cast<size_t>(k * (c / groups) * r * s);
    size_t x_elem = static_cast<size_t>(n * c * h * w);
    size_t bn_elem = static_cast<size_t>(c);
    size_t out_elem = static_cast<size_t>(n * c * h * w);
    if(config.file_index > 0 && !config.file_path.empty())
    {
        std::string base = config.file_path + "/" + std::to_string(config.file_index);

        std::vector<T> ref_dy, ref_w, ref_x;
        std::vector<float> ref_m, ref_v, ref_s, ref_b;

        bool dy_ok = readRawTensor<T>(base + "_dy.bin", ref_dy, dy_elem);
        bool w_ok = readRawTensor<T>(base + "_w.bin", ref_w, w_elem);
        bool x_ok = readRawTensor<T>(base + "_x.bin", ref_x, x_elem);
        bool m_ok = readRawTensor<float>(base + "_mean.bin", ref_m, bn_elem);
        bool v_ok = readRawTensor<float>(base + "_inv_var.bin", ref_v, bn_elem);
        bool s_ok = readRawTensor<float>(base + "_scale.bin", ref_s, bn_elem);
        bool b_ok = readRawTensor<float>(base + "_bias.bin", ref_b, bn_elem);

        readSuccess = dy_ok && w_ok && x_ok && m_ok && v_ok && s_ok && b_ok;

        if(readSuccess)
        {
            std::cout << "Successfully read input reference files!" << std::endl;
            std::copy(ref_dy.begin(), ref_dy.end(), dy_tensor.memory().hostData());
            std::copy(ref_w.begin(), ref_w.end(), w_tensor.memory().hostData());
            std::copy(ref_x.begin(), ref_x.end(), x_tensor.memory().hostData());
            std::copy(ref_m.begin(), ref_m.end(), m_tensor.memory().hostData());
            std::copy(ref_v.begin(), ref_v.end(), v_tensor.memory().hostData());
            std::copy(ref_s.begin(), ref_s.end(), s_tensor.memory().hostData());
            std::copy(ref_b.begin(), ref_b.end(), b_tensor.memory().hostData());

            dy_tensor.memory().markHostModified();
            w_tensor.memory().markHostModified();
            x_tensor.memory().markHostModified();
            m_tensor.memory().markHostModified();
            v_tensor.memory().markHostModified();
            s_tensor.memory().markHostModified();
            b_tensor.memory().markHostModified();
        }
        else
        {
            std::cerr << "[WARN] Read input files failed, use random values!" << std::endl;
        }
    }

    // 读取失败则用随机值初始化
    if(!readSuccess)
    {
        dy_tensor.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
        w_tensor.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
        x_tensor.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
        m_tensor.fillWithRandomValues(0.1f, 1.0f);
        v_tensor.fillWithRandomValues(0.1f, 1.0f);
        s_tensor.fillWithRandomValues(0.1f, 1.0f);
        b_tensor.fillWithRandomValues(0.1f, 1.0f);
    }

    // 绑定设备内存
    std::unordered_map<int64_t, void*> variantPack;
    variantPack[DY->get_uid()] = dy_tensor.memory().deviceData();
    variantPack[W->get_uid()] = w_tensor.memory().deviceData();
    variantPack[X->get_uid()] = x_tensor.memory().deviceData();
    variantPack[M->get_uid()] = m_tensor.memory().deviceData();
    variantPack[V->get_uid()] = v_tensor.memory().deviceData();
    variantPack[S->get_uid()] = s_tensor.memory().deviceData();
    variantPack[B->get_uid()] = b_tensor.memory().deviceData();
    variantPack[drelu_out->get_uid()] = drelu_tensor.memory().deviceData();
    variantPack[dscale->get_uid()] = dscale_tensor.memory().deviceData();
    variantPack[dbias->get_uid()] = dbias_tensor.memory().deviceData();
    variantPack[eq_scale_dy->get_uid()] = eq_dy_tensor.memory().deviceData();
    variantPack[eq_scale_x->get_uid()] = eq_x_tensor.memory().deviceData();
    variantPack[eq_bias->get_uid()] = eq_bias_tensor.memory().deviceData();

    // 工作空间
    int64_t workspace_size = 0;
    HIPDNN_FE_CHECK(graph->get_workspace_size(workspace_size));
    Workspace workspace(static_cast<size_t>(workspace_size));

    // 首次执行
    HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));

    drelu_tensor.memory().markDeviceModified();
    dscale_tensor.memory().markDeviceModified();
    dbias_tensor.memory().markDeviceModified();
    eq_dy_tensor.memory().markDeviceModified();
    eq_x_tensor.memory().markDeviceModified();
    eq_bias_tensor.memory().markDeviceModified();
    std::cout << "Graph execution successful!" << std::endl;

    // ===================== 文件参考验证 =====================
    auto printFirstNElements = [&](const auto& tensor, size_t total, const std::string& name) {
        std::cout << name << " first 10 elements: ";
        const auto* data = tensor.memory().hostData();
        size_t n = std::min<size_t>(10, total);
        for(size_t i = 0; i < n; ++i)
        {
            std::cout << data[i] << " ";
        }
        std::cout << std::endl;
    };

    if(config.file_index > 0 && !config.file_path.empty())
    {
        std::cout << "\n=== File Reference Validation ===" << std::endl;
        std::string base = config.file_path + "/" + std::to_string(config.file_index);

        // 创建用于存放参考数据的 Tensor 对象
        Tensor<T> ref_drelu(drelu_out->get_dim(), drelu_out->get_stride());
        Tensor<float> ref_dscale(dscale->get_dim(), dscale->get_stride());
        Tensor<float> ref_dbias(dbias->get_dim(), dbias->get_stride());
        Tensor<float> ref_eq_dy(eq_scale_dy->get_dim(), eq_scale_dy->get_stride());
        Tensor<float> ref_eq_x(eq_scale_x->get_dim(), eq_scale_x->get_stride());
        Tensor<float> ref_eq_bias(eq_bias->get_dim(), eq_bias->get_stride());

        // 从文件读取原始数据到 vector
        std::vector<T> ref_drelu_data;
        std::vector<float> ref_dscale_data, ref_dbias_data, ref_eq_dy_data, ref_eq_x_data,
            ref_eq_bias_data;

        readRawTensor<T>(base + "_drelu.bin", ref_drelu_data, out_elem);
        readRawTensor<float>(base + "_dscale.bin", ref_dscale_data, bn_elem);
        readRawTensor<float>(base + "_dbias.bin", ref_dbias_data, bn_elem);
        readRawTensor<float>(base + "_eq_scale_dy.bin", ref_eq_dy_data, bn_elem);
        readRawTensor<float>(base + "_eq_scale_x.bin", ref_eq_x_data, bn_elem);
        readRawTensor<float>(base + "_eq_bias.bin", ref_eq_bias_data, bn_elem);

        // 将数据拷贝到 Tensor 的 host 内存中
        std::copy(ref_drelu_data.begin(), ref_drelu_data.end(), ref_drelu.memory().hostData());
        std::copy(ref_dscale_data.begin(), ref_dscale_data.end(), ref_dscale.memory().hostData());
        std::copy(ref_dbias_data.begin(), ref_dbias_data.end(), ref_dbias.memory().hostData());
        std::copy(ref_eq_dy_data.begin(), ref_eq_dy_data.end(), ref_eq_dy.memory().hostData());
        std::copy(ref_eq_x_data.begin(), ref_eq_x_data.end(), ref_eq_x.memory().hostData());
        std::copy(
            ref_eq_bias_data.begin(), ref_eq_bias_data.end(), ref_eq_bias.memory().hostData());

        // 创建验证器
        auto validator = CpuFpReferenceValidation<T>(1e-2f, 1e-2f);
        auto validator_fp32 = CpuFpReferenceValidation<float>(1e-2f, 1e-2f);

        // drelu
        bool drelu_ok = validator.allClose(ref_drelu, drelu_tensor);
        std::cout << "drelu: " << (drelu_ok ? "successful" : "failed") << std::endl;
        if(!drelu_ok)
        {
            printFirstNElements(ref_drelu, out_elem, "ref_drelu");
            printFirstNElements(drelu_tensor, out_elem, "drelu_tensor");
        }

        // dscale
        bool dscale_ok = validator_fp32.allClose(ref_dscale, dscale_tensor);
        std::cout << "dscale: " << (dscale_ok ? "successful" : "failed") << std::endl;
        if(!dscale_ok)
        {
            printFirstNElements(ref_dscale, bn_elem, "ref_dscale");
            printFirstNElements(dscale_tensor, bn_elem, "dscale_tensor");
        }

        // dbias
        bool dbias_ok = validator_fp32.allClose(ref_dbias, dbias_tensor);
        std::cout << "dbias: " << (dbias_ok ? "successful" : "failed") << std::endl;
        if(!dbias_ok)
        {
            printFirstNElements(ref_dbias, bn_elem, "ref_dbias");
            printFirstNElements(dbias_tensor, bn_elem, "dbias_tensor");
        }

        // eq_scale_dy
        bool eq_dy_ok = validator_fp32.allClose(ref_eq_dy, eq_dy_tensor);
        std::cout << "eq_scale_dy: " << (eq_dy_ok ? "successful" : "failed") << std::endl;
        if(!eq_dy_ok)
        {
            printFirstNElements(ref_eq_dy, bn_elem, "ref_eq_dy");
            printFirstNElements(eq_dy_tensor, bn_elem, "eq_dy_tensor");
        }

        // eq_scale_x
        bool eq_x_ok = validator_fp32.allClose(ref_eq_x, eq_x_tensor);
        std::cout << "eq_scale_x: " << (eq_x_ok ? "successful" : "failed") << std::endl;
        if(!eq_x_ok)
        {
            printFirstNElements(ref_eq_x, bn_elem, "ref_eq_x");
            printFirstNElements(eq_x_tensor, bn_elem, "eq_x_tensor");
        }

        // eq_bias
        bool eq_bias_ok = validator_fp32.allClose(ref_eq_bias, eq_bias_tensor);
        std::cout << "eq_bias: " << (eq_bias_ok ? "successful" : "failed") << std::endl;
        if(!eq_bias_ok)
        {
            printFirstNElements(ref_eq_bias, bn_elem, "ref_eq_bias");
            printFirstNElements(eq_bias_tensor, bn_elem, "eq_bias_tensor");
        }
    }

    // ===================== CPU参考验证 =====================
    if(config.cpuValidation)
    {
        std::cout << "\n=== CPU Reference Validation ===" << std::endl;

        Tensor<T> cpu_drelu(drelu_out->get_dim(), drelu_out->get_stride());
        Tensor<float> cpu_dscale(dscale->get_dim(), dscale->get_stride());
        Tensor<float> cpu_dbias(dbias->get_dim(), dbias->get_stride());
        Tensor<float> cpu_eq_dy(eq_scale_dy->get_dim(), eq_scale_dy->get_stride());
        Tensor<float> cpu_eq_x(eq_scale_x->get_dim(), eq_scale_x->get_stride());
        Tensor<float> cpu_eq_bias(eq_bias->get_dim(), eq_bias->get_stride());

        std::unordered_map<int64_t, void*> cpu_variant;
        cpu_variant[DY->get_uid()] = dy_tensor.memory().hostData();
        cpu_variant[W->get_uid()] = w_tensor.memory().hostData();
        cpu_variant[X->get_uid()] = x_tensor.memory().hostData();
        cpu_variant[M->get_uid()] = m_tensor.memory().hostData();
        cpu_variant[V->get_uid()] = v_tensor.memory().hostData();
        cpu_variant[S->get_uid()] = s_tensor.memory().hostData();
        cpu_variant[B->get_uid()] = b_tensor.memory().hostData();
        cpu_variant[drelu_out->get_uid()] = cpu_drelu.memory().hostData();
        cpu_variant[dscale->get_uid()] = cpu_dscale.memory().hostData();
        cpu_variant[dbias->get_uid()] = cpu_dbias.memory().hostData();
        cpu_variant[eq_scale_dy->get_uid()] = cpu_eq_dy.memory().hostData();
        cpu_variant[eq_scale_x->get_uid()] = cpu_eq_x.memory().hostData();
        cpu_variant[eq_bias->get_uid()] = cpu_eq_bias.memory().hostData();

        auto graph_buf = graph->to_binary().first;
        CpuReferenceGraphExecutor cpu_exec;
        cpu_exec.execute(graph_buf.data(), graph_buf.size(), cpu_variant);

        // 根据数据类型选择容差
        float tol = 1e-2f;
        if(std::is_same<T, half>::value || std::is_same<T, bfloat16>::value)
        {
            tol = 1e-2f;
        }
        auto validator_float = CpuFpReferenceValidation<float>(tol, tol);
        auto validator_type = CpuFpReferenceValidation<T>(tol, tol);

        std::cout << "drelu: "
                  << (validator_type.allClose(cpu_drelu, drelu_tensor) ? "successful" : "failed")
                  << std::endl;
        std::cout << "dscale: "
                  << (validator_float.allClose(cpu_dscale, dscale_tensor) ? "successful" : "failed")
                  << std::endl;
        std::cout << "dbias: "
                  << (validator_float.allClose(cpu_dbias, dbias_tensor) ? "successful" : "failed")
                  << std::endl;
        std::cout << "eq_dy: "
                  << (validator_float.allClose(cpu_eq_dy, eq_dy_tensor) ? "successful" : "failed")
                  << std::endl;
        std::cout << "eq_x: "
                  << (validator_float.allClose(cpu_eq_x, eq_x_tensor) ? "successful" : "failed")
                  << std::endl;
        std::cout << "eq_bias: "
                  << (validator_float.allClose(cpu_eq_bias, eq_bias_tensor) ? "successful"
                                                                            : "failed")
                  << std::endl;
    }

    // ===================== 性能计时 =====================
    hipEvent_t start, stop;
    float total_time;
    HIP_CHECK(hipEventCreate(&start));
    HIP_CHECK(hipEventCreate(&stop));
    HIP_CHECK(hipDeviceSynchronize());
    HIP_CHECK(hipEventRecord(start));

    for(int i = 0; i < 100; i++)
    {
        HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
    }

    HIP_CHECK(hipEventRecord(stop));
    HIP_CHECK(hipEventSynchronize(stop));
    HIP_CHECK(hipEventElapsedTime(&total_time, start, stop));

    std::cout << "\n========== Performance ==========" << std::endl;
    std::cout << "Avg time: " << total_time / 100 << " ms" << std::endl;

    // 资源释放
    HIP_CHECK(hipEventDestroy(start));
    HIP_CHECK(hipEventDestroy(stop));
    HIPDNN_CHECK(backend->destroy(handle));
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; i++)
        std::cout << argv[i] << " ";
    std::cout << std::endl;

    Config config = parse_config(argc, argv);
    validate_config(config);

    if(config.dataType == "fp16")
    {
        run_with_type<half>(config);
    }
    else if(config.dataType == "fp32")
    {
        run_with_type<float>(config);
    }
    else if(config.dataType == "bf16")
    {
        run_with_type<bfloat16>(config);
    }
    else
    {
        std::cerr << "Unsupported dtype!" << std::endl;
        return 1;
    }

    return 0;
}
