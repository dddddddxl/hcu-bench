#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <vector>

#include "../utils.hpp"
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>

#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

struct Config
{
    int64_t n = 1;
    int64_t c = 64;
    int64_t h = 32;
    int64_t w = 32;
    std::string layout = "NHWC";
    std::string dataType = "fp32";
    int file_index = 0;
    std::string file_path = "";
    bool cpuValidation = false;
};

// ===================== 命令行解析 =====================
Config parse_config(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
            config.n = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
            config.c = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
            config.h = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
            config.w = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
            config.file_index = std::stoi(argv[++i]);
        else if(strcmp(argv[i], "-o") == 0 && i + 1 < argc)
            config.file_path = argv[++i];
        else if(strcmp(argv[i], "--cpu-validation") == 0)
            config.cpuValidation = true;
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

// ===================== 配置合法性校验 =====================
void validate_config(const Config& config)
{
    if(config.layout != "NHWC" && config.layout != "NCHW")
    {
        std::cerr << "Unsupported layout: " << config.layout << ", use NHWC/NCHW" << std::endl;
        exit(1);
    }
    if(config.dataType != "fp16" && config.dataType != "fp32" && config.dataType != "bf16")
    {
        std::cerr << "Unsupported data type: " << config.dataType << ", use fp16/fp32/bf16"
                  << std::endl;
        exit(1);
    }
}

// ===================== 数据类型映射 =====================
DataType getDataTypeEnum(const std::string& dtype)
{
    if(dtype == "fp16")
        return DataType::HALF;
    else if(dtype == "fp32")
        return DataType::FLOAT;
    else if(dtype == "bf16")
        return DataType::BFLOAT16;
    else
    {
        std::cerr << "Unsupported data type: " << dtype << std::endl;
        exit(1);
    }
}

template <typename T>
void run_with_type(const Config& config)
{
    int64_t n = config.n;
    int64_t c = config.c;
    int64_t h = config.h;
    int64_t w = config.w;
    std::string layout = config.layout;

    // ---------- 定义张量维度和步长 ----------
    std::vector<int64_t> x_dim = {n, c, h, w};
    std::vector<int64_t> scale_bias_dim = {1, c, 1, 1};

    std::vector<int64_t> x_stride, scale_bias_stride;
    if(layout == "NHWC")
    {
        x_stride = {c * h * w, 1, c * w, c};
        scale_bias_stride = {c, 1, c, c};
    }
    else // NCHW
    {
        x_stride = {c * h * w, h * w, w, 1};
        scale_bias_stride = {c, 1, 1, 1};
    }

    // ---------- y = (x * scale) + bias ----------
    auto build_graph = [=](hipdnnHandle_t handle) {
        auto graph = std::make_shared<graph::Graph>();
        graph->set_name("scale_bias_graph")
            .set_io_data_type(getDataTypeEnum(config.dataType))
            .set_intermediate_data_type(DataType::FLOAT)
            .set_compute_data_type(DataType::FLOAT);

        auto x = graph->tensor(
            graph::Tensor_attributes().set_name("x").set_dim(x_dim).set_stride(x_stride));
        auto scale = graph->tensor(graph::Tensor_attributes()
                                       .set_name("scale")
                                       .set_dim(scale_bias_dim)
                                       .set_stride(scale_bias_stride));
        auto bias = graph->tensor(graph::Tensor_attributes()
                                      .set_name("bias")
                                      .set_dim(scale_bias_dim)
                                      .set_stride(scale_bias_stride));

        auto mul_out = graph->pointwise(
            x, scale, graph::Pointwise_attributes().set_mode(PointwiseMode::MUL).set_name("mul"));
        auto y = graph->pointwise(
            mul_out,
            bias,
            graph::Pointwise_attributes().set_mode(PointwiseMode::ADD).set_name("add"));
        y->set_output(true);

        HIPDNN_FE_CHECK(graph->build(handle));
        return std::make_tuple(graph, x, scale, bias, y);
    };

    // ---------- 初始化 hipDNN ----------
    auto backend = hipdnn_frontend::detail::hipdnnBackend();
    if(!backend)
    {
        std::cerr << "Backend create failed!" << std::endl;
        return;
    }
    hipdnnHandle_t handle;
    HIPDNN_CHECK(backend->create(&handle));

    auto [graph, x, scale, bias, y] = build_graph(handle);

    // ---------- 分配主机/设备内存 ----------
    Tensor<T> x_tensor(x_dim, x_stride);
    Tensor<T> scale_tensor(scale_bias_dim, scale_bias_stride);
    Tensor<T> bias_tensor(scale_bias_dim, scale_bias_stride);
    Tensor<T> y_tensor(y->get_dim(), y->get_stride());

    // ---------- 初始化数据（随机或从文件读取）----------
    bool readSuccess = false;
    size_t x_elem = static_cast<size_t>(n * c * h * w);
    size_t scale_bias_elem = static_cast<size_t>(c); // 实际元素个数为 c

    if(config.file_index > 0 && !config.file_path.empty())
    {
        std::string base = config.file_path + "/" + std::to_string(config.file_index);
        std::vector<T> ref_x, ref_scale, ref_bias;

        bool x_ok = readRawTensor<T>(base + "_x.bin", ref_x, x_elem);
        bool scale_ok = readRawTensor<T>(base + "_scale.bin", ref_scale, scale_bias_elem);
        bool bias_ok = readRawTensor<T>(base + "_bias.bin", ref_bias, scale_bias_elem);
        readSuccess = x_ok && scale_ok && bias_ok;

        if(readSuccess)
        {
            std::cout << "Successfully read input reference files!" << std::endl;
            std::copy(ref_x.begin(), ref_x.end(), x_tensor.memory().hostData());
            std::copy(ref_scale.begin(), ref_scale.end(), scale_tensor.memory().hostData());
            std::copy(ref_bias.begin(), ref_bias.end(), bias_tensor.memory().hostData());

            x_tensor.memory().markHostModified();
            scale_tensor.memory().markHostModified();
            bias_tensor.memory().markHostModified();
        }
        else
        {
            std::cerr << "[WARN] Read input files failed, use random values!" << std::endl;
        }
    }

    if(!readSuccess)
    {
        x_tensor.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
        scale_tensor.fillWithRandomValues(static_cast<T>(0.1f), static_cast<T>(1.0f));
        bias_tensor.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(0.5f));
    }

    // ---------- variant pack ----------
    std::unordered_map<int64_t, void*> variantPack;
    variantPack[x->get_uid()] = x_tensor.memory().deviceData();
    variantPack[scale->get_uid()] = scale_tensor.memory().deviceData();
    variantPack[bias->get_uid()] = bias_tensor.memory().deviceData();
    variantPack[y->get_uid()] = y_tensor.memory().deviceData();

    // ---------- 工作空间 ----------
    int64_t workspace_size = 0;
    HIPDNN_FE_CHECK(graph->get_workspace_size(workspace_size));
    Workspace workspace(static_cast<size_t>(workspace_size));

    // ---------- 首次执行 ----------
    HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
    y_tensor.memory().markDeviceModified();
    std::cout << "Graph execution successful!" << std::endl;

    // ---------- 文件参考验证 ----------
    if(config.file_index > 0 && !config.file_path.empty())
    {
        std::cout << "\n=== File Reference Validation ===" << std::endl;
        std::string base = config.file_path + "/" + std::to_string(config.file_index);

        Tensor<T> ref_y(y->get_dim(), y->get_stride());
        std::vector<T> ref_y_data;
        bool y_ok = readRawTensor<T>(base + "_y.bin", ref_y_data, x_elem);
        if(y_ok)
        {
            std::copy(ref_y_data.begin(), ref_y_data.end(), ref_y.memory().hostData());
            float tol = 1e-2f;
            auto validator = CpuFpReferenceValidation<T>(tol, tol);
            std::cout << "y: " << (validator.allClose(ref_y, y_tensor) ? "successful" : "failed")
                      << std::endl;
        }
        else
        {
            std::cerr << "[WARN] Reference output file not found, skip file validation."
                      << std::endl;
        }
    }

    // ---------- CPU 参考验证 ----------
    if(config.cpuValidation)
    {
        std::cout << "\n=== CPU Reference Validation ===" << std::endl;
        Tensor<T> cpu_y(y->get_dim(), y->get_stride());

        std::unordered_map<int64_t, void*> cpu_variant;
        cpu_variant[x->get_uid()] = x_tensor.memory().hostData();
        cpu_variant[scale->get_uid()] = scale_tensor.memory().hostData();
        cpu_variant[bias->get_uid()] = bias_tensor.memory().hostData();
        cpu_variant[y->get_uid()] = cpu_y.memory().hostData();

        auto [graph_buf, buf_size] = graph->to_binary();
        CpuReferenceGraphExecutor cpu_exec;
        cpu_exec.execute(graph_buf.data(), graph_buf.size(), cpu_variant);
        float tol = 1e-2f;
        auto validator = CpuFpReferenceValidation<T>(tol, tol);
        std::cout << "y: " << (validator.allClose(cpu_y, y_tensor) ? "successful" : "failed")
                  << std::endl;
    }

    // ---------- 性能测量 ----------
    hipEvent_t start, stop;
    float total_time;
    HIP_CHECK(hipEventCreate(&start));
    HIP_CHECK(hipEventCreate(&stop));
    HIP_CHECK(hipDeviceSynchronize());
    HIP_CHECK(hipEventRecord(start));

    const int iterations = 100;
    for(int i = 0; i < iterations; ++i)
    {
        HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
    }

    HIP_CHECK(hipEventRecord(stop));
    HIP_CHECK(hipEventSynchronize(stop));
    HIP_CHECK(hipEventElapsedTime(&total_time, start, stop));

    std::cout << "\n========== Performance ==========" << std::endl;
    std::cout << "Avg time: " << total_time / iterations << " ms" << std::endl;

    // ---------- 清理 ----------
    HIP_CHECK(hipEventDestroy(start));
    HIP_CHECK(hipEventDestroy(stop));
    HIPDNN_CHECK(backend->destroy(handle));
}

// ===================== 主函数 =====================
int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
        std::cout << argv[i] << " ";
    std::cout << std::endl;

    Config config = parse_config(argc, argv);
    validate_config(config);

    if(config.dataType == "fp16")
    {
        run_with_type<half>(config);
    }
    else if(config.dataType == "fp32")
    {
        run_with_type<float>(config);
    }
    else if(config.dataType == "bf16")
    {
        run_with_type<bfloat16>(config);
    }
    else
    {
        std::cerr << "Unsupported dtype!" << std::endl;
        return 1;
    }

    return 0;
}
