#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <vector>

#include "../utils.hpp"
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>

#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

struct Config
{
    int64_t n = 1;
    int64_t c = 4;
    int64_t h = 32;
    int64_t w = 32;
    std::string dataType = "fp32";
    int file_index = 0;
    std::string file_path = "";
    bool cpuValidation = false;
};

Config parse_config(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
            config.n = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
            config.c = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
            config.h = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
            config.w = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
            config.file_index = std::stoi(argv[++i]);
        else if(strcmp(argv[i], "-o") == 0 && i + 1 < argc)
            config.file_path = argv[++i];
        else if(strcmp(argv[i], "--cpu-validation") == 0)
            config.cpuValidation = true;
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

void validate_config(const Config& config)
{
    // 新增 "bf16"
    if(config.dataType != "fp16" && config.dataType != "fp32" && config.dataType != "bf16")
    {
        std::cerr << "Unsupported data type: " << config.dataType << ", use fp16/fp32/bf16"
                  << std::endl;
        exit(1);
    }
}

DataType getDataTypeEnum(const std::string& dtype)
{
    if(dtype == "fp16")
        return DataType::HALF;
    else if(dtype == "fp32")
        return DataType::FLOAT;
    else if(dtype == "bf16")
        return DataType::BFLOAT16;
    else
    {
        std::cerr << "Unsupported data type: " << dtype << std::endl;
        exit(1);
    }
}

void run_mixed_precision(const Config& config)
{
    int64_t n = config.n;
    int64_t c = config.c;
    int64_t h = config.h;
    int64_t w = config.w;
    bool is_fp16 = (config.dataType == "fp16");
    bool is_bf16 = (config.dataType == "bf16");

    auto build_graph = [&](hipdnnHandle_t handle) {
        auto graph = std::make_shared<graph::Graph>();
        graph->set_name("mul_mul_add_add_graph")
            .set_io_data_type(getDataTypeEnum(config.dataType))
            .set_intermediate_data_type(DataType::FLOAT)
            .set_compute_data_type(DataType::FLOAT);

        auto x0 = graph->tensor(graph::Tensor_attributes()
                                    .set_name("x0")
                                    .set_dim({n, c, h, w})
                                    .set_stride({c * h * w, 1, c * w, c})
                                    .set_data_type(getDataTypeEnum(config.dataType)));
        auto x1 = graph->tensor(graph::Tensor_attributes()
                                    .set_name("x1")
                                    .set_dim({n, c, h, w})
                                    .set_stride({c * h * w, 1, c * w, c})
                                    .set_data_type(getDataTypeEnum(config.dataType)));
        auto scale0 = graph->tensor(graph::Tensor_attributes()
                                        .set_name("scale0")
                                        .set_dim({1, c, 1, 1})
                                        .set_stride({c, 1, c, c})
                                        .set_data_type(DataType::FLOAT));
        auto scale1 = graph->tensor(graph::Tensor_attributes()
                                        .set_name("scale1")
                                        .set_dim({1, c, 1, 1})
                                        .set_stride({c, 1, c, c})
                                        .set_data_type(DataType::FLOAT));
        auto bias = graph->tensor(graph::Tensor_attributes()
                                      .set_name("bias")
                                      .set_dim({1, c, 1, 1})
                                      .set_stride({c, 1, c, c})
                                      .set_data_type(DataType::FLOAT));

        auto mul0 = graph->pointwise(
            scale0,
            x0,
            graph::Pointwise_attributes().set_mode(PointwiseMode::MUL).set_name("mul0"));
        auto mul1 = graph->pointwise(
            scale1,
            x1,
            graph::Pointwise_attributes().set_mode(PointwiseMode::MUL).set_name("mul1"));
        auto add0 = graph->pointwise(
            mul0,
            mul1,
            graph::Pointwise_attributes().set_mode(PointwiseMode::ADD).set_name("add0"));
        auto y = graph->pointwise(
            add0,
            bias,
            graph::Pointwise_attributes().set_mode(PointwiseMode::ADD).set_name("add1"));
        y->set_output(true);

        HIPDNN_FE_CHECK(graph->build(handle));
        return std::make_tuple(graph, x0, scale0, x1, scale1, bias, y);
    };

    auto backend = hipdnn_frontend::detail::hipdnnBackend();
    if(!backend)
    {
        std::cerr << "Backend create failed!" << std::endl;
        return;
    }
    hipdnnHandle_t handle;
    HIPDNN_CHECK(backend->create(&handle));

    auto [graph, x0, scale0, x1, scale1, bias, y] = build_graph(handle);

    // --- 分配主机/设备内存 ---
    std::unique_ptr<Tensor<half>> x0_half, x1_half, y_half;
    std::unique_ptr<Tensor<bfloat16>> x0_bf16, x1_bf16, y_bf16; // 新增
    std::unique_ptr<Tensor<float>> x0_float, x1_float, y_float;
    Tensor<float> scale0_tensor(scale0->get_dim(), scale0->get_stride());
    Tensor<float> scale1_tensor(scale1->get_dim(), scale1->get_stride());
    Tensor<float> bias_tensor(bias->get_dim(), bias->get_stride());

    if(is_fp16)
    {
        x0_half = std::make_unique<Tensor<half>>(x0->get_dim(), x0->get_stride());
        x1_half = std::make_unique<Tensor<half>>(x1->get_dim(), x1->get_stride());
        y_half = std::make_unique<Tensor<half>>(y->get_dim(), y->get_stride());
    }
    else if(is_bf16)
    {
        x0_bf16 = std::make_unique<Tensor<bfloat16>>(x0->get_dim(), x0->get_stride());
        x1_bf16 = std::make_unique<Tensor<bfloat16>>(x1->get_dim(), x1->get_stride());
        y_bf16 = std::make_unique<Tensor<bfloat16>>(y->get_dim(), y->get_stride());
    }
    else
    {
        x0_float = std::make_unique<Tensor<float>>(x0->get_dim(), x0->get_stride());
        x1_float = std::make_unique<Tensor<float>>(x1->get_dim(), x1->get_stride());
        y_float = std::make_unique<Tensor<float>>(y->get_dim(), y->get_stride());
    }

    size_t elem_count = static_cast<size_t>(n * c * h * w);

    // --- 初始化数据（随机或从文件读取）---
    bool readSuccess = false;
    if(config.file_index > 0 && !config.file_path.empty())
    {
        std::string base = config.file_path + "/" + std::to_string(config.file_index);
        if(is_fp16)
        {
            std::vector<half> ref_x0, ref_x1;
            std::vector<float> ref_scale0, ref_scale1, ref_bias;
            bool x0_ok = readRawTensor<half>(base + "_x0.bin", ref_x0, elem_count);
            bool x1_ok = readRawTensor<half>(base + "_x1.bin", ref_x1, elem_count);
            bool scale0_ok = readRawTensor<float>(base + "_scale0.bin", ref_scale0, c);
            bool scale1_ok = readRawTensor<float>(base + "_scale1.bin", ref_scale1, c);
            bool bias_ok = readRawTensor<float>(base + "_bias.bin", ref_bias, c);
            readSuccess = x0_ok && x1_ok && scale0_ok && scale1_ok && bias_ok;
            if(readSuccess)
            {
                std::cout << "Read input files (fp16)." << std::endl;
                std::copy(ref_x0.begin(), ref_x0.end(), x0_half->memory().hostData());
                std::copy(ref_x1.begin(), ref_x1.end(), x1_half->memory().hostData());
                std::copy(ref_scale0.begin(), ref_scale0.end(), scale0_tensor.memory().hostData());
                std::copy(ref_scale1.begin(), ref_scale1.end(), scale1_tensor.memory().hostData());
                std::copy(ref_bias.begin(), ref_bias.end(), bias_tensor.memory().hostData());
                x0_half->memory().markHostModified();
                x1_half->memory().markHostModified();
                scale0_tensor.memory().markHostModified();
                scale1_tensor.memory().markHostModified();
                bias_tensor.memory().markHostModified();
            }
        }
        else if(is_bf16)
        {
            std::vector<bfloat16> ref_x0, ref_x1;
            std::vector<float> ref_scale0, ref_scale1, ref_bias;
            bool x0_ok = readRawTensor<bfloat16>(base + "_x0.bin", ref_x0, elem_count);
            bool x1_ok = readRawTensor<bfloat16>(base + "_x1.bin", ref_x1, elem_count);
            bool scale0_ok = readRawTensor<float>(base + "_scale0.bin", ref_scale0, c);
            bool scale1_ok = readRawTensor<float>(base + "_scale1.bin", ref_scale1, c);
            bool bias_ok = readRawTensor<float>(base + "_bias.bin", ref_bias, c);
            readSuccess = x0_ok && x1_ok && scale0_ok && scale1_ok && bias_ok;
            if(readSuccess)
            {
                std::cout << "Read input files (bf16)." << std::endl;
                std::copy(ref_x0.begin(), ref_x0.end(), x0_bf16->memory().hostData());
                std::copy(ref_x1.begin(), ref_x1.end(), x1_bf16->memory().hostData());
                std::copy(ref_scale0.begin(), ref_scale0.end(), scale0_tensor.memory().hostData());
                std::copy(ref_scale1.begin(), ref_scale1.end(), scale1_tensor.memory().hostData());
                std::copy(ref_bias.begin(), ref_bias.end(), bias_tensor.memory().hostData());
                x0_bf16->memory().markHostModified();
                x1_bf16->memory().markHostModified();
                scale0_tensor.memory().markHostModified();
                scale1_tensor.memory().markHostModified();
                bias_tensor.memory().markHostModified();
            }
        }
        else // fp32
        {
            std::vector<float> ref_x0, ref_x1, ref_scale0, ref_scale1, ref_bias;
            bool x0_ok = readRawTensor<float>(base + "_x0.bin", ref_x0, elem_count);
            bool x1_ok = readRawTensor<float>(base + "_x1.bin", ref_x1, elem_count);
            bool scale0_ok = readRawTensor<float>(base + "_scale0.bin", ref_scale0, c);
            bool scale1_ok = readRawTensor<float>(base + "_scale1.bin", ref_scale1, c);
            bool bias_ok = readRawTensor<float>(base + "_bias.bin", ref_bias, c);
            readSuccess = x0_ok && x1_ok && scale0_ok && scale1_ok && bias_ok;
            if(readSuccess)
            {
                std::cout << "Read input files (fp32)." << std::endl;
                std::copy(ref_x0.begin(), ref_x0.end(), x0_float->memory().hostData());
                std::copy(ref_x1.begin(), ref_x1.end(), x1_float->memory().hostData());
                std::copy(ref_scale0.begin(), ref_scale0.end(), scale0_tensor.memory().hostData());
                std::copy(ref_scale1.begin(), ref_scale1.end(), scale1_tensor.memory().hostData());
                std::copy(ref_bias.begin(), ref_bias.end(), bias_tensor.memory().hostData());
                x0_float->memory().markHostModified();
                x1_float->memory().markHostModified();
                scale0_tensor.memory().markHostModified();
                scale1_tensor.memory().markHostModified();
                bias_tensor.memory().markHostModified();
            }
        }
    }

    if(!readSuccess)
    {
        std::cout << "Random initialization." << std::endl;
        if(is_fp16)
        {
            x0_half->fillWithRandomValues(half(0.0f), half(1.0f));
            x1_half->fillWithRandomValues(half(0.0f), half(1.0f));
            y_half->fillWithValue(half(0.0f));
        }
        else if(is_bf16)
        {
            x0_bf16->fillWithRandomValues(static_cast<bfloat16>(0.0f), static_cast<bfloat16>(1.0f));
            x1_bf16->fillWithRandomValues(static_cast<bfloat16>(0.0f), static_cast<bfloat16>(1.0f));
            y_bf16->fillWithValue(static_cast<bfloat16>(0.0f));
        }
        else
        {
            x0_float->fillWithRandomValues(0.0f, 1.0f);
            x1_float->fillWithRandomValues(0.0f, 1.0f);
            y_float->fillWithValue(0.0f);
        }
        scale0_tensor.fillWithRandomValues(0.0f, 1.0f);
        scale1_tensor.fillWithRandomValues(0.0f, 1.0f);
        bias_tensor.fillWithRandomValues(0.0f, 1.0f);
    }

    // --- 准备 GPU 执行 variantPack ---
    std::unordered_map<int64_t, void*> variantPack;
    variantPack[scale0->get_uid()] = scale0_tensor.memory().deviceData();
    variantPack[scale1->get_uid()] = scale1_tensor.memory().deviceData();
    variantPack[bias->get_uid()] = bias_tensor.memory().deviceData();

    if(is_fp16)
    {
        variantPack[x0->get_uid()] = x0_half->memory().deviceData();
        variantPack[x1->get_uid()] = x1_half->memory().deviceData();
        variantPack[y->get_uid()] = y_half->memory().deviceData();
    }
    else if(is_bf16)
    {
        variantPack[x0->get_uid()] = x0_bf16->memory().deviceData();
        variantPack[x1->get_uid()] = x1_bf16->memory().deviceData();
        variantPack[y->get_uid()] = y_bf16->memory().deviceData();
    }
    else
    {
        variantPack[x0->get_uid()] = x0_float->memory().deviceData();
        variantPack[x1->get_uid()] = x1_float->memory().deviceData();
        variantPack[y->get_uid()] = y_float->memory().deviceData();
    }

    int64_t workspace_size = 0;
    HIPDNN_FE_CHECK(graph->get_workspace_size(workspace_size));
    Workspace workspace(static_cast<size_t>(workspace_size));

    // --- 首次执行（GPU）---
    HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
    if(is_fp16)
        y_half->memory().markDeviceModified();
    else if(is_bf16)
        y_bf16->memory().markDeviceModified();
    else
        y_float->memory().markDeviceModified();
    std::cout << "Graph execution successful!" << std::endl;

    // --- 文件参考验证---
    if(config.file_index > 0 && !config.file_path.empty())
    {
        std::cout << "\n=== File Reference Validation ===" << std::endl;
        std::string base = config.file_path + "/" + std::to_string(config.file_index);
        if(is_fp16)
        {
            Tensor<half> ref_y(y->get_dim(), y->get_stride());
            std::vector<half> ref_y_data;
            bool y_ok = readRawTensor<half>(base + "_y.bin", ref_y_data, elem_count);
            if(y_ok)
            {
                std::copy(ref_y_data.begin(), ref_y_data.end(), ref_y.memory().hostData());
                auto validator = CpuFpReferenceValidation<half>(1e-3f, 1e-3f); // half 容差
                std::cout << "y: " << (validator.allClose(ref_y, *y_half) ? "successful" : "failed")
                          << std::endl;
            }
            else
                std::cerr << "[WARN] Reference output not found." << std::endl;
        }
        else if(is_bf16)
        {
            Tensor<bfloat16> ref_y(y->get_dim(), y->get_stride());
            std::vector<bfloat16> ref_y_data;
            bool y_ok = readRawTensor<bfloat16>(base + "_y.bin", ref_y_data, elem_count);
            if(y_ok)
            {
                std::copy(ref_y_data.begin(), ref_y_data.end(), ref_y.memory().hostData());
                auto validator = CpuFpReferenceValidation<bfloat16>(1e-2f, 1e-2f); // bf16 容差更宽
                std::cout << "y: " << (validator.allClose(ref_y, *y_bf16) ? "successful" : "failed")
                          << std::endl;
            }
            else
                std::cerr << "[WARN] Reference output not found." << std::endl;
        }
        else // fp32
        {
            Tensor<float> ref_y(y->get_dim(), y->get_stride());
            std::vector<float> ref_y_data;
            bool y_ok = readRawTensor<float>(base + "_y.bin", ref_y_data, elem_count);
            if(y_ok)
            {
                std::copy(ref_y_data.begin(), ref_y_data.end(), ref_y.memory().hostData());
                auto validator = CpuFpReferenceValidation<float>(1e-2f, 1e-2f);
                std::cout << "y: "
                          << (validator.allClose(ref_y, *y_float) ? "successful" : "failed")
                          << std::endl;
            }
            else
                std::cerr << "[WARN] Reference output not found." << std::endl;
        }
    }

    // --- CPU 参考验证 ---
    if(config.cpuValidation)
    {
        std::cout << "\n=== CPU Reference Validation ===" << std::endl;
        std::unique_ptr<Tensor<half>> cpu_y_half;
        std::unique_ptr<Tensor<bfloat16>> cpu_y_bf16; // 新增
        std::unique_ptr<Tensor<float>> cpu_y_float;
        if(is_fp16)
            cpu_y_half = std::make_unique<Tensor<half>>(y->get_dim(), y->get_stride());
        else if(is_bf16)
            cpu_y_bf16 = std::make_unique<Tensor<bfloat16>>(y->get_dim(), y->get_stride());
        else
            cpu_y_float = std::make_unique<Tensor<float>>(y->get_dim(), y->get_stride());

        std::unordered_map<int64_t, void*> cpu_variant;
        cpu_variant[scale0->get_uid()] = scale0_tensor.memory().hostData();
        cpu_variant[scale1->get_uid()] = scale1_tensor.memory().hostData();
        cpu_variant[bias->get_uid()] = bias_tensor.memory().hostData();

        if(is_fp16)
        {
            cpu_variant[x0->get_uid()] = x0_half->memory().hostData();
            cpu_variant[x1->get_uid()] = x1_half->memory().hostData();
            cpu_variant[y->get_uid()] = cpu_y_half->memory().hostData();
        }
        else if(is_bf16)
        {
            cpu_variant[x0->get_uid()] = x0_bf16->memory().hostData();
            cpu_variant[x1->get_uid()] = x1_bf16->memory().hostData();
            cpu_variant[y->get_uid()] = cpu_y_bf16->memory().hostData();
        }
        else
        {
            cpu_variant[x0->get_uid()] = x0_float->memory().hostData();
            cpu_variant[x1->get_uid()] = x1_float->memory().hostData();
            cpu_variant[y->get_uid()] = cpu_y_float->memory().hostData();
        }
        auto graph_buf = graph->to_binary().first;
        CpuReferenceGraphExecutor cpu_exec;
        cpu_exec.execute(graph_buf.data(), graph_buf.size(), cpu_variant);

        if(is_fp16)
        {
            CpuFpReferenceValidation<half> validator(1e-2f, 1e-2f);
            std::cout << "y (CPU vs GPU): "
                      << (validator.allClose(*cpu_y_half, *y_half) ? "successful" : "failed")
                      << std::endl;
        }
        else if(is_bf16)
        {
            CpuFpReferenceValidation<bfloat16> validator(1e-2f, 1e-2f);
            std::cout << "y (CPU vs GPU): "
                      << (validator.allClose(*cpu_y_bf16, *y_bf16) ? "successful" : "failed")
                      << std::endl;
        }
        else
        {
            CpuFpReferenceValidation<float> validator(1e-5f, 1e-5f);
            std::cout << "y (CPU vs GPU): "
                      << (validator.allClose(*cpu_y_float, *y_float) ? "successful" : "failed")
                      << std::endl;
        }
    }

    // --- 性能测试---
    hipEvent_t start, stop;
    float total_time;
    HIP_CHECK(hipEventCreate(&start));
    HIP_CHECK(hipEventCreate(&stop));
    HIP_CHECK(hipDeviceSynchronize());
    HIP_CHECK(hipEventRecord(start));

    const int iterations = 100;
    for(int i = 0; i < iterations; ++i)
    {
        HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
    }

    HIP_CHECK(hipEventRecord(stop));
    HIP_CHECK(hipEventSynchronize(stop));
    HIP_CHECK(hipEventElapsedTime(&total_time, start, stop));

    std::cout << "\n========== Performance ==========" << std::endl;
    std::cout << "Avg time: " << total_time / iterations << " ms" << std::endl;

    HIP_CHECK(hipEventDestroy(start));
    HIP_CHECK(hipEventDestroy(stop));
    HIPDNN_CHECK(backend->destroy(handle));
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
        std::cout << argv[i] << " ";
    std::cout << std::endl;

    Config config = parse_config(argc, argv);
    validate_config(config);
    run_mixed_precision(config);
    return 0;
}
