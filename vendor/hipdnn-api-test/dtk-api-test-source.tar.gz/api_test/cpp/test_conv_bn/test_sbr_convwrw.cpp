#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <vector>

#include "../utils.hpp"
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>

#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// scale + bias + relu + conv_wgrad 融合算子
struct Config
{
    int64_t n = 4;
    int64_t h = 16;
    int64_t w = 16;
    int64_t k = 64;
    int64_t c = 32;
    int64_t r = 3;
    int64_t s = 3;
    int64_t padH = 1;
    int64_t padW = 1;
    int64_t strideH = 1;
    int64_t strideW = 1;
    int64_t dilH = 1;
    int64_t dilW = 1;
    int64_t groups = 1;
    std::string layout = "NHWC";
    std::string dataType = "fp16";
    int file_index = 0;
    std::string file_path = "";
    bool cpuValidation = false;
};

// 命令行参数解析
Config parse_config(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
            config.n = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
            config.c = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
            config.h = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
            config.w = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-k") == 0 && i + 1 < argc)
            config.k = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-y") == 0 && i + 1 < argc)
            config.r = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-x") == 0 && i + 1 < argc)
            config.s = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-p") == 0 && i + 1 < argc)
            config.padH = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc)
            config.padW = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-u") == 0 && i + 1 < argc)
            config.strideH = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-v") == 0 && i + 1 < argc)
            config.strideW = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-l") == 0 && i + 1 < argc)
            config.dilH = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-j") == 0 && i + 1 < argc)
            config.dilW = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-g") == 0 && i + 1 < argc)
            config.groups = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
            config.file_index = std::stoi(argv[++i]);
        else if(strcmp(argv[i], "-o") == 0 && i + 1 < argc)
            config.file_path = argv[++i];
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

// 配置合法性校验
void validate_config(const Config& config)
{
    if(config.layout != "NHWC" && config.layout != "NCHW")
    {
        std::cerr << "Unsupported layout: " << config.layout << ", use NHWC/NCHW" << std::endl;
        exit(1);
    }
    if(config.dataType != "fp16" && config.dataType != "fp32" && config.dataType != "bf16")
    {
        std::cerr << "Unsupported data type: " << config.dataType << ", use fp16/fp32/bf16"
                  << std::endl;
        exit(1);
    }
    if(config.c % config.groups != 0)
    {
        std::cerr << "Input channels must be divisible by groups" << std::endl;
        exit(1);
    }
    if(config.k % config.groups != 0)
    {
        std::cerr << "Output channels must be divisible by groups" << std::endl;
        exit(1);
    }
}

// hipDNN数据类型映射
DataType getDataTypeEnum(const std::string& dtype)
{
    if(dtype == "fp16")
        return DataType::HALF;
    else if(dtype == "fp32")
        return DataType::FLOAT;
    else if(dtype == "bf16")
        return DataType::BFLOAT16;
    else
    {
        std::cerr << "Unsupported data type: " << dtype << std::endl;
        exit(1);
    }
}

template <typename T>
void run_with_type(const Config& config)
{
    int64_t n = config.n;
    int64_t c = config.c;
    int64_t h = config.h;
    int64_t w = config.w;
    int64_t k = config.k;
    int64_t r = config.r;
    int64_t s = config.s;
    int64_t padH = config.padH;
    int64_t padW = config.padW;
    int64_t strideH = config.strideH;
    int64_t strideW = config.strideW;
    int64_t dilH = config.dilH;
    int64_t dilW = config.dilW;
    int64_t groups = config.groups;
    std::string layout = config.layout;

    // 计算卷积输出尺寸
    int64_t h_out = (h + 2 * padH - dilH * (r - 1) - 1) / strideH + 1;
    int64_t w_out = (w + 2 * padW - dilW * (s - 1) - 1) / strideW + 1;
    if(h_out <= 0 || w_out <= 0)
    {
        std::cerr << "Invalid convolution output dimension: " << h_out << "x" << w_out << std::endl;
        exit(1);
    }

    // 张量维度/步长定义
    std::vector<int64_t> x_dim, x_stride; // 输入 [n, c, h, w]
    std::vector<int64_t> scale_dim, scale_stride; // scale [1, c, 1, 1]
    std::vector<int64_t> bias_dim, bias_stride; // bias  [1, c, 1, 1]
    std::vector<int64_t> dy_dim, dy_stride; // 输出梯度 [n, k, h_out, w_out]
    std::vector<int64_t> dw_dim, dw_stride; // 权重梯度 [k, c/groups, r, s]

    x_dim = {n, c, h, w};
    scale_dim = {1, c, 1, 1};
    bias_dim = {1, c, 1, 1};
    dy_dim = {n, k, h_out, w_out};
    dw_dim = {k, c / groups, r, s};

    if(layout == "NHWC")
    {
        x_stride = {c * h * w, 1, c * w, c};
        scale_stride = {c, 1, c, c};
        bias_stride = {c, 1, c, c};
        dy_stride = {k * h_out * w_out, 1, k * w_out, k};
        dw_stride = {(c / groups) * r * s, 1, (c / groups) * s, (c / groups)};
    }
    else // NCHW
    {
        x_stride = {c * h * w, h * w, w, 1};
        scale_stride = {c, 1, 1, 1};
        bias_stride = {c, 1, 1, 1};
        dy_stride = {k * h_out * w_out, h_out * w_out, w_out, 1};
        dw_stride = {(c / groups) * r * s, r * s, s, 1};
    }

    // 构建计算图：scale * x + bias -> relu -> conv_wgrad(dy)
    auto build_graph = [=](hipdnnHandle_t handle) {
        auto graph = std::make_shared<graph::Graph>();
        graph->set_name("scale_bias_relu_conv_wgrad")
            .set_io_data_type(getDataTypeEnum(config.dataType))
            .set_intermediate_data_type(DataType::FLOAT)
            .set_compute_data_type(DataType::FLOAT);

        auto X = graph->tensor(
            graph::Tensor_attributes().set_name("x").set_dim(x_dim).set_stride(x_stride));
        auto Scale = graph->tensor(
            graph::Tensor_attributes().set_name("scale").set_dim(scale_dim).set_stride(
                scale_stride));
        auto Bias = graph->tensor(
            graph::Tensor_attributes().set_name("bias").set_dim(bias_dim).set_stride(bias_stride));
        auto DY = graph->tensor(
            graph::Tensor_attributes().set_name("dy").set_dim(dy_dim).set_stride(dy_stride));

        // scale * x
        auto mul_out = graph->pointwise(
            X, Scale, graph::Pointwise_attributes().set_mode(PointwiseMode_t::MUL));
        // + bias
        auto add_out = graph->pointwise(
            mul_out, Bias, graph::Pointwise_attributes().set_mode(PointwiseMode_t::ADD));
        // relu
        auto relu_out = graph->pointwise(
            add_out, graph::Pointwise_attributes().set_mode(PointwiseMode_t::RELU_FWD));

        // conv_wgrad
        auto wgrad_attrs = graph::Conv_wgrad_attributes()
                               .set_padding({padH, padW})
                               .set_stride({strideH, strideW})
                               .set_dilation({dilH, dilW});
        auto DW = graph->conv_wgrad(DY, relu_out, wgrad_attrs);
        DW->set_output(true).set_dim(dw_dim).set_stride(dw_stride);

        HIPDNN_FE_CHECK(graph->build(handle));
        return std::make_tuple(graph, X, Scale, Bias, DY, DW);
    };

    // 初始化hipDNN
    auto backend = hipdnn_frontend::detail::hipdnnBackend();
    if(!backend)
    {
        std::cerr << "Backend create failed!" << std::endl;
        return;
    }
    hipdnnHandle_t handle;
    HIPDNN_CHECK(backend->create(&handle));

    // 构建图
    auto [graph, X, Scale, Bias, DY, DW] = build_graph(handle);

    // ===================== 内存分配 =====================
    Tensor<T> x_tensor(x_dim, x_stride);
    Tensor<T> scale_tensor(scale_dim, scale_stride);
    Tensor<T> bias_tensor(bias_dim, bias_stride);
    Tensor<T> dy_tensor(dy_dim, dy_stride);
    Tensor<T> dw_tensor(dw_dim, dw_stride);

    // ===================== 读取参考文件初始化 =====================
    bool readSuccess = false;
    size_t x_elem = static_cast<size_t>(n * c * h * w);
    size_t scale_elem = static_cast<size_t>(c);
    size_t bias_elem = static_cast<size_t>(c);
    size_t dy_elem = static_cast<size_t>(n * k * h_out * w_out);
    size_t dw_elem = static_cast<size_t>(k * (c / groups) * r * s);

    if(config.file_index > 0 && !config.file_path.empty())
    {
        std::string base = config.file_path + "/" + std::to_string(config.file_index);

        std::vector<T> ref_x, ref_dy;
        std::vector<T> ref_scale, ref_bias;

        bool x_ok = readRawTensor<T>(base + "_input.bin", ref_x, x_elem);
        bool dy_ok = readRawTensor<T>(base + "_dy.bin", ref_dy, dy_elem);
        bool scale_ok = readRawTensor<T>(base + "_scale.bin", ref_scale, scale_elem);
        bool bias_ok = readRawTensor<T>(base + "_bias.bin", ref_bias, bias_elem);

        readSuccess = x_ok && dy_ok && scale_ok && bias_ok;

        if(readSuccess)
        {
            std::cout << "Successfully read input reference files!" << std::endl;
            std::copy(ref_x.begin(), ref_x.end(), x_tensor.memory().hostData());
            std::copy(ref_dy.begin(), ref_dy.end(), dy_tensor.memory().hostData());
            std::copy(ref_scale.begin(), ref_scale.end(), scale_tensor.memory().hostData());
            std::copy(ref_bias.begin(), ref_bias.end(), bias_tensor.memory().hostData());

            x_tensor.memory().markHostModified();
            dy_tensor.memory().markHostModified();
            scale_tensor.memory().markHostModified();
            bias_tensor.memory().markHostModified();
        }
        else
        {
            std::cerr << "[WARN] Read input files failed, use random values!" << std::endl;
        }
    }

    // 读取失败则用随机值初始化
    if(!readSuccess)
    {
        x_tensor.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
        dy_tensor.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
        scale_tensor.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
        bias_tensor.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
    }

    // 绑定设备内存
    std::unordered_map<int64_t, void*> variantPack;
    variantPack[X->get_uid()] = x_tensor.memory().deviceData();
    variantPack[Scale->get_uid()] = scale_tensor.memory().deviceData();
    variantPack[Bias->get_uid()] = bias_tensor.memory().deviceData();
    variantPack[DY->get_uid()] = dy_tensor.memory().deviceData();
    variantPack[DW->get_uid()] = dw_tensor.memory().deviceData();

    // 工作空间
    int64_t workspace_size = 0;
    HIPDNN_FE_CHECK(graph->get_workspace_size(workspace_size));
    Workspace workspace(static_cast<size_t>(workspace_size));

    // 首次执行
    HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
    dw_tensor.memory().markDeviceModified();
    std::cout << "Graph execution successful!" << std::endl;

    // ===================== 文件参考验证 =====================
    if(config.file_index > 0 && !config.file_path.empty())
    {
        std::cout << "\n=== File Reference Validation ===" << std::endl;
        std::string base = config.file_path + "/" + std::to_string(config.file_index);

        Tensor<T> ref_dw(dw_dim, dw_stride);
        std::vector<T> ref_dw_data;
        bool dw_ok = readRawTensor<T>(base + "_dw.bin", ref_dw_data, dw_elem);
        if(dw_ok)
        {
            std::copy(ref_dw_data.begin(), ref_dw_data.end(), ref_dw.memory().hostData());
            float tol = 1e-2f;
            auto validator = CpuFpReferenceValidation<T>(tol, tol);
            bool passed = validator.allClose(ref_dw, dw_tensor);
            std::cout << "dw: " << (passed ? "successful" : "failed") << std::endl;
        }
        else
        {
            std::cerr << "[WARN] No reference dw output file found, skip comparison." << std::endl;
        }
    }

    // ===================== CPU参考验证 =====================
    if(config.cpuValidation)
    {
        std::cout << "\n=== CPU Reference Validation ===" << std::endl;

        Tensor<T> cpu_dw(dw_dim, dw_stride);
        std::unordered_map<int64_t, void*> cpu_variant;
        cpu_variant[X->get_uid()] = x_tensor.memory().hostData();
        cpu_variant[Scale->get_uid()] = scale_tensor.memory().hostData();
        cpu_variant[Bias->get_uid()] = bias_tensor.memory().hostData();
        cpu_variant[DY->get_uid()] = dy_tensor.memory().hostData();
        cpu_variant[DW->get_uid()] = cpu_dw.memory().hostData();

        auto graph_buf = graph->to_binary().first;
        CpuReferenceGraphExecutor cpu_exec;
        cpu_exec.execute(graph_buf.data(), graph_buf.size(), cpu_variant);
        float tol = 1e-2f;
        auto validator = CpuFpReferenceValidation<T>(tol, tol);
        std::cout << "dw: " << (validator.allClose(cpu_dw, dw_tensor) ? "successful" : "failed")
                  << std::endl;
    }

    // ===================== 性能计时 =====================
    hipEvent_t start, stop;
    float total_time;
    HIP_CHECK(hipEventCreate(&start));
    HIP_CHECK(hipEventCreate(&stop));
    HIP_CHECK(hipDeviceSynchronize());
    HIP_CHECK(hipEventRecord(start));

    const int warmup = 10;
    for(int i = 0; i < warmup; ++i)
        HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));

    HIP_CHECK(hipEventRecord(start));
    const int iterations = 100;
    for(int i = 0; i < iterations; i++)
        HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
    HIP_CHECK(hipEventRecord(stop));
    HIP_CHECK(hipEventSynchronize(stop));
    HIP_CHECK(hipEventElapsedTime(&total_time, start, stop));

    std::cout << "\n========== Performance ==========" << std::endl;
    std::cout << "Avg time over " << iterations << " runs: " << total_time / iterations << " ms"
              << std::endl;

    // 资源释放
    HIP_CHECK(hipEventDestroy(start));
    HIP_CHECK(hipEventDestroy(stop));
    HIPDNN_CHECK(backend->destroy(handle));
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; i++)
        std::cout << argv[i] << " ";
    std::cout << std::endl;

    Config config = parse_config(argc, argv);
    validate_config(config);

    if(config.dataType == "fp16")
    {
        run_with_type<half>(config);
    }
    else if(config.dataType == "fp32")
    {
        run_with_type<float>(config);
    }
    else if(config.dataType == "bf16")
    {
        run_with_type<bfloat16>(config);
    }
    else
    {
        std::cerr << "Unsupported dtype!" << std::endl;
        return 1;
    }

    return 0;
}
