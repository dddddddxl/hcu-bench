#include <algorithm>
#include <cstring>
#include <iostream>
#include <random>
#include <string>
#include <unordered_map>
#include <vector>

#include <hipdnn_frontend.hpp>
#include <hipdnn_frontend/Graph.hpp>
#include <hipdnn_frontend/attributes/ReductionAttributes.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceReduction.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>

#include "../utils.hpp"
#include "hipdnn_frontend/Types.hpp"

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// 配置结构体 - 支持 3,4,5 维输入
struct Config
{
    std::vector<int64_t> input_dims; // 输入维度，支持 3,4,5 维
    int64_t reduce_mode = 0; // 对应 ReductionMode_t::ADD
    std::vector<int64_t> dims_to_reduce; // 要约减的维度索引
    std::string dataType = "fp16";
    bool cpuValidation = false;
    int fileIndex = 0;
    std::string filePath = ".";
    int iterations = 10; // 性能测试迭代次数
};

// 解析逗号分隔的维度字符串
std::vector<int64_t> parseDimsString(const std::string& str)
{
    std::vector<int64_t> result;
    std::string token;
    std::istringstream tokenStream(str);

    while(std::getline(tokenStream, token, ','))
    {
        result.push_back(std::stoll(token));
    }

    return result;
}

// 命令行解析
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-D") == 0 && i + 1 < argc)
        {
            // 输入维度：如 -D "2,16,512,32" (4维) 或 -D "1,128,256" (3维) 或 -D "1,2,64,128,256" (5维)
            config.input_dims = parseDimsString(argv[++i]);

            // 验证维度数量
            if(config.input_dims.size() < 3 || config.input_dims.size() > 5)
            {
                std::cerr << "Error: Input dimension count must be 3, 4, or 5. Got: "
                          << config.input_dims.size() << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "-O") == 0 && i + 1 < argc)
        {
            config.reduce_mode = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-R") == 0 && i + 1 < argc)
        {
            config.dims_to_reduce = parseDimsString(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }

    // 设置默认值（如果未提供）
    if(config.input_dims.empty())
    {
        // 默认 4 维张量 [batch, channels, height, width]
        config.input_dims = {2, 16, 512, 32};
        std::cout << "Using default 4D input dimensions: [2, 16, 512, 32]\n";
    }

    if(config.dims_to_reduce.empty())
    {
        // 默认约减最后一个维度
        config.dims_to_reduce = {static_cast<int64_t>(config.input_dims.size() - 1)};
    }

    return config;
}

class ReduceRunner
{
public:
    ReduceRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType, typename IntermediateType>
    void runReduce()
    {
        auto inputType = getDataTypeEnumFromType<InputType>();
        auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        // 计算输出维度
        std::vector<int64_t> output_dims = config_.input_dims;
        for(int64_t dim_idx : config_.dims_to_reduce)
        {
            size_t idx = static_cast<size_t>(dim_idx);
            if(dim_idx >= 0 && idx < output_dims.size())
            {
                output_dims[idx] = 1;
            }
        }

        // 创建图
        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_intermediate_data_type(intermediateType)
            .set_compute_data_type(DataType::FLOAT);

        // 创建输入张量
        auto x = createTensor(config_.input_dims, inputType);

        // 设置 Reduce 操作模式
        ReductionMode_t reductionMode = mapReductionMode(config_.reduce_mode);

        auto reductionAttributes = graph::ReductionAttributes();
        reductionAttributes.set_name("reduction_node").set_mode(reductionMode);

        auto y = graph->reduction(x, reductionAttributes);

        // 计算 stride
        std::vector<int64_t> output_stride(output_dims.size());
        output_stride[output_dims.size() - 1] = 1;
        for(int64_t i = static_cast<int64_t>(output_dims.size()) - 2; i >= 0; --i)
        {
            size_t idx = static_cast<size_t>(i);
            size_t next_idx = idx + 1;
            output_stride[idx] = output_stride[next_idx] * output_dims[next_idx];
        }

        y->set_dim(output_dims).set_stride(output_stride).set_output(true);

        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful.\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        // 创建 Tensor 对象
        Tensor<InputType> xTensor(x->get_dim(), x->get_stride());
        Tensor<InputType> yTensor(y->get_dim(), y->get_stride());

        // 读取参考数据或生成随机数据
        bool readSuccess = false;
        size_t xTotalElems = 1;
        for(int64_t dim : config_.input_dims)
            xTotalElems *= static_cast<size_t>(dim);

        size_t yTotalElems = 1;
        for(int64_t dim : output_dims)
            yTotalElems *= static_cast<size_t>(dim);

        if(config_.fileIndex > 0)
        {
            const std::string xFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_input.bin";
            const std::string yFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_output.bin";

            std::vector<InputType> refXData, refYData;
            readSuccess = readRawTensor<InputType>(xFilename, refXData, xTotalElems)
                          && readRawTensor<InputType>(yFilename, refYData, yTotalElems);

            if(readSuccess)
            {
                std::cout << "Successfully read reduce reference files.\n";

                // 将数据复制到张量
                std::copy(refXData.begin(), refXData.end(), xTensor.memory().hostData());
                xTensor.memory().markHostModified();
            }
            else
            {
                std::cerr << "[WARN] Failed to read reduce reference files. Using random values.\n";
                xTensor.fillWithRandomValues(static_cast<InputType>(-1.0f),
                                             static_cast<InputType>(1.0f));
                yTensor.fillWithValue(static_cast<InputType>(0.0f));
            }
        }
        else
        {
            // 使用随机值初始化
            xTensor.fillWithRandomValues(static_cast<InputType>(-1.0f),
                                         static_cast<InputType>(1.0f));
            yTensor.fillWithValue(static_cast<InputType>(0.0f));
        }

        // 获取工作空间大小
        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 绑定变体包
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[x->get_uid()] = xTensor.memory().deviceData();
        variantPack[y->get_uid()] = yTensor.memory().deviceData();

        // 预热
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

        yTensor.memory().markDeviceModified();

        // 计时执行
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < config_.iterations; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "Reduce avg time " << time / static_cast<float>(config_.iterations) << " ms"
                  << std::endl;

        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // 文件验证
        if(config_.fileIndex > 0 && readSuccess)
        {
            Tensor<InputType> refYTensor(y->get_dim(), y->get_stride());
            std::vector<InputType> refYData;
            const std::string yFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_output.bin";

            if(readRawTensor<InputType>(yFilename, refYData, yTotalElems))
            {
                std::copy(refYData.begin(), refYData.end(), refYTensor.memory().hostData());
                refYTensor.memory().markHostModified();

                auto tolerance = reduction::getTolerance<InputType>();
                auto validator = CpuFpReferenceValidation<InputType>(tolerance, tolerance);

                bool yMatch = validator.allClose(refYTensor, yTensor);

                std::cout << "File validation result:\n";
                std::cout << "  y: " << (yMatch ? "successful" : "failed") << "\n";

                if(!yMatch)
                {
                    // 打印前几个元素对比
                    const size_t printCount = std::min(yTotalElems, static_cast<size_t>(10));
                    const InputType* refYDataPtr = refYTensor.memory().hostData();
                    const InputType* currYDataPtr = yTensor.memory().hostData();

                    std::cout << "Reference: ";
                    for(size_t i = 0; i < printCount; ++i)
                    {
                        std::cout << static_cast<float>(refYDataPtr[i]) << " ";
                    }
                    std::cout << std::endl;

                    std::cout << "Actual:    ";
                    for(size_t i = 0; i < printCount; ++i)
                    {
                        std::cout << static_cast<float>(currYDataPtr[i]) << " ";
                    }
                    std::cout << std::endl;
                }
            }
        }

        if(config_.cpuValidation)
        {
            Tensor<InputType> yRefTensor(y->get_dim(), y->get_stride());

            auto input_dims = x->get_dim();

            runCpuReduction<InputType>(xTensor, yRefTensor, reductionMode);

            auto tolerance = reduction::getTolerance<InputType>();
            auto validator = CpuFpReferenceValidation<InputType>(tolerance, tolerance);

            bool yValid = validator.allClose(yRefTensor, yTensor);

            std::cout << "CPU reference validation:\n";
            std::cout << "  y: " << (yValid ? "successful" : "failed") << "\n";
        }
    }

private:
    template <typename InputType>
    void runCpuReduction(const Tensor<InputType>& input,
                         Tensor<InputType>& output,
                         ReductionMode_t reductionMode)
    {
        using FReductionMode = hipdnn_flatbuffers_sdk::data_objects::ReductionMode;

#define CPU_REDUCTION(MODE)                                       \
    CpuFpReferenceReduction::reduce<InputType, InputType, float>( \
        input, output, FReductionMode::MODE)

        switch(reductionMode)
        {
        case ReductionMode_t::ADD:
            CPU_REDUCTION(ADD);
            break;

        case ReductionMode_t::MUL:
            CPU_REDUCTION(MUL);
            break;

        case ReductionMode_t::MIN:
            CPU_REDUCTION(MIN_OP);
            break;

        case ReductionMode_t::MAX:
            CPU_REDUCTION(MAX_OP);
            break;

        case ReductionMode_t::AVG:
            CPU_REDUCTION(AVG);
            break;

        case ReductionMode_t::AMAX:
            CPU_REDUCTION(AMAX);
            break;

        case ReductionMode_t::NORM1:
            CPU_REDUCTION(NORM1);
            break;

        case ReductionMode_t::NORM2:
            CPU_REDUCTION(NORM2);
            break;

        default:
            std::cout << "CPU validation not implemented for reduction mode: "
                      << static_cast<int>(reductionMode) << std::endl;
            break;
        }

#undef CPU_REDUCTION
    }

    // 映射 Reduce 操作模式
    ReductionMode_t mapReductionMode(int64_t mode)
    {
        switch(mode)
        {
        case 0:
            return ReductionMode_t::ADD;
        case 1:
            return ReductionMode_t::MUL;
        case 2:
            return ReductionMode_t::MIN;
        case 3:
            return ReductionMode_t::MAX;
        case 4:
            return ReductionMode_t::AMAX;
        case 5:
            return ReductionMode_t::AVG;
        case 6:
            return ReductionMode_t::NORM1;
        case 7:
            return ReductionMode_t::NORM2;
        default:
            std::cerr << "Warning: Unknown reduction mode " << mode << ", using ADD.\n";
            return ReductionMode_t::ADD;
        }
    }

    hipdnnHandle_t handle_;
    Config config_;
    std::mt19937 rng;
};

// 运行不同数据类型的模板函数
template <typename F>
void runReduce(F&& f, const Config& config)
{
    if(config.dataType == "fp32")
    {
        f.template runReduce<float, float>();
    }
    else if(config.dataType == "fp16")
    {
        f.template runReduce<half, float>();
    }
    else if(config.dataType == "fp64")
    {
        f.template runReduce<double, double>();
    }
    else
    {
        std::cerr << "Unsupported data type for reduction: " << config.dataType << std::endl;
        std::cerr << "Supported types: fp32, fp16" << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    // 打印命令行参数
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));

    runReduce(ReduceRunner{handle, config}, config);

    HIPDNN_CHECK(hipdnnDestroy(handle));
    std::cout << "All reduction tests completed successfully.\n";
    return 0;
}
