#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include "../utils.hpp"
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceRMSNorm.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// 配置结构体
struct Config
{
    int64_t n = 1; // 批量大小
    int64_t c = 16; // 通道数
    int64_t h = 1; // 高度
    int64_t w = 16; // 宽度 (增加为16，用于归一化)
    std::string dataType = "fp32"; // 数据类型
    float epsilon = 1e-5f; // RMSNorm的epsilon值
    bool cpuValidation = false; // 是否进行CPU验证
    int fileIndex = 0; // 文件索引，0表示不使用文件
    std::string filePath = "."; // 文件路径
    int normType = 1; // 归一化类型: 1=前向推理
};

// 命令行解析
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-e") == 0 && i + 1 < argc)
        {
            config.epsilon = std::stof(argv[++i]);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else if(strcmp(argv[i], "-F") == 0 && i + 1 < argc)
        {
            int type = std::stoi(argv[++i]);
            if(type != 1)
            {
                std::cerr << "Invalid RMSNorm type: " << type << std::endl;
                std::cerr << "Currently only supports: 1(inference)" << std::endl;
                exit(1);
            }
            config.normType = type;
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            std::cerr << "-n <batch> -c <channels> -H <height> -W <width> "
                      << "-d <data_type> -e <epsilon> -i <file_index> "
                      << "[--cpu-validation] -path <path>\n";
            exit(1);
        }
    }
    return config;
}

class RmsnormRunner
{
public:
    RmsnormRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    // 获取张量维度和步长 (使用NCHW布局)
    std::tuple<std::vector<int64_t>, std::vector<int64_t>>
        get_tensor_dims_strides(const std::string& tensor_name)
    {
        std::vector<int64_t> dims;
        std::vector<int64_t> strides;

        if(tensor_name == "X" || tensor_name == "Y" || tensor_name == "DY" || tensor_name == "DX")
        {
            // 输入/输出张量: [n, c, h, w] - NCHW布局
            dims = {config_.n, config_.c, config_.h, config_.w};
            strides = {config_.c * config_.h * config_.w, config_.h * config_.w, config_.w, 1};
        }
        else if(tensor_name == "scale" || tensor_name == "bias" || tensor_name == "dscale"
                || tensor_name == "dbias")
        {
            // 由于我们对最后一维(w)进行归一化，所以scale/bias的形状应为[1, 1, 1, w]
            // 这样可以广播到每个通道和高度位置
            dims = {1, 1, 1, config_.w};
            strides = {config_.w, config_.w, config_.w, 1};
        }
        else if(tensor_name == "inv_variance")
        {
            // 逆方差: [n, c, h, 1] (对w维度归一化后的结果)
            dims = {config_.n, config_.c, config_.h, 1};
            strides = {config_.c * config_.h * 1, config_.h * 1, 1, 1};
        }

        return {dims, strides};
    }

    // 创建张量属性
    std::shared_ptr<graph::Tensor_attributes> createTensor(const std::string& tensor_name,
                                                           DataType data_type)
    {
        auto [dims, strides] = get_tensor_dims_strides(tensor_name);

        auto tensor_attr = std::make_shared<graph::Tensor_attributes>();
        tensor_attr->set_name(tensor_name)
            .set_dim(dims)
            .set_stride(strides)
            .set_data_type(data_type);

        return tensor_attr;
    }

    // 前向推理实现
    template <typename InputType>
    void inference()
    {
        // 根据输入类型选择合适的中间类型
        using IntermediateType
            = std::conditional_t<std::is_same_v<InputType, half>
                                     || std::is_same_v<InputType, bfloat16>,
                                 float, // half和bfloat16使用float作为中间类型
                                 std::conditional_t<std::is_same_v<InputType, int8_t>,
                                                    int32_t, // int8使用int32作为中间类型
                                                    InputType // fp32使用相同的类型作为中间类型
                                                    >>;

        const auto inputType = getDataTypeEnumFromType<InputType>();

        std::cout << "Running RMS normalization inference graph " << inputType
                  << (config_.cpuValidation ? " (with CPU validation)" : "") << "...\n";
        std::cout << "Tensor shape: [" << config_.n << ", " << config_.c << ", " << config_.h
                  << ", " << config_.w << "] (NCHW)" << std::endl;
        std::cout << "Normalizing over w dimension (last dimension)" << std::endl;

        // 计算张量元素总数
        const auto [x_dims, x_strides] = get_tensor_dims_strides("X");
        const auto [scale_dims, scale_strides] = get_tensor_dims_strides("scale");
        const auto [y_dims, y_strides] = get_tensor_dims_strides("Y");

        const size_t xTotalElems = getTotalElems(x_dims);
        const size_t scaleTotalElems = getTotalElems(scale_dims);

        std::shared_ptr<graph::Graph> graph;
        std::shared_ptr<graph::Tensor_attributes> xAttr, scaleAttr, yAttr;
        bool graphBuilt = false;

        // 尝试不同的配置策略
        std::vector<std::tuple<DataType, DataType, DataType>> configsToTry;

        if constexpr(std::is_same_v<InputType, half> || std::is_same_v<InputType, bfloat16>)
        {
            // 对于half和bfloat16，使用float作为中间和计算类型通常更稳定
            configsToTry = {{inputType,
                             DataType_t::FLOAT,
                             DataType_t::FLOAT}, // 输入half/bf16，中间float，计算float
                            {inputType, inputType, inputType}, // 全部使用输入类型
                            {inputType, DataType_t::FLOAT, DataType_t::FLOAT}};
        }
        else if constexpr(std::is_same_v<InputType, float>)
        {
            // 对于fp32，尝试不同的配置
            configsToTry = {
                {inputType, DataType_t::FLOAT, DataType_t::FLOAT}, // 全部float
                {inputType, DataType_t::DOUBLE, DataType_t::DOUBLE}, // 使用double
                {inputType, inputType, inputType} // 全部输入类型
            };
        }
        else if constexpr(std::is_same_v<InputType, int8_t>)
        {
            // 对于int8，使用int32作为中间和计算类型
            configsToTry = {
                {inputType, DataType_t::INT32, DataType_t::INT32}, // 输入int8，中间int32，计算int32
                {inputType, inputType, inputType}, // 全部int8
                {inputType, DataType_t::FLOAT, DataType_t::FLOAT} // 使用float
            };
        }

        for(const auto& [ioType, interType, compType] : configsToTry)
        {
            try
            {
                graph = std::make_shared<graph::Graph>();
                graph->set_io_data_type(ioType)
                    .set_intermediate_data_type(interType)
                    .set_compute_data_type(compType);

                // 创建输入张量
                xAttr = createTensor("X", ioType);
                scaleAttr = createTensor("scale", ioType);

                // 创建epsilon张量
                auto epsilonAttr = std::make_shared<graph::Tensor_attributes>();
                epsilonAttr->set_value(config_.epsilon);

                // 配置RMSNorm属性
                auto rmsnormAttributes = graph::RMSNormAttributes();
                rmsnormAttributes.set_name("Rmsnorm_inference_node")
                    .set_epsilon(epsilonAttr)
                    .set_forward_phase(NormFwdPhase_t::INFERENCE);

                // 添加RMSNorm操作到图中
                auto result = graph->rmsnorm(xAttr, scaleAttr, rmsnormAttributes);
                yAttr = std::get<0>(result);

                // 设置输出张量属性
                yAttr->set_output(true)
                    .set_name("Y")
                    .set_dim(y_dims)
                    .set_stride(y_strides)
                    .set_data_type(ioType);

                // 验证图形
                HIPDNN_FE_CHECK(graph->validate());
                HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
                HIPDNN_FE_CHECK(graph->create_execution_plans());
                HIPDNN_FE_CHECK(graph->check_support());
                HIPDNN_FE_CHECK(graph->build_plans());

                std::cout << "Graph built successfully with config: "
                          << "io_type=" << ioType << ", inter_type=" << interType
                          << ", compute_type=" << compType << std::endl;
                graphBuilt = true;
                break;
            }
            catch(const std::exception& e)
            {
                std::cout << "Graph build failed with config: "
                          << "io_type=" << ioType << ", inter_type=" << interType
                          << ", compute_type=" << compType << ", error: " << e.what() << std::endl;
                continue;
            }
        }

        if(!graphBuilt)
        {
            std::cerr << "Failed to build graph with any configuration." << std::endl;
            return;
        }

        // 初始化张量
        Tensor<InputType> xTensor(x_dims, x_strides);
        Tensor<InputType> scaleTensor(scale_dims, scale_strides);
        Tensor<InputType> yTensor(y_dims, y_strides);
        yTensor.fillWithValue(static_cast<InputType>(0.0f));

        // 读取cudnn生成的文件
        bool readSuccess = false;
        std::vector<InputType> refXData, refScaleData, refYData;
        Tensor<InputType> refYTensor(y_dims, y_strides);

        if(config_.fileIndex > 0)
        {
            // 使用cudnn生成的文件命名约定
            const std::string xFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_X.bin";
            const std::string scaleFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_scale.bin";
            const std::string yFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_Y.bin";

            readSuccess = readRawTensor<InputType>(xFilename, refXData, xTotalElems)
                          && readRawTensor<InputType>(scaleFilename, refScaleData, scaleTotalElems)
                          && readRawTensor<InputType>(yFilename, refYData, xTotalElems);

            if(readSuccess)
            {
                std::cout << "Successfully read RMSNorm reference files from cudnn.\n";
                std::copy(refXData.begin(), refXData.end(), xTensor.memory().hostData());
                xTensor.memory().markHostModified();
                std::copy(
                    refScaleData.begin(), refScaleData.end(), scaleTensor.memory().hostData());
                scaleTensor.memory().markHostModified();

                std::copy(refYData.begin(), refYData.end(), refYTensor.memory().hostData());
                refYTensor.memory().markHostModified();
            }
            else
            {
                std::cerr
                    << " [WARN] Failed to read RMSNorm reference files. Using random values.\n";
                generateRandomData(xTensor, scaleTensor);
            }
        }
        else
        {
            generateRandomData(xTensor, scaleTensor);
        }

        // 准备执行数据 - 使用我们保存的张量属性
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
        variantPack[scaleAttr->get_uid()] = scaleTensor.memory().deviceData();
        variantPack[yAttr->get_uid()] = yTensor.memory().deviceData();

        // 获取工作空间并执行
        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        yTensor.memory().markDeviceModified();

        // 计时运行
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        const int warmupRuns = 10;
        const int timedRuns = 100;

        // 预热运行
        for(int exec_idx = 0; exec_idx < warmupRuns; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(start, nullptr));
        for(int exec_idx = 0; exec_idx < timedRuns; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));

        std::cout << "RMSNorm inference avg time: " << time / timedRuns << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // 计算吞吐量
        const double totalElements
            = static_cast<double>(config_.n * config_.c * config_.h * config_.w);
        const double avgTimeMs = static_cast<double>(time) / timedRuns; // 显式转换为double
        const double throughput = totalElements / (avgTimeMs * 1e-3) / 1e9; // G elements/s
        std::cout << "Throughput: " << throughput << " G elements/s" << std::endl;

        // 文件验证
        if(config_.fileIndex > 0 && readSuccess)
        {
            // 对于int8类型使用特殊的验证方式
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                const InputType* refData = refYTensor.memory().hostData();
                const InputType* currData = yTensor.memory().hostData();
                bool isMatch = true;

                // 打印前10个元素对比
                const size_t printCount = std::min(xTotalElems, static_cast<size_t>(10));
                std::cout << "First " << printCount << " elements comparison:" << std::endl;
                std::cout << "Reference: ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<int>(refData[i]) << " ";
                }
                std::cout << std::endl;

                std::cout << "Current:   ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<int>(currData[i]) << " ";
                }
                std::cout << std::endl;

                // 检查所有元素是否匹配
                for(size_t i = 0; i < xTotalElems; ++i)
                {
                    if(currData[i] != refData[i])
                    {
                        std::cout << "Mismatch at index " << i
                                  << ": ref=" << static_cast<int>(refData[i])
                                  << ", curr=" << static_cast<int>(currData[i]) << std::endl;
                        isMatch = false;
                        break;
                    }
                }
                std::cout << "File validation result: " << (isMatch ? "successful" : "failed")
                          << "\n";
            }
            else
            {
                // 浮点类型的正常验证
                InputType tolerance = getTolerance<InputType>();
                CpuFpReferenceValidation<InputType> fileValidator(static_cast<float>(tolerance),
                                                                  static_cast<float>(tolerance));
                bool isMatch = fileValidator.allClose(refYTensor, yTensor);

                std::cout << "File validation result: " << (isMatch ? "successful" : "failed")
                          << "\n";

                // 打印前10个元素对比
                const size_t printCount = std::min(xTotalElems, static_cast<size_t>(10));
                const InputType* refData = refYTensor.memory().hostData();
                const InputType* currData = yTensor.memory().hostData();

                std::cout << "First " << printCount << " elements comparison:" << std::endl;
                std::cout << "Reference: ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<float>(refData[i]) << " ";
                }
                std::cout << std::endl;

                std::cout << "Current:   ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<float>(currData[i]) << " ";
                }
                std::cout << std::endl;
            }
        }

        // CPU验证
        if(config_.cpuValidation)
        {
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                std::cout << "CPU validation is not supported for int8 input type.\n";
            }
            else
            {
                std::cout << "Running CPU reference validation...\n";

                // CPU参考计算
                cpuRmsnormReference<InputType, IntermediateType>(
                    xTensor, scaleTensor, refYTensor, config_.epsilon);

                InputType tolerance = getTolerance<InputType>();
                auto validator = CpuFpReferenceValidation<InputType>(static_cast<float>(tolerance),
                                                                     static_cast<float>(tolerance));

                bool yValid = validator.allClose(refYTensor, yTensor);

                std::cout << "CPU reference validation: " << (yValid ? "successful" : "failed")
                          << "\n";

                // 打印前10个数据对比
                const size_t totalElems
                    = static_cast<size_t>(config_.n * config_.c * config_.h * config_.w);
                const size_t printCount = std::min(totalElems, static_cast<size_t>(10));

                const InputType* cpuRefData = refYTensor.memory().hostData();
                const InputType* gpuData = yTensor.memory().hostData();

                std::cout << "CPU validation - First " << printCount
                          << " elements comparison:" << std::endl;
                std::cout << "CPU Reference: ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    if constexpr(std::is_same_v<InputType, half>
                                 || std::is_same_v<InputType, bfloat16>)
                    {
                        std::cout << static_cast<float>(cpuRefData[i]) << " ";
                    }
                    else
                    {
                        std::cout << cpuRefData[i] << " ";
                    }
                }
                std::cout << std::endl;

                std::cout << "GPU Output:    ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    if constexpr(std::is_same_v<InputType, half>
                                 || std::is_same_v<InputType, bfloat16>)
                    {
                        std::cout << static_cast<float>(gpuData[i]) << " ";
                    }
                    else
                    {
                        std::cout << gpuData[i] << " ";
                    }
                }
                std::cout << std::endl;

                // 打印差异
                std::cout << "Differences:   ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    float cpuVal, gpuVal;
                    if constexpr(std::is_same_v<InputType, half>)
                    {
                        cpuVal = static_cast<float>(cpuRefData[i]);
                        gpuVal = static_cast<float>(gpuData[i]);
                    }
                    else if constexpr(std::is_same_v<InputType, bfloat16>)
                    {
                        cpuVal = static_cast<float>(cpuRefData[i]);
                        gpuVal = static_cast<float>(gpuData[i]);
                    }
                    else
                    {
                        cpuVal = static_cast<float>(cpuRefData[i]);
                        gpuVal = static_cast<float>(gpuData[i]);
                    }
                    std::cout << std::abs(cpuVal - gpuVal) << " ";
                }
                std::cout << std::endl;
            }
        }

        std::cout << "RMSNorm normalization inference graph execution complete for " << inputType
                  << ".\n\n";
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    // 计算张量元素总数
    size_t getTotalElems(const std::vector<int64_t>& dims)
    {
        size_t total = 1;
        for(auto dim : dims)
        {
            total *= static_cast<size_t>(dim);
        }
        return total;
    }

    // 生成随机数据
    template <typename InputType>
    void generateRandomData(Tensor<InputType>& xTensor, Tensor<InputType>& scaleTensor)
    {
        if constexpr(std::is_same_v<InputType, int8_t>)
        {
            xTensor.fillWithRandomValues(static_cast<InputType>(-127), static_cast<InputType>(127));
            scaleTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                             static_cast<InputType>(127));
        }
        else
        {
            xTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                         static_cast<InputType>(1.0f));
            scaleTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                             static_cast<InputType>(1.0f));
        }
    }

    // 获取容差值
    template <typename InputType>
    InputType getTolerance()
    {
        if constexpr(std::is_same_v<InputType, float>)
        {
            return static_cast<InputType>(1e-5f);
        }
        else if constexpr(std::is_same_v<InputType, half>)
        {
            return static_cast<InputType>(1e-2f);
        }
        else if constexpr(std::is_same_v<InputType, bfloat16>)
        {
            return static_cast<InputType>(1e-2f);
        }
        else if constexpr(std::is_same_v<InputType, int8_t>)
        {
            return static_cast<InputType>(1);
        }
        else
        {
            return static_cast<InputType>(1e-5f);
        }
    }

    // CPU参考实现，对w维度进行归一化
    template <typename InputType, typename IntermediateType = float>
    void cpuRmsnormReference(const Tensor<InputType>& input,
                             const Tensor<InputType>& scale,
                             Tensor<InputType>& output,
                             float epsilon)
    {
        const InputType* inputData = input.memory().hostData();
        const InputType* scaleData = scale.memory().hostData();
        InputType* outputData = output.memory().hostData();

        const int64_t n = config_.n;
        const int64_t c = config_.c;
        const int64_t h = config_.h;
        const int64_t w = config_.w;

        // 遍历所有n, c, h位置
        for(int64_t ni = 0; ni < n; ++ni)
        {
            for(int64_t ci = 0; ci < c; ++ci)
            {
                for(int64_t hi = 0; hi < h; ++hi)
                {
                    // 计算当前位置的w维度的均方根
                    IntermediateType sum_squares = 0.0;

                    // 计算w维度的平方和
                    for(int64_t wi = 0; wi < w; ++wi)
                    {
                        size_t idx = static_cast<size_t>(((ni * c + ci) * h + hi) * w + wi);
                        IntermediateType val = static_cast<IntermediateType>(inputData[idx]);
                        sum_squares += val * val;
                    }

                    // 计算均方根
                    IntermediateType rms = std::sqrt(sum_squares / static_cast<IntermediateType>(w)
                                                     + static_cast<IntermediateType>(epsilon));

                    // 应用归一化和缩放
                    for(int64_t wi = 0; wi < w; ++wi)
                    {
                        size_t idx = static_cast<size_t>(((ni * c + ci) * h + hi) * w + wi);
                        IntermediateType val = static_cast<IntermediateType>(inputData[idx]);
                        IntermediateType normalized = val / rms;
                        outputData[idx] = static_cast<InputType>(
                            normalized * static_cast<IntermediateType>(scaleData[wi]));
                    }
                }
            }
        }

        output.memory().markHostModified();
    }
};

// 根据参数选择执行类型
void run(hipdnnHandle_t handle, const Config& config)
{
    if(config.dataType == "fp32")
    {
        RmsnormRunner runner(handle, config);
        if(config.normType == 1)
        { // inference
            runner.template inference<float>();
        }
    }
    else if(config.dataType == "fp16")
    {
        RmsnormRunner runner(handle, config);
        if(config.normType == 1)
        {
            runner.template inference<half>();
        }
    }
    else if(config.dataType == "bfp16")
    {
        RmsnormRunner runner(handle, config);
        if(config.normType == 1)
        {
            runner.template inference<bfloat16>();
        }
    }
    else if(config.dataType == "int8")
    {
        RmsnormRunner runner(handle, config);
        if(config.normType == 1)
        {
            runner.template inference<int8_t>();
        }
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    // 打印命令行参数
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));

    run(handle, config);

    HIPDNN_CHECK(hipdnnDestroy(handle));
    std::cout << "All RMS normalization inference runs completed.\n";
    return 0;
}
