#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>

#include "../utils.hpp"

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

struct Config
{
    // 通用
    int64_t n = 1;
    int64_t c = 3;
    int64_t h = 32;
    int64_t w = 32;
    int64_t d = 1;
    int resampleMode = 0; // 0=nearest, 1=bilinear, 2=maxpool, 3=avgpool_exclude, 4=avgpool_include
    std::string dataType = "fp32";
    std::string layout = "nchw"; // nchw, nhwc, ncdhw, ndhwc
    int fileIndex = 0;
    std::string filePath = "";

    // 插值参数 (仅当 resampleMode 0/1)
    int64_t scale_h = 1;
    int64_t scale_w = 1;
    int nearestMode = 1; // 0..3
    int coordMode = 0; // 0..4

    // 池化参数 (当 resampleMode >= 2)
    std::vector<int64_t> prePadding = {0, 0};
    std::vector<int64_t> postPadding = {0, 0};
    std::vector<int64_t> stride = {1, 1};
    std::vector<int64_t> window = {2, 2};
    std::string paddingMode = "zero_pad"; // "zero_pad" 或 "neg_inf_pad"
    bool generateIndex = false;
    bool cpuValidation = false;

    // 辅助函数
    int getSpatialDims() const
    {
        if(layout == "nchw" || layout == "nhwc")
            return 2;
        if(layout == "ncdhw" || layout == "ndhwc")
            return 3;
        return 2;
    }
};

std::vector<int64_t> parseIntegerList(const std::string& s)
{
    std::vector<int64_t> result;
    std::stringstream ss(s);
    std::string item;
    while(std::getline(ss, item, ','))
    {
        if(!item.empty())
        {
            result.push_back(std::stoll(item));
        }
    }
    return result;
}

// ============================================================================
// 命令行参数解析
// ============================================================================
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-h") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-w") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-depth") == 0 && i + 1 < argc)
        {
            config.d = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-scale_h") == 0 && i + 1 < argc)
        {
            config.scale_h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-scale_w") == 0 && i + 1 < argc)
        {
            config.scale_w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-m") == 0 && i + 1 < argc)
        {
            config.resampleMode = std::stoi(argv[++i]);
            if(config.resampleMode < 0 || config.resampleMode > 4)
            {
                std::cerr << "Resample mode must be 0..4" << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "-r") == 0 && i + 1 < argc)
        {
            config.nearestMode = std::stoi(argv[++i]);
            if(config.nearestMode < 0 || config.nearestMode > 3)
            {
                std::cerr << "Nearest mode must be 0..3" << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "-t") == 0 && i + 1 < argc)
        {
            config.coordMode = std::stoi(argv[++i]);
            if(config.coordMode < 0 || config.coordMode > 4)
            {
                std::cerr << "Coord mode must be 0..4" << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::tolower);
            if(config.layout != "nchw" && config.layout != "nhwc" && config.layout != "ncdhw"
               && config.layout != "ndhwc")
            {
                std::cerr << "Unsupported layout: " << config.layout << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-file_index") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-file_path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
                config.filePath += "/";
        }
        else if(strcmp(argv[i], "-pre_pad") == 0 && i + 1 < argc)
        {
            config.prePadding = parseIntegerList(argv[++i]);
        }
        else if(strcmp(argv[i], "-post_pad") == 0 && i + 1 < argc)
        {
            config.postPadding = parseIntegerList(argv[++i]);
        }
        else if(strcmp(argv[i], "-stride") == 0 && i + 1 < argc)
        {
            config.stride = parseIntegerList(argv[++i]);
        }
        else if(strcmp(argv[i], "-window") == 0 && i + 1 < argc)
        {
            config.window = parseIntegerList(argv[++i]);
        }
        else if(strcmp(argv[i], "-pad_mode") == 0 && i + 1 < argc)
        {
            config.paddingMode = argv[++i];
            std::transform(config.paddingMode.begin(),
                           config.paddingMode.end(),
                           config.paddingMode.begin(),
                           ::tolower);
            if(config.paddingMode != "zero_pad" && config.paddingMode != "neg_inf_pad")
            {
                std::cerr << "Padding mode must be zero_pad or neg_inf_pad" << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "-gen_index") == 0 && i + 1 < argc)
        {
            config.generateIndex = (std::stoi(argv[++i]) == 1);
        }
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

struct DimsStrides
{
    std::vector<int64_t> inDims, inStride, outDims, outStride;
};

DimsStrides buildDimsStrides(const Config& config)
{
    int64_t n = config.n, c = config.c, h = config.h, w = config.w, d = config.d;
    int spatialDims = config.getSpatialDims();
    std::vector<int64_t> inSpatial, outSpatial;
    if(spatialDims == 2)
    {
        inSpatial = {h, w};
        if(config.resampleMode < 2)
        {
            outSpatial = {h * config.scale_h, w * config.scale_w};
        }
        else
        { // 池化
            for(int i = 0; i < 2; i++)
            {
                int64_t out = (inSpatial[i] + config.prePadding[i] + config.postPadding[i]
                               - config.window[i])
                                  / config.stride[i]
                              + 1;
                outSpatial.push_back(out);
            }
        }
    }
    else
    { // 5D
        inSpatial = {d, h, w};
        if(config.resampleMode < 2)
        {
            std::cerr << "Interpolation only supports 4D layouts" << std::endl;
            exit(1);
        }
        for(int i = 0; i < 3; i++)
        {
            int64_t out
                = (inSpatial[i] + config.prePadding[i] + config.postPadding[i] - config.window[i])
                      / config.stride[i]
                  + 1;
            outSpatial.push_back(out);
        }
    }

    DimsStrides result;
    if(config.layout == "nchw")
    {
        result.inDims = {n, c, inSpatial[0], inSpatial[1]};
        result.inStride
            = {c * inSpatial[0] * inSpatial[1], inSpatial[0] * inSpatial[1], inSpatial[1], 1};
        result.outDims = {n, c, outSpatial[0], outSpatial[1]};
        result.outStride
            = {c * outSpatial[0] * outSpatial[1], outSpatial[0] * outSpatial[1], outSpatial[1], 1};
    }
    else if(config.layout == "nhwc")
    {
        result.inDims = {n, inSpatial[0], inSpatial[1], c};
        result.inStride = {inSpatial[0] * inSpatial[1] * c, inSpatial[1] * c, c, 1};
        result.outDims = {n, outSpatial[0], outSpatial[1], c};
        result.outStride = {outSpatial[0] * outSpatial[1] * c, outSpatial[1] * c, c, 1};
    }
    else if(config.layout == "ncdhw")
    {
        result.inDims = {n, c, inSpatial[0], inSpatial[1], inSpatial[2]};
        result.inStride = {c * inSpatial[0] * inSpatial[1] * inSpatial[2],
                           inSpatial[0] * inSpatial[1] * inSpatial[2],
                           inSpatial[1] * inSpatial[2],
                           inSpatial[2],
                           1};
        result.outDims = {n, c, outSpatial[0], outSpatial[1], outSpatial[2]};
        result.outStride = {c * outSpatial[0] * outSpatial[1] * outSpatial[2],
                            outSpatial[0] * outSpatial[1] * outSpatial[2],
                            outSpatial[1] * outSpatial[2],
                            outSpatial[2],
                            1};
    }
    else if(config.layout == "ndhwc")
    {
        result.inDims = {n, inSpatial[0], inSpatial[1], inSpatial[2], c};
        result.inStride = {inSpatial[0] * inSpatial[1] * inSpatial[2] * c,
                           inSpatial[1] * inSpatial[2] * c,
                           inSpatial[2] * c,
                           c,
                           1};
        result.outDims = {n, outSpatial[0], outSpatial[1], outSpatial[2], c};
        result.outStride = {outSpatial[0] * outSpatial[1] * outSpatial[2] * c,
                            outSpatial[1] * outSpatial[2] * c,
                            outSpatial[2] * c,
                            c,
                            1};
    }
    return result;
}

class ResampleRunner
{
public:
    ResampleRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType>
    void run()
    {
        using OutputType = InputType;
        auto dataType = getDataTypeEnumFromType<InputType>();

        // 构建维度
        auto dimsStrides = buildDimsStrides(config_);
        auto& inDims = dimsStrides.inDims;
        auto& inStride = dimsStrides.inStride;
        auto& outDims = dimsStrides.outDims;
        auto& outStride = dimsStrides.outStride;

        size_t inputSize = 1, outputSize = 1;
        for(auto v : inDims)
            inputSize *= v;
        for(auto v : outDims)
            outputSize *= v;

        // 创建图
        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(dataType)
            .set_compute_data_type(DataType::FLOAT)
            .set_intermediate_data_type(DataType::FLOAT);

        auto input = createTensor(inDims, dataType, inStride);
        input->set_name("input");

        // 构建属性
        graph::ResampleFwdAttributes attr;
        attr.set_name("resample_node").set_generate_index(config_.generateIndex);

        if(config_.resampleMode < 2)
        { // 插值
            if(config_.getSpatialDims() != 2)
            {
                std::cerr << "Interpolation only supports 4D layouts" << std::endl;
                exit(1);
            }
            std::vector<int64_t> scale = {config_.scale_h, config_.scale_w};
            attr.set_scale(scale);

            // 模式
            if(config_.resampleMode == 0)
            { // nearest
                attr.set_resample_mode(ResampleMode_t::NEAREST);
                switch(config_.nearestMode)
                {
                case 0:
                    attr.set_nearest_mode(NearestMode::NEAREST_FLOOR);
                    break;
                case 1:
                    attr.set_nearest_mode(NearestMode::NEAREST_CEIL);
                    break;
                case 2:
                    attr.set_nearest_mode(NearestMode::NEAREST_ROUND_PREFER_FLOOR);
                    break;
                case 3:
                    attr.set_nearest_mode(NearestMode::NEAREST_ROUND_PREFER_CEIL);
                    break;
                }
            }
            else
            { // bilinear
                attr.set_resample_mode(ResampleMode_t::BILINEAR);
            }

            // 坐标变换模式
            switch(config_.coordMode)
            {
            case 0:
                attr.set_coordinate_transform_mode(
                    CoordinateTransformationMode_t::COORDINATE_ASYMMETRIC);
                break;
            case 1:
                attr.set_coordinate_transform_mode(
                    CoordinateTransformationMode_t::COORDINATE_HALF_PIXEL);
                break;
            case 2:
                attr.set_coordinate_transform_mode(
                    CoordinateTransformationMode_t::COORDINATE_ALIGN_CORNERS);
                break;
            case 3:
                attr.set_coordinate_transform_mode(
                    CoordinateTransformationMode_t::COORDINATE_PYTORCH_HALF_PIXEL);
                break;
            case 4:
                attr.set_coordinate_transform_mode(
                    CoordinateTransformationMode_t::COORDINATE_TF_HALF_PIXEL_FORXN);
                break;
            }
        }
        else
        { // 池化
            int spatialDims = config_.getSpatialDims();
            if((int)config_.prePadding.size() != spatialDims
               || (int)config_.postPadding.size() != spatialDims
               || (int)config_.stride.size() != spatialDims
               || (int)config_.window.size() != spatialDims)
            {
                std::cerr << "Padding/stride/window size must match spatial dims (" << spatialDims
                          << ")" << std::endl;
                exit(1);
            }
            // 检查对称padding
            for(int i = 0; i < spatialDims; ++i)
            {
                if(config_.prePadding[i] != config_.postPadding[i])
                {
                    std::cerr << "Only symmetric padding is supported" << std::endl;
                    exit(1);
                }
            }
            attr.set_pre_padding(config_.prePadding)
                .set_post_padding(config_.postPadding)
                .set_stride(config_.stride)
                .set_window(config_.window);

            // 模式
            switch(config_.resampleMode)
            {
            case 2:
                attr.set_resample_mode(ResampleMode_t::MAXPOOL);
                break;
            case 3:
                attr.set_resample_mode(ResampleMode_t::AVGPOOL_EXCLUDE_PADDING);
                break;
            case 4:
                attr.set_resample_mode(ResampleMode_t::AVGPOOL_INCLUDE_PADDING);
                break;
            }

            // Padding mode
            if(config_.paddingMode == "zero_pad")
                attr.set_padding_mode(PaddingMode_t::ZERO_PAD);
            else if(config_.paddingMode == "neg_inf_pad")
                attr.set_padding_mode(PaddingMode_t::NEG_INF_PAD);

            if(config_.resampleMode == 2 && config_.paddingMode != "neg_inf_pad")
            {
                std::cerr << "MAXPOOL requires neg_inf_pad" << std::endl;
                exit(1);
            }
            if(config_.resampleMode == 4 && config_.paddingMode != "zero_pad")
            {
                std::cerr << "AVGPOOL_INCLUDE_PADDING requires zero_pad" << std::endl;
                exit(1);
            }
        }

        auto [output, index] = graph->resample(input, attr);
        output->set_output(true).set_data_type(dataType);

        // 构建图
        HIPDNN_FE_CHECK(graph->build(handle_));
        std::cout << "Graph build successful." << std::endl;

        // 分配张量
        Tensor<InputType> inputTensor(inDims, inStride);
        Tensor<OutputType> outputTensor(outDims, outStride);

        // 数据初始化
        bool readSuccess = false;
        std::vector<InputType> refInputData;
        std::vector<OutputType> refOutputData;
        Tensor<OutputType> refOutputTensor(outDims, outStride);

        if(config_.fileIndex > 0)
        {
            std::string inputFile
                = config_.filePath + std::to_string(config_.fileIndex) + "_input.bin";
            std::string outputFile
                = config_.filePath + std::to_string(config_.fileIndex) + "_output.bin";
            bool readInput = readRawTensor<InputType>(inputFile, refInputData, inputSize);
            bool readOutput = readRawTensor<OutputType>(outputFile, refOutputData, outputSize);
            if(readInput && readOutput)
            {
                std::cout << "Successfully read reference files." << std::endl;
                readSuccess = true;
                std::copy(
                    refInputData.begin(), refInputData.end(), inputTensor.memory().hostData());
                inputTensor.memory().markHostModified();
                std::copy(refOutputData.begin(),
                          refOutputData.end(),
                          refOutputTensor.memory().hostData());
                refOutputTensor.memory().markHostModified();
            }
            else
            {
                std::cerr << "[WARN] Failed to read reference files. Using random." << std::endl;
                fillRandom(inputTensor);
            }
        }
        else
        {
            fillRandom(inputTensor);
        }

        inputTensor.memory().markHostModified();

        // Variant pack
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[input->get_uid()] = inputTensor.memory().deviceData();
        variantPack[output->get_uid()] = outputTensor.memory().deviceData();

        // Workspace
        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 预热和计时
        HIP_CHECK(hipDeviceSynchronize());
        const int warmup = 10;
        const int iterations = 100;
        for(int i = 0; i < warmup; ++i)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipDeviceSynchronize());

        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));
        for(int i = 0; i < iterations; ++i)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "Average time: " << time / iterations << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // 打印部分结果
        outputTensor.memory().markDeviceModified();
        const OutputType* gpuOut = outputTensor.memory().hostData();
        std::cout << "First 10 GPU output values: ";
        for(int i = 0; i < std::min(10, (int)outputSize); ++i)
        {
            std::cout << static_cast<float>(gpuOut[i]) << " ";
        }
        std::cout << std::endl;

        // CPU验证
        if(config_.cpuValidation)
        {
            std::unordered_map<int64_t, void*> cpuVariantPack;
            cpuVariantPack[input->get_uid()] = inputTensor.memory().hostData();
            Tensor<OutputType> cpuTensor(outDims, outStride);
            cpuVariantPack[output->get_uid()] = cpuTensor.memory().hostData();

            auto serializedGraph = graph->to_binary().first;
            CpuReferenceGraphExecutor cpuExecutor;
            cpuExecutor.execute(serializedGraph.data(), serializedGraph.size(), cpuVariantPack);
            cpuTensor.memory().markHostModified();

            float tolerance = 1e-2f;
            if(config_.resampleMode == 1 && std::is_same_v<OutputType, float>) // bilinear
                tolerance = 1e-4f;
            if constexpr(std::is_same_v<OutputType, int8_t>) // int8: ±1 rounding tolerance
                tolerance = 1.0f;

            auto validator = createAllCloseValidator<OutputType>(tolerance, tolerance);
            bool pass = validator->allClose(cpuTensor, outputTensor);
            std::cout << "CPU validation result: " << (pass ? "successful" : "failed") << std::endl;
        }

        // 文件参考验证 (仅浮点类型，CpuFpReferenceValidation 内部使用了 isnan/isinf)
        if(config_.fileIndex > 0 && readSuccess)
        {
            outputTensor.memory().markDeviceModified();
            if constexpr(!std::is_integral_v<OutputType>)
            {
                float tolerance = 0.01f;
                CpuFpReferenceValidation<OutputType> fileValidator(tolerance, tolerance);
                bool isMatch = fileValidator.allClose(refOutputTensor, outputTensor);
                std::cout << "Reference validation result: " << (isMatch ? "successful" : "failed")
                          << std::endl;
            }
            else
            {
                std::cout << "Reference validation skipped for non-floating-point type."
                          << std::endl;
            }
        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    template <typename T>
    void fillRandom(Tensor<T>& tensor)
    {
        if constexpr(std::is_same_v<T, int8_t>)
            tensor.fillWithRandomValues(static_cast<T>(-127), static_cast<T>(127));
        else
            tensor.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
    }

    std::shared_ptr<graph::TensorAttributes> createTensor(const std::vector<int64_t>& dims,
                                                          DataType dataType,
                                                          const std::vector<int64_t>& stride)
    {
        auto attr = std::make_shared<graph::TensorAttributes>();
        attr->set_dim(dims);
        attr->set_stride(stride);
        attr->set_data_type(dataType);
        return attr;
    }
};

void runResample(hipdnnHandle_t handle, const Config& config)
{
    if(config.resampleMode < 2)
    {
        if(config.getSpatialDims() != 2)
        {
            std::cerr << "Interpolation only supports 4D layouts" << std::endl;
            exit(1);
        }
        ResampleRunner runner(handle, config);
        if(config.dataType == "fp16")
        {
            runner.run<half>();
        }
        else if(config.dataType == "int8")
        {
            runner.run<int8_t>();
        }
        else
        {
            std::cerr << "Interpolation only supports fp16 and int8 data types" << std::endl;
            exit(1);
        }
    }
    else
    {
        ResampleRunner runner(handle, config);
        if(config.dataType == "fp32")
        {
            runner.run<float>();
        }
        else if(config.dataType == "fp16")
        {
            runner.run<half>();
        }
        else if(config.dataType == "int8")
        {
            runner.run<int8_t>();
        }
        else
        {
            std::cerr << "Pooling only supports fp16, fp32, and int8" << std::endl;
            exit(1);
        }
    }
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
        std::cout << argv[i] << " ";
    std::cout << std::endl;

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));
    runResample(handle, config);
    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
