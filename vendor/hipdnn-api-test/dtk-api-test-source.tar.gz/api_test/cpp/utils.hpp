// Copyright © Advanced Micro Devices, Inc., or its affiliates.
// SPDX-License-Identifier:  MIT
#pragma once

#include <algorithm>
#include <fstream>
#include <hip/hip_runtime.h>
#include <hipdnn_data_sdk/utilities/ShapeUtilities.hpp>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_frontend.hpp>
#include <iostream>
#include <memory>
#include <numeric>
#include <random>
#include <string>
#include <vector>

using hipdnn_data_sdk::utilities::TensorLayout;

#define HIP_CHECK(status)                                                                      \
    do                                                                                         \
    {                                                                                          \
        if(status != hipSuccess)                                                               \
        {                                                                                      \
            std::cerr << "HIP Error: " << hipGetErrorString(status) << " in file " << __FILE__ \
                      << " at line " << __LINE__ << "\n";                                      \
            exit(EXIT_FAILURE);                                                                \
        }                                                                                      \
    } while(0)

#define HIPDNN_CHECK(status)                                                             \
    do                                                                                   \
    {                                                                                    \
        if(status != HIPDNN_STATUS_SUCCESS)                                              \
        {                                                                                \
            std::cerr << "hipDNN Error: " << hipdnnGetErrorString(status) << " in file " \
                      << __FILE__ << " at line " << __LINE__ << "\n";                    \
            exit(EXIT_FAILURE);                                                          \
        }                                                                                \
    } while(0)

#define HIPDNN_FE_CHECK(statusObj)                                                        \
    do                                                                                    \
    {                                                                                     \
        auto const& status = statusObj;                                                   \
        if(!status.is_good())                                                             \
        {                                                                                 \
            std::cerr << "hipDNN Frontend Error: " << status.get_message() << " in file " \
                      << __FILE__ << " at line " << __LINE__ << "\n";                     \
            exit(EXIT_FAILURE);                                                           \
        }                                                                                 \
    } while(0)

inline void printSampleHelp(const std::string& sampleName)
{
    std::cout << "Usage: " << sampleName << " [OPTIONS]\n"
              << "Options:\n"
              << "  --verify-cpu, -vc    Enable CPU reference validation\n"
              << "  --help, -h      Show this help message\n"
              << "\n";
}

inline std::shared_ptr<hipdnn_frontend::graph::Tensor_attributes>
    createTensor(const std::vector<int64_t>& dims,
                 hipdnn_frontend::DataType_t dataType,
                 const std::vector<int64_t>& strideOrder = {4, 3, 2, 1, 0})
{
    auto tensor = std::make_shared<hipdnn_frontend::graph::Tensor_attributes>();
    tensor->set_dim(dims).set_data_type(dataType);
    tensor->set_stride(hipdnn_data_sdk::utilities::generateStrides(dims, strideOrder));

    return tensor;
}

// 读取文件
template <typename T>
bool readRawTensor(const std::string& filename, std::vector<T>& data, size_t totalElems)
{
    // 1. 打开文件
    std::ifstream file(filename, std::ios::binary | std::ios::in);
    if(!file.is_open())
    {
        std::cerr << "[ERROR] 无法打开文件: " << filename << "（检查路径/权限）\n";
        return false;
    }

    // 2. 移动指针到文件末尾
    file.seekg(0, std::ios::end);
    if(file.fail())
    {
        std::cerr << "[ERROR] 移动文件指针到末尾失败！文件: " << filename << "\n";
        std::cerr << "流状态：failbit=" << file.fail() << ", badbit=" << file.bad() << "\n";
        file.close();
        return false;
    }

    // 3. 获取文件大小
    const auto fileSizeStreamoff = file.tellg();
    if(fileSizeStreamoff == -1)
    {
        std::cerr << "[ERROR] 获取文件大小失败！文件: " << filename << "\n";
        file.close();
        return false;
    }
    const size_t fileSize = static_cast<size_t>(fileSizeStreamoff);
    const size_t expectedSize = totalElems * sizeof(T);

    // 4. 校验大小
    if(fileSize != expectedSize)
    {
        std::cerr << "[ERROR] 文件 " << filename << " 大小不匹配：\n";
        std::cerr << "  预期: " << expectedSize << " 字节，实际: " << fileSize << " 字节\n";
        file.close();
        return false;
    }

    // 5. 移动指针回开头
    file.seekg(0, std::ios::beg);
    if(file.fail())
    {
        std::cerr << "[ERROR] 移动文件指针到开头失败！文件: " << filename << "\n";
        file.close();
        return false;
    }

    // 6. 读取数据
    data.resize(totalElems);
    file.read(reinterpret_cast<char*>(data.data()), static_cast<std::streamsize>(expectedSize));
    if(file.gcount() != static_cast<std::streamsize>(expectedSize))
    {
        std::cerr << "[ERROR] 读取文件不完整！文件: " << filename << "\n";
        std::cerr << "  已读: " << file.gcount() << " 字节，预期: " << expectedSize << " 字节\n";
        file.close();
        return false;
    }

    // 7. 关闭文件
    file.close();
    // std::cout << "[INFO] 成功读取文件: " << filename << "，大小: " << fileSize << " 字节\n";
    return true;
}

template <typename T>
std::vector<T> nhwcToNchw(const std::vector<T>& nhwcData, const std::vector<long>& nhwcDims)
{
    // 检查维度数量是否为4（NHWC必须包含4个维度）
    if(nhwcDims.size() != 4)
    {
        throw std::invalid_argument("NHWC维度必须包含4个元素: [N, H, W, C]");
    }

    // 解析各维度（使用size_t匹配容器索引类型，显式转换避免精度丢失）
    const size_t N = static_cast<size_t>(nhwcDims[0]); // 批次
    const size_t H = static_cast<size_t>(nhwcDims[1]); // 高度
    const size_t W = static_cast<size_t>(nhwcDims[2]); // 宽度
    const size_t C = static_cast<size_t>(nhwcDims[3]); // 通道

    // 计算总元素数（使用size_t避免符号问题）
    const size_t total = N * H * W * C;

    // 检查输入数据大小是否匹配维度
    if(nhwcData.size() != total)
    {
        throw std::invalid_argument("输入数据大小与NHWC维度不匹配");
    }

    // 初始化输出容器（使用size_t作为大小参数）
    std::vector<T> nchwData(total);

    // 核心转换逻辑（循环变量使用size_t匹配容器索引类型）
    for(size_t n = 0; n < N; ++n)
    { // 批次维度
        for(size_t h = 0; h < H; ++h)
        { // 高度维度
            for(size_t w = 0; w < W; ++w)
            { // 宽度维度
                for(size_t c = 0; c < C; ++c)
                { // 通道维度
                    // NHWC格式索引：[N][H][W][C]
                    const size_t nhwcIdx = n * H * W * C + h * W * C + w * C + c;

                    // NCHW格式索引：[N][C][H][W]
                    const size_t nchwIdx = n * C * H * W + c * H * W + h * W + w;

                    // 赋值（索引类型与vector匹配，无符号转换问题）
                    nchwData[nchwIdx] = nhwcData[nhwcIdx];
                }
            }
        }
    }

    return nchwData;
}
