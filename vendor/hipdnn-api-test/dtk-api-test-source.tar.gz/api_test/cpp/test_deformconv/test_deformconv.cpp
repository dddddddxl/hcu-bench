#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceDeformConvolution.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>

#include "../utils.hpp"
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

struct Config
{
    int64_t n = 4; // batch size
    int64_t c = 64; // 输入通道数
    int64_t d = 16; // 输入深度
    int64_t h = 16; // 输入高度
    int64_t w = 16; // 输入宽度
    int64_t k = 64; // 输出通道数
    int64_t t = 1; // 可变形卷积核深度
    int64_t r = 1; // 可变形卷积核高度
    int64_t s = 1; // 可变形卷积核宽度
    int64_t padD = 0; // 深度方向padding
    int64_t padH = 0; // 高度方向padding
    int64_t padW = 0; // 宽度方向padding
    int64_t strideD = 1; // 深度方向步长
    int64_t strideH = 1; // 高度方向步长
    int64_t strideW = 1; // 宽度方向步长
    int64_t dilD = 1; // 深度方向dilation
    int64_t dilH = 1; // 高度方向dilation
    int64_t dilW = 1; // 宽度方向dilation
    int64_t groups = 1; // 组数
    int64_t tensorsused
        = 0; // 是否使用张量: 0/1(fprop/wgrad); V1:4/8/12, V2:3/5/9/13/11/7/15(dgrad)
    std::string dataType = "fp32";
    std::string layout = "NHWC";
    int deformconvType = 1; // 可变形卷积类型: fprop=1, dgrad=2, wgrad=4
    bool cpuValidation = true;
    int fileIndex = 0;
    std::string filePath = ".";
    int dimension = 2; // 可变形卷积维度: 2D=2, 3D=3
};

Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--in_d") == 0 && i + 1 < argc)
        {
            config.d = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-k") == 0 && i + 1 < argc)
        {
            config.k = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--fil_d") == 0 && i + 1 < argc)
        {
            config.t = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-y") == 0 && i + 1 < argc)
        {
            config.r = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-x") == 0 && i + 1 < argc)
        {
            config.s = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--pad_d") == 0 && i + 1 < argc)
        {
            config.padD = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-p") == 0 && i + 1 < argc)
        {
            config.padH = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc)
        {
            config.padW = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--conv_stride_d") == 0 && i + 1 < argc)
        {
            config.strideD = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-u") == 0 && i + 1 < argc)
        {
            config.strideH = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-v") == 0 && i + 1 < argc)
        {
            config.strideW = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--dilation_d") == 0 && i + 1 < argc)
        {
            config.dilD = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-l") == 0 && i + 1 < argc)
        {
            config.dilH = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-j") == 0 && i + 1 < argc)
        {
            config.dilW = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-g") == 0 && i + 1 < argc)
        {
            config.groups = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else if(strcmp(argv[i], "-F") == 0 && i + 1 < argc)
        {
            int type = std::stoi(argv[++i]);
            if(type != 1 && type != 2 && type != 4)
            {
                std::cerr << "Invalid deformconvolution type: " << type << std::endl;
                std::cerr << "Supported types: 1(fprop), 2(dgrad), 4(wgrad)" << std::endl;
                exit(1);
            }
            config.deformconvType = type;
        }
        else if(strcmp(argv[i], "--spatial_dim") == 0 && i + 1 < argc)
        {
            config.dimension = std::stoi(argv[++i]);
            if(config.dimension != 2 && config.dimension != 3)
            {
                std::cerr << "Invalid dimension: " << config.dimension << std::endl;
                std::cerr << "Supported dimensions: 2(2D), 3(3D)" << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "-M") == 0 && i + 1 < argc)
        {
            config.tensorsused = std::stoll(argv[++i]);
            if(config.tensorsused != 0 && config.tensorsused != 1 && config.tensorsused != 3
               && config.tensorsused != 4 && config.tensorsused != 5 && config.tensorsused != 7
               && config.tensorsused != 8 && config.tensorsused != 9 && config.tensorsused != 11
               && config.tensorsused != 12 && config.tensorsused != 13 && config.tensorsused != 15)
            {
                std::cerr << "Invalid deformconvolution tensorsused: " << config.tensorsused
                          << std::endl;
                std::cerr << "Supported tensorsused: 0/1(fprop/wgrad); V1:4/8/12, "
                             "V2:3/5/9/13/11/7/15(dgrad)"
                          << std::endl;
                exit(1);
            }
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            std::cerr << "-n <batch> -c <channels> --in_d <depth/height> -H <height> -W <width> "
                      << "-k <filters> --fil_d <filter_depth/height> -y <filter_h> -x <filter_w> "
                      << "--pad_d <pad_depth/height> -p <pad_h> -q <pad_w> "
                      << "--conv_stride_d <stride_d/height> -u <stride_h> -v <stride_w> "
                      << "--dilation_d <dil_d/height> -l <dil_h> -j <dil_w> -g <groups> "
                      << "-d <data_type> -L <layout> -i <file_index> -F <1/2/4> --spatial_dim "
                         "<2/3> -M <fwd/wrw:0/1; bwd:V1:4/8/12;V2:3/5/9/13/11/7/15> "
                      << "[--cpu-validation] -path <path>\n";
            exit(1);
        }
    }

    return config;
}

class DeformConvRunner
{
public:
    DeformConvRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType, typename IntermediateType>
    void fprop(const TensorLayout& layout)
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        using OutputType
            = std::conditional_t<std::is_same_v<InputType, int8_t>, int32_t, InputType>;
        const auto outputType = getDataTypeEnumFromType<OutputType>();

        std::cout << "Running deformable convolution forward graph " << inputType << " [" << layout
                  << "]" << (config_.cpuValidation ? " (with CPU validation)" : "") << "...\n";

        // 提取配置参数
        // Input
        const int64_t n = config_.n;
        const int64_t c = config_.c;
        const int64_t d = config_.d;
        const int64_t h = config_.h;
        const int64_t w = config_.w;
        // Filter
        const int64_t k = config_.k;
        const int64_t t = config_.t;
        const int64_t r = config_.r;
        const int64_t s = config_.s;
        const int64_t g = config_.groups;

        std::cout << "Parameter information of size: \n";
        std::cout << "n: " << n << '\n';
        std::cout << "c: " << c << '\n';
        std::cout << "h: " << h << '\n';
        std::cout << "w: " << w << '\n';
        std::cout << "k: " << k << '\n';
        std::cout << "t: " << t << '\n';
        std::cout << "r: " << r << '\n';
        std::cout << "s: " << s << '\n';
        std::cout << "g: " << g << '\n';
        std::cout << "dimension: " << config_.dimension << '\n';
        std::cout << "deformconvType: " << config_.deformconvType << '\n';
        std::cout << "tensorsused: " << config_.tensorsused << '\n';
        std::cout << '\n';

        // 根据维度设置padding、stride、dilation
        std::vector<int64_t> padding, stride, dilation;
        if(config_.dimension == 2)
        {
            padding = {config_.padH, config_.padW};
            stride = {config_.strideH, config_.strideW};
            dilation = {config_.dilH, config_.dilW};
        }
        else
        {
            padding = {config_.padD, config_.padH, config_.padW};
            stride = {config_.strideD, config_.strideH, config_.strideW};
            dilation = {config_.dilD, config_.dilH, config_.dilW};
        }

        // 计算输出维度
        int64_t od, oh, ow;
        if(config_.dimension == 2)
        {
            // 2D可变形卷积输出维度计算
            oh = ((h + 2 * config_.padH - (config_.dilH * (r - 1) + 1)) / config_.strideH) + 1;
            ow = ((w + 2 * config_.padW - (config_.dilW * (s - 1) + 1)) / config_.strideW) + 1;
            od = 1; // 2D可变形卷积深度为1
        }
        else
        {
            // 3D可变形卷积输出维度计算
            od = (d + 2 * config_.padD - config_.dilD * (t - 1) + 1) / config_.strideD + 1;
            oh = (h + 2 * config_.padH - config_.dilH * (r - 1) + 1) / config_.strideH + 1;
            ow = (w + 2 * config_.padW - config_.dilW * (s - 1) + 1) / config_.strideW + 1;
        }

        // 计算总元素数
        //        size_t xTotalElems, wTotalElems, yTotalElems;
        //        if(config_.dimension == 2)
        //        {
        //            xTotalElems = static_cast<size_t>(n * c * h * w);
        //            wTotalElems = static_cast<size_t>(k * (c / g) * r * s);
        //            yTotalElems = static_cast<size_t>(n * k * oh * ow);
        //        }
        //        else
        //        {
        //            xTotalElems = static_cast<size_t>(n * c * d * h * w);
        //            wTotalElems = static_cast<size_t>(k * (c / g) * t * r * s);
        //            yTotalElems = static_cast<size_t>(n * k * od * oh * ow);
        //        }

        // 创建计算图
        auto graph = std::make_shared<graph::Graph>();
        graph
            ->set_io_data_type(inputType) // 设置输入输出数据类型
            .set_compute_data_type(DataType::FLOAT) // 设置计算数据类型为float
            .set_intermediate_data_type(intermediateType); // 设置中间结果数据类型

        // 定义输入和权重张量属性
        std::shared_ptr<graph::TensorAttributes> xAttr, wAttr, offsetAttr, maskAttr;
        if(config_.dimension == 2)
        {
            xAttr = createTensor({n, c, h, w}, inputType, layout.strideOrder);
            wAttr = createTensor({k, c / g, r, s}, inputType, layout.strideOrder);
            offsetAttr = createTensor({n, 2 * r * s, oh, ow}, inputType, layout.strideOrder);
            maskAttr = createTensor({n, g * r * s, oh, ow}, inputType, layout.strideOrder);
        }
        else
        {
            xAttr = createTensor({n, c, d, h, w}, inputType, layout.strideOrder);
            wAttr = createTensor({k, c / g, t, r, s}, inputType, layout.strideOrder);
            offsetAttr
                = createTensor({n, 2 * t * r * s, od, oh, ow}, inputType, layout.strideOrder);
            maskAttr = createTensor({n, g * t * r * s, od, oh, ow}, inputType, layout.strideOrder);
        }

        // 可变形卷积参数配置
        graph::DeformConvFpropAttributes deformConvAttributes;
        deformConvAttributes.set_name(config_.dimension == 2 ? "deformconv2d_fprop_node"
                                                             : "deformconv3d_fprop_node");
        deformConvAttributes.set_padding(padding);
        deformConvAttributes.set_stride(stride);
        deformConvAttributes.set_dilation(dilation);
        if(config_.tensorsused == 1)
        {
            deformConvAttributes.set_mask(maskAttr);
        }

        // 创建输出张量并设置类型
        auto yAttr = graph->deform_conv_fprop(
            xAttr, offsetAttr, wAttr, deformConvAttributes); // hipdnn的接口

        yAttr->set_output(true).set_data_type(outputType);

        if(config_.tensorsused == 0)
        {
            // 图验证与构建
            HIPDNN_FE_CHECK(graph->validate());
            std::cout << "Graph validation successful (fprop).\n";

            HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
            std::cout << "Operation graph build successful (fprop).\n";

            HIPDNN_FE_CHECK(graph->create_execution_plans());
            std::cout << "Execution plans created successfully (fprop).\n";

            HIPDNN_FE_CHECK(graph->check_support());
            std::cout << "Graph support check successful (fprop).\n";

            HIPDNN_FE_CHECK(graph->build_plans());
            std::cout << "Plans build successful (fprop).\n";

            // 初始化张量
            Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
            Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
            Tensor<InputType> offsetTensor(offsetAttr->get_dim(), offsetAttr->get_stride());
            Tensor<OutputType> yTensor(yAttr->get_dim(), yAttr->get_stride());

            // 初始化值
            fillTensorWithRandomValues(xTensor);
            fillTensorWithRandomValues(wTensor);
            fillTensorWithRandomValues(offsetTensor);
            yTensor.fillWithValue(
                static_cast<OutputType>(std::is_floating_point_v<OutputType> ? 0.0f : 0));

            // 读取参考数据或生成随机数据
            Tensor<OutputType> refYTensor(yAttr->get_dim(), yAttr->get_stride());

            std::unordered_map<int64_t, void*> variantPack;
            variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
            variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
            variantPack[offsetAttr->get_uid()] = offsetTensor.memory().deviceData();
            variantPack[yAttr->get_uid()] = yTensor.memory().deviceData();

            int64_t workspaceSize;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 预热执行计算
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            yTensor.memory().markDeviceModified();
            const InputType* currYData = yTensor.memory().hostData();

            // 计时执行计算
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "fprop avg time: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            std::cout << "DCU fprop first 10 values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currYData[i]) << " ";
            }
            std::cout << '\n';

            // CPU验证
            if(config_.cpuValidation)
            {
                if constexpr(std::is_same_v<InputType, int8_t>)
                {
                    std::cout << "CPU validation is not supported for int8 input type.\n";
                }
                else
                {
                    // 根据维度调用不同的CPU验证函数
                    if(config_.dimension == 2)
                    {
                        CpuFpReferenceDeformConvolution::
                            fprop<InputType, InputType, InputType, float>(
                                xTensor,
                                wTensor,
                                offsetTensor,
                                nullptr,
                                nullptr,
                                refYTensor,
                                {config_.strideH, config_.strideW},
                                {config_.dilH, config_.dilW},
                                {config_.padH, config_.padW},
                                false,
                                false);
                    }
                    else
                    {
                        CpuFpReferenceDeformConvolution::
                            fprop<InputType, InputType, InputType, float>(xTensor,
                                                                          wTensor,
                                                                          offsetTensor,
                                                                          nullptr,
                                                                          nullptr,
                                                                          refYTensor,
                                                                          stride,
                                                                          dilation,
                                                                          padding,
                                                                          false,
                                                                          false);
                    }

                    const InputType* currrefYData = refYTensor.memory().hostData();

                    std::cout << "CPU fprop first 10 values: ";
                    for(int i = 0; i < 10; ++i)
                    {
                        std::cout << static_cast<float>(currrefYData[i]) << " ";
                    }
                    std::cout << '\n';

                    // 容差设置
                    float tolerance = getTolerance<InputType>();
                    CpuFpReferenceValidation<InputType> yValidator(tolerance, tolerance);
                    bool yValid = yValidator.allClose(refYTensor, yTensor);
                    std::cout << "CPU validation result: " << (yValid ? "successful" : "failed")
                              << "\n";
                }
            }
        }
        if(config_.tensorsused == 1)
        {
            // 图验证与构建
            HIPDNN_FE_CHECK(graph->validate());
            std::cout << "Graph validation successful (fprop).\n";

            HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
            std::cout << "Operation graph build successful (fprop).\n";

            HIPDNN_FE_CHECK(graph->create_execution_plans());
            std::cout << "Execution plans created successfully (fprop).\n";

            HIPDNN_FE_CHECK(graph->check_support());
            std::cout << "Graph support check successful (fprop).\n";

            HIPDNN_FE_CHECK(graph->build_plans());
            std::cout << "Plans build successful (fprop).\n";

            // 初始化张量
            Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
            Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
            Tensor<InputType> offsetTensor(offsetAttr->get_dim(), offsetAttr->get_stride());
            Tensor<InputType> maskTensor(maskAttr->get_dim(), maskAttr->get_stride());
            Tensor<OutputType> yTensor(yAttr->get_dim(), yAttr->get_stride());

            // 初始化值
            fillTensorWithRandomValues(xTensor);
            fillTensorWithRandomValues(wTensor);
            fillTensorWithRandomValues(offsetTensor);
            fillTensorWithRandomValues(maskTensor);
            yTensor.fillWithValue(
                static_cast<OutputType>(std::is_floating_point_v<OutputType> ? 0.0f : 0));

            // 读取参考数据或生成随机数据
            Tensor<OutputType> refYTensor(yAttr->get_dim(), yAttr->get_stride());

            std::unordered_map<int64_t, void*> variantPack;
            variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
            variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
            variantPack[offsetAttr->get_uid()] = offsetTensor.memory().deviceData();
            variantPack[yAttr->get_uid()] = yTensor.memory().deviceData();
            variantPack[maskAttr->get_uid()] = maskTensor.memory().deviceData();

            int64_t workspaceSize;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 预热执行计算
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            yTensor.memory().markDeviceModified();
            const InputType* currYData = yTensor.memory().hostData();

            // 计时执行计算
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "fprop avg time: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            std::cout << "DCU fprop first 10 values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currYData[i]) << " ";
            }
            std::cout << '\n';

            // CPU验证
            if(config_.cpuValidation)
            {
                if constexpr(std::is_same_v<InputType, int8_t>)
                {
                    std::cout << "CPU validation is not supported for int8 input type.\n";
                }
                else
                {
                    // 根据维度调用不同的CPU验证函数
                    if(config_.dimension == 2)
                    {
                        CpuFpReferenceDeformConvolution::
                            fprop<InputType, InputType, InputType, float>(
                                xTensor,
                                wTensor,
                                offsetTensor,
                                &maskTensor,
                                nullptr,
                                refYTensor,
                                {config_.strideH, config_.strideW},
                                {config_.dilH, config_.dilW},
                                {config_.padH, config_.padW},
                                true,
                                false);
                    }
                    else
                    {
                        CpuFpReferenceDeformConvolution::
                            fprop<InputType, InputType, InputType, float>(xTensor,
                                                                          wTensor,
                                                                          offsetTensor,
                                                                          &maskTensor,
                                                                          nullptr,
                                                                          refYTensor,
                                                                          stride,
                                                                          dilation,
                                                                          padding,
                                                                          true,
                                                                          false);
                    }

                    const InputType* currrefYData = refYTensor.memory().hostData();

                    std::cout << "CPU fprop first 10 values: ";
                    for(int i = 0; i < 10; ++i)
                    {
                        std::cout << static_cast<float>(currrefYData[i]) << " ";
                    }
                    std::cout << '\n';

                    // 容差设置
                    float tolerance = getTolerance<InputType>();
                    CpuFpReferenceValidation<InputType> yValidator(tolerance, tolerance);
                    bool yValid = yValidator.allClose(refYTensor, yTensor);
                    std::cout << "CPU validation result: " << (yValid ? "successful" : "failed")
                              << "\n";
                }
            }
        }
    }

    template <typename InputType, typename IntermediateType>
    void dgrad(const TensorLayout& layout)
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        std::cout << "Running deformable convolution backward graph " << inputType << " [" << layout
                  << "]" << (config_.cpuValidation ? " (with CPU validation)" : "") << "...\n";

        const int64_t n = config_.n;
        const int64_t c = config_.c;
        const int64_t d = config_.d;
        const int64_t h = config_.h;
        const int64_t w = config_.w;
        const int64_t k = config_.k;
        const int64_t t = config_.t;
        const int64_t r = config_.r;
        const int64_t s = config_.s;
        const int64_t g = config_.groups;

        std::cout << "Parameter information of size: \n";
        std::cout << "n: " << n << '\n';
        std::cout << "c: " << c << '\n';
        std::cout << "h: " << h << '\n';
        std::cout << "w: " << w << '\n';
        std::cout << "k: " << k << '\n';
        std::cout << "t: " << t << '\n';
        std::cout << "r: " << r << '\n';
        std::cout << "s: " << s << '\n';
        std::cout << "g: " << g << '\n';
        std::cout << "dimension: " << config_.dimension << '\n';
        std::cout << "deformconvType: " << config_.deformconvType << '\n';
        std::cout << "tensorsused: " << config_.tensorsused << '\n';
        std::cout << '\n';

        // 根据维度设置padding、stride、dilation
        std::vector<int64_t> padding, stride, dilation;
        if(config_.dimension == 2)
        {
            padding = {config_.padH, config_.padW};
            stride = {config_.strideH, config_.strideW};
            dilation = {config_.dilH, config_.dilW};
        }
        else
        {
            padding = {config_.padD, config_.padH, config_.padW};
            stride = {config_.strideD, config_.strideH, config_.strideW};
            dilation = {config_.dilD, config_.dilH, config_.dilW};
        }

        // 计算输出维度
        int64_t od, oh, ow;
        if(config_.dimension == 2)
        {
            // 2D可变形卷积输出维度计算
            oh = ((h + 2 * config_.padH - (config_.dilH * (r - 1) + 1)) / config_.strideH) + 1;
            ow = ((w + 2 * config_.padW - (config_.dilW * (s - 1) + 1)) / config_.strideW) + 1;
        }
        else
        {
            // 3D可变形卷积输出维度计算
            od = (d + 2 * config_.padD - config_.dilD * (t - 1) + 1) / config_.strideD + 1;
            oh = (h + 2 * config_.padH - config_.dilH * (r - 1) + 1) / config_.strideH + 1;
            ow = (w + 2 * config_.padW - config_.dilW * (s - 1) + 1) / config_.strideW + 1;
        }

        // 计算总元素数
        //        size_t wTotalElems, dyTotalElems, dxTotalElems;
        //        if(config_.dimension == 2)
        //        {
        //            wTotalElems = static_cast<size_t>(k * (c / g) * r * s);
        //            dyTotalElems = static_cast<size_t>(n * k * oh * ow);
        //            dxTotalElems = static_cast<size_t>(n * c * h * w);
        //        }
        //        else
        //        {
        //            wTotalElems = static_cast<size_t>(k * (c / g) * t * r * s);
        //            dyTotalElems = static_cast<size_t>(n * k * od * oh * ow);
        //            dxTotalElems = static_cast<size_t>(n * c * d * h * w);
        //        }

        // 创建计算图
        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_compute_data_type(DataType::FLOAT)
            .set_intermediate_data_type(intermediateType);

        // 定义输入和权重张量属性
        std::shared_ptr<graph::TensorAttributes> dyAttr, xAttr, wAttr, offsetAttr, maskAttr;
        if(config_.dimension == 2)
        {
            dyAttr = createTensor({n, k, oh, ow}, inputType, layout.strideOrder);
            xAttr = createTensor({n, c, h, w}, inputType, layout.strideOrder);
            wAttr = createTensor({k, c / g, r, s}, inputType, layout.strideOrder);
            offsetAttr = createTensor({n, g * 2 * r * s, oh, ow}, inputType, layout.strideOrder);
            maskAttr = createTensor({n, g * r * s, oh, ow}, inputType, layout.strideOrder);
        }
        else
        {
            dyAttr = createTensor({n, k, od, oh, ow}, inputType, layout.strideOrder);
            xAttr = createTensor({n, c, d, h, w}, inputType, layout.strideOrder);
            wAttr = createTensor({k, c / g, t, r, s}, inputType, layout.strideOrder);
            offsetAttr
                = createTensor({n, g * 2 * t * r * s, od, oh, ow}, inputType, layout.strideOrder);
            maskAttr = createTensor({n, g * t * r * s, od, oh, ow}, inputType, layout.strideOrder);
        }

        // 可变形卷积参数配置
        graph::DeformConvDgradAttributes deformConvAttributes;
        deformConvAttributes.set_name(config_.dimension == 2 ? "deformconv2d_dgrad_node"
                                                             : "deformconv3d_dgrad_node");
        deformConvAttributes.set_padding(padding);
        deformConvAttributes.set_stride(stride);
        deformConvAttributes.set_dilation(dilation);
        deformConvAttributes.set_x(xAttr);
        //        deformConvAttributes.set_mask(maskAttr);
        if(config_.tensorsused == 3 || config_.tensorsused == 5 || config_.tensorsused == 9
           || config_.tensorsused == 13 || config_.tensorsused == 11 || config_.tensorsused == 7
           || config_.tensorsused == 15)
        {
            deformConvAttributes.set_mask(maskAttr);
        }
        //        deformConvAttributes.set_deformconvolution_mode(DeformConvolutionMode::CROSS_CORRELATION);

        // 创建输出张量并设置类型
        auto [dxAttr, doffsetAttr, dmaskAttr]
            = graph->deform_conv_dgrad(dyAttr, wAttr, offsetAttr, deformConvAttributes);
        // 设置输出维度
        //        if(config_.dimension == 2)
        //        {
        //            dxAttr->set_output(true).set_dim({n, c, h, w});
        //            doffsetAttr->set_output(true).set_dim({n, g * 2 * r * s, oh, ow});
        //            dmaskAttr->set_output(true).set_dim({n, g * r * s, oh, ow});
        //        }
        //        else
        //        {
        //            dxAttr->set_output(true).set_dim({n, c, d, h, w});
        //            doffsetAttr->set_output(true).set_dim({n, g * 2 * t * r * s, od, oh, ow});
        //            dmaskAttr->set_output(true).set_dim({n, g * r * s, od, oh, ow});
        //        }

        if(config_.tensorsused == 4)
        {
            doffsetAttr->set_output(true).set_dim({n, g * 2 * r * s, oh, ow});

            // 图验证与构建
            HIPDNN_FE_CHECK(graph->validate());
            std::cout << "Graph validation successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
            std::cout << "Operation graph build successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->create_execution_plans());
            std::cout << "Execution plans created successfully (dgrad).\n";

            HIPDNN_FE_CHECK(graph->check_support());
            std::cout << "Graph support check successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_plans());
            std::cout << "Plans build successful (dgrad).\n";

            // 初始化张量
            Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
            Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
            Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
            Tensor<InputType> offsetTensor(offsetAttr->get_dim(), offsetAttr->get_stride());

            // 初始化值
            fillTensorWithRandomValues(dyTensor);
            fillTensorWithRandomValues(xTensor);
            fillTensorWithRandomValues(wTensor);
            fillTensorWithRandomValues(offsetTensor);

            // 读取参考数据或生成随机数据
            std::unordered_map<int64_t, void*> variantPack;
            variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
            variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
            variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
            variantPack[offsetAttr->get_uid()] = offsetTensor.memory().deviceData();

            Tensor<InputType> maskTensor(maskAttr->get_dim(), maskAttr->get_stride());
            Tensor<InputType> doffsetTensor(doffsetAttr->get_dim(), doffsetAttr->get_stride());

            fillTensorWithRandomValues(maskTensor);
            doffsetTensor.fillWithValue(static_cast<InputType>(0.0f));

            variantPack[doffsetAttr->get_uid()] = doffsetTensor.memory().deviceData();

            int64_t workspaceSize;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 预热执行
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            doffsetTensor.memory().markDeviceModified();
            const InputType* currDoffsetData = doffsetTensor.memory().hostData();

            // 计时执行计算
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "dgrad avg time: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            std::cout << "DCU dgrad first 10 doffset values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDoffsetData[i]) << " ";
            }
            std::cout << '\n';

            // CPU验证
            if(config_.cpuValidation)
            {
                std::cout << "Running CPU reference validation...\n";

                //                Tensor<InputType> dxDiffTensor(dxAttr->get_dim(), dxAttr->get_stride());

                Tensor<InputType> dxRefTensor(dxAttr->get_dim(), dxAttr->get_stride());
                Tensor<InputType> doffsetRefTensor(doffsetAttr->get_dim(),
                                                   doffsetAttr->get_stride());
                Tensor<InputType> dmaskRefTensor(dmaskAttr->get_dim(), dmaskAttr->get_stride());
                dxRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                doffsetRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                dmaskRefTensor.fillWithValue(static_cast<InputType>(0.0f));

                // 根据维度调用不同的CPU验证函数
                if(config_.dimension == 2)
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideH, config_.strideW},
                        {config_.dilH, config_.dilW},
                        {config_.padH, config_.padW},
                        false,
                        false,
                        false,
                        true);
                }
                else
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideD, config_.strideH, config_.strideW},
                        {config_.dilD, config_.dilH, config_.dilW},
                        {config_.padD, config_.padH, config_.padW},
                        false,
                        false,
                        false,
                        true);
                }

                const InputType* currDoffsetRefTensor = doffsetRefTensor.memory().hostData();
                std::cout << "CPU dgrad first 10 doffset values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDoffsetRefTensor[i]) << " ";
                }
                std::cout << '\n';

                // 容差设置
                float tolerance = getTolerance<InputType>();

                // 创建验证器
                CpuFpReferenceValidation<InputType> yValidator(tolerance, tolerance);

                // allClose用来比较两个张量是否在容差范围内相等
                bool doffsetValid = yValidator.allClose(doffsetRefTensor, doffsetTensor);
                std::cout << "CPU validation result, doffset: "
                          << (doffsetValid ? "successful" : "failed") << "\n";
            }
        }
        else if(config_.tensorsused == 8)
        {
            dxAttr->set_output(true).set_dim({n, c, h, w});

            // 图验证与构建
            HIPDNN_FE_CHECK(graph->validate());
            std::cout << "Graph validation successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
            std::cout << "Operation graph build successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->create_execution_plans());
            std::cout << "Execution plans created successfully (dgrad).\n";

            HIPDNN_FE_CHECK(graph->check_support());
            std::cout << "Graph support check successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_plans());
            std::cout << "Plans build successful (dgrad).\n";

            // 初始化张量
            Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
            Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
            Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
            Tensor<InputType> offsetTensor(offsetAttr->get_dim(), offsetAttr->get_stride());

            // 初始化值
            fillTensorWithRandomValues(dyTensor);
            fillTensorWithRandomValues(xTensor);
            fillTensorWithRandomValues(wTensor);
            fillTensorWithRandomValues(offsetTensor);

            // 读取参考数据或生成随机数据
            std::unordered_map<int64_t, void*> variantPack;
            variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
            variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
            variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
            variantPack[offsetAttr->get_uid()] = offsetTensor.memory().deviceData();

            Tensor<InputType> maskTensor(maskAttr->get_dim(), maskAttr->get_stride());
            Tensor<InputType> dxTensor(dxAttr->get_dim(), dxAttr->get_stride());

            fillTensorWithRandomValues(maskTensor);
            dxTensor.fillWithValue(static_cast<InputType>(0.0f));

            variantPack[dxAttr->get_uid()] = dxTensor.memory().deviceData();

            int64_t workspaceSize;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 预热执行
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            dxTensor.memory().markDeviceModified();
            const InputType* currDxData = dxTensor.memory().hostData();

            // 计时执行
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "dgrad avg time: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            std::cout << "DCU dgrad first 10 dx values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDxData[i]) << " ";
            }
            std::cout << '\n';

            // CPU验证
            if(config_.cpuValidation)
            {
                std::cout << "Running CPU reference validation...\n";

                //            Tensor<InputType> dxDiffTensor(dxAttr->get_dim(), dxAttr->get_stride());

                Tensor<InputType> dxRefTensor(dxAttr->get_dim(), dxAttr->get_stride());
                Tensor<InputType> doffsetRefTensor(doffsetAttr->get_dim(),
                                                   doffsetAttr->get_stride());
                Tensor<InputType> dmaskRefTensor(dmaskAttr->get_dim(), dmaskAttr->get_stride());
                dxRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                doffsetRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                dmaskRefTensor.fillWithValue(static_cast<InputType>(0.0f));

                if(config_.dimension == 2)
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideH, config_.strideW},
                        {config_.dilH, config_.dilW},
                        {config_.padH, config_.padW},
                        false,
                        true,
                        false,
                        false);
                }
                else
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideD, config_.strideH, config_.strideW},
                        {config_.dilD, config_.dilH, config_.dilW},
                        {config_.padD, config_.padH, config_.padW},
                        false,
                        true,
                        false,
                        false);
                }

                const InputType* currDxRefTensor = dxRefTensor.memory().hostData();

                std::cout << "CPU dgrad first 10 dx values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDxRefTensor[i]) << " ";
                }
                std::cout << '\n';

                // 容差设置
                float tolerance = getTolerance<InputType>();

                // 创建验证器
                CpuFpReferenceValidation<InputType> yValidator(tolerance, tolerance);

                // allClose用来比较两个张量是否在容差范围内相等
                bool yValid = yValidator.allClose(dxRefTensor, dxTensor);
                std::cout << "CPU validation result, dx: " << (yValid ? "successful" : "failed")
                          << "\n";
            }
        }
        else if(config_.tensorsused == 12)
        {
            dxAttr->set_output(true).set_dim({n, c, h, w});
            doffsetAttr->set_output(true).set_dim({n, g * 2 * r * s, oh, ow});

            // 图验证与构建
            HIPDNN_FE_CHECK(graph->validate());
            std::cout << "Graph validation successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
            std::cout << "Operation graph build successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->create_execution_plans());
            std::cout << "Execution plans created successfully (dgrad).\n";

            HIPDNN_FE_CHECK(graph->check_support());
            std::cout << "Graph support check successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_plans());
            std::cout << "Plans build successful (dgrad).\n";

            // 初始化张量
            Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
            Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
            Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
            Tensor<InputType> offsetTensor(offsetAttr->get_dim(), offsetAttr->get_stride());

            // 初始化值
            fillTensorWithRandomValues(dyTensor);
            fillTensorWithRandomValues(xTensor);
            fillTensorWithRandomValues(wTensor);
            fillTensorWithRandomValues(offsetTensor);

            // 读取参考数据或生成随机数据
            std::unordered_map<int64_t, void*> variantPack;
            variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
            variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
            variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
            variantPack[offsetAttr->get_uid()] = offsetTensor.memory().deviceData();

            Tensor<InputType> maskTensor(maskAttr->get_dim(), maskAttr->get_stride());
            Tensor<InputType> dxTensor(dxAttr->get_dim(), dxAttr->get_stride());
            Tensor<InputType> doffsetTensor(doffsetAttr->get_dim(), doffsetAttr->get_stride());

            fillTensorWithRandomValues(maskTensor);
            dxTensor.fillWithValue(static_cast<InputType>(0.0f));
            doffsetTensor.fillWithValue(static_cast<InputType>(0.0f));

            variantPack[dxAttr->get_uid()] = dxTensor.memory().deviceData();
            variantPack[doffsetAttr->get_uid()] = doffsetTensor.memory().deviceData();

            int64_t workspaceSize;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 预热执行
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            dxTensor.memory().markDeviceModified();
            doffsetTensor.memory().markDeviceModified();
            const InputType* currDxData = dxTensor.memory().hostData();
            const InputType* currDoffsetData = doffsetTensor.memory().hostData();

            // 计时执行
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "dgrad avg time: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            std::cout << "DCU dgrad first 10 dx values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDxData[i]) << " ";
            }
            std::cout << '\n';

            std::cout << "DCU dgrad first 10 doffset values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDoffsetData[i]) << " ";
            }
            std::cout << '\n';

            // CPU验证
            if(config_.cpuValidation)
            {
                std::cout << "Running CPU reference validation...\n";

                //            Tensor<InputType> dxDiffTensor(dxAttr->get_dim(), dxAttr->get_stride());

                Tensor<InputType> dxRefTensor(dxAttr->get_dim(), dxAttr->get_stride());
                Tensor<InputType> doffsetRefTensor(doffsetAttr->get_dim(),
                                                   doffsetAttr->get_stride());
                Tensor<InputType> dmaskRefTensor(dmaskAttr->get_dim(), dmaskAttr->get_stride());
                dxRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                doffsetRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                dmaskRefTensor.fillWithValue(static_cast<InputType>(0.0f));

                if(config_.dimension == 2)
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideH, config_.strideW},
                        {config_.dilH, config_.dilW},
                        {config_.padH, config_.padW},
                        false,
                        true,
                        false,
                        true);
                }
                else
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideD, config_.strideH, config_.strideW},
                        {config_.dilD, config_.dilH, config_.dilW},
                        {config_.padD, config_.padH, config_.padW},
                        false,
                        true,
                        false,
                        true);
                }

                const InputType* currDxRefTensor = dxRefTensor.memory().hostData();
                const InputType* currDoffsetRefTensor = doffsetRefTensor.memory().hostData();

                std::cout << "CPU dgrad first 10 dX values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDxRefTensor[i]) << " ";
                }
                std::cout << '\n';
                std::cout << "CPU dgrad first 10 doffset values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDoffsetRefTensor[i]) << " ";
                }
                std::cout << '\n';

                // 容差设置
                float tolerance = getTolerance<InputType>();

                CpuFpReferenceValidation<InputType> yValidator(tolerance, tolerance);

                bool yValid = yValidator.allClose(dxRefTensor, dxTensor);
                bool doffsetValid = yValidator.allClose(doffsetRefTensor, doffsetTensor);
                std::cout << "CPU validation result, dx: " << (yValid ? "successful" : "failed")
                          << "\n";
                std::cout << "CPU validation result, doffset: "
                          << (doffsetValid ? "successful" : "failed") << "\n";
            }
        }
        else if(config_.tensorsused == 3)
        {
            dmaskAttr->set_output(true).set_dim({n, g * r * s, oh, ow});

            // 图验证与构建
            HIPDNN_FE_CHECK(graph->validate());
            std::cout << "Graph validation successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
            std::cout << "Operation graph build successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->create_execution_plans());
            std::cout << "Execution plans created successfully (dgrad).\n";

            HIPDNN_FE_CHECK(graph->check_support());
            std::cout << "Graph support check successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_plans());
            std::cout << "Plans build successful (dgrad).\n";

            // 初始化张量
            Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
            Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
            Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
            Tensor<InputType> offsetTensor(offsetAttr->get_dim(), offsetAttr->get_stride());

            // 初始化值
            fillTensorWithRandomValues(dyTensor);
            fillTensorWithRandomValues(xTensor);
            fillTensorWithRandomValues(wTensor);
            fillTensorWithRandomValues(offsetTensor);

            // 读取参考数据或生成随机数据
            std::unordered_map<int64_t, void*> variantPack;
            variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
            variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
            variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
            variantPack[offsetAttr->get_uid()] = offsetTensor.memory().deviceData();

            Tensor<InputType> maskTensor(maskAttr->get_dim(), maskAttr->get_stride());
            Tensor<InputType> dmaskTensor(dmaskAttr->get_dim(), dmaskAttr->get_stride());

            fillTensorWithRandomValues(maskTensor);
            dmaskTensor.fillWithValue(static_cast<InputType>(0.0f));

            variantPack[maskAttr->get_uid()] = maskTensor.memory().deviceData();
            variantPack[dmaskAttr->get_uid()] = dmaskTensor.memory().deviceData();

            int64_t workspaceSize;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 预热执行
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            dmaskTensor.memory().markDeviceModified();
            const InputType* currDmaskData = dmaskTensor.memory().hostData();

            // 计时执行
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "dgrad avg time: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            std::cout << "DCU dgrad first 10 dmask values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDmaskData[i]) << " ";
            }
            std::cout << '\n';

            // CPU验证
            if(config_.cpuValidation)
            {
                std::cout << "Running CPU reference validation...\n";

                //            Tensor<InputType> dxDiffTensor(dxAttr->get_dim(), dxAttr->get_stride());

                Tensor<InputType> dxRefTensor(dxAttr->get_dim(), dxAttr->get_stride());
                Tensor<InputType> doffsetRefTensor(doffsetAttr->get_dim(),
                                                   doffsetAttr->get_stride());
                Tensor<InputType> dmaskRefTensor(dmaskAttr->get_dim(), dmaskAttr->get_stride());
                dxRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                doffsetRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                dmaskRefTensor.fillWithValue(static_cast<InputType>(0.0f));

                if(config_.dimension == 2)
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideH, config_.strideW},
                        {config_.dilH, config_.dilW},
                        {config_.padH, config_.padW},
                        true,
                        false,
                        true,
                        false);
                }
                else
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideD, config_.strideH, config_.strideW},
                        {config_.dilD, config_.dilH, config_.dilW},
                        {config_.padD, config_.padH, config_.padW},
                        true,
                        false,
                        true,
                        false);
                }

                const InputType* currDmaskRefTensor = dmaskRefTensor.memory().hostData();

                std::cout << "CPU dgrad first 10 dmask values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDmaskRefTensor[i]) << " ";
                }
                std::cout << '\n';

                // 容差设置
                float tolerance = getTolerance<InputType>();

                CpuFpReferenceValidation<InputType> yValidator(tolerance, tolerance);

                bool dmaskValid = yValidator.allClose(dmaskRefTensor, dmaskTensor);
                std::cout << "CPU validation result, dmask: "
                          << (dmaskValid ? "successful" : "failed") << "\n";
            }
        }
        else if(config_.tensorsused == 5)
        {
            doffsetAttr->set_output(true).set_dim({n, g * 2 * r * s, oh, ow});

            // 图验证与构建
            HIPDNN_FE_CHECK(graph->validate());
            std::cout << "Graph validation successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
            std::cout << "Operation graph build successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->create_execution_plans());
            std::cout << "Execution plans created successfully (dgrad).\n";

            HIPDNN_FE_CHECK(graph->check_support());
            std::cout << "Graph support check successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_plans());
            std::cout << "Plans build successful (dgrad).\n";

            // 初始化张量
            Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
            Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
            Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
            Tensor<InputType> offsetTensor(offsetAttr->get_dim(), offsetAttr->get_stride());

            // 初始化值
            fillTensorWithRandomValues(dyTensor);
            fillTensorWithRandomValues(xTensor);
            fillTensorWithRandomValues(wTensor);
            fillTensorWithRandomValues(offsetTensor);

            // 读取参考数据或生成随机数据
            std::unordered_map<int64_t, void*> variantPack;
            variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
            variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
            variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
            variantPack[offsetAttr->get_uid()] = offsetTensor.memory().deviceData();

            Tensor<InputType> maskTensor(maskAttr->get_dim(), maskAttr->get_stride());
            Tensor<InputType> doffsetTensor(doffsetAttr->get_dim(), doffsetAttr->get_stride());

            fillTensorWithRandomValues(maskTensor);
            doffsetTensor.fillWithValue(static_cast<InputType>(0.0f));

            variantPack[maskAttr->get_uid()] = maskTensor.memory().deviceData();
            variantPack[doffsetAttr->get_uid()] = doffsetTensor.memory().deviceData();

            int64_t workspaceSize;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 预热执行
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            doffsetTensor.memory().markDeviceModified();
            const InputType* currDoffsetData = doffsetTensor.memory().hostData();

            // 计时执行
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "dgrad avg time: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            std::cout << "DCU dgrad first 10 doffset values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDoffsetData[i]) << " ";
            }
            std::cout << '\n';

            // CPU验证
            if(config_.cpuValidation)
            {
                std::cout << "Running CPU reference validation...\n";

                //            Tensor<InputType> dxDiffTensor(dxAttr->get_dim(), dxAttr->get_stride());

                Tensor<InputType> dxRefTensor(dxAttr->get_dim(), dxAttr->get_stride());
                Tensor<InputType> doffsetRefTensor(doffsetAttr->get_dim(),
                                                   doffsetAttr->get_stride());
                Tensor<InputType> dmaskRefTensor(dmaskAttr->get_dim(), dmaskAttr->get_stride());
                dxRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                doffsetRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                dmaskRefTensor.fillWithValue(static_cast<InputType>(0.0f));

                if(config_.dimension == 2)
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideH, config_.strideW},
                        {config_.dilH, config_.dilW},
                        {config_.padH, config_.padW},
                        true,
                        false,
                        false,
                        true);
                }
                else
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideD, config_.strideH, config_.strideW},
                        {config_.dilD, config_.dilH, config_.dilW},
                        {config_.padD, config_.padH, config_.padW},
                        true,
                        false,
                        false,
                        true);
                }

                const InputType* currDoffsetRefTensor = doffsetRefTensor.memory().hostData();

                std::cout << "CPU dgrad first 10 doffset values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDoffsetRefTensor[i]) << " ";
                }
                std::cout << '\n';

                // 容差设置
                float tolerance = getTolerance<InputType>();

                CpuFpReferenceValidation<InputType> yValidator(tolerance, tolerance);

                bool doffsetValid = yValidator.allClose(doffsetRefTensor, doffsetTensor);
                std::cout << "CPU validation result, doffset: "
                          << (doffsetValid ? "successful" : "failed") << "\n";
            }
        }
        else if(config_.tensorsused == 9)
        {
            dxAttr->set_output(true).set_dim({n, c, h, w});

            // 图验证与构建
            HIPDNN_FE_CHECK(graph->validate());
            std::cout << "Graph validation successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
            std::cout << "Operation graph build successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->create_execution_plans());
            std::cout << "Execution plans created successfully (dgrad).\n";

            HIPDNN_FE_CHECK(graph->check_support());
            std::cout << "Graph support check successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_plans());
            std::cout << "Plans build successful (dgrad).\n";

            // 初始化张量
            Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
            Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
            Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
            Tensor<InputType> offsetTensor(offsetAttr->get_dim(), offsetAttr->get_stride());

            // 初始化值
            fillTensorWithRandomValues(dyTensor);
            fillTensorWithRandomValues(xTensor);
            fillTensorWithRandomValues(wTensor);
            fillTensorWithRandomValues(offsetTensor);

            // 读取参考数据或生成随机数据
            std::unordered_map<int64_t, void*> variantPack;
            variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
            variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
            variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
            variantPack[offsetAttr->get_uid()] = offsetTensor.memory().deviceData();

            Tensor<InputType> maskTensor(maskAttr->get_dim(), maskAttr->get_stride());
            Tensor<InputType> dxTensor(dxAttr->get_dim(), dxAttr->get_stride());

            fillTensorWithRandomValues(maskTensor);
            dxTensor.fillWithValue(static_cast<InputType>(0.0f));

            variantPack[maskAttr->get_uid()] = maskTensor.memory().deviceData();
            variantPack[dxAttr->get_uid()] = dxTensor.memory().deviceData();

            int64_t workspaceSize;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 预热执行
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            dxTensor.memory().markDeviceModified();
            const InputType* currDxData = dxTensor.memory().hostData();

            // 计时执行
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "dgrad avg time: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            std::cout << "DCU dgrad first 10 dx values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDxData[i]) << " ";
            }
            std::cout << '\n';

            // CPU验证
            if(config_.cpuValidation)
            {
                std::cout << "Running CPU reference validation...\n";

                //            Tensor<InputType> dxDiffTensor(dxAttr->get_dim(), dxAttr->get_stride());

                Tensor<InputType> dxRefTensor(dxAttr->get_dim(), dxAttr->get_stride());
                Tensor<InputType> doffsetRefTensor(doffsetAttr->get_dim(),
                                                   doffsetAttr->get_stride());
                Tensor<InputType> dmaskRefTensor(dmaskAttr->get_dim(), dmaskAttr->get_stride());
                dxRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                doffsetRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                dmaskRefTensor.fillWithValue(static_cast<InputType>(0.0f));

                if(config_.dimension == 2)
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideH, config_.strideW},
                        {config_.dilH, config_.dilW},
                        {config_.padH, config_.padW},
                        true,
                        true,
                        false,
                        false);
                }
                else
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideD, config_.strideH, config_.strideW},
                        {config_.dilD, config_.dilH, config_.dilW},
                        {config_.padD, config_.padH, config_.padW},
                        true,
                        true,
                        false,
                        false);
                }

                const InputType* currDxRefTensor = dxRefTensor.memory().hostData();

                std::cout << "CPU dgrad first 10 dX values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDxRefTensor[i]) << " ";
                }
                std::cout << '\n';

                // 容差设置
                float tolerance = getTolerance<InputType>();

                CpuFpReferenceValidation<InputType> yValidator(tolerance, tolerance);

                bool yValid = yValidator.allClose(dxRefTensor, dxTensor);
                std::cout << "CPU validation result, dx: " << (yValid ? "successful" : "failed")
                          << "\n";
            }
        }
        else if(config_.tensorsused == 13)
        {
            dxAttr->set_output(true).set_dim({n, c, h, w});
            doffsetAttr->set_output(true).set_dim({n, g * 2 * r * s, oh, ow});

            // 图验证与构建
            HIPDNN_FE_CHECK(graph->validate());
            std::cout << "Graph validation successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
            std::cout << "Operation graph build successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->create_execution_plans());
            std::cout << "Execution plans created successfully (dgrad).\n";

            HIPDNN_FE_CHECK(graph->check_support());
            std::cout << "Graph support check successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_plans());
            std::cout << "Plans build successful (dgrad).\n";

            // 初始化张量
            Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
            Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
            Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
            Tensor<InputType> offsetTensor(offsetAttr->get_dim(), offsetAttr->get_stride());

            // 初始化值
            fillTensorWithRandomValues(dyTensor);
            fillTensorWithRandomValues(xTensor);
            fillTensorWithRandomValues(wTensor);
            fillTensorWithRandomValues(offsetTensor);

            // 读取参考数据或生成随机数据
            std::unordered_map<int64_t, void*> variantPack;
            variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
            variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
            variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
            variantPack[offsetAttr->get_uid()] = offsetTensor.memory().deviceData();

            Tensor<InputType> maskTensor(maskAttr->get_dim(), maskAttr->get_stride());
            Tensor<InputType> dxTensor(dxAttr->get_dim(), dxAttr->get_stride());
            Tensor<InputType> doffsetTensor(doffsetAttr->get_dim(), doffsetAttr->get_stride());

            fillTensorWithRandomValues(maskTensor);
            dxTensor.fillWithValue(static_cast<InputType>(0.0f));
            doffsetTensor.fillWithValue(static_cast<InputType>(0.0f));

            variantPack[maskAttr->get_uid()] = maskTensor.memory().deviceData();
            variantPack[dxAttr->get_uid()] = dxTensor.memory().deviceData();
            variantPack[doffsetAttr->get_uid()] = doffsetTensor.memory().deviceData();

            int64_t workspaceSize;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 预热执行
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            dxTensor.memory().markDeviceModified();
            doffsetTensor.memory().markDeviceModified();
            const InputType* currDxData = dxTensor.memory().hostData();
            const InputType* currDoffsetData = doffsetTensor.memory().hostData();

            // 计时执行
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "dgrad avg time: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            std::cout << "DCU dgrad first 10 dx values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDxData[i]) << " ";
            }
            std::cout << '\n';

            std::cout << "DCU dgrad first 10 doffset values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDoffsetData[i]) << " ";
            }
            std::cout << '\n';

            // CPU验证
            if(config_.cpuValidation)
            {
                std::cout << "Running CPU reference validation...\n";

                //            Tensor<InputType> dxDiffTensor(dxAttr->get_dim(), dxAttr->get_stride());

                Tensor<InputType> dxRefTensor(dxAttr->get_dim(), dxAttr->get_stride());
                Tensor<InputType> doffsetRefTensor(doffsetAttr->get_dim(),
                                                   doffsetAttr->get_stride());
                Tensor<InputType> dmaskRefTensor(dmaskAttr->get_dim(), dmaskAttr->get_stride());
                dxRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                doffsetRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                dmaskRefTensor.fillWithValue(static_cast<InputType>(0.0f));

                if(config_.dimension == 2)
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideH, config_.strideW},
                        {config_.dilH, config_.dilW},
                        {config_.padH, config_.padW},
                        true,
                        true,
                        false,
                        true);
                }
                else
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideD, config_.strideH, config_.strideW},
                        {config_.dilD, config_.dilH, config_.dilW},
                        {config_.padD, config_.padH, config_.padW},
                        true,
                        true,
                        false,
                        true);
                }

                const InputType* currDxRefTensor = dxRefTensor.memory().hostData();
                const InputType* currDoffsetRefTensor = doffsetRefTensor.memory().hostData();

                std::cout << "CPU dgrad first 10 dX values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDxRefTensor[i]) << " ";
                }
                std::cout << '\n';
                std::cout << "CPU dgrad first 10 doffset values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDoffsetRefTensor[i]) << " ";
                }
                std::cout << '\n';

                // 容差设置
                float tolerance = getTolerance<InputType>();

                CpuFpReferenceValidation<InputType> yValidator(tolerance, tolerance);

                bool yValid = yValidator.allClose(dxRefTensor, dxTensor);
                bool doffsetValid = yValidator.allClose(doffsetRefTensor, doffsetTensor);
                std::cout << "CPU validation result, dx: " << (yValid ? "successful" : "failed")
                          << "\n";
                std::cout << "CPU validation result, doffset: "
                          << (doffsetValid ? "successful" : "failed") << "\n";
            }
        }
        else if(config_.tensorsused == 11)
        {
            dxAttr->set_output(true).set_dim({n, c, h, w});
            dmaskAttr->set_output(true).set_dim({n, g * r * s, oh, ow});

            // 图验证与构建
            HIPDNN_FE_CHECK(graph->validate());
            std::cout << "Graph validation successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
            std::cout << "Operation graph build successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->create_execution_plans());
            std::cout << "Execution plans created successfully (dgrad).\n";

            HIPDNN_FE_CHECK(graph->check_support());
            std::cout << "Graph support check successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_plans());
            std::cout << "Plans build successful (dgrad).\n";

            // 初始化张量
            Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
            Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
            Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
            Tensor<InputType> offsetTensor(offsetAttr->get_dim(), offsetAttr->get_stride());

            // 初始化值
            fillTensorWithRandomValues(dyTensor);
            fillTensorWithRandomValues(xTensor);
            fillTensorWithRandomValues(wTensor);
            fillTensorWithRandomValues(offsetTensor);

            // 读取参考数据或生成随机数据
            std::unordered_map<int64_t, void*> variantPack;
            variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
            variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
            variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
            variantPack[offsetAttr->get_uid()] = offsetTensor.memory().deviceData();

            Tensor<InputType> maskTensor(maskAttr->get_dim(), maskAttr->get_stride());
            Tensor<InputType> dxTensor(dxAttr->get_dim(), dxAttr->get_stride());
            Tensor<InputType> dmaskTensor(dmaskAttr->get_dim(), dmaskAttr->get_stride());

            fillTensorWithRandomValues(maskTensor);
            dxTensor.fillWithValue(static_cast<InputType>(0.0f));
            dmaskTensor.fillWithValue(static_cast<InputType>(0.0f));

            variantPack[maskAttr->get_uid()] = maskTensor.memory().deviceData();
            variantPack[dxAttr->get_uid()] = dxTensor.memory().deviceData();
            variantPack[dmaskAttr->get_uid()] = dmaskTensor.memory().deviceData();

            int64_t workspaceSize;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 预热执行
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            dxTensor.memory().markDeviceModified();
            dmaskTensor.memory().markDeviceModified();
            const InputType* currDxData = dxTensor.memory().hostData();
            const InputType* currDmaskData = dmaskTensor.memory().hostData();

            // 计时执行
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "dgrad avg time: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            std::cout << "DCU dgrad first 10 dx values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDxData[i]) << " ";
            }
            std::cout << '\n';

            std::cout << "DCU dgrad first 10 dmask values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDmaskData[i]) << " ";
            }
            std::cout << '\n';

            // CPU验证
            if(config_.cpuValidation)
            {
                std::cout << "Running CPU reference validation...\n";

                //            Tensor<InputType> dxDiffTensor(dxAttr->get_dim(), dxAttr->get_stride());

                Tensor<InputType> dxRefTensor(dxAttr->get_dim(), dxAttr->get_stride());
                Tensor<InputType> doffsetRefTensor(doffsetAttr->get_dim(),
                                                   doffsetAttr->get_stride());
                Tensor<InputType> dmaskRefTensor(dmaskAttr->get_dim(), dmaskAttr->get_stride());
                dxRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                doffsetRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                dmaskRefTensor.fillWithValue(static_cast<InputType>(0.0f));

                if(config_.dimension == 2)
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideH, config_.strideW},
                        {config_.dilH, config_.dilW},
                        {config_.padH, config_.padW},
                        true,
                        true,
                        true,
                        false);
                }
                else
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideD, config_.strideH, config_.strideW},
                        {config_.dilD, config_.dilH, config_.dilW},
                        {config_.padD, config_.padH, config_.padW},
                        true,
                        true,
                        true,
                        false);
                }

                const InputType* currDxRefTensor = dxRefTensor.memory().hostData();
                const InputType* currDmaskRefTensor = dmaskRefTensor.memory().hostData();

                std::cout << "CPU dgrad first 10 dX values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDxRefTensor[i]) << " ";
                }
                std::cout << '\n';
                std::cout << "CPU dgrad first 10 dmask values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDmaskRefTensor[i]) << " ";
                }
                std::cout << '\n';

                // 容差设置
                float tolerance = getTolerance<InputType>();

                CpuFpReferenceValidation<InputType> yValidator(tolerance, tolerance);

                bool yValid = yValidator.allClose(dxRefTensor, dxTensor);
                bool dmaskValid = yValidator.allClose(dmaskRefTensor, dmaskTensor);
                std::cout << "CPU validation result, dx: " << (yValid ? "successful" : "failed")
                          << "\n";
                std::cout << "CPU validation result, dmask: "
                          << (dmaskValid ? "successful" : "failed") << "\n";
            }
        }
        else if(config_.tensorsused == 7)
        {
            doffsetAttr->set_output(true).set_dim({n, g * 2 * r * s, oh, ow});
            dmaskAttr->set_output(true).set_dim({n, g * r * s, oh, ow});

            // 图验证与构建
            HIPDNN_FE_CHECK(graph->validate());
            std::cout << "Graph validation successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
            std::cout << "Operation graph build successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->create_execution_plans());
            std::cout << "Execution plans created successfully (dgrad).\n";

            HIPDNN_FE_CHECK(graph->check_support());
            std::cout << "Graph support check successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_plans());
            std::cout << "Plans build successful (dgrad).\n";

            // 初始化张量
            Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
            Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
            Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
            Tensor<InputType> offsetTensor(offsetAttr->get_dim(), offsetAttr->get_stride());

            // 初始化值
            fillTensorWithRandomValues(dyTensor);
            fillTensorWithRandomValues(xTensor);
            fillTensorWithRandomValues(wTensor);
            fillTensorWithRandomValues(offsetTensor);

            // 读取参考数据或生成随机数据
            std::unordered_map<int64_t, void*> variantPack;
            variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
            variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
            variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
            variantPack[offsetAttr->get_uid()] = offsetTensor.memory().deviceData();

            Tensor<InputType> maskTensor(maskAttr->get_dim(), maskAttr->get_stride());
            Tensor<InputType> doffsetTensor(doffsetAttr->get_dim(), doffsetAttr->get_stride());
            Tensor<InputType> dmaskTensor(dmaskAttr->get_dim(), dmaskAttr->get_stride());

            fillTensorWithRandomValues(maskTensor);
            doffsetTensor.fillWithValue(static_cast<InputType>(0.0f));
            dmaskTensor.fillWithValue(static_cast<InputType>(0.0f));

            variantPack[maskAttr->get_uid()] = maskTensor.memory().deviceData();
            variantPack[doffsetAttr->get_uid()] = doffsetTensor.memory().deviceData();
            variantPack[dmaskAttr->get_uid()] = dmaskTensor.memory().deviceData();

            int64_t workspaceSize;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 预热执行
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            doffsetTensor.memory().markDeviceModified();
            dmaskTensor.memory().markDeviceModified();
            const InputType* currDoffsetData = doffsetTensor.memory().hostData();
            const InputType* currDmaskData = dmaskTensor.memory().hostData();

            // 计时执行
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "dgrad avg time: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            std::cout << "DCU dgrad first 10 doffset values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDoffsetData[i]) << " ";
            }
            std::cout << '\n';

            std::cout << "DCU dgrad first 10 dmask values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDmaskData[i]) << " ";
            }
            std::cout << '\n';

            // CPU验证
            if(config_.cpuValidation)
            {
                std::cout << "Running CPU reference validation...\n";

                //            Tensor<InputType> dxDiffTensor(dxAttr->get_dim(), dxAttr->get_stride());

                Tensor<InputType> dxRefTensor(dxAttr->get_dim(), dxAttr->get_stride());
                Tensor<InputType> doffsetRefTensor(doffsetAttr->get_dim(),
                                                   doffsetAttr->get_stride());
                Tensor<InputType> dmaskRefTensor(dmaskAttr->get_dim(), dmaskAttr->get_stride());
                dxRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                doffsetRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                dmaskRefTensor.fillWithValue(static_cast<InputType>(0.0f));

                if(config_.dimension == 2)
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideH, config_.strideW},
                        {config_.dilH, config_.dilW},
                        {config_.padH, config_.padW},
                        true,
                        false,
                        true,
                        true);
                }
                else
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideD, config_.strideH, config_.strideW},
                        {config_.dilD, config_.dilH, config_.dilW},
                        {config_.padD, config_.padH, config_.padW},
                        true,
                        false,
                        true,
                        true);
                }

                const InputType* currDoffsetRefTensor = doffsetRefTensor.memory().hostData();
                const InputType* currDmaskRefTensor = dmaskRefTensor.memory().hostData();

                std::cout << "CPU dgrad first 10 doffset values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDoffsetRefTensor[i]) << " ";
                }
                std::cout << '\n';
                std::cout << "CPU dgrad first 10 dmask values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDmaskRefTensor[i]) << " ";
                }
                std::cout << '\n';

                // 容差设置
                float tolerance = getTolerance<InputType>();

                CpuFpReferenceValidation<InputType> yValidator(tolerance, tolerance);

                bool doffsetValid = yValidator.allClose(doffsetRefTensor, doffsetTensor);
                bool dmaskValid = yValidator.allClose(dmaskRefTensor, dmaskTensor);
                std::cout << "CPU validation result, doffset: "
                          << (doffsetValid ? "successful" : "failed") << "\n";
                std::cout << "CPU validation result, dmask: "
                          << (dmaskValid ? "successful" : "failed") << "\n";
            }
        }
        else
        {
            dxAttr->set_output(true).set_dim({n, c, h, w});
            doffsetAttr->set_output(true).set_dim({n, g * 2 * r * s, oh, ow});
            dmaskAttr->set_output(true).set_dim({n, g * r * s, oh, ow});

            // 图验证与构建
            HIPDNN_FE_CHECK(graph->validate());
            std::cout << "Graph validation successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
            std::cout << "Operation graph build successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->create_execution_plans());
            std::cout << "Execution plans created successfully (dgrad).\n";

            HIPDNN_FE_CHECK(graph->check_support());
            std::cout << "Graph support check successful (dgrad).\n";

            HIPDNN_FE_CHECK(graph->build_plans());
            std::cout << "Plans build successful (dgrad).\n";

            // 初始化张量
            Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
            Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
            Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
            Tensor<InputType> offsetTensor(offsetAttr->get_dim(), offsetAttr->get_stride());

            // 初始化值
            fillTensorWithRandomValues(dyTensor);
            fillTensorWithRandomValues(xTensor);
            fillTensorWithRandomValues(wTensor);
            fillTensorWithRandomValues(offsetTensor);

            // 读取参考数据或生成随机数据
            std::unordered_map<int64_t, void*> variantPack;
            variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
            variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
            variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
            variantPack[offsetAttr->get_uid()] = offsetTensor.memory().deviceData();

            Tensor<InputType> maskTensor(maskAttr->get_dim(), maskAttr->get_stride());
            Tensor<InputType> dxTensor(dxAttr->get_dim(), dxAttr->get_stride());
            Tensor<InputType> doffsetTensor(doffsetAttr->get_dim(), doffsetAttr->get_stride());
            Tensor<InputType> dmaskTensor(dmaskAttr->get_dim(), dmaskAttr->get_stride());

            fillTensorWithRandomValues(maskTensor);
            dxTensor.fillWithValue(static_cast<InputType>(0.0f));
            doffsetTensor.fillWithValue(static_cast<InputType>(0.0f));
            dmaskTensor.fillWithValue(static_cast<InputType>(0.0f));

            variantPack[maskAttr->get_uid()] = maskTensor.memory().deviceData();
            variantPack[dxAttr->get_uid()] = dxTensor.memory().deviceData();
            variantPack[doffsetAttr->get_uid()] = doffsetTensor.memory().deviceData();
            variantPack[dmaskAttr->get_uid()] = dmaskTensor.memory().deviceData();

            int64_t workspaceSize;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 预热执行
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            dxTensor.memory().markDeviceModified();
            doffsetTensor.memory().markDeviceModified();
            dmaskTensor.memory().markDeviceModified();
            const InputType* currDxData = dxTensor.memory().hostData();
            const InputType* currDoffsetData = doffsetTensor.memory().hostData();
            const InputType* currDmaskData = dmaskTensor.memory().hostData();

            // 计时执行
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "dgrad avg time: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            std::cout << "DCU dgrad first 10 dx values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDxData[i]) << " ";
            }
            std::cout << '\n';

            std::cout << "DCU dgrad first 10 doffset values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDoffsetData[i]) << " ";
            }
            std::cout << '\n';

            std::cout << "DCU dgrad first 10 dmask values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDmaskData[i]) << " ";
            }
            std::cout << '\n';

            // CPU验证
            if(config_.cpuValidation)
            {
                std::cout << "Running CPU reference validation...\n";

                //            Tensor<InputType> dxDiffTensor(dxAttr->get_dim(), dxAttr->get_stride());

                Tensor<InputType> dxRefTensor(dxAttr->get_dim(), dxAttr->get_stride());
                Tensor<InputType> doffsetRefTensor(doffsetAttr->get_dim(),
                                                   doffsetAttr->get_stride());
                Tensor<InputType> dmaskRefTensor(dmaskAttr->get_dim(), dmaskAttr->get_stride());
                dxRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                doffsetRefTensor.fillWithValue(static_cast<InputType>(0.0f));
                dmaskRefTensor.fillWithValue(static_cast<InputType>(0.0f));

                if(config_.dimension == 2)
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideH, config_.strideW},
                        {config_.dilH, config_.dilW},
                        {config_.padH, config_.padW},
                        true,
                        true,
                        true,
                        true);
                }
                else
                {
                    CpuFpReferenceDeformConvolution::dgrad<InputType, InputType, InputType, float>(
                        wTensor,
                        dyTensor,
                        offsetTensor,
                        maskTensor,
                        xTensor,
                        dxRefTensor,
                        doffsetRefTensor,
                        dmaskRefTensor,
                        {config_.strideD, config_.strideH, config_.strideW},
                        {config_.dilD, config_.dilH, config_.dilW},
                        {config_.padD, config_.padH, config_.padW},
                        true,
                        true,
                        true,
                        true);
                }

                const InputType* currDxRefTensor = dxRefTensor.memory().hostData();
                const InputType* currDoffsetRefTensor = doffsetRefTensor.memory().hostData();
                const InputType* currDmaskRefTensor = dmaskRefTensor.memory().hostData();

                std::cout << "CPU dgrad first 10 dX values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDxRefTensor[i]) << " ";
                }
                std::cout << '\n';
                std::cout << "CPU dgrad first 10 doffset values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDoffsetRefTensor[i]) << " ";
                }
                std::cout << '\n';
                std::cout << "CPU dgrad first 10 dmask values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDmaskRefTensor[i]) << " ";
                }
                std::cout << '\n';

                // 容差设置
                float tolerance = getTolerance<InputType>();

                CpuFpReferenceValidation<InputType> yValidator(tolerance, tolerance);

                bool yValid = yValidator.allClose(dxRefTensor, dxTensor);
                bool doffsetValid = yValidator.allClose(doffsetRefTensor, doffsetTensor);
                bool dmaskValid = yValidator.allClose(dmaskRefTensor, dmaskTensor);
                std::cout << "CPU validation result, dx: " << (yValid ? "successful" : "failed")
                          << "\n";
                std::cout << "CPU validation result, doffset: "
                          << (doffsetValid ? "successful" : "failed") << "\n";
                std::cout << "CPU validation result, dmask: "
                          << (dmaskValid ? "successful" : "failed") << "\n";
            }
        }
    }

    template <typename InputType, typename IntermediateType>
    void wgrad(const TensorLayout& layout)
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        std::cout << "Running deformable convolution weight graph " << inputType << " [" << layout
                  << "]" << (config_.cpuValidation ? " (with CPU validation)" : "") << "...\n";

        const int64_t n = config_.n;
        const int64_t c = config_.c;
        const int64_t d = config_.d;
        const int64_t h = config_.h;
        const int64_t w = config_.w;
        const int64_t k = config_.k;
        const int64_t t = config_.t;
        const int64_t r = config_.r;
        const int64_t s = config_.s;
        const int64_t g = config_.groups;

        std::cout << "Parameter information of size: \n";
        std::cout << "n: " << n << '\n';
        std::cout << "c: " << c << '\n';
        std::cout << "h: " << h << '\n';
        std::cout << "w: " << w << '\n';
        std::cout << "k: " << k << '\n';
        std::cout << "t: " << t << '\n';
        std::cout << "r: " << r << '\n';
        std::cout << "s: " << s << '\n';
        std::cout << "g: " << g << '\n';
        std::cout << "dimension: " << config_.dimension << '\n';
        std::cout << "deformconvType: " << config_.deformconvType << '\n';
        std::cout << "tensorsused: " << config_.tensorsused << '\n';
        std::cout << '\n';

        // 根据维度设置padding、stride、dilation
        std::vector<int64_t> padding, stride, dilation;
        if(config_.dimension == 2)
        {
            padding = {config_.padH, config_.padW};
            stride = {config_.strideH, config_.strideW};
            dilation = {config_.dilH, config_.dilW};
        }
        else
        {
            padding = {config_.padD, config_.padH, config_.padW};
            stride = {config_.strideD, config_.strideH, config_.strideW};
            dilation = {config_.dilD, config_.dilH, config_.dilW};
        }

        // 计算输出维度
        int64_t od, oh, ow;
        if(config_.dimension == 2)
        {
            // 2D可变形卷积输出维度计算
            oh = ((h + 2 * config_.padH - (config_.dilH * (r - 1) + 1)) / config_.strideH) + 1;
            ow = ((w + 2 * config_.padW - (config_.dilW * (s - 1) + 1)) / config_.strideW) + 1;
            od = 1; // 2D可变形卷积深度为1
        }
        else
        {
            // 3D可变形卷积输出维度计算
            od = (d + 2 * config_.padD - config_.dilD * (t - 1) + 1) / config_.strideD + 1;
            oh = (h + 2 * config_.padH - config_.dilH * (r - 1) + 1) / config_.strideH + 1;
            ow = (w + 2 * config_.padW - config_.dilW * (s - 1) + 1) / config_.strideW + 1;
        }

        // 计算总元素数
        //        size_t xTotalElems, dyTotalElems, dwTotalElems;
        //        if(config_.dimension == 2)
        //        {
        //            xTotalElems = static_cast<size_t>(n * c * h * w);
        //            dyTotalElems = static_cast<size_t>(n * k * oh * ow);
        //            dwTotalElems = static_cast<size_t>(k * (c / g) * r * s);
        //        }
        //        else
        //        {
        //            xTotalElems = static_cast<size_t>(n * c * d * h * w);
        //            dyTotalElems = static_cast<size_t>(n * k * od * oh * ow);
        //            dwTotalElems = static_cast<size_t>(k * (c / g) * t * r * s);
        //        }

        // 创建计算图
        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_compute_data_type(DataType::FLOAT)
            .set_intermediate_data_type(intermediateType);

        // 定义输入和权重张量属性
        std::shared_ptr<graph::TensorAttributes> xAttr, dyAttr, offsetAttr, maskAttr;
        if(config_.dimension == 2)
        {
            xAttr = createTensor({n, c, h, w}, inputType, layout.strideOrder);
            dyAttr = createTensor({n, k, oh, ow}, inputType, layout.strideOrder);
            offsetAttr = createTensor({n, g * 2 * r * s, oh, ow}, inputType, layout.strideOrder);
            maskAttr = createTensor({n, g * r * s, oh, ow}, inputType, layout.strideOrder);
        }
        else
        {
            xAttr = createTensor({n, c, d, h, w}, inputType, layout.strideOrder);
            dyAttr = createTensor({n, k, od, oh, ow}, inputType, layout.strideOrder);
            offsetAttr
                = createTensor({n, g * 2 * t * r * s, od, oh, ow}, inputType, layout.strideOrder);
            maskAttr = createTensor({n, g * r * s, oh, ow}, inputType, layout.strideOrder);
        }

        // 可变形卷积参数配置
        graph::DeformConvWgradAttributes deformConvAttributes;
        deformConvAttributes.set_name(config_.dimension == 2 ? "deformconv2d_wgrad_node"
                                                             : "deformconv3d_wgrad_node");
        deformConvAttributes.set_padding(padding);
        deformConvAttributes.set_stride(stride);
        deformConvAttributes.set_dilation(dilation);
        if(config_.tensorsused == 1)
        {
            deformConvAttributes.set_mask(maskAttr);
        }

        // 创建输出张量并设置类型
        auto dwAttr = graph->deform_conv_wgrad(dyAttr, offsetAttr, xAttr, deformConvAttributes);
        if(config_.dimension == 2)
        {
            dwAttr->set_output(true).set_dim({k, c / g, r, s});
        }
        else
        {
            dwAttr->set_output(true).set_dim({k, c / g, t, r, s});
        }

        if(config_.tensorsused == 0)
        {
            // 图验证与构建
            HIPDNN_FE_CHECK(graph->validate());
            std::cout << "Graph validation successful (wgrad).\n";

            HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
            std::cout << "Operation graph build successful (wgrad).\n";

            HIPDNN_FE_CHECK(graph->create_execution_plans());
            std::cout << "Execution plans created successfully (wgrad).\n";

            HIPDNN_FE_CHECK(graph->check_support());
            std::cout << "Graph support check successful (wgrad).\n";

            HIPDNN_FE_CHECK(graph->build_plans());
            std::cout << "Plans build successful (wgrad).\n";

            // 初始化张量
            Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
            Tensor<InputType> offsetTensor(offsetAttr->get_dim(), offsetAttr->get_stride());
            Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
            Tensor<InputType> dwTensor(dwAttr->get_dim(), dwAttr->get_stride());

            // 初始化值
            fillTensorWithRandomValues(xTensor);
            fillTensorWithRandomValues(offsetTensor);
            fillTensorWithRandomValues(dyTensor);
            dwTensor.fillWithValue(static_cast<InputType>(0.0f));

            // 读取参考数据或生成随机数据

            std::unordered_map<int64_t, void*> variantPack;
            variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
            variantPack[offsetAttr->get_uid()] = offsetTensor.memory().deviceData();
            variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
            variantPack[dwAttr->get_uid()] = dwTensor.memory().deviceData();

            int64_t workspaceSize;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 预热执行
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            dwTensor.memory().markDeviceModified();

            const InputType* currDwData = dwTensor.memory().hostData();

            // 计时执行
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "wgrad avg time: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            std::cout << "DCU wgrad first 10 values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDwData[i]) << " ";
            }
            std::cout << '\n';

            // CPU验证
            if(config_.cpuValidation)
            {
                Tensor<InputType> dwRefTensor(dwAttr->get_dim(), dwAttr->get_stride());
                // 根据维度调用不同的CPU验证函数
                if(config_.dimension == 2)
                {
                    CpuFpReferenceDeformConvolution::wgrad<InputType, InputType, InputType, float>(
                        xTensor,
                        dyTensor,
                        offsetTensor,
                        nullptr,
                        dwRefTensor,
                        {config_.strideD, config_.strideH},
                        {config_.strideD, config_.strideH},
                        {config_.dilD, config_.dilH},
                        {config_.padD, config_.padH},
                        false);
                }
                else
                {
                    CpuFpReferenceDeformConvolution::wgrad<InputType, InputType, InputType, float>(
                        xTensor,
                        dyTensor,
                        offsetTensor,
                        nullptr,
                        dwRefTensor,
                        stride,
                        dilation,
                        padding,
                        false);
                }

                const InputType* currDwRefData = dwRefTensor.memory().hostData();
                //                const InputType* currDyData = dyTensor.memory().hostData();
                //                std::cout << "CPU wgrad first 10 dy values: ";
                //                for(int i = 0; i < 10; ++i)
                //                {
                //                    std::cout << static_cast<float>(currDyData[i]) << " ";
                //                }
                //                std::cout << '\n';
                std::cout << "CPU wgrad first 10 dw values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDwRefData[i]) << " ";
                }
                std::cout << '\n';

                float tolerance = getTolerance<InputType>();
                CpuFpReferenceValidation<InputType> dwValidator(tolerance, tolerance);
                bool dwValid = dwValidator.allClose(dwRefTensor, dwTensor);
                std::cout << "CPU validation result: " << (dwValid ? "successful" : "failed")
                          << "\n";
            }
        }
        if(config_.tensorsused == 1)
        {
            // 图验证与构建
            HIPDNN_FE_CHECK(graph->validate());
            std::cout << "Graph validation successful (wgrad).\n";

            HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
            std::cout << "Operation graph build successful (wgrad).\n";

            HIPDNN_FE_CHECK(graph->create_execution_plans());
            std::cout << "Execution plans created successfully (wgrad).\n";

            HIPDNN_FE_CHECK(graph->check_support());
            std::cout << "Graph support check successful (wgrad).\n";

            HIPDNN_FE_CHECK(graph->build_plans());
            std::cout << "Plans build successful (wgrad).\n";

            // 初始化张量
            Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
            Tensor<InputType> offsetTensor(offsetAttr->get_dim(), offsetAttr->get_stride());
            Tensor<InputType> maskTensor(maskAttr->get_dim(), maskAttr->get_stride());
            Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
            Tensor<InputType> dwTensor(dwAttr->get_dim(), dwAttr->get_stride());

            // 初始化值
            fillTensorWithRandomValues(xTensor);
            fillTensorWithRandomValues(offsetTensor);
            fillTensorWithRandomValues(dyTensor);
            fillTensorWithRandomValues(maskTensor);
            dwTensor.fillWithValue(static_cast<InputType>(0.0f));

            // 读取参考数据或生成随机数据

            std::unordered_map<int64_t, void*> variantPack;
            variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
            variantPack[offsetAttr->get_uid()] = offsetTensor.memory().deviceData();
            variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
            variantPack[dwAttr->get_uid()] = dwTensor.memory().deviceData();
            variantPack[maskAttr->get_uid()] = maskTensor.memory().deviceData();

            int64_t workspaceSize;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 预热执行
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            dwTensor.memory().markDeviceModified();

            const InputType* currDwData = dwTensor.memory().hostData();

            // 计时执行
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "wgrad avg time: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            std::cout << "DCU wgrad first 10 values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(currDwData[i]) << " ";
            }
            std::cout << '\n';

            // CPU验证
            if(config_.cpuValidation)
            {
                Tensor<InputType> dwRefTensor(dwAttr->get_dim(), dwAttr->get_stride());
                // 根据维度调用不同的CPU验证函数
                if(config_.dimension == 2)
                {
                    CpuFpReferenceDeformConvolution::wgrad<InputType, InputType, InputType, float>(
                        xTensor,
                        dyTensor,
                        offsetTensor,
                        &maskTensor,
                        dwRefTensor,
                        {config_.strideD, config_.strideH},
                        {config_.strideD, config_.strideH},
                        {config_.dilD, config_.dilH},
                        {config_.padD, config_.padH},
                        true);
                }
                else
                {
                    CpuFpReferenceDeformConvolution::wgrad<InputType, InputType, InputType, float>(
                        xTensor,
                        dyTensor,
                        offsetTensor,
                        &maskTensor,
                        dwRefTensor,
                        stride,
                        dilation,
                        padding,
                        true);
                }

                const InputType* currDwRefData = dwRefTensor.memory().hostData();
                //                const InputType* currDyData = dyTensor.memory().hostData();
                //                std::cout << "CPU wgrad first 10 dy values: ";
                //                for(int i = 0; i < 10; ++i)
                //                {
                //                    std::cout << static_cast<float>(currDyData[i]) << " ";
                //                }
                //                std::cout << '\n';
                std::cout << "CPU wgrad first 10 dw values: ";
                for(int i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(currDwRefData[i]) << " ";
                }
                std::cout << '\n';

                float tolerance = getTolerance<InputType>();
                CpuFpReferenceValidation<InputType> dwValidator(tolerance, tolerance);
                bool dwValid = dwValidator.allClose(dwRefTensor, dwTensor);
                std::cout << "CPU validation result: " << (dwValid ? "successful" : "failed")
                          << "\n";
            }
        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    template <typename T>
    T getTolerance()
    {
        if(config_.dataType == "tf32")
        {
            return static_cast<T>(1e-2f);
        }
        else
        {
            if(config_.deformconvType == 1)
            {
                return deform_conv::getToleranceFwd<T>();
            }
            else if(config_.deformconvType == 2)
                if(config_.dataType == "fp32")
                {
                    return static_cast<T>(8.5e-5f);
                }
                else
                {
                    return deform_conv::getToleranceBwd<T>();
                }
            else if(config_.deformconvType == 4)
            {
                return deform_conv::getToleranceWrw<T>();
            }
        }
    }

    template <typename InputType>
    void fillTensorWithRandomValues(Tensor<InputType>& tensor)
    {
        if constexpr(std::is_same_v<InputType, int8_t>)
        {
            tensor.fillWithRandomValues(static_cast<InputType>(-127), static_cast<InputType>(127));
        }
        else
        {
            tensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));
        }
    }
};

void runDeformConv(hipdnnHandle_t handle, const Config& config)
{
    TensorLayout layout;
    if(config.dimension == 2)
    {
        layout = (config.layout == "NHWC") ? TensorLayout::NHWC : TensorLayout::NCHW;
    }
    else
    {
        layout = (config.layout == "NHWC") ? TensorLayout::NDHWC : TensorLayout::NCDHW;
    }

    DeformConvRunner runner(handle, config); //DeformConvRunner类的实例化
    if(config.deformconvType == 1)
    {
        if(config.dataType == "fp32" || config.dataType == "tf32")
        {
            runner.template fprop<float, float>(layout);
        }
        //        else if(config.dataType == "fp16")
        //        {
        //            runner.template fprop<half, float>(layout);
        //        }
        else
        {
            std::cerr << "Unsupported data type: " << config.dataType << std::endl;
            exit(1);
        }
    }
    else if(config.deformconvType == 2)
    {
        if(config.dataType == "fp32" || config.dataType == "tf32")
        {
            runner.template dgrad<float, float>(layout);
        }
        //        else if(config.dataType == "fp16")
        //        {
        //            runner.template dgrad<half, float>(layout);
        //        }
        else
        {
            std::cerr << "Unsupported data type: " << config.dataType << std::endl;
            exit(1);
        }
    }
    else if(config.deformconvType == 4)
    {
        if(config.dataType == "fp32" || config.dataType == "tf32")
        {
            runner.template wgrad<float, float>(layout);
        }
        //        else if(config.dataType == "fp16")
        //        {
        //            runner.template wgrad<half, float>(layout);
        //        }
        else
        {
            std::cerr << "Unsupported data type: " << config.dataType << std::endl;
            exit(1);
        }
    }
}

int main(int argc, char* argv[])
{
    // 打印参数
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    // 解析配置
    auto config = parseCommandLineArgs(argc, argv);

    // 初始化日志
    initializeFrontendLogging();

    // 使用RAII管理句柄
    hipdnnHandle_t handle;

    HIPDNN_CHECK(hipdnnCreate(&handle));
    // 执行可变形卷积
    runDeformConv(handle, config);
    std::cout << "\nDeformConv test completed successfully.\n";

    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
