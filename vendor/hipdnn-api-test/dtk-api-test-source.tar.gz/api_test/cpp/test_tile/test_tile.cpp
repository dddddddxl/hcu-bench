// Copyright © Advanced Micro Devices, Inc., or its affiliates.
// SPDX-License-Identifier: MIT

#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

#include <hip/hip_runtime.h>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;

// ==================== 工具宏定义 ====================
#define HIP_CHECK(status)                                                                      \
    do                                                                                         \
    {                                                                                          \
        if(status != hipSuccess)                                                               \
        {                                                                                      \
            std::cerr << "HIP Error: " << hipGetErrorString(status) << " in file " << __FILE__ \
                      << " at line " << __LINE__ << "\n";                                      \
            exit(EXIT_FAILURE);                                                                \
        }                                                                                      \
    } while(0)

#define HIPDNN_CHECK(status)                                                             \
    do                                                                                   \
    {                                                                                    \
        if(status != HIPDNN_STATUS_SUCCESS)                                              \
        {                                                                                \
            std::cerr << "hipDNN Error: " << hipdnnGetErrorString(status) << " in file " \
                      << __FILE__ << " at line " << __LINE__ << "\n";                    \
            exit(EXIT_FAILURE);                                                          \
        }                                                                                \
    } while(0)

#define HIPDNN_FE_CHECK(statusObj)                                                        \
    do                                                                                    \
    {                                                                                     \
        auto const& status = statusObj;                                                   \
        if(!status.is_good())                                                             \
        {                                                                                 \
            std::cerr << "hipDNN Frontend Error: " << status.get_message() << " in file " \
                      << __FILE__ << " at line " << __LINE__ << "\n";                     \
            exit(EXIT_FAILURE);                                                           \
        }                                                                                 \
    } while(0)

// ==================== 配置结构体 ====================
struct Config
{
    int64_t n = 2; // 批量大小
    int64_t c = 3; // 通道数
    int64_t h = 4; // 高度
    int64_t w = 4; // 宽度
    std::vector<int64_t> repeats = {1, 2, 1, 3}; // 每个维度的重复次数
    std::string dataType = "fp32"; // 数据类型 (fp32/fp16/bfp16)
    bool cpuValidation = false; // 是否进行 CPU 验证
    int fileIndex = 0; // 文件索引，0 表示不使用文件
    std::string filePath = "."; // 文件路径
};

// ==================== 命令行解析 ====================
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-r") == 0 && i + 1 < argc)
        {
            std::string repeatStr = argv[++i];
            std::replace(repeatStr.begin(), repeatStr.end(), ',', ' ');
            std::istringstream iss(repeatStr);
            config.repeats.clear();
            int64_t val;
            while(iss >> val)
                config.repeats.push_back(val);
            if(config.repeats.size() != 4)
            {
                std::cerr << "Repeats must have exactly 4 values (for N,C,H,W)." << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            std::cerr << "Usage: " << argv[0] << " -n <batch> -c <channels> -H <height> -W <width> "
                      << "-r <N_repeat,C_repeat,H_repeat,W_repeat> -d <data_type> "
                      << "--cpu-validation -i <file_index> -path <path>\n";
            exit(1);
        }
    }

    // 确保 repeats 长度正确
    if(config.repeats.size() != 4)
    {
        config.repeats = {1, 1, 1, 1}; // 默认不重复
    }
    return config;
}

// ==================== TileRunner 类 ====================
class TileRunner
{
public:
    TileRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    // 创建张量属性 (NCHW 连续布局)
    std::shared_ptr<graph::Tensor_attributes> createTensor(const std::vector<int64_t>& dims,
                                                           DataType data_type,
                                                           const std::string& name = "")
    {
        auto tensor = std::make_shared<graph::Tensor_attributes>();
        tensor->set_dim(dims).set_data_type(data_type);
        if(!name.empty())
            tensor->set_name(name);

        // 计算 NCHW 连续步长
        std::vector<int64_t> strides(dims.size());
        int64_t stride = 1;
        for(int64_t i = static_cast<int64_t>(dims.size()) - 1; i >= 0; --i)
        {
            size_t idx = static_cast<size_t>(i);
            strides[idx] = stride;
            stride *= dims[idx];
        }
        tensor->set_stride(strides);
        return tensor;
    }

    // ---------- 前向传播 ----------
    template <typename InputType, typename ComputeType = float>
    void forward()
    {
        const auto dataType = getDataTypeEnumFromType<InputType>();
        const auto computeType = getDataTypeEnumFromType<ComputeType>();

        std::cout << "Running Tile forward graph " << dataType << " (repeats = [";
        for(size_t i = 0; i < config_.repeats.size(); ++i)
        {
            if(i > 0)
                std::cout << ", ";
            std::cout << config_.repeats[i];
        }
        std::cout << "])" << (config_.cpuValidation ? " (with CPU validation)" : "") << "...\n";

        // 输入和输出维度
        std::vector<int64_t> inputDims = {config_.n, config_.c, config_.h, config_.w};
        std::vector<int64_t> outputDims = inputDims;
        for(size_t i = 0; i < 4; ++i)
            outputDims[i] *= config_.repeats[i];

        size_t inputElems = static_cast<size_t>(config_.n * config_.c * config_.h * config_.w);
        size_t outputElems
            = static_cast<size_t>(outputDims[0] * outputDims[1] * outputDims[2] * outputDims[3]);

        auto graph = std::make_shared<graph::Graph>();
        graph->set_name("tile_graph")
            .set_io_data_type(dataType)
            .set_intermediate_data_type(dataType)
            .set_compute_data_type(computeType);

        // 输入张量
        auto x = createTensor(inputDims, dataType, "input");
        auto tileAttrs = graph::TileAttributes().set_name("tile_node").set_repeats(config_.repeats);

        auto y = graph->tile(x, tileAttrs);
        y->set_output(true);

        // 构建图
        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful (Tile).\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful (Tile).\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully (Tile).\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful (Tile).\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful (Tile).\n";

        // 分配张量
        Tensor<InputType> xTensor(x->get_dim(), x->get_stride());
        Tensor<InputType> yTensor(y->get_dim(), y->get_stride());

        // 读取参考文件 (如果提供)
        bool readSuccess = false;
        std::vector<InputType> refXData, refYData;
        Tensor<InputType> refYTensor(y->get_dim(), y->get_stride());
        if(config_.fileIndex > 0)
        {
            const std::string xFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_X.bin";
            const std::string yFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_Y.bin";
            readSuccess = readRawTensor<InputType>(xFilename, refXData, inputElems)
                          && readRawTensor<InputType>(yFilename, refYData, outputElems);
            if(readSuccess)
            {
                std::cout << "Successfully read Tile reference files.\n";
                std::copy(refXData.begin(), refXData.end(), xTensor.memory().hostData());
                xTensor.memory().markHostModified();
                std::copy(refYData.begin(), refYData.end(), refYTensor.memory().hostData());
                refYTensor.memory().markHostModified();
            }
            else
            {
                std::cerr << " [WARN] Failed to read reference files. Using random values.\n";
            }
        }

        // 随机填充输入（如果未从文件读取）
        if(!readSuccess || config_.fileIndex == 0)
        {
            xTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                         static_cast<InputType>(1.0f));
        }

        // 准备执行数据包
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[x->get_uid()] = xTensor.memory().deviceData();
        variantPack[y->get_uid()] = yTensor.memory().deviceData();

        // 工作空间
        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 首次执行 (确保编译)
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        yTensor.memory().markDeviceModified();

        // 性能计时
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));

        const int warmupRuns = 10;
        const int timedRuns = 100;

        for(int i = 0; i < warmupRuns; ++i)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipEventRecord(start, nullptr));
        for(int i = 0; i < timedRuns; ++i)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));

        std::cout << "Tile forward average execution time: " << time / timedRuns << " ms\n";
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // 同步主机数据
        (void)yTensor.memory().hostData();

        // 文件验证
        if(config_.fileIndex > 0 && readSuccess)
        {
            bool match = compareTensors(refYTensor, yTensor, outputElems);
            std::cout << "File validation result: " << (match ? "successful" : "failed") << "\n";
            printFirstElements(refYTensor, yTensor, outputElems);
        }

        // CPU 参考验证
        if(config_.cpuValidation)
        {
            std::cout << "Running CPU reference validation...\n";
            Tensor<InputType> cpuYTensor(y->get_dim(), y->get_stride());
            runCpuReference(xTensor, cpuYTensor, config_.repeats);
            float tolerance = getTolerance<InputType>();
            auto validator = hipdnn_test_sdk::utilities::CpuFpReferenceValidation<InputType>(
                tolerance, tolerance);
            bool yValid = validator.allClose(cpuYTensor, yTensor);
            std::cout << "CPU reference validation: " << (yValid ? "successful" : "failed") << "\n";
            printFirstElements(cpuYTensor, yTensor, outputElems, "CPU Reference", "GPU Output");
        }

        // 打印前10个输出值
        std::cout << "First 10 y values: ";
        auto yHostPtr = yTensor.memory().hostData();
        for(int i = 0; i < 10 && i < static_cast<int>(outputElems); ++i)
        {
            printValue(yHostPtr[i]);
            std::cout << " ";
        }
        std::cout << "\n";

        std::cout << "Tile graph execution complete for " << dataType << ".\n\n";
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    // 读取二进制文件
    template <typename T>
    bool readRawTensor(const std::string& filename, std::vector<T>& data, size_t totalElems)
    {
        std::ifstream file(filename, std::ios::binary);
        if(!file.is_open())
        {
            std::cerr << "Failed to open file: " << filename << std::endl;
            return false;
        }
        file.seekg(0, std::ios::end);
        std::streampos fileSize = file.tellg();
        file.seekg(0, std::ios::beg);
        size_t expectedBytes = totalElems * sizeof(T);
        if(static_cast<size_t>(fileSize) != expectedBytes)
        {
            std::cerr << "File size mismatch: expected " << expectedBytes << " bytes, got "
                      << fileSize << " bytes" << std::endl;
            return false;
        }
        data.resize(totalElems);
        file.read(reinterpret_cast<char*>(data.data()), static_cast<std::streamsize>(fileSize));
        file.close();
        return true;
    }

    // 比较两个张量是否相等 (用于文件验证)
    template <typename T>
    bool compareTensors(const Tensor<T>& ref, const Tensor<T>& cur, size_t totalElems)
    {
        const T* refData = ref.memory().hostData();
        const T* curData = cur.memory().hostData();
        for(size_t i = 0; i < totalElems; ++i)
        {
            if(refData[i] != curData[i])
            {
                std::cout << "Mismatch at index " << i << ": ref=" << static_cast<float>(refData[i])
                          << ", cur=" << static_cast<float>(curData[i]) << std::endl;
                return false;
            }
        }
        return true;
    }

    template <typename T>
    void printFirstElements(const Tensor<T>& ref,
                            const Tensor<T>& cur,
                            size_t totalElems,
                            const std::string& refName = "Reference",
                            const std::string& curName = "Current")
    {
        size_t printCount = std::min(totalElems, static_cast<size_t>(10));
        std::cout << "First " << printCount << " elements comparison:\n";
        std::cout << refName << ": ";
        for(size_t i = 0; i < printCount; ++i)
        {
            printValue(ref.memory().hostData()[i]);
            std::cout << " ";
        }
        std::cout << "\n" << curName << ":   ";
        for(size_t i = 0; i < printCount; ++i)
        {
            printValue(cur.memory().hostData()[i]);
            std::cout << " ";
        }
        std::cout << std::endl;
    }

    template <typename T>
    void printValue(T val)
    {
        if constexpr(std::is_same_v<T, half> || std::is_same_v<T, bfloat16>)
            std::cout << static_cast<float>(val);
        else if constexpr(std::is_same_v<T, int8_t>)
            std::cout << static_cast<int>(val);
        else
            std::cout << val;
    }

    // 获取容差值
    template <typename InputType>
    float getTolerance()
    {
        if constexpr(std::is_same_v<InputType, float>)
        {
            return 1e-5f;
        }
        else if constexpr(std::is_same_v<InputType, half>)
        {
            return 1e-2f;
        }
        else if constexpr(std::is_same_v<InputType, bfloat16>)
        {
            return 1e-2f;
        }
        else
        {
            return 1e-5f;
        }
    }

    // ---------- CPU 参考实现（修正索引映射为取模） ----------
    template <typename InputType>
    void runCpuReference(const Tensor<InputType>& inputTensor,
                         Tensor<InputType>& outputTensor,
                         const std::vector<int64_t>& repeats)
    {
        const InputType* x = inputTensor.memory().hostData();
        InputType* y = outputTensor.memory().hostData();

        int64_t n = config_.n;
        int64_t c = config_.c;
        int64_t h = config_.h;
        int64_t w = config_.w;

        int64_t rN = repeats[0];
        int64_t rC = repeats[1];
        int64_t rH = repeats[2];
        int64_t rW = repeats[3];

        int64_t outN = n * rN;
        int64_t outC = c * rC;
        int64_t outH = h * rH;
        int64_t outW = w * rW;

        for(int64_t on = 0; on < outN; ++on)
        {
            int64_t in = on % n; // 关键修正：取模（不是除法）
            for(int64_t oc = 0; oc < outC; ++oc)
            {
                int64_t ic = oc % c; // 修正
                for(int64_t oh = 0; oh < outH; ++oh)
                {
                    int64_t ih = oh % h; // 修正
                    for(int64_t ow = 0; ow < outW; ++ow)
                    {
                        int64_t iw = ow % w; // 修正
                        int64_t idxIn = ((in * c + ic) * h + ih) * w + iw;
                        int64_t idxOut = ((on * outC + oc) * outH + oh) * outW + ow;
                        y[idxOut] = x[idxIn];
                    }
                }
            }
        }
        outputTensor.memory().markHostModified();
    }
};

// ==================== 根据参数选择执行类型 ====================
void run(hipdnnHandle_t handle, const Config& config)
{
    if(config.dataType == "fp32")
    {
        TileRunner runner(handle, config);
        runner.forward<float, float>();
    }
    else if(config.dataType == "fp16")
    {
        TileRunner runner(handle, config);
        runner.forward<half, float>();
    }
    else if(config.dataType == "bfp16")
    {
        TileRunner runner(handle, config);
        runner.forward<bfloat16, float>();
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType
                  << " (supported: fp32, fp16, bfp16)" << std::endl;
        exit(1);
    }
}

// ==================== 主函数 ====================
int main(int argc, char* argv[])
{
    // 打印命令行
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    // 初始化前端日志
    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));

    run(handle, config);

    HIPDNN_CHECK(hipdnnDestroy(handle));
    std::cout << "Tile test completed.\n";
    return 0;
}
