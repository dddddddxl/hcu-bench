#include <algorithm>
#include <cctype>
#include <cstring>
#include <iostream>
#include <string>
#include <typeinfo>
#include <unordered_map>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_frontend/Graph.hpp>

#include "../utils.hpp"

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace std;

// 融合模式枚举
enum class FusionMode
{
    CONV_DTS,
    CONV_BIAS_DTS,
    CONV_BIAS_ADD_DTS, // 新增：bias之后、dts之前添加Add
    CONV_BIAS_DTS_ADD,
    CONV_BIAS_DTS_RELU,
    CONV_BIAS_DTS_LEAKYRELU,
    CONV_BIAS_DTS_CLIPPEDRELU,
    CONV_BIAS_DTS_RELU_ADD,
    CONV_BIAS_DTS_LEAKYRELU_ADD,
    CONV_BIAS_DTS_CLIPPEDRELU_ADD
};

// 配置结构体
struct Config
{
    int64_t n = 1;
    int64_t c = 8;
    int64_t H = 128;
    int64_t W = 128;
    int64_t k = 16;
    int64_t r = 3;
    int64_t s = 3;
    int64_t blockSize = 2;
    int64_t stride_h = 1;
    int64_t stride_w = 1;
    int64_t pad_h = 1;
    int64_t pad_w = 1;
    int64_t dilation_h = 1;
    int64_t dilation_w = 1;
    string dataType = "fp32";
    string layout = "NHWC";
    string trans_mode = "CRD"; // 转换类型
    bool cpuValidation = false;
    FusionMode fusionMode = FusionMode::CONV_BIAS_DTS;
    float reluAlpha = 0.25f;
};

unordered_map<string, FusionMode> fusionModeMap
    = {{"conv_dts", FusionMode::CONV_DTS},
       {"conv_bias_dts", FusionMode::CONV_BIAS_DTS},
       {"conv_bias_add_dts", FusionMode::CONV_BIAS_ADD_DTS},
       {"conv_bias_dts_add", FusionMode::CONV_BIAS_DTS_ADD},
       {"conv_bias_dts_relu", FusionMode::CONV_BIAS_DTS_RELU},
       {"conv_bias_dts_leakyrelu", FusionMode::CONV_BIAS_DTS_LEAKYRELU},
       {"conv_bias_dts_clippedrelu", FusionMode::CONV_BIAS_DTS_CLIPPEDRELU},
       {"conv_bias_dts_relu_add", FusionMode::CONV_BIAS_DTS_RELU_ADD},
       {"conv_bias_dts_leakyrelu_add", FusionMode::CONV_BIAS_DTS_LEAKYRELU_ADD},
       {"conv_bias_dts_clippedrelu_add", FusionMode::CONV_BIAS_DTS_CLIPPEDRELU_ADD}};

// 融合模式到字符串的转换
string fusionModeToString(FusionMode mode)
{
    for(const auto& pair : fusionModeMap)
    {
        if(pair.second == mode)
        {
            return pair.first;
        }
    }
    return "unknown";
}

// 解析命令行参数
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.H = stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.W = stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-k") == 0 && i + 1 < argc)
        {
            config.k = stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-y") == 0 && i + 1 < argc)
        {
            config.r = stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-x") == 0 && i + 1 < argc)
        {
            config.s = stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-p") == 0 && i + 1 < argc)
        {
            config.pad_h = stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc)
        {
            config.pad_w = stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-u") == 0 && i + 1 < argc)
        {
            config.stride_h = stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-v") == 0 && i + 1 < argc)
        {
            config.stride_w = stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-l") == 0 && i + 1 < argc)
        {
            config.dilation_h = stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-j") == 0 && i + 1 < argc)
        {
            config.dilation_w = stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-bs") == 0 && i + 1 < argc)
        {
            config.blockSize = stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            for(char& ch : config.dataType)
            {
                ch = static_cast<char>(tolower(static_cast<unsigned char>(ch)));
            }
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            for(char& ch : config.layout)
            {
                ch = static_cast<char>(toupper(static_cast<unsigned char>(ch)));
            }
        }
        else if(strcmp(argv[i], "-t") == 0 && i + 1 < argc)
        {
            config.trans_mode = argv[++i];
            for(char& ch : config.trans_mode)
            {
                ch = static_cast<char>(toupper(static_cast<unsigned char>(ch)));
            }
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-a") == 0 && i + 1 < argc)
        {
            string modeStr = argv[++i];
            transform(modeStr.begin(), modeStr.end(), modeStr.begin(), ::tolower);
            if(fusionModeMap.find(modeStr) != fusionModeMap.end())
            {
                config.fusionMode = fusionModeMap[modeStr];
            }
            else
            {
                cerr << "Unknown fusion mode: " << modeStr << endl;
                cerr << "Available modes: ";
                for(const auto& pair : fusionModeMap)
                {
                    std::cerr << pair.first << " ";
                }
                std::cerr << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "--relu-alpha") == 0 && i + 1 < argc)
        {
            config.reluAlpha = stof(argv[++i]);
        }
        else if(strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0)
        {
            cout << "convDepthToSpace 测试用例示例\n";
            cout << "参数选项:\n";
            cout << "   -n <batch>                  批次大小(默认: 1)\n";
            cout << "   -c <channels>               通道数(默认: 8)\n";
            cout << "   -H <height>                 高度(默认: 128)\n";
            cout << "   -W <width>                  宽度(默认: 128)\n";
            cout << "   -k <outputChannels>         输出通道数(默认: 16)\n";
            cout << "   -y <kernelH>                Kernel高度(默认: 3)\n";
            cout << "   -x <kernelW>                Kernel宽度(默认: 3)\n";
            cout << "   -p <padH>                   高度方向上的padding(默认: 1)\n";
            cout << "   -q <padW>                   宽度方向上的padding(默认: 1)\n";
            cout << "   -u <strideH>                高度方向上的步长(默认: 1)\n";
            cout << "   -v <strideW>                宽度方向上的步长(默认: 1)\n";
            cout << "   -l <dilationH>              高度方向上的膨胀系数(默认: 1)\n";
            cout << "   -j <dilationW>              宽度方向上的膨胀系数(默认: 1)\n";
            cout << "   -bs <blockSize>             分块数量\n";
            cout << "   -d <dataType>               精度类型(fp32, fp16)\n";
            cout << "   -L <layout>                 布局类型(NHWC)\n";
            cout << "   -t <transMode>              转换类型(CRD, DCR)\n";
            cout << "   --cpu-validation            启用CPU参考验证\n";
            cout << "   -a                          融合模式\n";
            cout << "   --relu-alpha                leaky和clippedrelu的参数\n";
            cout << "   -h                          显示此帮助信息\n";
            cout << "\n";
            cout << "可用的融合模式:\n";
            for(const auto& pair : fusionModeMap)
            {
                cout << "   " << pair.first << "\n";
            }
            cout << endl;
            exit(1);
        }
        else
        {
            cerr << "unknown parameter: " << argv[i] << endl;
            cerr << "使用 --help或-h 查看帮助信息" << endl;
            cerr << "./test_trans -n <batch> -c <channels> -H <height> -W <width> -k <out_chanels> "
                    "-y <kernelH> -x <kernelW> ";
            cerr << "-p <padH> -q <padW> -u <strideH> -v <strideW> -l <dilationH> -j <dilationW> "
                    "-bs <blockSize> -d <precision> ";
            cerr << "-L <layout> -a <fusion_mode> --relu-alpha <value>" << endl;
            exit(1);
        }
    }

    return config;
}

class ConvDepthToSpaceRunner
{
private:
    Config config_;
    hipdnnHandle_t handle_;

public:
    ConvDepthToSpaceRunner(hipdnnHandle_t handle, Config& config)
        : config_(config)
        , handle_(handle)
    {
    }

    template <typename InputType, typename IntermediateType>
    void operator()()
    {
        auto inputType = getDataTypeEnumFromType<InputType>();
        auto intermediateType = getDataTypeEnumFromType<IntermediateType>();
        cout << "Running ConvDepthToSpace graph with fusion mode: "
             << fusionModeToString(config_.fusionMode) << endl;
        cout << "CPU validation: " << config_.cpuValidation << endl;

        const int64_t n = config_.n;
        const int64_t c = config_.c;
        const int64_t H = config_.H;
        const int64_t W = config_.W;
        const int64_t k = config_.k;
        const int64_t r = config_.r;
        const int64_t s = config_.s;
        const int64_t p = config_.pad_h;
        const int64_t q = config_.pad_w;
        const int64_t u = config_.stride_h;
        const int64_t v = config_.stride_w;
        const int64_t l = config_.dilation_h;
        const int64_t j = config_.dilation_w;
        const int64_t bs = config_.blockSize;
        string layout = config_.layout;
        string trans_mode = config_.trans_mode;
        FusionMode fusionMode = config_.fusionMode;

        // 当前convDepthToSpace只支持NHWC布局
        if(layout != "NHWC")
        {
            cerr << "unsupported layout: " << layout << endl;
            exit(1);
        }

        // convDepthToSpace只支持CRD及DCR两种转换模式
        if(trans_mode != "CRD" && trans_mode != "DCR")
        {
            cerr << "unsupported trans mode: " << trans_mode << endl;
            exit(1);
        }

        vector<int64_t> strides = {u, v};
        vector<int64_t> padding = {p, q};
        vector<int64_t> dilation = {l, j};

        int64_t outH = ((H + 2 * padding[0] - (dilation[0] * (r - 1) + 1)) / strides[0]) + 1;
        int64_t outW = ((W + 2 * padding[1] - (dilation[1] * (s - 1) + 1)) / strides[1]) + 1;

        cout << "Output dimensions (before DTS): " << outH << " x " << outW << endl;
        cout << "Output dimensions (after DTS): " << outH * bs << " x " << outW * bs << endl;
        cout << "Output channels: " << k / (bs * bs) << endl;

        // 构建图的函数
        auto buildAndExecute = [&]() {
            auto graph = make_shared<graph::Graph>();

            graph->set_name("ConvDepthToSpaceGraph")
                .set_io_data_type(inputType)
                .set_intermediate_data_type(intermediateType)
                .set_compute_data_type(hipdnn_frontend::DataType::FLOAT);

            // create conv tensor
            auto input
                = make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                           .set_name("image")
                                                           .set_dim({n, c, H, W})
                                                           .set_stride({c * H * W, 1, c * W, c}));

            // create filter tensor
            auto filter
                = make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                           .set_name("filter")
                                                           .set_dim({k, c, r, s})
                                                           .set_stride({c * r * s, 1, c * s, c}));

            // execute conv fprop
            auto convFpropAttributes = graph::ConvFpropAttributes()
                                           .set_name("conv_fprop_node")
                                           .set_padding(padding)
                                           .set_stride(strides)
                                           .set_dilation(dilation);
            auto convOutput = graph->conv_fprop(input, filter, convFpropAttributes);
            cout << "execute conv_fprop operator" << endl;

            // 处理bias
            shared_ptr<graph::TensorAttributes> bias = nullptr;
            shared_ptr<graph::TensorAttributes> biasOutput = nullptr;

            if(fusionMode != FusionMode::CONV_DTS)
            {
                cout << "execute bias operator" << endl;
                graph::PointwiseAttributes addBiasAttributes;
                addBiasAttributes.set_name("bias_node");
                addBiasAttributes.set_mode(PointwiseMode_t::ADD);

                bias = make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                .set_name("bias_tensor")
                                                                .set_dim({1, k, 1, 1})
                                                                .set_stride({k, 1, k, k}));
                biasOutput = graph->pointwise(convOutput, bias, addBiasAttributes);
            }
            else
            {
                biasOutput = convOutput;
            }

            // 对于 CONV_BIAS_ADD_DTS 模式，在 bias 之后、DTS 之前添加 Add 操作
            shared_ptr<graph::TensorAttributes> preDTSAdd = nullptr;
            shared_ptr<graph::TensorAttributes> dtsInput = biasOutput;

            if(fusionMode == FusionMode::CONV_BIAS_ADD_DTS)
            {
                cout << "execute add operator before DTS" << endl;
                auto addTensor = make_shared<graph::TensorAttributes>(
                    graph::Tensor_attributes()
                        .set_name("pre_dts_add_tensor")
                        .set_dim({n, k, outH, outW})
                        .set_stride({k * outH * outW, 1, k * outW, k}));

                auto addAttributes = graph::PointwiseAttributes()
                                         .set_name("pre_dts_add_node")
                                         .set_mode(PointwiseMode_t::ADD);
                dtsInput = graph->pointwise(biasOutput, addTensor, addAttributes);
                preDTSAdd = addTensor;
                cout << "Add operator before DTS created successfully" << endl;
            }

            // DepthToSpace转换开始
            cout << "Starting DepthToSpace transformation..." << endl;

            // create first reshape (将DTS输入reshape为6D)
            auto firstReshapeAttributes = graph::ReshapeAttributes().set_name("first_reshape_node");
            auto firstReshapeOutput = graph->reshape(dtsInput, firstReshapeAttributes);

            // 根据转换模式设置reshape后的维度
            if(trans_mode == "CRD")
            {
                firstReshapeOutput->set_dim({n, k / (bs * bs), bs, bs, outH, outW});
            }
            else // DCR
            {
                firstReshapeOutput->set_dim({n, bs, bs, k / (bs * bs), outH, outW});
            }
            cout << "execute first reshape operator" << endl;

            // create transform (transpose)
            vector<int64_t> trans_dims_order;
            if(trans_mode == "CRD")
            {
                trans_dims_order
                    = {0,
                       1,
                       4,
                       2,
                       5,
                       3}; // CRD: (n, c', bs, bs, outH, outW) -> (n, c', outH, bs, outW, bs)
            }
            else
            {
                trans_dims_order
                    = {0,
                       3,
                       4,
                       1,
                       5,
                       2}; // DCR: (n, bs, bs, c', outH, outW) -> (n, c', outH, bs, outW, bs)
            }
            auto transformAttributes = graph::TransposeAttributes()
                                           .set_name("transform_node")
                                           .set_permutation(trans_dims_order);
            auto transformOutput = graph->transpose(firstReshapeOutput, transformAttributes);
            cout << "execute transform operator" << endl;

            // create second reshape (将6D reshape回4D)
            auto secondReshapeAttributes
                = graph::ReshapeAttributes().set_name("second_reshape_node");
            auto secondReshapeOutput = graph->reshape(transformOutput, secondReshapeAttributes);
            secondReshapeOutput->set_dim({n, k / (bs * bs), outH * bs, outW * bs})
                .set_stride({k * outH * outW, 1, k / bs * outW, k / (bs * bs)});
            cout << "execute second reshape operator" << endl;

            // 根据融合模式添加DTS之后的操作
            shared_ptr<graph::TensorAttributes> output;
            shared_ptr<graph::TensorAttributes> postDTSAdd = nullptr;

            switch(fusionMode)
            {
            case FusionMode::CONV_DTS:
            case FusionMode::CONV_BIAS_DTS:
            case FusionMode::CONV_BIAS_ADD_DTS: // Add已经在DTS之前处理，DTS之后直接输出
                output = secondReshapeOutput;
                break;

            case FusionMode::CONV_BIAS_DTS_ADD:
            {
                cout << "execute add operator after DTS" << endl;
                graph::PointwiseAttributes addAttributes;
                addAttributes.set_name("add_node");
                addAttributes.set_mode(PointwiseMode_t::ADD);

                postDTSAdd = make_shared<graph::TensorAttributes>(
                    graph::Tensor_attributes()
                        .set_name("post_dts_add_tensor")
                        .set_dim({n, k / (bs * bs), outH * bs, outW * bs})
                        .set_stride({k * outH * outW, 1, k / bs * outW, k / (bs * bs)}));
                output = graph->pointwise(secondReshapeOutput, postDTSAdd, addAttributes);
                output->set_output(true);
            }
            break;

            case FusionMode::CONV_BIAS_DTS_RELU:
            {
                cout << "execute relu operator after DTS" << endl;
                graph::PointwiseAttributes reluAttributes;
                reluAttributes.set_name("relu_node");
                reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
                output = graph->pointwise(secondReshapeOutput, reluAttributes);
                output->set_output(true);
            }
            break;

            case FusionMode::CONV_BIAS_DTS_LEAKYRELU:
            {
                cout << "execute leakyrelu operator after DTS (alpha=" << config_.reluAlpha << ")"
                     << endl;
                graph::PointwiseAttributes reluAttributes;
                reluAttributes.set_name("leakyrelu_node");
                reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
                reluAttributes.set_relu_lower_clip_slope(config_.reluAlpha);
                output = graph->pointwise(secondReshapeOutput, reluAttributes);
                output->set_output(true);
            }
            break;

            case FusionMode::CONV_BIAS_DTS_CLIPPEDRELU:
            {
                cout << "execute clippedrelu operator after DTS (clip=" << config_.reluAlpha << ")"
                     << endl;
                graph::PointwiseAttributes reluAttributes;
                reluAttributes.set_name("clippedrelu_node");
                reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
                reluAttributes.set_relu_upper_clip(config_.reluAlpha);
                output = graph->pointwise(secondReshapeOutput, reluAttributes);
                output->set_output(true);
            }
            break;

            case FusionMode::CONV_BIAS_DTS_RELU_ADD:
            {
                cout << "execute relu+add operators after DTS" << endl;
                graph::PointwiseAttributes reluAttributes;
                reluAttributes.set_name("relu_node");
                reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
                auto reluOutput = graph->pointwise(secondReshapeOutput, reluAttributes);

                graph::PointwiseAttributes addAttributes;
                addAttributes.set_name("add_node");
                addAttributes.set_mode(PointwiseMode_t::ADD);

                postDTSAdd = make_shared<graph::TensorAttributes>(
                    graph::Tensor_attributes()
                        .set_name("post_dts_add_tensor")
                        .set_dim({n, k / (bs * bs), outH * bs, outW * bs})
                        .set_stride({k * outH * outW, 1, k / bs * outW, k / (bs * bs)}));
                output = graph->pointwise(reluOutput, postDTSAdd, addAttributes);
                output->set_output(true);
            }
            break;

            case FusionMode::CONV_BIAS_DTS_LEAKYRELU_ADD:
            {
                cout << "execute leakyrelu+add operators after DTS" << endl;
                graph::PointwiseAttributes reluAttributes;
                reluAttributes.set_name("leakyrelu_node");
                reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
                reluAttributes.set_relu_lower_clip_slope(config_.reluAlpha);
                auto leakyReluOutput = graph->pointwise(secondReshapeOutput, reluAttributes);

                graph::PointwiseAttributes addAttributes;
                addAttributes.set_name("add_node");
                addAttributes.set_mode(PointwiseMode_t::ADD);

                postDTSAdd = make_shared<graph::TensorAttributes>(
                    graph::Tensor_attributes()
                        .set_name("post_dts_add_tensor")
                        .set_dim({n, k / (bs * bs), outH * bs, outW * bs})
                        .set_stride({k * outH * outW, 1, k / bs * outW, k / (bs * bs)}));
                output = graph->pointwise(leakyReluOutput, postDTSAdd, addAttributes);
                output->set_output(true);
            }
            break;

            case FusionMode::CONV_BIAS_DTS_CLIPPEDRELU_ADD:
            {
                cout << "execute clippedrelu+add operators after DTS" << endl;
                graph::PointwiseAttributes reluAttributes;
                reluAttributes.set_name("clippedrelu_node");
                reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
                reluAttributes.set_relu_upper_clip(config_.reluAlpha);
                auto clippedReluOutput = graph->pointwise(secondReshapeOutput, reluAttributes);

                graph::PointwiseAttributes addAttributes;
                addAttributes.set_name("add_node");
                addAttributes.set_mode(PointwiseMode_t::ADD);

                postDTSAdd = make_shared<graph::TensorAttributes>(
                    graph::Tensor_attributes()
                        .set_name("post_dts_add_tensor")
                        .set_dim({n, k / (bs * bs), outH * bs, outW * bs})
                        .set_stride({k * outH * outW, 1, k / bs * outW, k / (bs * bs)}));
                output = graph->pointwise(clippedReluOutput, postDTSAdd, addAttributes);
                output->set_output(true);
            }
            break;

            default:
                cerr << "Unsupported fusion mode" << endl;
                exit(1);
            }

            output->set_output(true);

            // build graph
            cout << "Building graph..." << endl;
            HIPDNN_FE_CHECK(graph->build(handle_));

            // Allocate DCU memory
            cout << "Allocating memory..." << endl;
            Tensor<InputType> inputTensor(input->get_dim(), input->get_stride());
            Tensor<InputType> wTensor(filter->get_dim(), filter->get_stride());
            Tensor<InputType> yTensor(output->get_dim(), output->get_stride());

            // 为bias操作申请空间
            unique_ptr<Tensor<InputType>> biasTensorPtr = nullptr;
            if(fusionMode != FusionMode::CONV_DTS && bias)
            {
                biasTensorPtr = make_unique<Tensor<InputType>>(bias->get_dim(), bias->get_stride());
                cout << "Allocated bias tensor" << endl;
            }

            // 为preDTSAdd分配内存
            unique_ptr<Tensor<InputType>> preDTSAddTensorPtr = nullptr;
            if(fusionMode == FusionMode::CONV_BIAS_ADD_DTS && preDTSAdd)
            {
                preDTSAddTensorPtr
                    = make_unique<Tensor<InputType>>(preDTSAdd->get_dim(), preDTSAdd->get_stride());
                cout << "Allocated pre-DTS add tensor" << endl;
            }

            // 为postDTSAdd分配内存
            unique_ptr<Tensor<InputType>> postDTSAddTensorPtr = nullptr;
            if((fusionMode == FusionMode::CONV_BIAS_DTS_ADD
                || fusionMode == FusionMode::CONV_BIAS_DTS_RELU_ADD
                || fusionMode == FusionMode::CONV_BIAS_DTS_LEAKYRELU_ADD
                || fusionMode == FusionMode::CONV_BIAS_DTS_CLIPPEDRELU_ADD)
               && postDTSAdd)
            {
                postDTSAddTensorPtr = make_unique<Tensor<InputType>>(postDTSAdd->get_dim(),
                                                                     postDTSAdd->get_stride());
                cout << "Allocated post-DTS add tensor" << endl;
            }

            // 设置variant pack
            unordered_map<int64_t, void*> variantPack;
            variantPack[input->get_uid()] = inputTensor.memory().deviceData();
            variantPack[filter->get_uid()] = wTensor.memory().deviceData();
            variantPack[output->get_uid()] = yTensor.memory().deviceData();

            if(biasTensorPtr)
            {
                variantPack[bias->get_uid()] = biasTensorPtr->memory().deviceData();
            }
            if(preDTSAddTensorPtr)
            {
                variantPack[preDTSAdd->get_uid()] = preDTSAddTensorPtr->memory().deviceData();
            }
            if(postDTSAddTensorPtr)
            {
                variantPack[postDTSAdd->get_uid()] = postDTSAddTensorPtr->memory().deviceData();
            }

            // 获取并分配workspace
            int64_t workspaceSize = 0;
            HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
            cout << "Workspace size: " << workspaceSize << " bytes" << endl;
            Workspace workspace(static_cast<size_t>(workspaceSize));

            // 执行graph
            cout << "Executing graph..." << endl;
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

            // 计时执行
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
            {
                HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
            }
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            std::cout << "conv dts avg times: " << time / 100 << " ms" << std::endl;
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));

            cout << "Convolution_depth_to_space graph executed successfully!" << endl;

            return 0;
        };

        // 调用上面创建的graph
        buildAndExecute();
    }
};

void run(hipdnnHandle_t handle, Config& config)
{
    if(config.dataType == "fp32")
    {
        ConvDepthToSpaceRunner runner(handle, config);
        runner.template operator()<float, float>();
    }
    else if(config.dataType == "fp16")
    {
        ConvDepthToSpaceRunner runner(handle, config);
        runner.template operator()<half, float>();
    }
    else if(config.dataType == "bfp16")
    {
        ConvDepthToSpaceRunner runner(handle, config);
        runner.template operator()<bfloat16, float>();
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    // 打印命令行参数
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));

    try
    {
        run(handle, config);
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error: " << e.what() << std::endl;
        HIPDNN_CHECK(hipdnnDestroy(handle));
        return 1;
    }

    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
