#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceConvolution.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>

#include "../utils.hpp"
using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

struct Config
{
    int64_t n = 1; // batch size
    int64_t c = 16; // 输入通道数
    int64_t d = 16; // 输入深度
    int64_t h = 16; // 输入高度
    int64_t w = 16; // 输入宽度
    int64_t k = 16; // 输出通道数
    int64_t t = 3; // 卷积核深度
    int64_t r = 3; // 卷积核高度
    int64_t s = 3; // 卷积核宽度
    int64_t padD = 1; // 深度方向对称padding
    int64_t padH = 1; // 高度方向对称padding
    int64_t padW = 1; // 宽度方向对称padding

    // 新增：非对称前后独立padding
    int64_t prePadD = 1;
    int64_t postPadD = 1;
    int64_t prePadH = 1;
    int64_t postPadH = 1;
    int64_t prePadW = 1;
    int64_t postPadW = 1;

    int64_t strideD = 1; // 深度方向步长
    int64_t strideH = 1; // 高度方向步长
    int64_t strideW = 1; // 宽度方向步长
    int64_t dilD = 1; // 深度方向dilation
    int64_t dilH = 1; // 高度方向dilation
    int64_t dilW = 1; // 宽度方向dilation
    int64_t groups = 1; // 组数
    std::string dataType = "fp32";
    std::string layout = "NCHW";
    int convType = 1; // 卷积类型: fprop=1, dgrad=2, wgrad=4
    bool cpuValidation = false;
    int fileIndex = 0;
    std::string filePath = ".";
    int dimension = 2; // 卷积维度: 2D=2, 3D=3
};

Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--in_d") == 0 && i + 1 < argc)
        {
            config.d = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-k") == 0 && i + 1 < argc)
        {
            config.k = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--fil_d") == 0 && i + 1 < argc)
        {
            config.t = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-y") == 0 && i + 1 < argc)
        {
            config.r = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-x") == 0 && i + 1 < argc)
        {
            config.s = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--pad_d") == 0 && i + 1 < argc)
        {
            config.padD = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-p") == 0 && i + 1 < argc)
        {
            config.padH = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc)
        {
            config.padW = std::stoll(argv[++i]);
        }
        // 新增非对称padding命令行参数
        else if(strcmp(argv[i], "--pre_pad-d") == 0 && i + 1 < argc)
        {
            config.prePadD = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--post_pad-d") == 0 && i + 1 < argc)
        {
            config.postPadD = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--pre-pad-h") == 0 && i + 1 < argc)
        {
            config.prePadH = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--post-pad-h") == 0 && i + 1 < argc)
        {
            config.postPadH = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--pre-pad-w") == 0 && i + 1 < argc)
        {
            config.prePadW = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--post-pad-w") == 0 && i + 1 < argc)
        {
            config.postPadW = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--conv_stride_d") == 0 && i + 1 < argc)
        {
            config.strideD = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-u") == 0 && i + 1 < argc)
        {
            config.strideH = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-v") == 0 && i + 1 < argc)
        {
            config.strideW = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--dilation_d") == 0 && i + 1 < argc)
        {
            config.dilD = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-l") == 0 && i + 1 < argc)
        {
            config.dilH = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-j") == 0 && i + 1 < argc)
        {
            config.dilW = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-g") == 0 && i + 1 < argc)
        {
            config.groups = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else if(strcmp(argv[i], "-F") == 0 && i + 1 < argc)
        {
            int type = std::stoi(argv[++i]);
            if(type != 1 && type != 2 && type != 4)
            {
                std::cerr << "Invalid convolution type: " << type << std::endl;
                std::cerr << "Supported types: 1(fprop), 2(dgrad), 4(wgrad)" << std::endl;
                exit(1);
            }
            config.convType = type;
        }
        else if(strcmp(argv[i], "--spatial_dim") == 0 && i + 1 < argc)
        {
            config.dimension = std::stoi(argv[++i]);
            if(config.dimension != 2 && config.dimension != 3)
            {
                std::cerr << "Invalid dimension: " << config.dimension << std::endl;
                std::cerr << "Supported dimensions: 2(2D), 3(3D)" << std::endl;
                exit(1);
            }
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            std::cerr
                << "-n <batch> -c <channels> --in_d <depth/height> -H <height> -W <width> "
                << "-k <filters> --fil_d <filter_depth/height> -y <filter_h> -x <filter_w> "
                << "--pad_d <pad_depth/height> -p <pad_h> -q <pad_w> "
                << "--pre_pad_d / --post_pad_d / --pre_pad_h / --post_pad_h / --pre_pad_w / "
                   "--post_pad_w "
                << "--conv_stride_d <stride_d/height> -u <stride_h> -v <stride_w> "
                << "--dilation_d <dil_d/height> -l <dil_h> -j <dil_w> -g <groups> "
                << "-d <data_type> -L <layout> -i <file_index> -F <1/2/4> --spatial_dim <2/3> "
                << "[--cpu-validation] -path <path>\n";
            exit(1);
        }
    }

    return config;
}

class ConvRunner
{
public:
    ConvRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType, typename IntermediateType>
    void fprop(const TensorLayout& layout)
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        using OutputType
            = std::conditional_t<std::is_same_v<InputType, int8_t>, int32_t, InputType>;
        const auto outputType = getDataTypeEnumFromType<OutputType>();

        const int64_t n = config_.n;
        const int64_t c = config_.c;
        const int64_t d = config_.d;
        const int64_t h = config_.h;
        const int64_t w = config_.w;
        const int64_t k = config_.k;
        const int64_t t = config_.t;
        const int64_t r = config_.r;
        const int64_t s = config_.s;
        const int64_t groups = config_.groups;

        std::vector<int64_t> stride, dilation;
        if(config_.dimension == 2)
        {
            stride = {config_.strideH, config_.strideW};
            dilation = {config_.dilH, config_.dilW};
        }
        else
        {
            stride = {config_.strideD, config_.strideH, config_.strideW};
            dilation = {config_.dilD, config_.dilH, config_.dilW};
        }

        // 新增：判断是否使用非对称padding
        bool useAsymPad = false;
        std::vector<int64_t> prePadding, postPadding, symPadding;
        if(config_.dimension == 2)
        {
            prePadding = {config_.prePadH, config_.prePadW};
            postPadding = {config_.postPadH, config_.postPadW};
            symPadding = {config_.padH, config_.padW};
            if(config_.prePadH != config_.postPadH || config_.prePadW != config_.postPadW)
                useAsymPad = true;
        }
        else
        {
            prePadding = {config_.prePadD, config_.prePadH, config_.prePadW};
            postPadding = {config_.postPadD, config_.postPadH, config_.postPadW};
            symPadding = {config_.padD, config_.padH, config_.padW};
            if(config_.prePadD != config_.postPadD || config_.prePadH != config_.postPadH
               || config_.prePadW != config_.postPadW)
                useAsymPad = true;
        }

        // 计算输出维度：非对称用pre+post总和，对称用2*pad
        int64_t od, oh, ow;
        if(config_.dimension == 2)
        {
            int64_t totalH = useAsymPad ? (config_.prePadH + config_.postPadH) : 2 * config_.padH;
            int64_t totalW = useAsymPad ? (config_.prePadW + config_.postPadW) : 2 * config_.padW;
            oh = (h + totalH - dilation[0] * (r - 1) - 1) / config_.strideH + 1;
            ow = (w + totalW - dilation[1] * (s - 1) - 1) / config_.strideW + 1;
            od = 1;
        }
        else
        {
            int64_t totalD = useAsymPad ? (config_.prePadD + config_.postPadD) : 2 * config_.padD;
            int64_t totalH = useAsymPad ? (config_.prePadH + config_.postPadH) : 2 * config_.padH;
            int64_t totalW = useAsymPad ? (config_.prePadW + config_.postPadW) : 2 * config_.padW;
            od = (d + totalD - dilation[0] * (t - 1) - 1) / config_.strideD + 1;
            oh = (h + totalH - dilation[1] * (r - 1) - 1) / config_.strideH + 1;
            ow = (w + totalW - dilation[2] * (s - 1) - 1) / config_.strideW + 1;
        }

        size_t xTotalElems, wTotalElems, yTotalElems;
        if(config_.dimension == 2)
        {
            xTotalElems = static_cast<size_t>(n * c * h * w);
            wTotalElems = static_cast<size_t>(k * (c / groups) * s * r);
            yTotalElems = static_cast<size_t>(n * k * oh * ow);
        }
        else
        {
            xTotalElems = static_cast<size_t>(n * c * d * h * w);
            wTotalElems = static_cast<size_t>(k * (c / groups) * t * r * s);
            yTotalElems = static_cast<size_t>(n * k * od * oh * ow);
        }

        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_compute_data_type(DataType::FLOAT)
            .set_intermediate_data_type(intermediateType);

        std::shared_ptr<graph::TensorAttributes> xAttr, wAttr;
        if(config_.dimension == 2)
        {
            xAttr = createTensor({n, c, h, w}, inputType, layout.strideOrder);
            wAttr = createTensor({k, c / groups, r, s}, inputType, layout.strideOrder);
        }
        else
        {
            xAttr = createTensor({n, c, d, h, w}, inputType, layout.strideOrder);
            wAttr = createTensor({k, c / groups, t, r, s}, inputType, layout.strideOrder);
        }

        graph::ConvFpropAttributes convAttributes;
        convAttributes.set_name(config_.dimension == 2 ? "conv2d_fprop_node" : "conv3d_fprop_node");
        convAttributes.set_stride(stride);
        convAttributes.set_dilation(dilation);

        // 新增分支：非对称设置pre/post padding，对称保留原有set_padding
        if(useAsymPad)
        {
            convAttributes.set_pre_padding(prePadding);
            convAttributes.set_post_padding(postPadding);
        }
        else
        {
            convAttributes.set_padding(symPadding);
        }

        auto yAttr = graph->conv_fprop(xAttr, wAttr, convAttributes);
        yAttr->set_output(true).set_data_type(outputType);

        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful (fprop).\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful (fprop).\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully (fprop).\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful (fprop).\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful (fprop).\n";

        Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
        Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
        Tensor<OutputType> yTensor(yAttr->get_dim(), yAttr->get_stride());

        yTensor.fillWithValue(
            static_cast<OutputType>(std::is_floating_point_v<OutputType> ? 0.0f : 0));

        bool readSuccess = false;
        std::vector<InputType> refXData, refWData;
        std::vector<OutputType> refYData;
        Tensor<OutputType> refYTensor(yAttr->get_dim(), yAttr->get_stride());

        if(config_.fileIndex > 0)
        {
            const std::string xFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_input.bin";
            const std::string wFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_weight.bin";
            const std::string yFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_output.bin";

            readSuccess = readRawTensor<InputType>(xFilename, refXData, xTotalElems)
                          && readRawTensor<InputType>(wFilename, refWData, wTotalElems)
                          && readRawTensor<OutputType>(yFilename, refYData, yTotalElems);

            if(readSuccess)
            {
                std::cout << "Successfully read fprop reference files.\n";
                std::copy(refXData.begin(), refXData.end(), xTensor.memory().hostData());
                xTensor.memory().markHostModified();
                std::copy(refWData.begin(), refWData.end(), wTensor.memory().hostData());
                wTensor.memory().markHostModified();
                std::copy(refYData.begin(), refYData.end(), refYTensor.memory().hostData());
                refYTensor.memory().markHostModified();
            }
            else
            {
                std::cerr << "[WARN] Failed to read fprop reference files. Using random values.\n";
                fillTensorWithRandomValues(xTensor, wTensor);
            }
        }
        else
        {
            fillTensorWithRandomValues(xTensor, wTensor);
        }

        std::unordered_map<int64_t, void*> variantPack;
        variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
        variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
        variantPack[yAttr->get_uid()] = yTensor.memory().deviceData();

        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        yTensor.memory().markDeviceModified();

        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "fprop avg times: " << time / 100 << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        if(config_.fileIndex > 0 && readSuccess)
        {
            bool isMatch = false;

            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                const OutputType* refData = refYTensor.memory().hostData();
                const OutputType* currData = yTensor.memory().hostData();
                isMatch = true;

                const size_t printCount = std::min(yTotalElems, static_cast<size_t>(10));
                std::cout << "前" << printCount << "个元素对比：" << std::endl;
                std::cout << "(refData): ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<int>(refData[i]) << " ";
                }
                std::cout << std::endl;

                std::cout << "(currData): ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<int>(static_cast<int8_t>(currData[i])) << " ";
                }
                std::cout << std::endl;

                for(size_t i = 0; i < yTotalElems; ++i)
                {
                    if(currData[i] != refData[i])
                    {
                        std::cout << "不匹配！索引 " << i
                                  << ": ref(int8)=" << static_cast<int>(refData[i])
                                  << ", curr(原始)=" << static_cast<int>(currData[i]) << std::endl;
                        break;
                    }
                }
            }
            else
            {
                float tolerance = getTolerance<InputType>();
                CpuFpReferenceValidation<InputType> fileValidator(tolerance, tolerance);
                isMatch = fileValidator.allClose(refYTensor, yTensor);
            }
            std::cout << "cuDNN validation result: " << (isMatch ? "successful" : "failed") << "\n";
        }

        if(config_.cpuValidation)
        {
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                std::cout << "CPU validation is not supported for int8 input type.\n";
            }
            else
            {
                if(!useAsymPad)
                {
                    prePadding = symPadding;
                    postPadding = symPadding;
                }
                if(config_.dimension == 2)
                {
                    CpuFpReferenceConvolution::fprop<InputType, InputType, InputType, float>(
                        xTensor, wTensor, refYTensor, stride, dilation, prePadding, postPadding);
                }
                else
                {
                    CpuFpReferenceConvolution::fprop<InputType, InputType, InputType, float>(
                        xTensor, wTensor, refYTensor, stride, dilation, prePadding, postPadding);
                }

                float tolerance = getTolerance<InputType>();
                CpuFpReferenceValidation<InputType> yValidator(tolerance, tolerance);
                bool yValid = yValidator.allClose(refYTensor, yTensor);
                std::cout << "CPU validation result: " << (yValid ? "successful" : "failed")
                          << "\n";
            }
        }
    }

    template <typename InputType, typename IntermediateType>
    void dgrad(const TensorLayout& layout)
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        const int64_t n = config_.n;
        const int64_t c = config_.c;
        const int64_t d = config_.d;
        const int64_t h = config_.h;
        const int64_t w = config_.w;
        const int64_t k = config_.k;
        const int64_t t = config_.t;
        const int64_t r = config_.r;
        const int64_t s = config_.s;
        const int64_t g = config_.groups;

        std::vector<int64_t> stride, dilation;
        if(config_.dimension == 2)
        {
            stride = {config_.strideH, config_.strideW};
            dilation = {config_.dilH, config_.dilW};
        }
        else
        {
            stride = {config_.strideD, config_.strideH, config_.strideW};
            dilation = {config_.dilD, config_.dilH, config_.dilW};
        }

        bool useAsymPad = false;
        std::vector<int64_t> prePadding, postPadding, symPadding;
        if(config_.dimension == 2)
        {
            prePadding = {config_.prePadH, config_.prePadW};
            postPadding = {config_.postPadH, config_.postPadW};
            symPadding = {config_.padH, config_.padW};
            if(config_.prePadH != config_.postPadH || config_.prePadW != config_.postPadW)
                useAsymPad = true;
        }
        else
        {
            prePadding = {config_.prePadD, config_.prePadH, config_.prePadW};
            postPadding = {config_.postPadD, config_.postPadH, config_.postPadW};
            symPadding = {config_.padD, config_.padH, config_.padW};
            if(config_.prePadD != config_.postPadD || config_.prePadH != config_.postPadH
               || config_.prePadW != config_.postPadW)
                useAsymPad = true;
        }

        int64_t od, oh, ow;
        if(config_.dimension == 2)
        {
            int64_t totalH = useAsymPad ? (config_.prePadH + config_.postPadH) : 2 * config_.padH;
            int64_t totalW = useAsymPad ? (config_.prePadW + config_.postPadW) : 2 * config_.padW;
            oh = (h + totalH - dilation[0] * (r - 1) - 1) / config_.strideH + 1;
            ow = (w + totalW - dilation[1] * (s - 1) - 1) / config_.strideW + 1;
            od = 1;
        }
        else
        {
            int64_t totalD = useAsymPad ? (config_.prePadD + config_.postPadD) : 2 * config_.padD;
            int64_t totalH = useAsymPad ? (config_.prePadH + config_.postPadH) : 2 * config_.padH;
            int64_t totalW = useAsymPad ? (config_.prePadW + config_.postPadW) : 2 * config_.padW;
            od = (d + totalD - dilation[0] * (t - 1) - 1) / config_.strideD + 1;
            oh = (h + totalH - dilation[1] * (r - 1) - 1) / config_.strideH + 1;
            ow = (w + totalW - dilation[2] * (s - 1) - 1) / config_.strideW + 1;
        }

        size_t wTotalElems, dyTotalElems, dxTotalElems;
        if(config_.dimension == 2)
        {
            wTotalElems = static_cast<size_t>(k * (c / g) * s * r);
            dyTotalElems = static_cast<size_t>(n * k * oh * ow);
            dxTotalElems = static_cast<size_t>(n * c * h * w);
        }
        else
        {
            wTotalElems = static_cast<size_t>(k * (c / g) * t * r * s);
            dyTotalElems = static_cast<size_t>(n * k * od * oh * ow);
            dxTotalElems = static_cast<size_t>(n * c * d * h * w);
        }

        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_compute_data_type(DataType::FLOAT)
            .set_intermediate_data_type(intermediateType);

        std::shared_ptr<graph::TensorAttributes> wAttr, dyAttr;
        if(config_.dimension == 2)
        {
            wAttr = createTensor({k, c / g, r, s}, inputType, layout.strideOrder);
            dyAttr = createTensor({n, k, oh, ow}, inputType, layout.strideOrder);
        }
        else
        {
            wAttr = createTensor({k, c / g, t, r, s}, inputType, layout.strideOrder);
            dyAttr = createTensor({n, k, od, oh, ow}, inputType, layout.strideOrder);
        }

        graph::ConvDgradAttributes convAttributes;
        convAttributes.set_name(config_.dimension == 2 ? "conv2d_dgrad_node" : "conv3d_dgrad_node");
        convAttributes.set_stride(stride);
        convAttributes.set_dilation(dilation);
        convAttributes.set_convolution_mode(ConvolutionMode::CROSS_CORRELATION);

        if(useAsymPad)
        {
            convAttributes.set_pre_padding(prePadding);
            convAttributes.set_post_padding(postPadding);
        }
        else
        {
            convAttributes.set_padding(symPadding);
        }

        auto dxAttr = graph->conv_dgrad(dyAttr, wAttr, convAttributes);
        if(config_.dimension == 2)
        {
            dxAttr->set_output(true).set_dim({n, c, h, w});
        }
        else
        {
            dxAttr->set_output(true).set_dim({n, c, d, h, w});
        }

        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful (dgrad).\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful (dgrad).\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully (dgrad).\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful (dgrad).\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful (dgrad).\n";

        Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
        Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
        Tensor<InputType> dxTensor(dxAttr->get_dim(), dxAttr->get_stride());
        dxTensor.fillWithValue(static_cast<InputType>(0.0f));

        bool readSuccess = false;
        std::vector<InputType> refWData, refDyData, refDxData;
        Tensor<InputType> refDxTensor(dxAttr->get_dim(), dxAttr->get_stride());

        if(config_.fileIndex > 0)
        {
            const std::string wFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_weight.bin";
            const std::string dyFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_output.bin";
            const std::string dxFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_input.bin";

            readSuccess = readRawTensor<InputType>(wFilename, refWData, wTotalElems)
                          && readRawTensor<InputType>(dyFilename, refDyData, dyTotalElems)
                          && readRawTensor<InputType>(dxFilename, refDxData, dxTotalElems);

            if(readSuccess)
            {
                std::cout << "Successfully read dgrad reference files.\n";
                std::copy(refWData.begin(), refWData.end(), wTensor.memory().hostData());
                wTensor.memory().markHostModified();
                std::copy(refDyData.begin(), refDyData.end(), dyTensor.memory().hostData());
                dyTensor.memory().markHostModified();
                std::copy(refDxData.begin(), refDxData.end(), refDxTensor.memory().hostData());
                refDxTensor.memory().markHostModified();
            }
            else
            {
                std::cerr << "[WARN] Failed to read dgrad reference files. Using random values.\n";
                fillTensorWithRandomValues(wTensor, dyTensor);
            }
        }
        else
        {
            fillTensorWithRandomValues(wTensor, dyTensor);
        }

        std::unordered_map<int64_t, void*> variantPack;
        variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
        variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
        variantPack[dxAttr->get_uid()] = dxTensor.memory().deviceData();

        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        dxTensor.memory().markDeviceModified();
        const InputType* currDxData = dxTensor.memory().hostData();

        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "dgrad avg times: " << time / 100 << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        std::cout << "dgrad first 10 values: ";
        for(int i = 0; i < 10; ++i)
        {
            std::cout << static_cast<float>(currDxData[i]) << " ";
        }
        std::cout << '\n';

        if(config_.fileIndex > 0 && readSuccess)
        {
            float tolerance = getTolerance<InputType>();
            CpuFpReferenceValidation<InputType> fileValidator(tolerance, tolerance);
            bool isMatch = fileValidator.allClose(refDxTensor, dxTensor);
            std::cout << "cuDNN validation result: " << (isMatch ? "successful" : "failed") << "\n";
        }

        if(config_.cpuValidation)
        {
            if(!useAsymPad)
            {
                prePadding = symPadding;
                postPadding = symPadding;
            }
            if(config_.dimension == 2)
            {
                CpuFpReferenceConvolution::dgrad<InputType, InputType, InputType, float>(
                    refDxTensor, wTensor, dyTensor, stride, dilation, prePadding, postPadding);
            }
            else
            {
                CpuFpReferenceConvolution::dgrad<InputType, InputType, InputType, float>(
                    refDxTensor, wTensor, dyTensor, stride, dilation, prePadding, postPadding);
            }

            float tolerance = getTolerance<InputType>();
            CpuFpReferenceValidation<InputType> dxValidator(tolerance, tolerance);
            bool dxValid = dxValidator.allClose(refDxTensor, dxTensor);
            std::cout << "CPU validation result: " << (dxValid ? "successful" : "failed") << "\n";
        }
    }

    template <typename InputType, typename IntermediateType>
    void wgrad(const TensorLayout& layout)
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        const int64_t n = config_.n;
        const int64_t c = config_.c;
        const int64_t d = config_.d;
        const int64_t h = config_.h;
        const int64_t w = config_.w;
        const int64_t k = config_.k;
        const int64_t t = config_.t;
        const int64_t r = config_.r;
        const int64_t s = config_.s;
        const int64_t g = config_.groups;

        std::vector<int64_t> stride, dilation;
        if(config_.dimension == 2)
        {
            stride = {config_.strideH, config_.strideW};
            dilation = {config_.dilH, config_.dilW};
        }
        else
        {
            stride = {config_.strideD, config_.strideH, config_.strideW};
            dilation = {config_.dilD, config_.dilH, config_.dilW};
        }

        bool useAsymPad = false;
        std::vector<int64_t> prePadding, postPadding, symPadding;
        if(config_.dimension == 2)
        {
            prePadding = {config_.prePadH, config_.prePadW};
            postPadding = {config_.postPadH, config_.postPadW};
            symPadding = {config_.padH, config_.padW};
            if(config_.prePadH != config_.postPadH || config_.prePadW != config_.postPadW)
                useAsymPad = true;
        }
        else
        {
            prePadding = {config_.prePadD, config_.prePadH, config_.prePadW};
            postPadding = {config_.postPadD, config_.postPadH, config_.postPadW};
            symPadding = {config_.padD, config_.padH, config_.padW};
            if(config_.prePadD != config_.postPadD || config_.prePadH != config_.postPadH
               || config_.prePadW != config_.postPadW)
                useAsymPad = true;
        }

        int64_t od, oh, ow;
        if(config_.dimension == 2)
        {
            int64_t totalH = useAsymPad ? (config_.prePadH + config_.postPadH) : 2 * config_.padH;
            int64_t totalW = useAsymPad ? (config_.prePadW + config_.postPadW) : 2 * config_.padW;
            oh = (h + totalH - dilation[0] * (r - 1) - 1) / config_.strideH + 1;
            ow = (w + totalW - dilation[1] * (s - 1) - 1) / config_.strideW + 1;
            od = 1;
        }
        else
        {
            int64_t totalD = useAsymPad ? (config_.prePadD + config_.postPadD) : 2 * config_.padD;
            int64_t totalH = useAsymPad ? (config_.prePadH + config_.postPadH) : 2 * config_.padH;
            int64_t totalW = useAsymPad ? (config_.prePadW + config_.postPadW) : 2 * config_.padW;
            od = (d + totalD - dilation[0] * (t - 1) - 1) / config_.strideD + 1;
            oh = (h + totalH - dilation[1] * (r - 1) - 1) / config_.strideH + 1;
            ow = (w + totalW - dilation[2] * (s - 1) - 1) / config_.strideW + 1;
        }

        size_t xTotalElems, dyTotalElems, dwTotalElems;
        if(config_.dimension == 2)
        {
            xTotalElems = static_cast<size_t>(n * c * h * w);
            dyTotalElems = static_cast<size_t>(n * k * oh * ow);
            dwTotalElems = static_cast<size_t>(k * (c / g) * s * r);
        }
        else
        {
            xTotalElems = static_cast<size_t>(n * c * d * h * w);
            dyTotalElems = static_cast<size_t>(n * k * od * oh * ow);
            dwTotalElems = static_cast<size_t>(k * (c / g) * t * r * s);
        }

        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_compute_data_type(DataType::FLOAT)
            .set_intermediate_data_type(intermediateType);

        std::shared_ptr<graph::TensorAttributes> xAttr, dyAttr;
        if(config_.dimension == 2)
        {
            xAttr = createTensor({n, c, h, w}, inputType, layout.strideOrder);
            dyAttr = createTensor({n, k, oh, ow}, inputType, layout.strideOrder);
        }
        else
        {
            xAttr = createTensor({n, c, d, h, w}, inputType, layout.strideOrder);
            dyAttr = createTensor({n, k, od, oh, ow}, inputType, layout.strideOrder);
        }

        graph::ConvWgradAttributes convAttributes;
        convAttributes.set_name(config_.dimension == 2 ? "conv2d_wgrad_node" : "conv3d_wgrad_node");
        convAttributes.set_stride(stride);
        convAttributes.set_dilation(dilation);

        if(useAsymPad)
        {
            convAttributes.set_pre_padding(prePadding);
            convAttributes.set_post_padding(postPadding);
        }
        else
        {
            convAttributes.set_padding(symPadding);
        }

        auto dwAttr = graph->conv_wgrad(dyAttr, xAttr, convAttributes);
        if(config_.dimension == 2)
        {
            dwAttr->set_output(true).set_dim({k, c / g, r, s});
        }
        else
        {
            dwAttr->set_output(true).set_dim({k, c / g, t, r, s});
        }

        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful (wgrad).\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful (wgrad).\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully (wgrad).\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful (wgrad).\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful (wgrad).\n";

        Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
        Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
        Tensor<InputType> dwTensor(dwAttr->get_dim(), dwAttr->get_stride());
        dwTensor.fillWithValue(static_cast<InputType>(0.0f));

        bool readSuccess = false;
        std::vector<InputType> refXData, refDyData, refDwData;
        Tensor<InputType> refDwTensor(dwAttr->get_dim(), dwAttr->get_stride());

        if(config_.fileIndex > 0)
        {
            const std::string xFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_input.bin";
            const std::string dyFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_output.bin";
            const std::string dwFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_weight.bin";

            readSuccess = readRawTensor<InputType>(xFilename, refXData, xTotalElems)
                          && readRawTensor<InputType>(dyFilename, refDyData, dyTotalElems)
                          && readRawTensor<InputType>(dwFilename, refDwData, dwTotalElems);

            if(readSuccess)
            {
                std::cout << "Successfully read wgrad reference files.\n";
                std::copy(refXData.begin(), refXData.end(), xTensor.memory().hostData());
                xTensor.memory().markHostModified();
                std::copy(refDyData.begin(), refDyData.end(), dyTensor.memory().hostData());
                dyTensor.memory().markHostModified();
                std::copy(refDwData.begin(), refDwData.end(), refDwTensor.memory().hostData());
                refDwTensor.memory().markHostModified();
            }
            else
            {
                std::cerr << "[WARN] Failed to read wgrad reference files. Using random values.\n";
                fillTensorWithRandomValues(xTensor, dyTensor);
            }
        }
        else
        {
            fillTensorWithRandomValues(xTensor, dyTensor);
        }

        std::unordered_map<int64_t, void*> variantPack;
        variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
        variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
        variantPack[dwAttr->get_uid()] = dwTensor.memory().deviceData();

        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        dwTensor.memory().markDeviceModified();
        const InputType* currDwData = dwTensor.memory().hostData();

        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "wgrad avg times: " << time / 100 << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        std::cout << "wgrad first 10 values: ";
        for(int i = 0; i < 10; ++i)
        {
            std::cout << static_cast<float>(currDwData[i]) << " ";
        }
        std::cout << '\n';

        if(config_.fileIndex > 0 && readSuccess)
        {
            float tolerance = getTolerance<InputType>();
            CpuFpReferenceValidation<InputType> fileValidator(tolerance, tolerance);
            bool isMatch = fileValidator.allClose(refDwTensor, dwTensor);
            std::cout << "cuDNN validation result: " << (isMatch ? "successful" : "failed") << "\n";
        }

        if(config_.cpuValidation)
        {
            if(!useAsymPad)
            {
                prePadding = symPadding;
                postPadding = symPadding;
            }
            if(config_.dimension == 2)
            {
                CpuFpReferenceConvolution::wgrad<InputType, InputType, InputType, float>(
                    xTensor, refDwTensor, dyTensor, stride, dilation, prePadding, postPadding);
            }
            else
            {
                CpuFpReferenceConvolution::wgrad<InputType, InputType, InputType, float>(
                    xTensor, refDwTensor, dyTensor, stride, dilation, prePadding, postPadding);
            }

            float tolerance = getTolerance<InputType>();
            CpuFpReferenceValidation<InputType> dwValidator(tolerance, tolerance);
            bool dwValid = dwValidator.allClose(refDwTensor, dwTensor);
            std::cout << "CPU validation result: " << (dwValid ? "successful" : "failed") << "\n";
        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    template <typename T>
    float getTolerance()
    {
        if constexpr(std::is_same_v<T, int8_t>)
        {
            return 0.0f;
        }
        if(config_.dataType == "tf32")
        {
            return static_cast<float>(1e-2f);
        }
        else
        {
            if(config_.convType == 1)
            {
                return conv::getToleranceFwd<T>();
            }
            else if(config_.convType == 2)
            {
                return conv::getToleranceBwd<T>();
            }
            else if(config_.convType == 4)
            {
                return conv::getToleranceWrw<T>();
            }
        }
        return 1e-5f;
    }

    template <typename InputType>
    void fillTensorWithRandomValues(Tensor<InputType>& tensor1, Tensor<InputType>& tensor2)
    {
        if constexpr(std::is_same_v<InputType, int8_t>)
        {
            tensor1.fillWithRandomValues(static_cast<InputType>(-127), static_cast<InputType>(127));
            tensor2.fillWithRandomValues(static_cast<InputType>(-127), static_cast<InputType>(127));
        }
        else
        {
            tensor1.fillWithRandomValues(static_cast<InputType>(0.0f),
                                         static_cast<InputType>(1.0f));
            tensor2.fillWithRandomValues(static_cast<InputType>(0.0f),
                                         static_cast<InputType>(1.0f));
        }
    }
};

void runConv(hipdnnHandle_t handle, const Config& config)
{
    TensorLayout layout;
    if(config.dimension == 2)
    {
        layout = (config.layout == "NHWC") ? TensorLayout::NHWC : TensorLayout::NCHW;
    }
    else
    {
        layout = (config.layout == "NHWC") ? TensorLayout::NDHWC : TensorLayout::NCDHW;
    }

    ConvRunner runner(handle, config);
    if(config.convType == 1)
    {
        if(config.dataType == "fp32" || config.dataType == "tf32")
        {
            runner.template fprop<float, float>(layout);
        }
        else if(config.dataType == "fp16")
        {
            runner.template fprop<half, float>(layout);
        }
        else if(config.dataType == "bfp16")
        {
            runner.template fprop<bfloat16, float>(layout);
        }
        else if(config.dataType == "int8")
        {
            runner.template fprop<int8_t, int32_t>(layout);
        }
        else
        {
            std::cerr << "Unsupported data type: " << config.dataType << std::endl;
            exit(1);
        }
    }
    else if(config.convType == 2)
    {
        if(config.dataType == "fp32" || config.dataType == "tf32")
        {
            runner.template dgrad<float, float>(layout);
        }
        else if(config.dataType == "fp16")
        {
            runner.template dgrad<half, float>(layout);
        }
        else if(config.dataType == "bfp16")
        {
            runner.template dgrad<bfloat16, float>(layout);
        }
        else
        {
            std::cerr << "Unsupported data type: " << config.dataType << std::endl;
            exit(1);
        }
    }
    else if(config.convType == 4)
    {
        if(config.dataType == "fp32" || config.dataType == "tf32")
        {
            runner.template wgrad<float, float>(layout);
        }
        else if(config.dataType == "fp16")
        {
            runner.template wgrad<half, float>(layout);
        }
        else if(config.dataType == "bfp16")
        {
            runner.template wgrad<bfloat16, float>(layout);
        }
        else
        {
            std::cerr << "Unsupported data type: " << config.dataType << std::endl;
            exit(1);
        }
    }
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));
    runConv(handle, config);
    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
