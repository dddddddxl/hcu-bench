// Copyright © Advanced Micro Devices, Inc., or its affiliates.
// SPDX-License-Identifier: MIT

#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

#include <hip/hip_runtime.h>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;

// ==================== 工具宏 ====================
#define HIP_CHECK(status)                                                                      \
    do                                                                                         \
    {                                                                                          \
        if(status != hipSuccess)                                                               \
        {                                                                                      \
            std::cerr << "HIP Error: " << hipGetErrorString(status) << " in file " << __FILE__ \
                      << " at line " << __LINE__ << "\n";                                      \
            exit(EXIT_FAILURE);                                                                \
        }                                                                                      \
    } while(0)

#define HIPDNN_CHECK(status)                                                             \
    do                                                                                   \
    {                                                                                    \
        if(status != HIPDNN_STATUS_SUCCESS)                                              \
        {                                                                                \
            std::cerr << "hipDNN Error: " << hipdnnGetErrorString(status) << " in file " \
                      << __FILE__ << " at line " << __LINE__ << "\n";                    \
            exit(EXIT_FAILURE);                                                          \
        }                                                                                \
    } while(0)

#define HIPDNN_FE_CHECK(statusObj)                                                        \
    do                                                                                    \
    {                                                                                     \
        auto const& status = statusObj;                                                   \
        if(!status.is_good())                                                             \
        {                                                                                 \
            std::cerr << "hipDNN Frontend Error: " << status.get_message() << " in file " \
                      << __FILE__ << " at line " << __LINE__ << "\n";                     \
            exit(EXIT_FAILURE);                                                           \
        }                                                                                 \
    } while(0)

// ==================== 配置结构 ====================
struct Config
{
    int64_t n = 1;
    int64_t c = 2;
    int64_t h = 3;
    int64_t w = 4;
    std::string dataType = "fp32";
    int64_t axis = 2;
    bool exclusive = false;
    bool reverse = false;
    bool cpuValidation = false;
    int fileIndex = 0;
    std::string filePath = ".";
};

// ==================== 命令行解析 ====================
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
            config.n = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
            config.c = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
            config.h = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
            config.w = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-axis") == 0 && i + 1 < argc)
        {
            config.axis = std::stoll(argv[++i]);
            if(config.axis < 0 || config.axis > 3)
            {
                std::cerr << "axis must be 0..3\n";
                exit(1);
            }
        }
        else if(strcmp(argv[i], "--exclusive") == 0)
            config.exclusive = true;
        else if(strcmp(argv[i], "--reverse") == 0)
            config.reverse = true;
        else if(strcmp(argv[i], "--cpu-validation") == 0)
            config.cpuValidation = true;
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
            config.fileIndex = std::stoi(argv[++i]);
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
                config.filePath += "/";
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << "\n";
            exit(1);
        }
    }
    return config;
}

// ==================== 辅助函数 ====================
template <typename T>
bool readRawTensor(const std::string& filename, std::vector<T>& data, size_t totalElems)
{
    std::ifstream file(filename, std::ios::binary);
    if(!file.is_open())
        return false;
    file.seekg(0, std::ios::end);
    std::streampos fileSize = file.tellg();
    file.seekg(0, std::ios::beg);
    size_t expectedBytes = totalElems * sizeof(T);
    if(static_cast<size_t>(fileSize) != expectedBytes)
        return false;
    data.resize(totalElems);
    file.read(reinterpret_cast<char*>(data.data()), static_cast<std::streamsize>(fileSize));
    file.close();
    return true;
}

template <typename T>
bool compareTensors(const Tensor<T>& ref, const Tensor<T>& cur, size_t totalElems)
{
    const T* refData = ref.memory().hostData();
    const T* curData = cur.memory().hostData();
    for(size_t i = 0; i < totalElems; ++i)
    {
        if(refData[i] != curData[i])
        {
            std::cout << "Mismatch at " << i << ": ref=" << static_cast<float>(refData[i])
                      << ", cur=" << static_cast<float>(curData[i]) << std::endl;
            return false;
        }
    }
    return true;
}

// 打印单个值（必须定义在 printFirstElements 之前）
template <typename T>
void printValue(T val)
{
    if constexpr(std::is_same_v<T, half> || std::is_same_v<T, bfloat16>)
        std::cout << static_cast<float>(val);
    else
        std::cout << val;
}

template <typename T>
void printFirstElements(const Tensor<T>& ref,
                        const Tensor<T>& cur,
                        size_t totalElems,
                        const std::string& refName = "Reference",
                        const std::string& curName = "Current")
{
    size_t printCount = std::min(totalElems, static_cast<size_t>(10));
    std::cout << "First " << printCount << " elements comparison:\n";
    std::cout << refName << ": ";
    for(size_t i = 0; i < printCount; ++i)
        printValue(ref.memory().hostData()[i]), std::cout << " ";
    std::cout << "\n" << curName << ":   ";
    for(size_t i = 0; i < printCount; ++i)
        printValue(cur.memory().hostData()[i]), std::cout << " ";
    std::cout << std::endl;
}

template <typename InputType>
float getTolerance()
{
    if constexpr(std::is_same_v<InputType, float>)
        return 1e-5f;
    else if constexpr(std::is_same_v<InputType, half>)
        return 1e-2f;
    else if constexpr(std::is_same_v<InputType, bfloat16>)
        return 1e-2f;
    else
        return 1e-5f;
}

// CPU 参考实现：使用传入的 dims 和 strides（避免依赖 Tensor::get_dim）
template <typename InputType>
void cpuCumsumReference(const Tensor<InputType>& input,
                        Tensor<InputType>& output,
                        const std::vector<int64_t>& dims,
                        const std::vector<int64_t>& strides,
                        int64_t axis,
                        bool exclusive,
                        bool reverse)
{
    const InputType* inData = input.memory().hostData();
    InputType* outData = output.memory().hostData();
    int64_t n = dims[0], c = dims[1], h = dims[2], w = dims[3];
    size_t axisIdx = static_cast<size_t>(axis); // 转为 size_t 用作 vector 索引

    for(int64_t ni = 0; ni < n; ++ni)
        for(int64_t ci = 0; ci < c; ++ci)
            for(int64_t hi = 0; hi < h; ++hi)
                for(int64_t wi = 0; wi < w; ++wi)
                {
                    std::vector<int64_t> idx = {ni, ci, hi, wi};
                    int64_t current = idx[axisIdx]; // axisIdx 已是 size_t
                    int64_t start, end;
                    if(!reverse)
                    {
                        start = 0;
                        end = current;
                    }
                    else
                    {
                        start = current;
                        end = dims[axisIdx] - 1;
                    }
                    if(exclusive)
                    {
                        if(!reverse)
                            end = current - 1;
                        else
                            start = current + 1;
                    }
                    double sum = 0.0;
                    for(int64_t k = start; k <= end; ++k)
                    {
                        idx[axisIdx] = k;
                        int64_t linear = idx[0] * strides[0] + idx[1] * strides[1]
                                         + idx[2] * strides[2] + idx[3] * strides[3];
                        sum += static_cast<double>(inData[linear]);
                    }
                    int64_t outLinear
                        = ni * strides[0] + ci * strides[1] + hi * strides[2] + wi * strides[3];
                    outData[outLinear] = static_cast<InputType>(sum);
                }
    output.memory().markHostModified();
}

// ==================== CumsumRunner ====================
class CumsumRunner
{
public:
    CumsumRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType>
    void run()
    {
        const auto dataType = getDataTypeEnumFromType<InputType>();
        std::cout << "Running Cumsum " << dataType << " (axis=" << config_.axis
                  << ", exclusive=" << config_.exclusive << ", reverse=" << config_.reverse
                  << (config_.cpuValidation ? ", CPU validation" : "") << "...\n";

        std::vector<int64_t> dims = {config_.n, config_.c, config_.h, config_.w};
        std::vector<int64_t> strides
            = {config_.c * config_.h * config_.w, config_.h * config_.w, config_.w, 1};
        size_t totalElems = static_cast<size_t>(config_.n * config_.c * config_.h * config_.w);

        // 构建图
        auto graph = std::make_shared<graph::Graph>();
        graph->set_name("cumsum_graph")
            .set_io_data_type(dataType)
            .set_intermediate_data_type(dataType)
            .set_compute_data_type(DataType::FLOAT);

        auto input = std::make_shared<graph::Tensor_attributes>();
        input->set_name("input").set_dim(dims).set_stride(strides);

        auto cumsumAttrs = graph::CumsumAttributes()
                               .set_axis(config_.axis)
                               .set_exclusive(config_.exclusive)
                               .set_reverse(config_.reverse)
                               .set_name("cumsum_node");

        auto output = graph->cumsum(input, cumsumAttrs);
        output->set_output(true);

        HIPDNN_FE_CHECK(graph->build(handle_));
        std::cout << "Graph built successfully.\n";

        Tensor<InputType> inputTensor(dims, strides);
        Tensor<InputType> outputTensor(dims, strides);

        bool readSuccess = false;
        std::vector<InputType> refXData, refYData;
        Tensor<InputType> refOutputTensor(dims, strides);

        if(config_.fileIndex > 0)
        {
            std::string xFile = config_.filePath + std::to_string(config_.fileIndex) + "_X.bin";
            std::string yFile = config_.filePath + std::to_string(config_.fileIndex) + "_Y.bin";
            readSuccess = readRawTensor<InputType>(xFile, refXData, totalElems)
                          && readRawTensor<InputType>(yFile, refYData, totalElems);
            if(readSuccess)
            {
                std::cout << "Read reference files.\n";
                std::copy(refXData.begin(), refXData.end(), inputTensor.memory().hostData());
                inputTensor.memory().markHostModified();
                std::copy(refYData.begin(), refYData.end(), refOutputTensor.memory().hostData());
                refOutputTensor.memory().markHostModified();
            }
            else
                std::cerr << " [WARN] Failed to read ref files. Using random data.\n";
        }

        if(!readSuccess || config_.fileIndex == 0)
            inputTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                             static_cast<InputType>(1.0f));

        std::unordered_map<int64_t, void*> variantPack;
        variantPack[input->get_uid()] = inputTensor.memory().deviceData();
        variantPack[output->get_uid()] = outputTensor.memory().deviceData();

        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 首次执行
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        outputTensor.memory().markDeviceModified();

        // 性能测试
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));

        const int warmup = 10, timed = 100;
        for(int i = 0; i < warmup; ++i)
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        HIP_CHECK(hipEventRecord(start, nullptr));
        for(int i = 0; i < timed; ++i)
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "Average execution time: " << time / timed << " ms\n";
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        (void)outputTensor.memory().hostData(); // sync

        // 文件验证
        if(config_.fileIndex > 0 && readSuccess)
        {
            bool match = compareTensors(refOutputTensor, outputTensor, totalElems);
            std::cout << "File validation: " << (match ? "PASS" : "FAIL") << "\n";
            printFirstElements(refOutputTensor, outputTensor, totalElems);
        }

        // CPU 验证
        if(config_.cpuValidation)
        {
            std::cout << "CPU reference validation...\n";
            Tensor<InputType> cpuOutputTensor(dims, strides);
            cpuCumsumReference<InputType>(inputTensor,
                                          cpuOutputTensor,
                                          dims,
                                          strides,
                                          config_.axis,
                                          config_.exclusive,
                                          config_.reverse);

            float tol = getTolerance<InputType>();
            auto validator
                = hipdnn_test_sdk::utilities::CpuFpReferenceValidation<InputType>(tol, tol);
            bool valid = validator.allClose(cpuOutputTensor, outputTensor);
            std::cout << "CPU validation: " << (valid ? "PASS" : "FAIL") << "\n";
            printFirstElements(
                cpuOutputTensor, outputTensor, totalElems, "CPU Reference", "GPU Output");
        }

        // 打印前 10 个输出
        std::cout << "First 10 outputs: ";
        auto outHost = outputTensor.memory().hostData();
        for(int i = 0; i < 10 && i < static_cast<int>(totalElems); ++i)
            printValue(outHost[i]), std::cout << " ";
        std::cout << "\n\n";
    }

private:
    hipdnnHandle_t handle_;
    Config config_;
};

// ==================== 调度 ====================
void run(hipdnnHandle_t handle, const Config& config)
{
    CumsumRunner runner(handle, config);
    if(config.dataType == "fp32")
        runner.run<float>();
    else if(config.dataType == "fp16")
        runner.run<half>();
    else if(config.dataType == "bfp16")
        runner.run<bfloat16>();
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << "\n";
        exit(1);
    }
}

// ==================== main ====================
int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
        std::cout << argv[i] << " ";
    std::cout << "\n";

    Config config = parseCommandLineArgs(argc, argv);
    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));

    run(handle, config);

    HIPDNN_CHECK(hipdnnDestroy(handle));
    std::cout << "Cumsum test completed.\n";
    return 0;
}
