#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Constants.hpp>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
//#include <hipdnn_test_sdk/utilities/CpuFpReferenceTransformerAdamw.hpp>     // 未实现
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>

#include "../utils.hpp"
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// 配置结构
struct Config
{
    int64_t n = 2; // Batch size
    int64_t c = 3; // Number of channels
    int64_t h = 4; // Input height
    int64_t w = 5; // Input width
    //    int32_t dim = 0; // dim
    //    int64_t k = 12; // k
    //    int64_t contiguous = 0; // is contiguous
    std::string dataType = "fp32"; // Data type (fp32/fp16)
    bool cpuValidation = true; // Enable CPU validation (default=false)
    int fileIndex = 0; // Reference file index (0 = no file reading)
    std::string filePath = "."; // Path to reference files
};

// 解析命令行参数以填充配置结构
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        //        else if(strcmp(argv[i], "--dim") == 0 && i + 1 < argc)
        //        {
        //            config.dim = std::stoi(argv[++i]);
        //        }
        //        else if(strcmp(argv[i], "-k") == 0 && i + 1 < argc)
        //        {
        //            config.k = std::stoll(argv[++i]);
        //        }
        //        else if(strcmp(argv[i], "--is-contiguous") == 0 && i + 1 < argc)
        //        {
        //            config.contiguous = std::stoll(argv[++i]);
        //        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            std::cerr << "Usage: transformeradamw -n <batch> -c <channels> -H <height> -W <width> "
                      << "--dim <dim> -k <k> --is-contiguous <is-contiguous> -d <data_type> "
                      << "-i <file_index> [--cpu-validation] -path <path>\n";
            exit(1);
        }
    }

    return config;
}

class TransformerAdamwRunner
{
public:
    TransformerAdamwRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType, typename IntermediateType>
    void runtransformeradamw()
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        //        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        std::cout << "Running transformeradamw graph " << inputType
                  << (config_.cpuValidation ? " (with CPU validation)" : "") << "...\n";

        // 读取配置参数
        const int64_t n = config_.n;
        const int64_t c = config_.c;
        const int64_t h = config_.h;
        const int64_t w = config_.w;
        //        const int64_t k = config_.k;
        //        const int32_t dim = config_.dim;
        //        bool keepdim = (config_.contiguous == 0);

        std::cout << "Parameter information of size: \n";
        std::cout << "n: " << n << '\n';
        std::cout << "c: " << c << '\n';
        std::cout << "h: " << h << '\n';
        std::cout << "w: " << w << '\n';
        //        std::cout << "dim: " << dim << '\n';
        //        std::cout << "k: " << k << '\n';
        //        std::cout << "is-contiguous: " << (keepdim ? "true" : "false") << '\n';
        std::cout << "data_type: " << config_.dataType << '\n';
        std::cout << '\n';

        // 根据模式计算总元素和参数尺寸
        std::vector<int64_t> transformeradamwParamDims;
        std::vector<int64_t> transformeradamwParamstride;

        transformeradamwParamDims = {n, c, h, w};
        transformeradamwParamstride = {c * h * w, h * w, w, 1};

        // 构建批量规范化图
        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_intermediate_data_type(inputType)
            .set_compute_data_type(DataType::FLOAT);

        // 创建输入/输出张量
        auto params = createTensor(transformeradamwParamDims, inputType);
        params->set_stride(transformeradamwParamstride);

        auto grads = createTensor(transformeradamwParamDims, inputType);
        grads->set_stride(transformeradamwParamstride);

        auto expAvgs = createTensor(transformeradamwParamDims, inputType);
        expAvgs->set_stride(transformeradamwParamstride);

        auto expAvgSqs = createTensor(transformeradamwParamDims, inputType);
        expAvgSqs->set_stride(transformeradamwParamstride);

        // 配置transformeradamw属性
        auto transformeradamwAttributes = graph::AdamwAttributes()
                                              .set_name("transformer_adamw_node")
                                              .set_correct_bias(false)
                                              .set_transformeradamw(true);

        // 在图中添加transformeradamw节点
        graph->adamw(params, grads, expAvgs, expAvgSqs, transformeradamwAttributes);

        // 验证并构建图形
        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful.\n";
        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";
        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";
        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";
        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        // 初始化张量
        Tensor<InputType> paramsTensor(params->get_dim(), params->get_stride());
        Tensor<InputType> gradsTensor(grads->get_dim(), grads->get_stride());
        Tensor<InputType> expAvgsTensor(expAvgs->get_dim(), expAvgs->get_stride());
        Tensor<InputType> expAvgSqsTensor(expAvgSqs->get_dim(), expAvgSqs->get_stride());

        // 初始化值
        fillTensorWithRandomValues(paramsTensor);
        fillTensorWithRandomValues(gradsTensor);
        fillTensorWithRandomValues(expAvgsTensor);
        fillTensorWithRandomValues(expAvgSqsTensor);

        // 准备变量包以执行transformeradamw计时
        std::unordered_map<int64_t, void*> variantPack;

        // 内存管理
        variantPack[params->get_uid()] = paramsTensor.memory().deviceData();
        variantPack[grads->get_uid()] = gradsTensor.memory().deviceData();
        variantPack[expAvgs->get_uid()] = expAvgsTensor.memory().deviceData();
        variantPack[expAvgSqs->get_uid()] = expAvgSqsTensor.memory().deviceData();

        // 分配工作空间
        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 用100次迭代来衡量执行时间
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        //        for (int exec_idx = 0; exec_idx < 100; ++exec_idx) {
        //            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        //        }
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        //        std::cout << "Average execution time (mode " << mode << "): " << time / 100 << " ms\n";
        std::cout << "Average execution time: " << time << " ms\n";
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        paramsTensor.memory().markDeviceModified();
        gradsTensor.memory().markDeviceModified();

        const InputType* paramsHostPtr = paramsTensor.memory().hostData();
        const InputType* gradsHostPtr = gradsTensor.memory().hostData();

        std::cout << "First 10 transformeradamw params values: ";
        for(int i = 0; i < 10; ++i)
        {
            std::cout << static_cast<float>(paramsHostPtr[i]) << " ";
        }
        std::cout << "\n";

        std::cout << "First 10 transformeradamw grads values: ";
        for(int i = 0; i < 10; ++i)
        {
            std::cout << static_cast<float>(gradsHostPtr[i]) << " ";
        }
        std::cout << "\n";

        // 结果比较

        // CPU validation   未实现
        //        if(config_.cpuValidation)
        //        {
        //            std::cout << "Running CPU reference validation (mode " << mode << ")...\n";
        //
        //            // 创建参考输出张量
        //            Tensor<InputType> yRefTensor(y->get_dim(), y->get_stride());
        //
        //            // 执行 CPU 参考计算
        //            CpuFpReferenceTransformerAdamw::fwdTraining(inputTensor,
        //                                                 yRefTensor,
        //                                                 BATCHNORM_DEFAULT_EPSILON,
        //                                                 0.1);
        //
        //            const InputType* yRefHostPtr = yRefTensor.memory().hostData();
        //
        //            std::cout << "First 10 transformeradamw output values: ";
        //            for(int i = 0; i < 10; ++i)
        //            {
        //                std::cout << static_cast<float>(yRefHostPtr[i]) << " ";
        //            }
        //            std::cout << "\n";
        //
        //            // Validate results
        //            // 容差设置
        //            auto tolerance = transformeradamw::getToleranceTraining<InputType>();
        //
        //            // 创建验证器
        //            auto yValidator = CpuFpReferenceValidation<InputType>(tolerance, tolerance);
        //            auto statsValidator = CpuFpReferenceValidation<IntermediateType>(
        //                static_cast<IntermediateType>(tolerance), static_cast<IntermediateType>(tolerance));
        //
        //            // allClose用来比较两个张量是否在容差范围内相等
        //            bool yValid = yValidator.allClose(yRefTensor, outputTensor);
        //
        //            std::cout << "CPU reference validation:\n";
        //            std::cout << "y: " << (yValid ? "successful" : "failed") << "\n";
        //        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    template <typename InputType>
    void fillTensorWithRandomValues(Tensor<InputType>& tensor)
    {
        if constexpr(std::is_same_v<InputType, int8_t>)
        {
            tensor.fillWithRandomValues(static_cast<InputType>(-127), static_cast<InputType>(127));
        }
        else
        {
            tensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));
        }
    }
};

// Dispatch function: selects appropriate data type implementation
void runTransformerAdamw(hipdnnHandle_t handle, const Config& config)
{
    if(config.dataType == "fp32")
    {
        TransformerAdamwRunner runner(handle, config);
        runner.template runtransformeradamw<float, float>();
    }
    else if(config.dataType == "fp16")
    {
        TransformerAdamwRunner runner(handle, config);
        runner.template runtransformeradamw<half, float>();
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    // 打印参数
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << "\n";

    // 解析配置
    auto config = parseCommandLineArgs(argc, argv);

    // 初始化日志
    initializeFrontendLogging();

    // 使用RAII管理句柄
    hipdnnHandle_t handle;

    HIPDNN_CHECK(hipdnnCreate(&handle));
    // 执行transformeradamw
    runTransformerAdamw(handle, config);

    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
