#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceConcatenate.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>

#include "../utils.hpp"
using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

struct Config
{
    int64_t axis = 1; // concatenation axis
    std::string dataType = "fp32";
    std::string layout = "NCHW"; // user-specified layout (optional)
    bool cpuValidation = false;
    int fileIndex = 0;
    std::string filePath = ".";
    std::vector<std::vector<int64_t>> input_dims_list;
};

std::vector<int64_t> computeStrides(const std::vector<int64_t>& dims)
{
    std::vector<int64_t> strides(dims.size());
    int64_t stride = 1;
    for(size_t i = dims.size() - 1; i < dims.size(); --i)
    {
        strides[i] = stride;
        stride *= dims[i];
    }
    return strides;
}

// ------------------------------------------------------------------------
// Command line parsing
// ------------------------------------------------------------------------
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-d") == 0 && i + 1 < argc) // data type
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-axis") == 0 && i + 1 < argc) // concatenation axis
        {
            config.axis = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc) // layout (optional)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0) // CPU validation flag
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc) // file index
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc) // file path
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else if(strncmp(argv[i], "--input", 7) == 0 && i + 1 < argc) // --inputN
        {
            std::string dimStr = argv[++i];
            std::vector<int64_t> dims;
            size_t pos = 0;
            while(pos < dimStr.size())
            {
                size_t found = dimStr.find('x', pos);
                if(found == std::string::npos)
                {
                    dims.push_back(std::stoll(dimStr.substr(pos)));
                    break;
                }
                else
                {
                    dims.push_back(std::stoll(dimStr.substr(pos, found - pos)));
                    pos = found + 1;
                }
            }
            config.input_dims_list.push_back(dims);
        }
        else if(strcmp(argv[i], "-F") == 0 && i + 1 < argc) // ignore -F and its argument
        {
            ++i;
        }
        else if(strcmp(argv[i], "-t") == 0 && i + 1 < argc) // ignore -t and its argument
        {
            ++i;
        }
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            std::cerr << "Usage: " << argv[0]
                      << " -d <data_type> -axis <axis> [ -L <layout> ] [ --cpu-validation ]"
                      << " [ -i <file_index> -path <path> ] --input1 <dim1> --input2 <dim2> ...\n";
            exit(1);
        }
    }

    // Must have at least two inputs
    if(config.input_dims_list.size() < 2)
    {
        std::cerr << "Error: At least two --inputN arguments are required.\n";
        exit(1);
    }

    // Validate all inputs have same number of dimensions
    int ndims = static_cast<int>(config.input_dims_list[0].size());
    for(size_t i = 1; i < config.input_dims_list.size(); ++i)
    {
        if(static_cast<int>(config.input_dims_list[i].size()) != ndims)
        {
            std::cerr << "All inputs must have the same number of dimensions.\n";
            exit(1);
        }
    }

    // Validate axis range
    if(config.axis < 0 || config.axis >= ndims)
    {
        std::cerr << "Invalid axis: " << config.axis << ". Must be between 0 and " << ndims - 1
                  << std::endl;
        exit(1);
    }

    // Layout string length check is removed – layout is optional and not used for stride calculation.
    // All strides are computed in row-major order regardless of layout.

    return config;
}

// ------------------------------------------------------------------------
// CatRunner class
// ------------------------------------------------------------------------
class CatRunner
{
public:
    CatRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType, typename IntermediateType>
    void run()
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();
        using OutputType = InputType;
        const auto outputType = getDataTypeEnumFromType<OutputType>();

        const auto& input_dims_list = config_.input_dims_list;
        const int64_t num_inputs = static_cast<int64_t>(input_dims_list.size());
        const int64_t axis = config_.axis;
        const int ndims = static_cast<int>(input_dims_list[0].size());

        // Verify all inputs have same dimensions except on axis
        std::vector<int64_t> output_dims = input_dims_list[0];
        output_dims[static_cast<size_t>(axis)] = 0;
        for(const auto& dims : input_dims_list)
        {
            for(size_t d = 0; d < static_cast<size_t>(ndims); ++d)
            {
                if(d != static_cast<size_t>(axis) && dims[d] != input_dims_list[0][d])
                {
                    std::cerr << "Inputs dimension mismatch on non-axis dimension " << d
                              << std::endl;
                    exit(1);
                }
            }
            output_dims[static_cast<size_t>(axis)] += dims[static_cast<size_t>(axis)];
        }

        // Total elements in output
        size_t output_total_elems = 1;
        for(auto d : output_dims)
            output_total_elems *= static_cast<size_t>(d);

        // --------------------------------------------------------------------
        // Build graph
        // --------------------------------------------------------------------
        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_intermediate_data_type(intermediateType)
            .set_compute_data_type(DataType::FLOAT);

        // Create input tensor attributes
        std::vector<std::shared_ptr<graph::TensorAttributes>> input_attrs;
        for(int64_t i = 0; i < num_inputs; ++i)
        {
            auto strides = computeStrides(input_dims_list[static_cast<size_t>(i)]);
            auto input_attr = std::make_shared<graph::TensorAttributes>(
                graph::Tensor_attributes()
                    .set_dim(input_dims_list[static_cast<size_t>(i)])
                    .set_stride(strides)
                    .set_data_type(inputType));
            input_attr->set_name("input_" + std::to_string(i));
            input_attrs.push_back(input_attr);
        }

        // Concatenate attributes
        graph::ConcatenateAttributes concatAttributes;
        concatAttributes.set_axis(axis);

        // Output tensor
        auto output_strides = computeStrides(output_dims);
        auto output_attr = graph->concatenate(input_attrs, concatAttributes);
        output_attr->set_output(true)
            .set_name("output")
            .set_data_type(outputType)
            .set_stride(output_strides); // ensure strides are set

        // Graph validation and build
        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful.\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        // --------------------------------------------------------------------
        // Create tensors and prepare data
        // --------------------------------------------------------------------
        std::vector<Tensor<InputType>> input_tensors;
        for(int64_t i = 0; i < num_inputs; ++i)
        {
            Tensor<InputType> tensor(input_dims_list[static_cast<size_t>(i)],
                                     computeStrides(input_dims_list[static_cast<size_t>(i)]));
            input_tensors.push_back(std::move(tensor));
        }

        Tensor<OutputType> output_tensor(output_dims, output_strides);
        Tensor<OutputType> ref_output_tensor(output_dims, output_strides);

        // Initialize output
        if constexpr(std::is_same_v<OutputType, int8_t>)
        {
            output_tensor.fillWithValue(static_cast<OutputType>(0));
        }
        else
        {
            output_tensor.fillWithValue(static_cast<OutputType>(0.0f));
        }

        // Read reference data or fill random
        bool readSuccess = false;
        if(config_.fileIndex > 0)
        {
            readSuccess = true;
            for(int64_t i = 0; i < num_inputs; ++i)
            {
                const std::string filename = config_.filePath + std::to_string(config_.fileIndex)
                                             + "_input_" + std::to_string(i) + ".bin";
                std::vector<InputType> data;
                size_t input_total_elems = 1;
                for(auto d : input_dims_list[static_cast<size_t>(i)])
                    input_total_elems *= static_cast<size_t>(d);

                if(!readRawTensor<InputType>(filename, data, input_total_elems))
                {
                    readSuccess = false;
                    std::cerr << "[WARN] Failed to read input file: " << filename << std::endl;
                    break;
                }
                std::copy(data.begin(),
                          data.end(),
                          input_tensors[static_cast<size_t>(i)].memory().hostData());
                input_tensors[static_cast<size_t>(i)].memory().markHostModified();
            }

            if(readSuccess)
            {
                const std::string output_filename
                    = config_.filePath + std::to_string(config_.fileIndex) + "_output.bin";
                std::vector<OutputType> output_data;

                if(readRawTensor<OutputType>(output_filename, output_data, output_total_elems))
                {
                    std::copy(output_data.begin(),
                              output_data.end(),
                              ref_output_tensor.memory().hostData());
                    ref_output_tensor.memory().markHostModified();
                    std::cout << "Successfully read concatenate reference files.\n";
                }
                else
                {
                    readSuccess = false;
                    std::cerr << "[WARN] Failed to read output file: " << output_filename
                              << std::endl;
                }
            }

            if(!readSuccess)
            {
                std::cerr << "[WARN] Failed to read reference files. Using random values.\n";
                for(auto& tensor : input_tensors)
                {
                    fillTensorWithRandomValues(tensor);
                }
            }
        }
        else
        {
            for(auto& tensor : input_tensors)
            {
                fillTensorWithRandomValues(tensor);
            }
        }

        // --------------------------------------------------------------------
        // Execute graph
        // --------------------------------------------------------------------
        std::unordered_map<int64_t, void*> variantPack;
        for(int64_t i = 0; i < num_inputs; ++i)
        {
            variantPack[input_attrs[static_cast<size_t>(i)]->get_uid()]
                = input_tensors[static_cast<size_t>(i)].memory().deviceData();
        }
        variantPack[output_attr->get_uid()] = output_tensor.memory().deviceData();

        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        output_tensor.memory().markDeviceModified();

        // Timing
        hipEvent_t start, stop;
        float time = 0.0f;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));

        std::cout << "Concatenate avg time: " << time / 100.0f << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // Print first 10 output values
        std::cout << "First 10 output values: ";
        const OutputType* output_data = output_tensor.memory().hostData();
        for(int i = 0; i < 10 && i < static_cast<int>(output_total_elems); ++i)
        {
            if constexpr(std::is_same_v<OutputType, int8_t>)
            {
                std::cout << static_cast<int>(output_data[i]) << " ";
            }
            else
            {
                std::cout << static_cast<float>(output_data[i]) << " ";
            }
        }
        std::cout << std::endl;

        // --------------------------------------------------------------------
        // Validation
        // --------------------------------------------------------------------
        if(config_.fileIndex > 0 && readSuccess)
        {
            bool isMatch = false;

            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                const OutputType* refData = ref_output_tensor.memory().hostData();
                const OutputType* currData = output_tensor.memory().hostData();
                isMatch = true;

                const size_t printCount = std::min(output_total_elems, static_cast<size_t>(10));
                std::cout << "前" << printCount << "个元素对比：" << std::endl;
                std::cout << "(refData): ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<int>(refData[i]) << " ";
                }
                std::cout << std::endl;

                std::cout << "(currData): ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<int>(currData[i]) << " ";
                }
                std::cout << std::endl;

                for(size_t i = 0; i < output_total_elems; ++i)
                {
                    if(currData[i] != refData[i])
                    {
                        std::cout << "不匹配！索引 " << i
                                  << ": ref=" << static_cast<int>(refData[i])
                                  << ", curr=" << static_cast<int>(currData[i]) << std::endl;
                        isMatch = false;
                        break;
                    }
                }
            }
            else
            {
                float tolerance = getTolerance<InputType>();
                CpuFpReferenceValidation<InputType> fileValidator(tolerance, tolerance);
                isMatch = fileValidator.allClose(ref_output_tensor, output_tensor);
            }
            std::cout << "cuDNN validation result: " << (isMatch ? "successful" : "failed") << "\n";
        }

        if(config_.cpuValidation)
        {
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                std::cout << "CPU validation is not supported for int8 input type.\n";
            }
            else
            {
                Tensor<OutputType> cpu_output_tensor(output_dims, output_strides);
                std::vector<std::unique_ptr<hipdnn_data_sdk::utilities::TensorBase<InputType>>>
                    input_ptr_vec;
                for(auto& tensor : input_tensors)
                {
                    input_ptr_vec.emplace_back(&tensor);
                }
                CpuFpReferenceConcatenate::fwdInference<InputType, OutputType>(
                    input_ptr_vec, cpu_output_tensor, static_cast<size_t>(axis));

                float tolerance = getTolerance<InputType>();
                CpuFpReferenceValidation<InputType> validator(tolerance, tolerance);
                bool isMatch = validator.allClose(cpu_output_tensor, output_tensor);
                std::cout << "CPU validation result: " << (isMatch ? "successful" : "failed")
                          << "\n";
            }
        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    template <typename T>
    float getTolerance()
    {
        if(config_.dataType == "tf32")
            return static_cast<float>(1e-2f);
        else if(config_.dataType == "fp32")
            return static_cast<float>(1e-5f);
        else if(config_.dataType == "fp16")
        {
            if constexpr(std::is_same_v<T, half>)
            {
                float result;
                result = static_cast<float>(1e-2f);
                return result;
            }
            else
                return static_cast<float>(1e-2f);
        }
        else if(config_.dataType == "bfp16")
        {
            if constexpr(std::is_same_v<T, bfloat16>)
            {
                float result;
                result = static_cast<float>(1e-2f);
                return result;
            }
            else
                return static_cast<float>(1e-2f);
        }
        else // int8
        {
            if constexpr(std::is_same_v<T, int8_t>)
                return static_cast<float>(1);
            else
                return float{};
        }
    }

    template <typename InputType>
    void fillTensorWithRandomValues(Tensor<InputType>& tensor)
    {
        if constexpr(std::is_same_v<InputType, int8_t>)
        {
            tensor.fillWithRandomValues(static_cast<InputType>(-127), static_cast<InputType>(127));
        }
        else
        {
            tensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));
        }
    }
};

// ------------------------------------------------------------------------
// runCat dispatcher
// ------------------------------------------------------------------------
void runCat(hipdnnHandle_t handle, const Config& config)
{
    CatRunner runner(handle, config);

    if(config.dataType == "fp32" || config.dataType == "tf32")
    {
        runner.run<float, float>();
    }
    else if(config.dataType == "fp16")
    {
        runner.run<half, float>();
    }
    else if(config.dataType == "bfp16")
    {
        runner.run<bfloat16, float>();
    }
    else if(config.dataType == "int8")
    {
        runner.run<int8_t, int32_t>();
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

// ------------------------------------------------------------------------
// main
// ------------------------------------------------------------------------
int main(int argc, char* argv[])
{
    // Print command line
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));
    runCat(handle, config);
    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
