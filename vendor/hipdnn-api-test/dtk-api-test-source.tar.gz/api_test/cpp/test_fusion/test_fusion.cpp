#include "../utils.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>
using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// 融合模式枚举
enum class FusionMode
{
    CONV_BIAS,
    CONV_BIAS_RELU,
    CONV_BIAS_CLIPPEDRELU,
    CONV_BIAS_LEAKYRELU,
    CONV_BIAS_ADD,
    CONV_BIAS_SWISH,
    CONV_BIAS_ADD_RELU,
    CONV_BIAS_SWISH_ADD,
    CONV_BIAS_PRELU,
    CONV_BIAS_PRELU_ADD
};

// 配置结构体
struct Config
{
    int64_t n = 1;
    int64_t c = 128;
    int64_t h = 28;
    int64_t w = 28;
    int64_t k = 12;
    int64_t r = 3;
    int64_t s = 3;
    int64_t padH = 1;
    int64_t padW = 1;
    int64_t u = 1;
    int64_t v = 1;
    int64_t dilH = 1;
    int64_t dilW = 1;
    int64_t groups = 1;
    std::string dataType = "fp16";
    std::string layout = "NHWC";
    bool cpuValidation = false;
    int fileIndex = 0;
    std::string filePath = ".";
    FusionMode fusionMode = FusionMode::CONV_BIAS_SWISH_ADD; // 默认模式
    float reluAlpha = 0.25f;
};

// 融合模式字符串映射
std::unordered_map<std::string, FusionMode> fusionModeMap
    = {{"conv_bias", FusionMode::CONV_BIAS},
       {"conv_bias_relu", FusionMode::CONV_BIAS_RELU},
       {"conv_bias_clippedrelu", FusionMode::CONV_BIAS_CLIPPEDRELU},
       {"conv_bias_leakyrelu", FusionMode::CONV_BIAS_LEAKYRELU},
       {"conv_bias_add", FusionMode::CONV_BIAS_ADD},
       {"conv_bias_swish", FusionMode::CONV_BIAS_SWISH},
       {"conv_bias_add_relu", FusionMode::CONV_BIAS_ADD_RELU},
       {"conv_bias_swish_add", FusionMode::CONV_BIAS_SWISH_ADD},
       {"conv_bias_prelu", FusionMode::CONV_BIAS_PRELU},
       {"conv_bias_prelu_add", FusionMode::CONV_BIAS_PRELU_ADD}};

// 融合模式到字符串的转换
std::string fusionModeToString(FusionMode mode)
{
    for(const auto& pair : fusionModeMap)
    {
        if(pair.second == mode)
        {
            return pair.first;
        }
    }
    return "unknown";
}

// 命令行解析
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-k") == 0 && i + 1 < argc)
        {
            config.k = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-y") == 0 && i + 1 < argc)
        {
            config.r = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-x") == 0 && i + 1 < argc)
        {
            config.s = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-p") == 0 && i + 1 < argc)
        {
            config.padH = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc)
        {
            config.padW = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-u") == 0 && i + 1 < argc)
        {
            config.u = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-v") == 0 && i + 1 < argc)
        {
            config.v = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-l") == 0 && i + 1 < argc)
        {
            config.dilH = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-j") == 0 && i + 1 < argc)
        {
            config.dilW = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-g") == 0 && i + 1 < argc)
        {
            config.groups = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--relu-alpha") == 0 && i + 1 < argc)
        {
            config.reluAlpha = std::stof(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "-a") == 0 && i + 1 < argc)
        {
            std::string modeStr = argv[++i];
            std::transform(modeStr.begin(), modeStr.end(), modeStr.begin(), ::tolower);
            if(fusionModeMap.find(modeStr) != fusionModeMap.end())
            {
                config.fusionMode = fusionModeMap[modeStr];
            }
            else
            {
                std::cerr << "Unknown fusion mode: " << modeStr << std::endl;
                std::cerr << "Available modes: ";
                for(const auto& pair : fusionModeMap)
                {
                    std::cerr << pair.first << " ";
                }
                std::cerr << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

class ConvRunner
{
public:
    ConvRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType, typename IntermediateType>
    void fprop(const TensorLayout& layout)
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        using OutputType
            = std::conditional_t<std::is_same_v<InputType, int8_t>, IntermediateType, InputType>;
        const auto outputType = getDataTypeEnumFromType<OutputType>();

        // 计算每个组的输入输出通道数
        int64_t c_per_group = config_.c / config_.groups;

        const size_t xTotalElems
            = static_cast<size_t>(config_.n * config_.c * config_.h * config_.w);
        const size_t wTotalElems
            = static_cast<size_t>(config_.k * c_per_group * config_.r * config_.s);
        const size_t bTotalElems = static_cast<size_t>(1 * config_.k * 1 * 1);
        size_t addTotalElems = 0;

        const int64_t oh
            = (config_.h + 2 * config_.padH - config_.dilH * (config_.r - 1) - 1) / config_.u + 1;
        const int64_t ow
            = (config_.w + 2 * config_.padW - config_.dilW * (config_.s - 1) - 1) / config_.v + 1;

        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_compute_data_type(DataType::FLOAT)
            .set_intermediate_data_type(intermediateType);

        // 使用配置参数创建张量
        auto xAttr = createTensor(
            {config_.n, config_.c, config_.h, config_.w}, inputType, layout.strideOrder);
        auto wAttr = createTensor(
            {config_.k, c_per_group, config_.r, config_.s}, inputType, layout.strideOrder);
        auto biasAttr = createTensor({1, config_.k, 1, 1}, inputType, layout.strideOrder);

        xAttr->set_is_virtual(false);
        wAttr->set_is_virtual(false);
        biasAttr->set_is_virtual(false);

        // 卷积
        graph::ConvFpropAttributes convAttributes;
        convAttributes.set_name("conv_forward_node");
        convAttributes.set_padding({config_.padH, config_.padW});
        convAttributes.set_stride({config_.u, config_.v});
        convAttributes.set_dilation({config_.dilH, config_.dilW});

        auto currentOutput = graph->conv_fprop(xAttr, wAttr, convAttributes);
        currentOutput->set_is_virtual(true).set_data_type(inputType);

        // bias
        graph::PointwiseAttributes addBiasAttributes;
        addBiasAttributes.set_name("bias_node");
        addBiasAttributes.set_mode(PointwiseMode_t::ADD);

        currentOutput = graph->pointwise(currentOutput, biasAttr, addBiasAttributes);
        currentOutput->set_is_virtual(true).set_data_type(inputType);

        // 根据融合模式添加不同的操作
        std::shared_ptr<graph::Tensor_attributes> addAttr = nullptr;

        switch(config_.fusionMode)
        {
        case FusionMode::CONV_BIAS:
            // 只到bias，不需要额外操作
            break;

        case FusionMode::CONV_BIAS_RELU:
        {
            graph::PointwiseAttributes reluAttributes;
            reluAttributes.set_name("relu_node");
            reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
            currentOutput = graph->pointwise(currentOutput, reluAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        break;

        case FusionMode::CONV_BIAS_CLIPPEDRELU:
        {
            graph::PointwiseAttributes reluAttributes;
            reluAttributes.set_name("relu_node");
            reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
            reluAttributes.set_relu_upper_clip(config_.reluAlpha);
            currentOutput = graph->pointwise(currentOutput, reluAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        break;

        case FusionMode::CONV_BIAS_LEAKYRELU:
        {
            graph::PointwiseAttributes reluAttributes;
            reluAttributes.set_name("relu_node");
            reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
            reluAttributes.set_relu_lower_clip_slope(config_.reluAlpha);
            currentOutput = graph->pointwise(currentOutput, reluAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        break;

        case FusionMode::CONV_BIAS_ADD:
        {
            addAttr = createTensor({config_.n, config_.k, oh, ow}, inputType, layout.strideOrder);
            addAttr->set_is_virtual(false);

            graph::PointwiseAttributes addAttributes;
            addAttributes.set_name("add_node");
            addAttributes.set_mode(PointwiseMode_t::ADD);
            currentOutput = graph->pointwise(currentOutput, addAttr, addAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        break;

        case FusionMode::CONV_BIAS_SWISH:
        {
            graph::PointwiseAttributes swishAttributes;
            swishAttributes.set_name("swish_node");
            swishAttributes.set_mode(PointwiseMode_t::SWISH_FWD);
            currentOutput = graph->pointwise(currentOutput, swishAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        break;

        case FusionMode::CONV_BIAS_ADD_RELU:
        {
            addAttr = createTensor({config_.n, config_.k, oh, ow}, inputType, layout.strideOrder);
            addAttr->set_is_virtual(false);

            graph::PointwiseAttributes addAttributes;
            addAttributes.set_name("add_node");
            addAttributes.set_mode(PointwiseMode_t::ADD);
            currentOutput = graph->pointwise(currentOutput, addAttr, addAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);

            graph::PointwiseAttributes reluAttributes;
            reluAttributes.set_name("relu_node");
            reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
            currentOutput = graph->pointwise(currentOutput, reluAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        break;

        case FusionMode::CONV_BIAS_SWISH_ADD:
        {
            graph::PointwiseAttributes swishAttributes;
            swishAttributes.set_name("swish_node");
            swishAttributes.set_mode(PointwiseMode_t::SWISH_FWD);
            currentOutput = graph->pointwise(currentOutput, swishAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);

            addAttr = createTensor({config_.n, config_.k, oh, ow}, inputType, layout.strideOrder);
            addAttr->set_is_virtual(false);

            graph::PointwiseAttributes addAttributes;
            addAttributes.set_name("add_node");
            addAttributes.set_mode(PointwiseMode_t::ADD);
            currentOutput = graph->pointwise(currentOutput, addAttr, addAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        break;
        case FusionMode::CONV_BIAS_PRELU:
        {
            graph::PointwiseAttributes preluAttributes;
            preluAttributes.set_name("prelu_node");
            preluAttributes.set_mode(PointwiseMode_t::PRELU_FWD);
            preluAttributes.set_elu_alpha(config_.reluAlpha);
            currentOutput = graph->pointwise(currentOutput, preluAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        break;
        case FusionMode::CONV_BIAS_PRELU_ADD:
        {
            graph::PointwiseAttributes preluAttributes;
            preluAttributes.set_name("prelu_node");
            preluAttributes.set_mode(PointwiseMode_t::PRELU_FWD);
            preluAttributes.set_elu_alpha(config_.reluAlpha);
            currentOutput = graph->pointwise(currentOutput, preluAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);

            addAttr = createTensor({config_.n, config_.k, oh, ow}, inputType, layout.strideOrder);
            addAttr->set_is_virtual(false);

            graph::PointwiseAttributes addAttributes;
            addAttributes.set_name("add_node");
            addAttributes.set_mode(PointwiseMode_t::ADD);
            currentOutput = graph->pointwise(currentOutput, addAttr, addAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        break;
        default:
            break;
        }

        // 设置最终输出
        currentOutput->set_output(true).set_data_type(outputType);
        currentOutput->set_is_virtual(false);

        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful. Fusion mode: "
                  << fusionModeToString(config_.fusionMode) << ", groups: " << config_.groups
                  << "\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
        Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
        Tensor<InputType> bTensor(biasAttr->get_dim(), biasAttr->get_stride());
        Tensor<OutputType> yTensor(currentOutput->get_dim(), currentOutput->get_stride());

        Tensor<InputType>* addTensorPtr = nullptr;
        if(addAttr != nullptr)
        {
            addTensorPtr = new Tensor<InputType>(addAttr->get_dim(), addAttr->get_stride());
            addTotalElems = 1;
            for(int64_t dim : addAttr->get_dim())
            {
                addTotalElems *= static_cast<size_t>(dim);
            }
        }

        const auto& yDims = currentOutput->get_dim();
        size_t yTotalElems = 1;
        for(int64_t dim : yDims)
        {
            yTotalElems *= static_cast<size_t>(dim);
        }

        // 初始化输出值
        yTensor.fillWithValue(
            static_cast<OutputType>(std::is_floating_point_v<OutputType> ? 0.0f : 0));

        // 读取或生成数据
        bool readSuccess = false;
        std::vector<InputType> refXData, refWData, refBData, refAddData;
        std::vector<OutputType> refYData;
        Tensor<OutputType> refYTensor(currentOutput->get_dim(), currentOutput->get_stride());

        if(config_.fileIndex > 0)
        {
            const std::string xFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_input.bin";
            const std::string wFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_weight.bin";
            const std::string bFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bias.bin";
            const std::string yFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_output.bin";

            readSuccess = readRawTensor<InputType>(xFilename, refXData, xTotalElems)
                          && readRawTensor<InputType>(wFilename, refWData, wTotalElems)
                          && readRawTensor<InputType>(bFilename, refBData, bTotalElems)
                          && readRawTensor<OutputType>(yFilename, refYData, yTotalElems);

            // 如果模式需要add张量，尝试读取add文件
            if(addTensorPtr != nullptr && readSuccess)
            {
                const std::string addFilename
                    = config_.filePath + std::to_string(config_.fileIndex) + "_add.bin";
                if(readRawTensor<InputType>(addFilename, refAddData, addTotalElems))
                {
                    std::copy(
                        refAddData.begin(), refAddData.end(), addTensorPtr->memory().hostData());
                    addTensorPtr->memory().markHostModified();
                }
                else
                {
                    std::cerr << " [WARN] Failed to read add file. Using random values "
                                 "for add tensor.\n";
                    if constexpr(std::is_same_v<InputType, int8_t>)
                    {
                        addTensorPtr->fillWithRandomValues(static_cast<InputType>(-127),
                                                           static_cast<InputType>(127));
                    }
                    else
                    {
                        addTensorPtr->fillWithRandomValues(static_cast<InputType>(0.0f),
                                                           static_cast<InputType>(1.0f));
                    }
                }
            }

            if(readSuccess)
            {
                std::cout << "Successfully read fprop reference files for fusion mode: "
                          << fusionModeToString(config_.fusionMode)
                          << ", groups: " << config_.groups << "\n";
                std::copy(refXData.begin(), refXData.end(), xTensor.memory().hostData());
                xTensor.memory().markHostModified();
                std::copy(refWData.begin(), refWData.end(), wTensor.memory().hostData());
                wTensor.memory().markHostModified();
                std::copy(refBData.begin(), refBData.end(), bTensor.memory().hostData());
                bTensor.memory().markHostModified();
                std::copy(refYData.begin(), refYData.end(), refYTensor.memory().hostData());
                refYTensor.memory().markHostModified();
            }
            else
            {
                std::cerr << " [WARN] Failed to read reference files. Using random values.\n";
                // 输入/权重/偏置随机初始化
                if constexpr(std::is_same_v<InputType, int8_t>)
                {
                    xTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                                 static_cast<InputType>(127));
                    wTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                                 static_cast<InputType>(127));
                    bTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                                 static_cast<InputType>(127));
                    if(addTensorPtr != nullptr)
                    {
                        addTensorPtr->fillWithRandomValues(static_cast<InputType>(-127),
                                                           static_cast<InputType>(127));
                    }
                }
                else
                {
                    xTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                 static_cast<InputType>(1.0f));
                    wTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                 static_cast<InputType>(1.0f));
                    bTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                 static_cast<InputType>(1.0f));
                    if(addTensorPtr != nullptr)
                    {
                        addTensorPtr->fillWithRandomValues(static_cast<InputType>(0.0f),
                                                           static_cast<InputType>(1.0f));
                    }
                }
            }
        }
        else
        {
            // 无文件索引时生成随机数据
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                xTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                             static_cast<InputType>(127));
                wTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                             static_cast<InputType>(127));
                bTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                             static_cast<InputType>(127));
                if(addTensorPtr != nullptr)
                {
                    addTensorPtr->fillWithRandomValues(static_cast<InputType>(-127),
                                                       static_cast<InputType>(127));
                }
            }
            else
            {
                xTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                             static_cast<InputType>(1.0f));
                wTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                             static_cast<InputType>(1.0f));
                bTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                             static_cast<InputType>(1.0f));
                if(addTensorPtr != nullptr)
                {
                    addTensorPtr->fillWithRandomValues(static_cast<InputType>(0.0f),
                                                       static_cast<InputType>(1.0f));
                }
            }
        }

        // 绑定设备内存
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
        variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
        variantPack[biasAttr->get_uid()] = bTensor.memory().deviceData();
        if(addAttr != nullptr)
        {
            variantPack[addAttr->get_uid()] = addTensorPtr->memory().deviceData();
        }
        variantPack[currentOutput->get_uid()] = yTensor.memory().deviceData();

        // 申请工作空间
        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 预热执行
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        yTensor.memory().markDeviceModified();

        // 计时运行
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "avg times: " << time / 100 << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // 验证结果
        if(config_.fileIndex > 0 && readSuccess)
        {
            bool isMatch = true;
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                const OutputType* refData = refYTensor.memory().hostData();
                const OutputType* currData = yTensor.memory().hostData();

                const size_t printCount = std::min(yTotalElems, static_cast<size_t>(10));
                std::cout << "前" << printCount << "个元素对比（"
                          << fusionModeToString(config_.fusionMode) << "）：" << std::endl;
                std::cout << "(refData): ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<int>(refData[i]) << " ";
                }
                std::cout << std::endl;

                std::cout << "(currData): ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<int>(static_cast<int8_t>(currData[i])) << " ";
                }
                std::cout << std::endl;

                // 校验
                for(size_t i = 0; i < yTotalElems; ++i)
                {
                    if(currData[i] != refData[i])
                    {
                        std::cout << "不匹配！索引 " << i
                                  << ": ref(int8)=" << static_cast<int>(refData[i])
                                  << ", curr(原始)=" << static_cast<int>(currData[i]) << std::endl;
                        isMatch = false;
                        break;
                    }
                }
            }
            else
            {
                float tolerance = (config_.dataType == "tf32") ? static_cast<float>(1e-2f)
                                                               : conv::getToleranceFwd<InputType>();
                CpuFpReferenceValidation<InputType> fileValidator(tolerance, tolerance);
                isMatch = fileValidator.allClose(refYTensor, yTensor);
            }
            std::cout << "cudnn validation result (" << fusionModeToString(config_.fusionMode)
                      << "): " << (isMatch ? "successful" : "failed") << "\n";
        }

        if(config_.cpuValidation)
        {
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                std::cout << "CPU validation is not supported for int8 input type.\n";
            }
            else
            {
                std::unordered_map<int64_t, void*> cpuVariantPack;
                cpuVariantPack[xAttr->get_uid()] = xTensor.memory().hostData();
                cpuVariantPack[wAttr->get_uid()] = wTensor.memory().hostData();
                cpuVariantPack[biasAttr->get_uid()] = bTensor.memory().hostData();
                cpuVariantPack[currentOutput->get_uid()] = refYTensor.memory().hostData();
                if(addTensorPtr != nullptr)
                {
                    cpuVariantPack[addAttr->get_uid()] = addTensorPtr->memory().hostData();
                }

                // Execute on CPU using graph executor
                auto serializedGraph = graph->to_binary().first;
                CpuReferenceGraphExecutor cpuExecutor;
                cpuExecutor.execute(serializedGraph.data(), serializedGraph.size(), cpuVariantPack);

                float tolerance = (config_.dataType == "tf32") ? static_cast<float>(1e-2f)
                                                               : conv::getToleranceFwd<InputType>();
                CpuFpReferenceValidation<InputType> yValidator(tolerance, tolerance);
                bool yValid = yValidator.allClose(refYTensor, yTensor);

                std::cout << "CPU validation result (" << fusionModeToString(config_.fusionMode)
                          << "): " << (yValid ? "successful" : "failed") << "\n";
            }
        }
        if(addTensorPtr != nullptr)
        {
            delete addTensorPtr;
        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;
};

// 根据参数选择执行类型
void run(hipdnnHandle_t handle, const Config& config)
{
    TensorLayout layout = (config.layout == "NHWC") ? TensorLayout::NHWC : TensorLayout::NCHW;

    if(config.dataType == "fp32" || config.dataType == "tf32")
    {
        ConvRunner runner(handle, config);
        runner.template fprop<float, float>(layout);
    }
    else if(config.dataType == "fp16")
    {
        ConvRunner runner(handle, config);
        runner.template fprop<half, float>(layout);
    }
    else if(config.dataType == "int8")
    {
        ConvRunner runner(handle, config);
        runner.template fprop<int8_t, int32_t>(layout);
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));
    run(handle, config);
    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
