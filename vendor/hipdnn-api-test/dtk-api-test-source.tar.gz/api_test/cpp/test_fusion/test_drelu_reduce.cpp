#include <algorithm>
#include <cstring>
#include <iostream>
#include <random>
#include <tuple>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>

#include "../utils.hpp"
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;
using namespace std;

// 定义drelu+reduce需要的参数，c和k需保持相等，此处的c本质上是经过conv fporp后的通道数
struct Config
{
    int64_t n = 4;
    int64_t c = 64;
    int64_t h = 16;
    int64_t w = 16;
    int64_t k = 64;
    string layout = "NHWC";
    string dataType = "fp32";
    int file_index = 0; // 输出文件索引
    string file_path = ""; // 文件保存路径
};

// 参数解析
Config parse_config(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
            config.n = stoll(argv[++i]);
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
            config.c = stoll(argv[++i]);
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
            config.h = stoll(argv[++i]);
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
            config.w = stoll(argv[++i]);
        else if(strcmp(argv[i], "-k") == 0 && i + 1 < argc)
            config.k = stoll(argv[++i]);
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            transform(config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.file_index = stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-o") == 0 && i + 1 < argc)
        {
            config.file_path = argv[++i];
        }
        else
        {
            cerr << "Unknown parameter: " << argv[i] << endl;
            exit(1);
        }
    }
    return config;
}

// 配置校验
void validate_config(const Config& config)
{
    if(config.layout != "NHWC" && config.layout != "NCHW")
    {
        cerr << "Unsupported layout: " << config.layout << ", use NHWC/NCHW" << endl;
        exit(1);
    }
    if(config.dataType != "fp16" && config.dataType != "fp32")
    {
        cerr << "Unsupported data type: " << config.dataType << ", use fp32/fp16" << endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    cout << "build drelu_reduce graph..." << endl;

    // 打印命令行参数
    for(int i = 0; i < argc; ++i)
    {
        cout << argv[i] << " ";
    }
    cout << endl;

    try
    {
        // 解析命令行参数并校验
        Config config = parse_config(argc, argv);
        validate_config(config);

        int64_t n = config.n;
        int64_t c = config.c;
        int64_t h = config.h;
        int64_t w = config.w;
        int64_t k = config.k;
        string data_type = config.dataType;
        string layout = config.layout;

        // 数据类型映射
        hipdnn_frontend::DataType dtype;
        if(data_type == "fp32")
        {
            dtype = hipdnn_frontend::DataType::FLOAT;
        }
        else if(data_type == "fp16")
        {
            dtype = hipdnn_frontend::DataType::HALF;
        }

        // 创建 hipDNN handle
        hipdnnHandle_t handle;
        hipdnnCreate(&handle);

        // 定义并执行计算图构建函数
        auto build_new_graph = [&](hipdnnHandle_t handle) {
            auto graph = make_shared<graph::Graph>();

            graph->set_name("drelu_reduce")
                .set_io_data_type(dtype)
                .set_intermediate_data_type(dtype)
                .set_compute_data_type(hipdnn_frontend::DataType::FLOAT);

            // 计算步长，drelu操作需要两个输入，经过conv fprop后的输出即此处的x和上一次反传回来的梯度dy
            vector<int64_t> x_stride = {h * w * c, 1, w * c, c};
            vector<int64_t> dy_stride = {h * w * k, 1, w * k, k};

            // 输入张量定义，认为X是经过Conv_fprop的输出
            auto X = make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                              .set_name("conv_output")
                                                              .set_dim({n, c, h, w})
                                                              .set_stride(x_stride));

            // 从下一层传来的梯度
            auto DY = make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                               .set_name("grad_output")
                                                               .set_dim({n, k, h, w})
                                                               .set_stride(dy_stride));

            // ReLU反向传播
            auto relu_bwd_options = graph::PointwiseAttributes()
                                        .set_mode(PointwiseMode::RELU_BWD)
                                        .set_name("relu_bwd");
            auto dY_relu = graph->pointwise(DY, X, relu_bwd_options);
            dY_relu->set_output(true);

            // 对drelu的梯度执行reduce操作
            auto reduce_options
                = graph::ReductionAttributes().set_name("reduction").set_mode(ReductionMode_t::ADD);

            vector<int64_t> dbias_dim = {1, k, 1, 1};
            vector<int64_t> dbias_stride = {k, 1, k, 1};
            auto output = graph->reduction(dY_relu, reduce_options);
            output->set_output(true).set_data_type(dtype).set_dim(dbias_dim).set_stride(
                dbias_stride);

            // 验证和构建计算图
            HIPDNN_FE_CHECK(graph->build(handle));

            // 分配GPU内存
            void* inputDevPtr = nullptr;
            void* dyDevPtr = nullptr;
            void* dreluDevPtr = nullptr;
            void* outputDevPtr = nullptr;

            unique_ptr<Tensor<float>> inputTensor_fp32, dyTensor_fp32, dreluTensor_fp32,
                outputTensor_fp32;
            unique_ptr<Tensor<half>> inputTensor_fp16, dyTensor_fp16, dreluTensor_fp16,
                outputTensor_fp16;
            if(data_type == "fp32")
            {
                inputTensor_fp32 = make_unique<Tensor<float>>(X->get_dim(), X->get_stride());
                dyTensor_fp32 = make_unique<Tensor<float>>(DY->get_dim(), DY->get_stride());
                dreluTensor_fp32
                    = make_unique<Tensor<float>>(dY_relu->get_dim(), dY_relu->get_stride());
                outputTensor_fp32
                    = make_unique<Tensor<float>>(output->get_dim(), output->get_stride());

                inputDevPtr = inputTensor_fp32->memory().deviceData();
                dyDevPtr = dyTensor_fp32->memory().deviceData();
                dreluDevPtr = dreluTensor_fp32->memory().deviceData();
                outputDevPtr = outputTensor_fp32->memory().deviceData();
            }
            else
            {
                inputTensor_fp16 = make_unique<Tensor<half>>(X->get_dim(), X->get_stride());
                dyTensor_fp16 = make_unique<Tensor<half>>(DY->get_dim(), DY->get_stride());
                dreluTensor_fp16
                    = make_unique<Tensor<half>>(dY_relu->get_dim(), dY_relu->get_stride());
                outputTensor_fp16
                    = make_unique<Tensor<half>>(output->get_dim(), output->get_stride());

                inputDevPtr = inputTensor_fp16->memory().deviceData();
                dyDevPtr = dyTensor_fp16->memory().deviceData();
                dreluDevPtr = dreluTensor_fp16->memory().deviceData();
                outputDevPtr = outputTensor_fp16->memory().deviceData();
            }

            // 获取workspace大小并分配
            int64_t workspace_size = 0;
            graph->get_workspace_size(workspace_size);
            Workspace workspace(static_cast<size_t>(workspace_size));

            // 绑定张量id和张量在设备端的地址
            unordered_map<int64_t, void*> variant_pack;
            variant_pack[X->get_uid()] = inputDevPtr;
            variant_pack[DY->get_uid()] = dyDevPtr;
            variant_pack[dY_relu->get_uid()] = dreluDevPtr;
            variant_pack[output->get_uid()] = outputDevPtr;

            // 预热执行
            HIPDNN_FE_CHECK(graph->execute(handle, variant_pack, workspace.get()));
            if(data_type == "fp32")
            {
                outputTensor_fp32->memory().markDeviceModified();
            }
            else
            {
                outputTensor_fp16->memory().markDeviceModified();
            }

            // 性能测试
            hipEvent_t start, stop;
            float time;
            HIP_CHECK(hipDeviceSynchronize());
            HIP_CHECK(hipEventCreate(&start));
            HIP_CHECK(hipEventCreate(&stop));
            HIP_CHECK(hipEventRecord(start, nullptr));

            // 执行多次以测量平均时间
            const int iterations = 100;
            for(int i = 0; i < iterations; i++)
            {
                HIPDNN_FE_CHECK(graph->execute(handle, variant_pack, workspace.get()));
            }

            HIP_CHECK(hipEventRecord(stop, nullptr));
            HIP_CHECK(hipEventSynchronize(stop));
            HIP_CHECK(hipEventElapsedTime(&time, start, stop));
            HIP_CHECK(hipEventDestroy(start));
            HIP_CHECK(hipEventDestroy(stop));
            std::cout << "Drelu+reduce time: " << time / iterations << " ms" << std::endl;
            std::cout << "Drelu+reduce graph execution complete. \n";
        };

        // 调用函数
        build_new_graph(handle);

        // 销毁 hipDNN handle
        hipdnnDestroy(handle);
    }
    catch(const exception& e)
    {
        cerr << "错误: " << e.what() << endl;
        return -1;
    }

    cout << "程序执行完毕！" << endl;
    return 0;
}
