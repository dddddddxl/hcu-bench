#include "../utils.hpp"
#include "hipdnn_frontend/attributes/PointwiseAttributes.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// BN融合模式枚举
enum class BNFusionMode
{
    BN_RELU,
    BN_CLIPPEDRELU
};

// 配置结构体
struct Config
{
    int64_t n = 16; // batch size
    int64_t c = 16; // 通道数
    int64_t h = 16; // 高度
    int64_t w = 16; // 宽度
    std::string dataType = "fp32";
    std::string layout = "NCHW";
    bool cpuValidation = false;
    int fileIndex = 0;
    std::string filePath = ".";
    BNFusionMode fusionMode = BNFusionMode::BN_RELU; // 默认模式
    float reluAlpha = 0.25f; // for clipped relu
    float clampMin = 0.0f; // for clamp
    float clampMax = 1.0f; // for clamp
    float epsilon = 1e-5f; // BN epsilon
};

// 融合模式字符串映射
std::unordered_map<std::string, BNFusionMode> bnFusionModeMap
    = {{"bn_relu", BNFusionMode::BN_RELU}, {"bn_clippedrelu", BNFusionMode::BN_CLIPPEDRELU}};

// 融合模式到字符串的转换
std::string bnFusionModeToString(BNFusionMode mode)
{
    for(const auto& pair : bnFusionModeMap)
    {
        if(pair.second == mode)
        {
            return pair.first;
        }
    }
    return "unknown";
}

// 命令行解析（适配BN融合参数）
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--relu-alpha") == 0 && i + 1 < argc)
        {
            config.reluAlpha = std::stof(argv[++i]);
        }
        else if(strcmp(argv[i], "--clamp-min") == 0 && i + 1 < argc)
        {
            config.clampMin = std::stof(argv[++i]);
        }
        else if(strcmp(argv[i], "--clamp-max") == 0 && i + 1 < argc)
        {
            config.clampMax = std::stof(argv[++i]);
        }
        else if(strcmp(argv[i], "--epsilon") == 0 && i + 1 < argc)
        {
            config.epsilon = std::stof(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "-a") == 0 && i + 1 < argc)
        {
            std::string modeStr = argv[++i];
            std::transform(modeStr.begin(), modeStr.end(), modeStr.begin(), ::tolower);
            if(bnFusionModeMap.find(modeStr) != bnFusionModeMap.end())
            {
                config.fusionMode = bnFusionModeMap[modeStr];
            }
            else
            {
                std::cerr << "Unknown BN fusion mode: " << modeStr << std::endl;
                std::cerr << "Available modes: ";
                for(const auto& pair : bnFusionModeMap)
                {
                    std::cerr << pair.first << " ";
                }
                std::cerr << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

class BNFusionRunner
{
public:
    BNFusionRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType, typename IntermediateType>
    void fprop(const TensorLayout& layout)
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        using OutputType
            = std::conditional_t<std::is_same_v<InputType, int8_t>, IntermediateType, InputType>;
        const auto outputType = getDataTypeEnumFromType<OutputType>();

        // 计算张量元素总数
        const size_t xTotalElems
            = static_cast<size_t>(config_.n * config_.c * config_.h * config_.w);
        const size_t bnScalarElems
            = static_cast<size_t>(1 * config_.c * 1 * 1); // scale/bias/mean/var
        const size_t epsilonElems = 1;

        // 创建Graph（复用test_fusion的graph构建流程）
        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_compute_data_type(DataType::FLOAT)
            .set_intermediate_data_type(intermediateType);

        // 创建bninfer_ext张量
        auto xAttr = createTensor(
            {config_.n, config_.c, config_.h, config_.w}, inputType, layout.strideOrder);
        auto scaleAttr = createTensor({1, config_.c, 1, 1}, DataType::FLOAT, layout.strideOrder);
        auto biasAttr = createTensor({1, config_.c, 1, 1}, DataType::FLOAT, layout.strideOrder);
        auto meanAttr = createTensor({1, config_.c, 1, 1}, DataType::FLOAT, layout.strideOrder);
        auto varianceAttr = createTensor({1, config_.c, 1, 1}, DataType::FLOAT, layout.strideOrder);
        auto epsilonAttr = createTensor({1, 1, 1, 1}, DataType::FLOAT, layout.strideOrder);

        // 设置非虚拟张量
        xAttr->set_is_virtual(false);
        scaleAttr->set_is_virtual(false);
        biasAttr->set_is_virtual(false);
        meanAttr->set_is_virtual(false);
        varianceAttr->set_is_virtual(false);
        epsilonAttr->set_is_virtual(false).set_value(config_.epsilon);

        // 构建BN推理节点
        graph::BatchnormInferenceAttributesVarianceExt bnAttributes;
        bnAttributes.set_name("bn_inference_node");
        auto currentOutput = graph->batchnorm_inference_variance_ext(
            xAttr, meanAttr, varianceAttr, scaleAttr, biasAttr, epsilonAttr, bnAttributes);
        currentOutput->set_is_virtual(true).set_data_type(DataType::FLOAT);

        // 根据融合模式添加Pointwise操作
        switch(config_.fusionMode)
        {
        case BNFusionMode::BN_RELU:
        {
            graph::PointwiseAttributes reluAttributes;
            reluAttributes.set_name("relu_node");
            reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
            currentOutput = graph->pointwise(currentOutput, reluAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        break;

        case BNFusionMode::BN_CLIPPEDRELU:
        {
            graph::PointwiseAttributes reluAttributes;
            reluAttributes.set_name("clipped_relu_node");
            reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
            reluAttributes.set_relu_upper_clip(config_.reluAlpha);
            currentOutput = graph->pointwise(currentOutput, reluAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        break;
        }

        // 设置最终输出
        currentOutput->set_output(true).set_data_type(outputType);
        currentOutput->set_is_virtual(false);

        // Graph验证
        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful. Fusion mode: "
                  << bnFusionModeToString(config_.fusionMode) << "\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        // 创建张量并初始化
        Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
        Tensor<InputType> scaleTensor(scaleAttr->get_dim(), scaleAttr->get_stride());
        Tensor<InputType> biasTensor(biasAttr->get_dim(), biasAttr->get_stride());
        Tensor<InputType> meanTensor(meanAttr->get_dim(), meanAttr->get_stride());
        Tensor<InputType> varianceTensor(varianceAttr->get_dim(), varianceAttr->get_stride());
        Tensor<InputType> epsilonTensor(epsilonAttr->get_dim(), epsilonAttr->get_stride());
        Tensor<OutputType> yTensor(currentOutput->get_dim(), currentOutput->get_stride());

        // 初始化输出值
        yTensor.fillWithValue(
            static_cast<OutputType>(std::is_floating_point_v<OutputType> ? 0.0f : 0));

        // 读取或生成数据
        bool readSuccess = false;
        std::vector<InputType> refXData, refScaleData, refBiasData, refMeanData, refVarianceData,
            refEpsilonData;
        std::vector<OutputType> refYData;
        Tensor<OutputType> refYTensor(currentOutput->get_dim(), currentOutput->get_stride());

        if(config_.fileIndex > 0)
        {
            const std::string xFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_input.bin";
            const std::string scaleFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_scale.bin";
            const std::string biasFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bias.bin";
            const std::string meanFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_mean.bin";
            const std::string varianceFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_variance.bin";
            const std::string yFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_output.bin";

            // 读取权重/输入文件
            readSuccess
                = readRawTensor<InputType>(xFilename, refXData, xTotalElems)
                  && readRawTensor<InputType>(scaleFilename, refScaleData, bnScalarElems)
                  && readRawTensor<InputType>(biasFilename, refBiasData, bnScalarElems)
                  && readRawTensor<InputType>(meanFilename, refMeanData, bnScalarElems)
                  && readRawTensor<InputType>(varianceFilename, refVarianceData, bnScalarElems)
                  && readRawTensor<OutputType>(yFilename, refYData, xTotalElems);

            if(readSuccess)
            {
                std::cout << "Successfully read reference files for fusion mode: "
                          << bnFusionModeToString(config_.fusionMode) << "\n";
                std::copy(refXData.begin(), refXData.end(), xTensor.memory().hostData());
                std::copy(
                    refScaleData.begin(), refScaleData.end(), scaleTensor.memory().hostData());
                std::copy(refBiasData.begin(), refBiasData.end(), biasTensor.memory().hostData());
                std::copy(refMeanData.begin(), refMeanData.end(), meanTensor.memory().hostData());
                std::copy(refVarianceData.begin(),
                          refVarianceData.end(),
                          varianceTensor.memory().hostData());
                std::copy(refYData.begin(), refYData.end(), refYTensor.memory().hostData());

                xTensor.memory().markHostModified();
                scaleTensor.memory().markHostModified();
                biasTensor.memory().markHostModified();
                meanTensor.memory().markHostModified();
                varianceTensor.memory().markHostModified();
                refYTensor.memory().markHostModified();
            }
            else
            {
                std::cerr << " [WARN] Failed to read reference files. Using random values.\n";
            }
        }

        // 随机初始化数据
        if(!readSuccess || config_.fileIndex <= 0)
        {
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                xTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                             static_cast<InputType>(127));
                scaleTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                                 static_cast<InputType>(127));
                biasTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                                static_cast<InputType>(127));
                meanTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                                static_cast<InputType>(127));
                varianceTensor.fillWithRandomValues(static_cast<InputType>(1),
                                                    static_cast<InputType>(127));
                epsilonTensor.fillWithValue(static_cast<InputType>(config_.epsilon));
            }
            else
            {
                xTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                             static_cast<InputType>(1.0f));
                scaleTensor.fillWithRandomValues(static_cast<InputType>(0.5f),
                                                 static_cast<InputType>(1.5f));
                biasTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                static_cast<InputType>(1.0f));
                meanTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                static_cast<InputType>(1.0f));
                varianceTensor.fillWithRandomValues(static_cast<InputType>(0.1f),
                                                    static_cast<InputType>(1.0f));
                epsilonTensor.fillWithValue(static_cast<InputType>(config_.epsilon));
            }
        }

        // 绑定设备内存
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
        variantPack[scaleAttr->get_uid()] = scaleTensor.memory().deviceData();
        variantPack[biasAttr->get_uid()] = biasTensor.memory().deviceData();
        variantPack[meanAttr->get_uid()] = meanTensor.memory().deviceData();
        variantPack[varianceAttr->get_uid()] = varianceTensor.memory().deviceData();
        variantPack[epsilonAttr->get_uid()] = epsilonTensor.memory().deviceData();
        variantPack[currentOutput->get_uid()] = yTensor.memory().deviceData();

        // 申请工作空间
        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 预热执行
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        yTensor.memory().markDeviceModified();

        // 计时运行
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "avg times: " << time / 100 << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // 结果验证
        if(config_.fileIndex > 0 && readSuccess)
        {
            bool isMatch = true;
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                const OutputType* refData = refYTensor.memory().hostData();
                const OutputType* currData = yTensor.memory().hostData();

                const size_t printCount = std::min(xTotalElems, static_cast<size_t>(10));
                std::cout << "前" << printCount << "个元素对比（"
                          << bnFusionModeToString(config_.fusionMode) << "）：" << std::endl;
                std::cout << "(refData): ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<int>(refData[i]) << " ";
                }
                std::cout << std::endl;

                std::cout << "(currData): ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<int>(static_cast<int8_t>(currData[i])) << " ";
                }
                std::cout << std::endl;

                // 校验
                for(size_t i = 0; i < xTotalElems; ++i)
                {
                    if(currData[i] != refData[i])
                    {
                        std::cout << "不匹配！索引 " << i
                                  << ": ref(int8)=" << static_cast<int>(refData[i])
                                  << ", curr(原始)=" << static_cast<int>(currData[i]) << std::endl;
                        isMatch = false;
                        break;
                    }
                }
            }
            else
            {
                float tolerance = (config_.dataType == "tf32") ? static_cast<float>(1e-2f)
                                                               : conv::getToleranceFwd<InputType>();
                CpuFpReferenceValidation<InputType> fileValidator(tolerance, tolerance);
                isMatch = fileValidator.allClose(refYTensor, yTensor);
            }
            std::cout << "Validation result (" << bnFusionModeToString(config_.fusionMode)
                      << "): " << (isMatch ? "successful" : "failed") << "\n";
        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;
};

// 根据参数选择执行类型
void run(hipdnnHandle_t handle, const Config& config)
{
    TensorLayout layout = (config.layout == "NHWC") ? TensorLayout::NHWC : TensorLayout::NCHW;

    if(config.dataType == "fp32")
    {
        BNFusionRunner runner(handle, config);
        runner.template fprop<float, float>(layout);
    }
    else if(config.dataType == "fp16")
    {
        BNFusionRunner runner(handle, config);
        runner.template fprop<half, float>(layout);
    }
    else if(config.dataType == "bfp16")
    {
        BNFusionRunner runner(handle, config);
        runner.template fprop<bfloat16, float>(layout);
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

// 主函数
int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));
    run(handle, config);
    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
