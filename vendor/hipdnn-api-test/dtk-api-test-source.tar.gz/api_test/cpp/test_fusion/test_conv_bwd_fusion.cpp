#include "../utils.hpp"
#include "hipdnn_frontend/attributes/PointwiseAttributes.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// ==================== 枚举定义 ====================
enum class ActivationType
{
    RELU,
    PRELU,
    LEAKYRELU,
    CLIPPEDRELU,
    SWISH,
    SIGMOID,
    ELU,
    TANH,
    GELU,
    GELU_APPROX_TANH
};

enum class FusionMode
{
    CONV_BWD_BIAS,
    CONV_BWD_BIAS_ADD,
    CONV_BWD_BIAS_ACT,
    CONV_BWD_BIAS_ACT_ADD,
    CONV_BWD_BIAS_ADD_ACT
};

// ==================== 辅助映射 ====================
std::unordered_map<std::string, ActivationType> activationMap
    = {{"relu", ActivationType::RELU},
       {"prelu", ActivationType::PRELU},
       {"leakyrelu", ActivationType::LEAKYRELU},
       {"clippedrelu", ActivationType::CLIPPEDRELU},
       {"swish", ActivationType::SWISH},
       {"sigmoid", ActivationType::SIGMOID},
       {"elu", ActivationType::ELU},
       {"tanh", ActivationType::TANH},
       {"gelu", ActivationType::GELU},
       {"gelu_approx_tanh", ActivationType::GELU_APPROX_TANH}};

std::unordered_map<std::string, FusionMode> fusionModeMap
    = {{"conv_bwd_bias", FusionMode::CONV_BWD_BIAS},
       {"conv_bwd_bias_add", FusionMode::CONV_BWD_BIAS_ADD},
       {"conv_bwd_bias_act", FusionMode::CONV_BWD_BIAS_ACT},
       {"conv_bwd_bias_act_add", FusionMode::CONV_BWD_BIAS_ACT_ADD},
       {"conv_bwd_bias_add_act", FusionMode::CONV_BWD_BIAS_ADD_ACT}};

std::string fusionModeToString(FusionMode mode)
{
    for(const auto& pair : fusionModeMap)
        if(pair.second == mode)
            return pair.first;
    return "unknown";
}

// ==================== 配置结构体 ====================
struct Config
{
    int64_t n = 1, c = 128, h = 28, w = 28, k = 12, r = 3, s = 3;
    int64_t padH = 1, padW = 1, u = 1, v = 1, dilH = 1, dilW = 1;
    std::string dataType = "fp16", layout = "NHWC";
    bool cpuValidation = false;
    int fileIndex = 0;
    std::string filePath = ".";
    FusionMode fusionMode = FusionMode::CONV_BWD_BIAS_ADD_ACT;
    ActivationType actType = ActivationType::RELU;
    float reluAlpha = 0.25f;
};

// ==================== 命令行解析 ====================
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        std::string arg = argv[i];
        if(arg == "-n" && i + 1 < argc)
            config.n = std::stoll(argv[++i]);
        else if(arg == "-c" && i + 1 < argc)
            config.c = std::stoll(argv[++i]);
        else if(arg == "-H" && i + 1 < argc)
            config.h = std::stoll(argv[++i]);
        else if(arg == "-W" && i + 1 < argc)
            config.w = std::stoll(argv[++i]);
        else if(arg == "-k" && i + 1 < argc)
            config.k = std::stoll(argv[++i]);
        else if(arg == "-y" && i + 1 < argc)
            config.r = std::stoll(argv[++i]);
        else if(arg == "-x" && i + 1 < argc)
            config.s = std::stoll(argv[++i]);
        else if(arg == "-p" && i + 1 < argc)
            config.padH = std::stoll(argv[++i]);
        else if(arg == "-q" && i + 1 < argc)
            config.padW = std::stoll(argv[++i]);
        else if(arg == "-u" && i + 1 < argc)
            config.u = std::stoll(argv[++i]);
        else if(arg == "-v" && i + 1 < argc)
            config.v = std::stoll(argv[++i]);
        else if(arg == "-l" && i + 1 < argc)
            config.dilH = std::stoll(argv[++i]);
        else if(arg == "-j" && i + 1 < argc)
            config.dilW = std::stoll(argv[++i]);
        else if(arg == "--relu-alpha" && i + 1 < argc)
            config.reluAlpha = std::stof(argv[++i]);
        else if(arg == "-d" && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(arg == "-L" && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(arg == "--op-mode" && i + 1 < argc)
        {
            std::string modeStr = argv[++i];
            std::transform(modeStr.begin(), modeStr.end(), modeStr.begin(), ::tolower);
            if(fusionModeMap.find(modeStr) != fusionModeMap.end())
                config.fusionMode = fusionModeMap[modeStr];
            else
            {
                std::cerr << "Unknown op-mode: " << modeStr << std::endl;
                exit(1);
            }
        }
        else if(arg == "--activation" && i + 1 < argc)
        {
            std::string actStr = argv[++i];
            std::transform(actStr.begin(), actStr.end(), actStr.begin(), ::tolower);
            if(activationMap.find(actStr) != activationMap.end())
                config.actType = activationMap[actStr];
            else
            {
                std::cerr << "Unknown activation: " << actStr << std::endl;
                exit(1);
            }
        }
        else if(arg == "--cpu-validation")
            config.cpuValidation = true;
        else if(arg == "-i" && i + 1 < argc)
            config.fileIndex = std::stoi(argv[++i]);
        else if(arg == "-path" && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
                config.filePath += "/";
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

class ConvRunner
{
public:
    ConvRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType, typename IntermediateType>
    void bprop(const TensorLayout& layout)
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();
        using OutputType
            = std::conditional_t<std::is_same_v<InputType, int8_t>, IntermediateType, InputType>;
        const auto outputType = getDataTypeEnumFromType<OutputType>();

        const int64_t H_in
            = (config_.h - 1) * config_.u - 2 * config_.padH + config_.dilH * (config_.r - 1) + 1;
        const int64_t W_in
            = (config_.w - 1) * config_.v - 2 * config_.padW + config_.dilW * (config_.s - 1) + 1;
        const size_t dlossTotalElems
            = static_cast<size_t>(config_.n * config_.c * config_.h * config_.w);
        const size_t wTotalElems
            = static_cast<size_t>(config_.k * config_.c * config_.r * config_.s);
        const size_t dxTotalElems = static_cast<size_t>(config_.n * config_.k * H_in * W_in);

        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_compute_data_type(DataType::FLOAT)
            .set_intermediate_data_type(intermediateType);

        auto dlossAttr = createTensor(
            {config_.n, config_.c, config_.h, config_.w}, inputType, layout.strideOrder);
        auto wAttr = createTensor(
            {config_.c, config_.k, config_.r, config_.s}, inputType, layout.strideOrder);
        dlossAttr->set_is_virtual(false);
        wAttr->set_is_virtual(false);

        graph::ConvDgradAttributes convAttributes;
        convAttributes.set_name("conv_backward_node")
            .set_padding({config_.padH, config_.padW})
            .set_stride({config_.u, config_.v})
            .set_dilation({config_.dilH, config_.dilW});
        auto currentOutput = graph->conv_dgrad(dlossAttr, wAttr, convAttributes);
        currentOutput->set_is_virtual(true).set_data_type(inputType).set_dim(
            {config_.n, config_.k, H_in, W_in});

        auto biasAttr = createTensor({1, config_.k, 1, 1}, inputType, layout.strideOrder);
        biasAttr->set_is_virtual(false);
        graph::PointwiseAttributes addBiasAttr;
        addBiasAttr.set_name("bias_grad_node").set_mode(PointwiseMode_t::ADD);
        currentOutput = graph->pointwise(currentOutput, biasAttr, addBiasAttr);
        currentOutput->set_is_virtual(true).set_data_type(inputType);

        // Lambda 添加激活节点
        auto addActivation = [&](const std::shared_ptr<graph::Tensor_attributes>& input,
                                 ActivationType actType,
                                 float alpha,
                                 const std::string& name) {
            graph::PointwiseAttributes attr;
            attr.set_name(name);
            switch(actType)
            {
            case ActivationType::RELU:
                attr.set_mode(PointwiseMode_t::RELU_FWD);
                break;
            case ActivationType::PRELU:
                attr.set_mode(PointwiseMode_t::PRELU_FWD);
                attr.set_elu_alpha(alpha);
                break;
            case ActivationType::LEAKYRELU:
                attr.set_mode(PointwiseMode_t::RELU_FWD);
                attr.set_relu_lower_clip_slope(alpha);
                break;
            case ActivationType::CLIPPEDRELU:
                attr.set_mode(PointwiseMode_t::RELU_FWD);
                attr.set_relu_upper_clip(alpha);
                break;
            case ActivationType::SWISH:
                attr.set_mode(PointwiseMode_t::SWISH_FWD);
                break;
            case ActivationType::SIGMOID:
                attr.set_mode(PointwiseMode_t::SIGMOID_FWD);
                break;
            case ActivationType::ELU:
                attr.set_mode(PointwiseMode_t::ELU_FWD);
                attr.set_elu_alpha(alpha);
                break;
            case ActivationType::TANH:
                attr.set_mode(PointwiseMode_t::TANH_FWD);
                break;
            case ActivationType::GELU:
                attr.set_mode(PointwiseMode_t::GELU_FWD);
                break;
            case ActivationType::GELU_APPROX_TANH:
                attr.set_mode(PointwiseMode_t::GELU_APPROX_TANH_FWD);
                break;
            default:
                return input;
            }
            return graph->pointwise(input, attr);
        };

        std::shared_ptr<graph::Tensor_attributes> addAttr = nullptr;
        size_t addTotalElems = 0;

        bool needAdd = false, needAct = false, actBeforeAdd = false;
        switch(config_.fusionMode)
        {
        case FusionMode::CONV_BWD_BIAS:
            break;
        case FusionMode::CONV_BWD_BIAS_ADD:
            needAdd = true;
            break;
        case FusionMode::CONV_BWD_BIAS_ACT:
            needAct = true;
            break;
        case FusionMode::CONV_BWD_BIAS_ACT_ADD:
            needAct = true;
            needAdd = true;
            actBeforeAdd = true;
            break;
        case FusionMode::CONV_BWD_BIAS_ADD_ACT:
            needAdd = true;
            needAct = true;
            actBeforeAdd = false;
            break;
        default:
            throw std::runtime_error("Unsupported fusion mode");
        }

        if(needAdd)
        {
            addAttr
                = createTensor({config_.n, config_.k, H_in, W_in}, inputType, layout.strideOrder);
            addAttr->set_is_virtual(false);
            addTotalElems = static_cast<size_t>(config_.n * config_.k * H_in * W_in);
        }

        if(needAct && actBeforeAdd)
        {
            currentOutput = addActivation(
                currentOutput, config_.actType, config_.reluAlpha, "activation_node");
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        if(needAdd)
        {
            graph::PointwiseAttributes addAttributes;
            addAttributes.set_name("add_node").set_mode(PointwiseMode_t::ADD);
            currentOutput = graph->pointwise(currentOutput, addAttr, addAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        if(needAct && !actBeforeAdd)
        {
            currentOutput = addActivation(
                currentOutput, config_.actType, config_.reluAlpha, "activation_node");
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }

        currentOutput->set_output(true).set_data_type(outputType);
        currentOutput->set_is_virtual(false);

        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful. Fusion mode: "
                  << fusionModeToString(config_.fusionMode) << "\n";
        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        HIPDNN_FE_CHECK(graph->create_execution_plans());
        HIPDNN_FE_CHECK(graph->check_support());
        HIPDNN_FE_CHECK(graph->build_plans());

        // 创建张量（使用指针处理可选的 addTensor）
        Tensor<InputType> dlossTensor(dlossAttr->get_dim(), dlossAttr->get_stride());
        Tensor<InputType> wTensor(wAttr->get_dim(), wAttr->get_stride());
        Tensor<OutputType> dxTensor(currentOutput->get_dim(), currentOutput->get_stride());
        Tensor<InputType> biasTensor(biasAttr->get_dim(), biasAttr->get_stride());
        Tensor<InputType>* addTensorPtr = nullptr;
        if(addAttr)
            addTensorPtr = new Tensor<InputType>(addAttr->get_dim(), addAttr->get_stride());

        Tensor<OutputType> refDxTensor(currentOutput->get_dim(), currentOutput->get_stride());

        // 数据初始化（从文件或随机）
        bool readSuccess = false;
        std::vector<InputType> refDlossData, refWData, refBiasData, refAddData;
        std::vector<OutputType> refDxData;

        if(config_.fileIndex > 0)
        {
            const std::string dlossFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_dloss.bin";
            const std::string wFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_weight.bin";
            const std::string dxFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_dx.bin";
            readSuccess = readRawTensor<InputType>(dlossFilename, refDlossData, dlossTotalElems)
                          && readRawTensor<InputType>(wFilename, refWData, wTotalElems)
                          && readRawTensor<OutputType>(dxFilename, refDxData, dxTotalElems);
            if(readSuccess)
            {
                std::cout << "Successfully read bprop reference files.\n";
                std::copy(
                    refDlossData.begin(), refDlossData.end(), dlossTensor.memory().hostData());
                dlossTensor.memory().markHostModified();
                std::copy(refWData.begin(), refWData.end(), wTensor.memory().hostData());
                wTensor.memory().markHostModified();
                std::copy(refDxData.begin(), refDxData.end(), refDxTensor.memory().hostData());
                refDxTensor.memory().markHostModified();
            }
            // bias
            std::string biasFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bias_grad.bin";
            size_t biasTotalElems = static_cast<size_t>(1 * config_.c * 1 * 1);
            if(readRawTensor<InputType>(biasFilename, refBiasData, biasTotalElems))
            {
                std::copy(refBiasData.begin(), refBiasData.end(), biasTensor.memory().hostData());
                biasTensor.memory().markHostModified();
            }
            else
            {
                std::cerr << " [WARN] Failed to read bias grad file. Using random values.\n";
                if constexpr(std::is_same_v<InputType, int8_t>)
                    biasTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                                    static_cast<InputType>(127));
                else
                    biasTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                    static_cast<InputType>(1.0f));
            }
            // add
            if(addTensorPtr)
            {
                std::string addFilename
                    = config_.filePath + std::to_string(config_.fileIndex) + "_add_grad.bin";
                if(readRawTensor<InputType>(addFilename, refAddData, addTotalElems))
                {
                    std::copy(
                        refAddData.begin(), refAddData.end(), addTensorPtr->memory().hostData());
                    addTensorPtr->memory().markHostModified();
                }
                else
                {
                    std::cerr << " [WARN] Failed to read add grad file. Using random values.\n";
                    if constexpr(std::is_same_v<InputType, int8_t>)
                        addTensorPtr->fillWithRandomValues(static_cast<InputType>(-127),
                                                           static_cast<InputType>(127));
                    else
                        addTensorPtr->fillWithRandomValues(static_cast<InputType>(0.0f),
                                                           static_cast<InputType>(1.0f));
                }
            }
        }

        if(!readSuccess)
        {
            std::cout << "Generating random input data.\n";
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                dlossTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                                 static_cast<InputType>(127));
                wTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                             static_cast<InputType>(127));
                biasTensor.fillWithRandomValues(static_cast<InputType>(-127),
                                                static_cast<InputType>(127));
                if(addTensorPtr)
                    addTensorPtr->fillWithRandomValues(static_cast<InputType>(-127),
                                                       static_cast<InputType>(127));
            }
            else
            {
                dlossTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                 static_cast<InputType>(1.0f));
                wTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                             static_cast<InputType>(1.0f));
                biasTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                static_cast<InputType>(1.0f));
                if(addTensorPtr)
                    addTensorPtr->fillWithRandomValues(static_cast<InputType>(0.0f),
                                                       static_cast<InputType>(1.0f));
            }
        }

        // 绑定设备内存
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[dlossAttr->get_uid()] = dlossTensor.memory().deviceData();
        variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
        variantPack[biasAttr->get_uid()] = biasTensor.memory().deviceData();
        if(addTensorPtr)
            variantPack[addAttr->get_uid()] = addTensorPtr->memory().deviceData();
        variantPack[currentOutput->get_uid()] = dxTensor.memory().deviceData();

        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        dxTensor.memory().markDeviceModified();

        // 计时
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));
        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "avg times: " << time / 100 << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // 文件验证
        if(config_.fileIndex > 0 && readSuccess)
        {
            bool isMatch = true;
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                const OutputType* refData = refDxTensor.memory().hostData();
                const OutputType* currData = dxTensor.memory().hostData();
                for(int64_t i = 0; i < dxTotalElems; ++i)
                {
                    if(currData[i] != refData[i])
                    {
                        isMatch = false;
                        break;
                    }
                }
            }
            else
            {
                float tolerance
                    = (config_.dataType == "tf32") ? 1e-2f : conv::getToleranceFwd<InputType>();
                CpuFpReferenceValidation<InputType> fileValidator(tolerance, tolerance);
                isMatch = fileValidator.allClose(refDxTensor, dxTensor);
            }
            std::cout << "hipdnn validation result: " << (isMatch ? "successful" : "failed")
                      << "\n";
        }

        // CPU 验证
        if(config_.cpuValidation && !std::is_same_v<InputType, int8_t>)
        {
            std::unordered_map<int64_t, void*> cpuVariantPack;
            cpuVariantPack[dlossAttr->get_uid()] = dlossTensor.memory().hostData();
            cpuVariantPack[wAttr->get_uid()] = wTensor.memory().hostData();
            cpuVariantPack[biasAttr->get_uid()] = biasTensor.memory().hostData();
            if(addTensorPtr)
                cpuVariantPack[addAttr->get_uid()] = addTensorPtr->memory().hostData();
            cpuVariantPack[currentOutput->get_uid()] = refDxTensor.memory().hostData();

            auto serializedGraph = graph->to_binary().first;
            CpuReferenceGraphExecutor cpuExecutor;
            cpuExecutor.execute(serializedGraph.data(), serializedGraph.size(), cpuVariantPack);

            float tolerance
                = (config_.dataType == "tf32") ? 1e-2f : conv::getToleranceFwd<InputType>();
            CpuFpReferenceValidation<InputType> dxValidator(tolerance, tolerance);
            bool dxValid = dxValidator.allClose(refDxTensor, dxTensor);
            std::cout << "CPU validation result: " << (dxValid ? "successful" : "failed") << "\n";
        }

        if(addTensorPtr)
            delete addTensorPtr;
    }

private:
    hipdnnHandle_t handle_;
    Config config_;
};

void run(hipdnnHandle_t handle, const Config& config)
{
    TensorLayout layout = (config.layout == "NHWC") ? TensorLayout::NHWC : TensorLayout::NCHW;
    if(config.dataType == "fp32" || config.dataType == "tf32")
    {
        ConvRunner runner(handle, config);
        runner.bprop<float, float>(layout);
    }
    else if(config.dataType == "fp16")
    {
        ConvRunner runner(handle, config);
        runner.bprop<half, float>(layout);
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
        std::cout << argv[i] << " ";
    std::cout << '\n';
    auto config = parseCommandLineArgs(argc, argv);
    initializeFrontendLogging();
    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));
    run(handle, config);
    HIPDNN_CHECK(hipdnnDestroy(handle));
    return 0;
}
