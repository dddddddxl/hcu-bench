#include <algorithm>
#include <cstring>
#include <iostream>
#include <memory>
#include <random>
#include <tuple>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>

#include "../utils.hpp"
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// ==================== 枚举定义 ====================
enum class ActivationType
{
    RELU,
    PRELU,
    LEAKYRELU,
    CLIPPEDRELU,
    SWISH,
    SIGMOID,
    ELU,
    TANH,
    GELU,
    GELU_APPROX_TANH
};

enum class FusionMode
{
    CONCAT_CONV, // concat + convFwd
    CONCAT_CONV_BIAS, // concat + convFwd + bias
    CONCAT_CONV_BIAS_ADD, // concat + convFwd + bias + add
    CONCAT_CONV_BIAS_ACT, // concat + convFwd + bias + act
    CONCAT_CONV_BIAS_ACT_ADD // concat + convFwd + bias + act + add
};

// ==================== 辅助映射 ====================
std::unordered_map<std::string, ActivationType> activationMap
    = {{"relu", ActivationType::RELU},
       {"prelu", ActivationType::PRELU},
       {"leakyrelu", ActivationType::LEAKYRELU},
       {"clippedrelu", ActivationType::CLIPPEDRELU},
       {"swish", ActivationType::SWISH},
       {"sigmoid", ActivationType::SIGMOID},
       {"elu", ActivationType::ELU},
       {"tanh", ActivationType::TANH},
       {"gelu", ActivationType::GELU},
       {"gelu_approx_tanh", ActivationType::GELU_APPROX_TANH}};

std::unordered_map<std::string, FusionMode> fusionModeMap
    = {{"concat_conv", FusionMode::CONCAT_CONV},
       {"concat_conv_bias", FusionMode::CONCAT_CONV_BIAS},
       {"concat_conv_bias_add", FusionMode::CONCAT_CONV_BIAS_ADD},
       {"concat_conv_bias_act", FusionMode::CONCAT_CONV_BIAS_ACT},
       {"concat_conv_bias_act_add", FusionMode::CONCAT_CONV_BIAS_ACT_ADD}};

std::string fusionModeToString(FusionMode mode)
{
    for(const auto& pair : fusionModeMap)
        if(pair.second == mode)
            return pair.first;
    return "unknown";
}

std::string activationToString(ActivationType act)
{
    for(const auto& pair : activationMap)
        if(pair.second == act)
            return pair.first;
    return "unknown";
}

// ==================== 配置结构体 ====================
struct Config
{
    int64_t n = 1, c = 32, h = 128, w = 128, k = 32, r = 2, s = 2;
    int64_t padH = 1, padW = 1, u = 1, v = 1, dilH = 1, dilW = 1;
    int64_t axis = 1;
    int64_t concatX = 8;
    std::string dataType = "fp16", layout = "NCHW";
    bool cpuValidation = false;
    FusionMode fusionMode = FusionMode::CONCAT_CONV_BIAS_ACT_ADD;
    ActivationType actType = ActivationType::RELU;
    float reluAlpha = 0.2f;
};

// ==================== 命令行解析 ====================
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        std::string arg = argv[i];
        if(arg == "-n" && i + 1 < argc)
            config.n = std::stoll(argv[++i]);
        else if(arg == "-c" && i + 1 < argc)
            config.c = std::stoll(argv[++i]);
        else if(arg == "-H" && i + 1 < argc)
            config.h = std::stoll(argv[++i]);
        else if(arg == "-W" && i + 1 < argc)
            config.w = std::stoll(argv[++i]);
        else if(arg == "-k" && i + 1 < argc)
            config.k = std::stoll(argv[++i]);
        else if(arg == "-y" && i + 1 < argc)
            config.r = std::stoll(argv[++i]);
        else if(arg == "-x" && i + 1 < argc)
            config.s = std::stoll(argv[++i]);
        else if(arg == "-p" && i + 1 < argc)
            config.padH = std::stoll(argv[++i]);
        else if(arg == "-q" && i + 1 < argc)
            config.padW = std::stoll(argv[++i]);
        else if(arg == "-u" && i + 1 < argc)
            config.u = std::stoll(argv[++i]);
        else if(arg == "-v" && i + 1 < argc)
            config.v = std::stoll(argv[++i]);
        else if(arg == "-l" && i + 1 < argc)
            config.dilH = std::stoll(argv[++i]);
        else if(arg == "-j" && i + 1 < argc)
            config.dilW = std::stoll(argv[++i]);
        else if(arg == "-axis" && i + 1 < argc)
            config.axis = std::stoll(argv[++i]);
        else if(arg == "-concatX" && i + 1 < argc)
            config.concatX = std::stoll(argv[++i]);
        else if(arg == "--relu-alpha" && i + 1 < argc)
            config.reluAlpha = std::stof(argv[++i]);
        else if(arg == "-d" && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(arg == "-L" && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(arg == "--op-mode" && i + 1 < argc)
        {
            std::string modeStr = argv[++i];
            std::transform(modeStr.begin(), modeStr.end(), modeStr.begin(), ::tolower);
            if(fusionModeMap.find(modeStr) != fusionModeMap.end())
                config.fusionMode = fusionModeMap[modeStr];
            else
            {
                std::cerr << "Unknown op-mode: " << modeStr << std::endl;
                exit(1);
            }
        }
        else if(arg == "--activation" && i + 1 < argc)
        {
            std::string actStr = argv[++i];
            std::transform(actStr.begin(), actStr.end(), actStr.begin(), ::tolower);
            if(activationMap.find(actStr) != activationMap.end())
                config.actType = activationMap[actStr];
            else
            {
                std::cerr << "Unknown activation: " << actStr << std::endl;
                exit(1);
            }
        }
        else if(arg == "--cpu-validation")
            config.cpuValidation = true;
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    if(config.layout != "NCHW" && config.layout != "NHWC")
    {
        std::cerr << "Error: Layout must be NCHW or NHWC" << std::endl;
        exit(1);
    }
    return config;
}

// ==================== 张量工具函数 ====================
std::tuple<std::vector<int64_t>, std::vector<int64_t>>
    getTensorShapeAndStride(const std::string& layout, int64_t n, int64_t c, int64_t h, int64_t w)
{
    std::vector<int64_t> dims = {n, c, h, w};
    std::vector<int64_t> strides;
    if(layout == "NCHW")
    {
        strides = {h * w * c, w * h, w, 1};
    }
    else
    {
        strides = {c * h * w, 1, c * w, c};
    }
    return {dims, strides};
}

std::tuple<std::vector<int64_t>, std::vector<int64_t>>
    getFilterShapeAndStride(const std::string& layout, int64_t k, int64_t c, int64_t r, int64_t s)
{
    std::vector<int64_t> dims = {k, c, r, s};
    std::vector<int64_t> strides;
    if(layout == "NCHW")
    {
        strides = {r * s * c, s * c, c, 1};
    }
    else
    {
        strides = {c * r * s, 1, c * s, c};
    }
    return {dims, strides};
}

std::tuple<int64_t, int64_t> convOutputSize(int64_t h,
                                            int64_t w,
                                            int64_t r,
                                            int64_t s,
                                            int64_t padH,
                                            int64_t padW,
                                            int64_t u,
                                            int64_t v,
                                            int64_t dilH,
                                            int64_t dilW)
{
    int64_t oh = (h + 2 * padH - dilH * (r - 1) - 1) / u + 1;
    int64_t ow = (w + 2 * padW - dilW * (s - 1) - 1) / v + 1;
    return {oh, ow};
}

// ==================== 核心 Runner ====================
class ConcatConvRunner
{
private:
    Config config_;

    void setupActivationAttributes(ActivationType act, graph::PointwiseAttributes& attrs) const
    {
        switch(act)
        {
        case ActivationType::RELU:
            attrs.set_mode(PointwiseMode_t::RELU_FWD);
            break;
        case ActivationType::LEAKYRELU:
            attrs.set_mode(PointwiseMode_t::RELU_FWD);
            attrs.set_relu_lower_clip_slope(config_.reluAlpha);
            break;
        case ActivationType::CLIPPEDRELU:
            attrs.set_mode(PointwiseMode_t::RELU_FWD);
            attrs.set_relu_upper_clip(config_.reluAlpha);
            break;
        case ActivationType::SWISH:
            attrs.set_mode(PointwiseMode_t::SWISH_FWD);
            break;
        case ActivationType::SIGMOID:
            attrs.set_mode(PointwiseMode_t::SIGMOID_FWD);
            break;
        case ActivationType::ELU:
            attrs.set_mode(PointwiseMode_t::ELU_FWD);
            attrs.set_elu_alpha(config_.reluAlpha);
            break;
        case ActivationType::TANH:
            attrs.set_mode(PointwiseMode_t::TANH_FWD);
            break;
        case ActivationType::GELU:
            attrs.set_mode(PointwiseMode_t::GELU_FWD);
            break;
        case ActivationType::GELU_APPROX_TANH:
            attrs.set_mode(PointwiseMode_t::GELU_APPROX_TANH_FWD);
            break;
        case ActivationType::PRELU:
            attrs.set_mode(PointwiseMode_t::PRELU_FWD);
            attrs.set_relu_lower_clip_slope(config_.reluAlpha);
            break;
        default:
            break;
        }
    }

    bool hasBias() const
    {
        return (config_.fusionMode != FusionMode::CONCAT_CONV);
    }

    bool hasActivation() const
    {
        return (config_.fusionMode == FusionMode::CONCAT_CONV_BIAS_ACT
                || config_.fusionMode == FusionMode::CONCAT_CONV_BIAS_ACT_ADD);
    }

    bool hasAdd() const
    {
        return (config_.fusionMode == FusionMode::CONCAT_CONV_BIAS_ADD
                || config_.fusionMode == FusionMode::CONCAT_CONV_BIAS_ACT_ADD);
    }

public:
    ConcatConvRunner(const Config& config)
        : config_(config)
    {
    }

    template <typename InputType, typename ComputeType>
    void operator()()
    {
        // 计算输出尺寸
        int64_t oh, ow;
        std::tie(oh, ow) = convOutputSize(config_.h,
                                          config_.w,
                                          config_.r,
                                          config_.s,
                                          config_.padH,
                                          config_.padW,
                                          config_.u,
                                          config_.v,
                                          config_.dilH,
                                          config_.dilW);

        auto buildGraph = [&, oh, ow](hipdnnHandle_t handle) {
            auto graph = std::make_shared<graph::Graph>();
            const auto inputType = getDataTypeEnumFromType<InputType>();

            graph->set_name("ConcatConvForward")
                .set_io_data_type(inputType)
                .set_intermediate_data_type(inputType)
                .set_compute_data_type(getDataTypeEnumFromType<ComputeType>());

            // 输入 x1, x2
            auto [x1_dims, x1_strides] = getTensorShapeAndStride(
                config_.layout, config_.n, config_.c, config_.h, config_.w);
            auto [x2_dims, x2_strides] = getTensorShapeAndStride(
                config_.layout, config_.n, config_.concatX, config_.h, config_.w);

            auto x1 = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                    .set_name("x1")
                                                                    .set_dim(x1_dims)
                                                                    .set_stride(x1_strides)
                                                                    .set_data_type(inputType));
            auto x2 = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                    .set_name("x2")
                                                                    .set_dim(x2_dims)
                                                                    .set_stride(x2_strides)
                                                                    .set_data_type(inputType));

            // Concat 操作
            auto concatAttrs = graph::ConcatenateAttributes().set_axis(config_.axis);
            auto concatOut = graph->concatenate({x1, x2}, concatAttrs);
            concatOut->set_is_virtual(true).set_data_type(inputType);

            int64_t c_concat = config_.c + config_.concatX;

            // 卷积滤波器
            auto [filter_dims, filter_strides] = getFilterShapeAndStride(
                config_.layout, config_.k, c_concat, config_.r, config_.s);
            auto filter = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                        .set_name("filter")
                                                                        .set_dim(filter_dims)
                                                                        .set_stride(filter_strides)
                                                                        .set_data_type(inputType));

            // 卷积操作
            auto convAttrs = graph::ConvFpropAttributes()
                                 .set_name("conv_fprop")
                                 .set_padding({config_.padH, config_.padW})
                                 .set_stride({config_.u, config_.v})
                                 .set_dilation({config_.dilH, config_.dilW});
            auto current = graph->conv_fprop(concatOut, filter, convAttrs);
            current->set_is_virtual(true).set_data_type(inputType);

            // Bias (如果需要)
            std::shared_ptr<graph::TensorAttributes> biasAttr = nullptr;
            if(hasBias())
            {
                std::vector<int64_t> bias_dims = {1, config_.k, 1, 1};
                std::vector<int64_t> bias_strides = {config_.k, 1, 1, 1};
                biasAttr = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                         .set_name("bias")
                                                                         .set_dim(bias_dims)
                                                                         .set_stride(bias_strides)
                                                                         .set_data_type(inputType));
                biasAttr->set_is_virtual(false);
                graph::PointwiseAttributes addBias;
                addBias.set_name("add_bias").set_mode(PointwiseMode_t::ADD);
                current = graph->pointwise(current, biasAttr, addBias);
                current->set_is_virtual(true).set_data_type(inputType);
            }

            // Add 张量 (如果需要)
            std::shared_ptr<graph::TensorAttributes> addTensorAttr = nullptr;
            if(hasAdd())
            {
                std::vector<int64_t> add_dims = {config_.n, config_.k, oh, ow};
                std::vector<int64_t> add_strides;
                if(config_.layout == "NCHW")
                {
                    add_strides = {oh * ow * config_.k, ow * oh, ow, 1};
                }
                else
                {
                    add_strides = {config_.k * oh * ow, 1, config_.k * ow, config_.k};
                }
                addTensorAttr
                    = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                    .set_name("add_tensor")
                                                                    .set_dim(add_dims)
                                                                    .set_stride(add_strides)
                                                                    .set_data_type(inputType));
                addTensorAttr->set_is_virtual(false);
            }

            // 添加激活 (如果需要)
            if(hasActivation())
            {
                graph::PointwiseAttributes actOp;
                actOp.set_name("activation");
                setupActivationAttributes(config_.actType, actOp);
                current = graph->pointwise(current, actOp);
                current->set_is_virtual(true).set_data_type(inputType);
            }

            // 添加加法 (如果需要) - 注意：顺序为先激活后加法
            if(hasAdd())
            {
                graph::PointwiseAttributes addOp;
                addOp.set_name("add_op").set_mode(PointwiseMode_t::ADD);
                current = graph->pointwise(current, addTensorAttr, addOp);
                current->set_is_virtual(true).set_data_type(inputType);
            }

            current->set_output(true).set_is_virtual(false).set_data_type(inputType);

            HIPDNN_FE_CHECK(graph->validate());
            HIPDNN_FE_CHECK(graph->build_operation_graph(handle));
            HIPDNN_FE_CHECK(graph->create_execution_plans());
            HIPDNN_FE_CHECK(graph->check_support());
            HIPDNN_FE_CHECK(graph->build_plans());

            return std::make_tuple(graph, x1, x2, filter, biasAttr, addTensorAttr, current);
        };

        auto backend = hipdnn_frontend::detail::hipdnnBackend();
        if(!backend)
        {
            std::cout << "Create backend failed.\n";
            return;
        }
        hipdnnHandle_t handle;
        HIPDNN_CHECK(backend->create(&handle));

        auto [graph, x1, x2, filter, biasAttr, addAttr, y] = buildGraph(handle);

        // 分配 GPU 内存
        Tensor<InputType> x1Tensor(x1->get_dim(), x1->get_stride());
        Tensor<InputType> x2Tensor(x2->get_dim(), x2->get_stride());
        Tensor<InputType> filterTensor(filter->get_dim(), filter->get_stride());
        Tensor<InputType> yTensor(y->get_dim(), y->get_stride());
        std::unique_ptr<Tensor<InputType>> biasTensorPtr = nullptr;
        std::unique_ptr<Tensor<InputType>> addTensorPtr = nullptr;

        if(biasAttr)
            biasTensorPtr
                = std::make_unique<Tensor<InputType>>(biasAttr->get_dim(), biasAttr->get_stride());
        if(addAttr)
            addTensorPtr
                = std::make_unique<Tensor<InputType>>(addAttr->get_dim(), addAttr->get_stride());

        auto fillRandom = [](auto& t) {
            t.fillWithRandomValues(static_cast<InputType>(-1.0f), static_cast<InputType>(1.0f));
        };
        fillRandom(x1Tensor);
        fillRandom(x2Tensor);
        fillRandom(filterTensor);
        if(biasTensorPtr)
            fillRandom(*biasTensorPtr);
        if(addTensorPtr)
            fillRandom(*addTensorPtr);
        yTensor.fillWithValue(static_cast<InputType>(0.0f));

        std::unordered_map<int64_t, void*> variantPack;
        variantPack[x1->get_uid()] = x1Tensor.memory().deviceData();
        variantPack[x2->get_uid()] = x2Tensor.memory().deviceData();
        variantPack[filter->get_uid()] = filterTensor.memory().deviceData();
        if(biasTensorPtr)
            variantPack[biasAttr->get_uid()] = biasTensorPtr->memory().deviceData();
        if(addTensorPtr)
            variantPack[addAttr->get_uid()] = addTensorPtr->memory().deviceData();
        variantPack[y->get_uid()] = yTensor.memory().deviceData();

        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 预热
        HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
        yTensor.memory().markDeviceModified();

        // 性能测试
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        const int iterations = 100;
        for(int i = 0; i < iterations; i++)
        {
            HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        std::cout << "Fusion mode: " << fusionModeToString(config_.fusionMode);
        if(hasActivation())
        {
            std::cout << " + activation: " << activationToString(config_.actType);
            if(config_.actType == ActivationType::LEAKYRELU
               || config_.actType == ActivationType::CLIPPEDRELU
               || config_.actType == ActivationType::ELU)
            {
                std::cout << " (alpha=" << config_.reluAlpha << ")";
            }
        }
        std::cout << std::endl;
        std::cout << "Forward time: " << time / iterations << " ms" << std::endl;

        // CPU 验证
        if(config_.cpuValidation)
        {
            std::cout << "Running CPU reference validation...\n";
            Tensor<InputType> refYTensor(y->get_dim(), y->get_stride());
            std::unordered_map<int64_t, void*> cpuPack;
            cpuPack[x1->get_uid()] = x1Tensor.memory().hostData();
            cpuPack[x2->get_uid()] = x2Tensor.memory().hostData();
            cpuPack[filter->get_uid()] = filterTensor.memory().hostData();
            if(biasTensorPtr)
                cpuPack[biasAttr->get_uid()] = biasTensorPtr->memory().hostData();
            if(addTensorPtr)
                cpuPack[addAttr->get_uid()] = addTensorPtr->memory().hostData();
            cpuPack[y->get_uid()] = refYTensor.memory().hostData();

            auto serialized = graph->to_binary().first;
            CpuReferenceGraphExecutor cpuExec;
            cpuExec.execute(serialized.data(), serialized.size(), cpuPack);

            auto tol = conv::getToleranceFwd<InputType>();
            CpuFpReferenceValidation<InputType> validator(tol, tol);
            bool valid = validator.allClose(refYTensor, yTensor);
            std::cout << "CPU validation: " << (valid ? "successful" : "failed") << std::endl;
        }

        HIPDNN_CHECK(backend->destroy(handle));
    }
};

// ==================== 运行入口 ====================
void run(const Config& config)
{
    if(config.dataType == "fp32")
    {
        ConcatConvRunner runner(config);
        runner.operator()<float, float>();
    }
    else if(config.dataType == "fp16")
    {
        ConcatConvRunner runner(config);
        runner.operator()<half, float>();
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
        std::cout << argv[i] << " ";
    std::cout << std::endl;

    auto config = parseCommandLineArgs(argc, argv);
    initializeFrontendLogging();
    run(config);
    return 0;
}
