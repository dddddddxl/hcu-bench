#include "../utils.hpp"
#include "hipdnn_frontend/attributes/BatchnormInferenceAttributes.hpp"
#include "hipdnn_frontend/attributes/PointwiseAttributes.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>
using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// 融合模式枚举
enum class FusionMode
{
    BN_INFERENCE,
    BN_INFERENCE_RELU,
    BN_INFERENCE_CLIPPEDRELU,
    BN_INFERENCE_LEAKYRELU
};

// 配置结构体
struct Config
{
    int64_t n = 1;
    int64_t c = 128;
    int64_t h = 28;
    int64_t w = 28;
    std::string dataType = "fp32";
    std::string layout = "nchw";
    bool cpuValidation = false;
    int fileIndex = 0;
    std::string filePath = ".";
    FusionMode fusionMode = FusionMode::BN_INFERENCE_RELU; // 默认模式
    float reluAlpha = 0.25f;
    float bnEpsilon = 1e-5f; // BN epsilon参数
};

// 融合模式字符串映射
std::unordered_map<std::string, FusionMode> fusionModeMap
    = {{"bn_inference", FusionMode::BN_INFERENCE},
       {"bn_inference_relu", FusionMode::BN_INFERENCE_RELU},
       {"bn_inference_clippedrelu", FusionMode::BN_INFERENCE_CLIPPEDRELU},
       {"bn_inference_leakyrelu", FusionMode::BN_INFERENCE_LEAKYRELU}};

// 融合模式到字符串的转换
std::string fusionModeToString(FusionMode mode)
{
    for(const auto& pair : fusionModeMap)
    {
        if(pair.second == mode)
        {
            return pair.first;
        }
    }
    return "unknown";
}

// 命令行解析
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--relu-alpha") == 0 && i + 1 < argc)
        {
            config.reluAlpha = std::stof(argv[++i]);
        }
        else if(strcmp(argv[i], "--bn-epsilon") == 0 && i + 1 < argc)
        {
            config.bnEpsilon = std::stof(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "-a") == 0 && i + 1 < argc)
        {
            std::string modeStr = argv[++i];
            std::transform(modeStr.begin(), modeStr.end(), modeStr.begin(), ::tolower);
            if(fusionModeMap.find(modeStr) != fusionModeMap.end())
            {
                config.fusionMode = fusionModeMap[modeStr];
            }
            else
            {
                std::cerr << "Unknown fusion mode: " << modeStr << std::endl;
                std::cerr << "Available modes: ";
                for(const auto& pair : fusionModeMap)
                {
                    std::cerr << pair.first << " ";
                }
                std::cerr << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

class BnRunner
{
public:
    BnRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType, typename IntermediateType>
    void fprop(const TensorLayout& layout)
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();
        std::cout << "inputtype: " << inputType << std::endl;
        std::cout << "intermediatetype: " << intermediateType << std::endl;

        std::cout << "Running batchnorm inference fusion graph " << inputType << " [" << layout
                  << "]" << (config_.cpuValidation ? " (with CPU validation)" : "") << "...\n";

        // 计算张量元素数量
        const size_t xTotalElems
            = static_cast<size_t>(config_.n * config_.c * config_.h * config_.w);
        const size_t bnPerChannelElems = static_cast<size_t>(config_.c); // BN参数按通道存储

        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_compute_data_type(DataType::FLOAT)
            .set_intermediate_data_type(intermediateType);

        // 创建输入张量 (NHWC/NCHW)
        auto xAttr = createTensor(
            {config_.n, config_.c, config_.h, config_.w}, inputType, layout.strideOrder);
        xAttr->set_is_virtual(false);

        // 创建BN参数张量 (仅通道维度)
        std::cout << std::endl;
        auto meanAttr = createTensor({1, config_.c, 1, 1}, DataType::FLOAT, layout.strideOrder);
        auto invVarianceAttr
            = createTensor({1, config_.c, 1, 1}, DataType::FLOAT, layout.strideOrder);
        auto scaleAttr = createTensor({1, config_.c, 1, 1}, DataType::FLOAT, layout.strideOrder);
        auto biasAttr = createTensor({1, config_.c, 1, 1}, DataType::FLOAT, layout.strideOrder);

        meanAttr->set_is_virtual(false);
        invVarianceAttr->set_is_virtual(false);
        scaleAttr->set_is_virtual(false);
        biasAttr->set_is_virtual(false);

        // 构建BN Inference节点
        graph::BatchnormInferenceAttributes bnAttributes;
        bnAttributes.set_name("bn_inference_node");

        // 执行BN Inference
        auto currentOutput = graph->batchnorm_inference(
            xAttr, meanAttr, invVarianceAttr, scaleAttr, biasAttr, bnAttributes);
        currentOutput->set_is_virtual(true).set_data_type(DataType::FLOAT);

        // 根据融合模式添加Pointwise操作
        switch(config_.fusionMode)
        {
        case FusionMode::BN_INFERENCE:
            // 仅BN Inference，无额外操作
            break;

        case FusionMode::BN_INFERENCE_RELU:
        {
            graph::PointwiseAttributes reluAttributes;
            reluAttributes.set_name("relu_node");
            reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
            currentOutput = graph->pointwise(currentOutput, reluAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        break;

        case FusionMode::BN_INFERENCE_CLIPPEDRELU:
        {
            graph::PointwiseAttributes reluAttributes;
            reluAttributes.set_name("clipped_relu_node");
            reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
            reluAttributes.set_relu_upper_clip(config_.reluAlpha);
            currentOutput = graph->pointwise(currentOutput, reluAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        break;

        case FusionMode::BN_INFERENCE_LEAKYRELU:
        {
            graph::PointwiseAttributes reluAttributes;
            reluAttributes.set_name("leaky_relu_node");
            reluAttributes.set_mode(PointwiseMode_t::RELU_FWD);
            reluAttributes.set_relu_lower_clip_slope(config_.reluAlpha);
            currentOutput = graph->pointwise(currentOutput, reluAttributes);
            currentOutput->set_is_virtual(true).set_data_type(inputType);
        }
        break;
        }

        // 设置最终输出
        currentOutput->set_output(true).set_data_type(inputType);
        currentOutput->set_is_virtual(false);

        // 验证并构建图
        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful. Fusion mode: "
                  << fusionModeToString(config_.fusionMode) << "\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        // 初始化张量内存
        Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
        Tensor<InputType> meanTensor(meanAttr->get_dim(), meanAttr->get_stride());
        Tensor<InputType> invVarianceTensor(invVarianceAttr->get_dim(),
                                            invVarianceAttr->get_stride());
        Tensor<InputType> scaleTensor(scaleAttr->get_dim(), scaleAttr->get_stride());
        Tensor<InputType> biasTensor(biasAttr->get_dim(), biasAttr->get_stride());
        Tensor<InputType> yTensor(currentOutput->get_dim(), currentOutput->get_stride());

        // 计算输出张量元素数量
        const auto& yDims = currentOutput->get_dim();
        size_t yTotalElems = 1;
        for(int64_t dim : yDims)
        {
            yTotalElems *= static_cast<size_t>(dim);
        }

        // 初始化输出值
        yTensor.fillWithValue(
            static_cast<InputType>(std::is_floating_point_v<InputType> ? 0.0f : 0));

        // 读取或生成数据
        bool readSuccess = false;
        std::vector<InputType> refXData, refMeanData, refInvVarianceData, refScaleData, refBiasData;
        std::vector<InputType> refYData;
        Tensor<InputType> refYTensor(currentOutput->get_dim(), currentOutput->get_stride());

        if(config_.fileIndex > 0)
        {
            // 读取参考文件
            const std::string xFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_input.bin";
            const std::string meanFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_mean.bin";
            const std::string invVarianceFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_inv_variance.bin";
            const std::string scaleFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_scale.bin";
            const std::string biasFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bias.bin";
            const std::string yFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_output.bin";

            // 验证文件大小并读取
            readSuccess
                = readRawTensor<InputType>(xFilename, refXData, xTotalElems)
                  && readRawTensor<InputType>(meanFilename, refMeanData, bnPerChannelElems)
                  && readRawTensor<InputType>(
                      invVarianceFilename, refInvVarianceData, bnPerChannelElems)
                  && readRawTensor<InputType>(scaleFilename, refScaleData, bnPerChannelElems)
                  && readRawTensor<InputType>(biasFilename, refBiasData, bnPerChannelElems)
                  && readRawTensor<InputType>(yFilename, refYData, yTotalElems);

            if(readSuccess)
            {
                std::cout << "Successfully read fprop reference files for fusion mode: "
                          << fusionModeToString(config_.fusionMode) << "\n";
                // 拷贝数据到张量
                std::copy(refXData.begin(), refXData.end(), xTensor.memory().hostData());
                xTensor.memory().markHostModified();

                std::copy(refMeanData.begin(), refMeanData.end(), meanTensor.memory().hostData());
                meanTensor.memory().markHostModified();

                std::copy(refInvVarianceData.begin(),
                          refInvVarianceData.end(),
                          invVarianceTensor.memory().hostData());
                invVarianceTensor.memory().markHostModified();

                std::copy(
                    refScaleData.begin(), refScaleData.end(), scaleTensor.memory().hostData());
                scaleTensor.memory().markHostModified();

                std::copy(refBiasData.begin(), refBiasData.end(), biasTensor.memory().hostData());
                biasTensor.memory().markHostModified();

                std::copy(refYData.begin(), refYData.end(), refYTensor.memory().hostData());
                refYTensor.memory().markHostModified();
            }
            else
            {
                std::cerr << " [WARN] Failed to read reference files. Using random values.\n";
            }
        }

        // 随机初始化数据（文件读取失败或无文件索引时）
        if(!readSuccess || config_.fileIndex <= 0)
        {
            xTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                         static_cast<InputType>(1.0f));
            meanTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                            static_cast<InputType>(1.0f));
            invVarianceTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                   static_cast<InputType>(1.0f));
            scaleTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                             static_cast<InputType>(1.0f));
            biasTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                            static_cast<InputType>(1.0f));
        }

        // 绑定设备内存
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
        variantPack[meanAttr->get_uid()] = meanTensor.memory().deviceData();
        variantPack[invVarianceAttr->get_uid()] = invVarianceTensor.memory().deviceData();
        variantPack[scaleAttr->get_uid()] = scaleTensor.memory().deviceData();
        variantPack[biasAttr->get_uid()] = biasTensor.memory().deviceData();
        variantPack[currentOutput->get_uid()] = yTensor.memory().deviceData();

        // 申请工作空间
        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 预热执行
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        yTensor.memory().markDeviceModified();

        // 计时运行
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "avg times: " << time / 100 << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // 验证结果（文件读取成功时）
        if(config_.fileIndex > 0 && readSuccess)
        {
            bool isMatch = true;
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                const InputType* refData = refYTensor.memory().hostData();
                const InputType* currData = yTensor.memory().hostData();

                const size_t printCount = std::min(yTotalElems, static_cast<size_t>(10));
                std::cout << "前" << printCount << "个元素对比（"
                          << fusionModeToString(config_.fusionMode) << "）：" << std::endl;
                std::cout << "(refData): ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<int>(refData[i]) << " ";
                }
                std::cout << std::endl;

                std::cout << "(currData): ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<int>(static_cast<int8_t>(currData[i])) << " ";
                }
                std::cout << std::endl;

                // 校验
                for(size_t i = 0; i < yTotalElems; ++i)
                {
                    if(currData[i] != refData[i])
                    {
                        std::cout << "不匹配！索引 " << i
                                  << ": ref(int8)=" << static_cast<int>(refData[i])
                                  << ", curr(原始)=" << static_cast<int>(currData[i]) << std::endl;
                        isMatch = false;
                        break;
                    }
                }
            }
            else
            {
                float tolerance = (config_.dataType == "tf32") ? static_cast<float>(1e-2f)
                                                               : conv::getToleranceFwd<InputType>();
                CpuFpReferenceValidation<InputType> fileValidator(tolerance, tolerance);
                isMatch = fileValidator.allClose(refYTensor, yTensor);
            }
            std::cout << "cudnn validation result (" << fusionModeToString(config_.fusionMode)
                      << "): " << (isMatch ? "successful" : "failed") << "\n";
        }

        // CPU验证
        if(config_.cpuValidation)
        {
            std::cout << "Running CPU reference validation...\n";
            Tensor<InputType> yRefTensor(currentOutput->get_dim(), currentOutput->get_stride());
            // 此处需要补充cpu端的bninfer和relu功能，计算出真实的yRefTensor
            float tolerance;
            if(config_.dataType == "fp32")
            {
                tolerance = static_cast<float>(1e-5f);
            }
            else
            {
                tolerance = static_cast<float>(1e-2f);
            }

            auto validator = CpuFpReferenceValidation<InputType>(tolerance, tolerance);
            bool yValid = validator.allClose(yRefTensor, yTensor);

            std::cout << "CPU reference validation:\n";
            std::cout << "  y: " << (yValid ? "successful" : "failed") << "\n";
        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;
};

// 根据参数选择执行类型
void run(hipdnnHandle_t handle, const Config& config)
{
    TensorLayout layout = (config.layout == "NHWC") ? TensorLayout::NHWC : TensorLayout::NCHW;

    if(config.dataType == "fp32")
    {
        BnRunner runner(handle, config);
        runner.template fprop<float, float>(layout);
    }
    else if(config.dataType == "fp16")
    {
        BnRunner runner(handle, config);
        runner.template fprop<half, float>(layout);
    }
    else if(config.dataType == "bfp16")
    {
        BnRunner runner(handle, config);
        runner.template fprop<bfloat16, float>(layout);
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));
    run(handle, config);
    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
