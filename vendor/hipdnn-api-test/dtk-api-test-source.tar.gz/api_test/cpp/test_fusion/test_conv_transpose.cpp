#include <algorithm>
#include <cstring>
#include <iostream>
#include <string>

#include "../utils.hpp"

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// ==================== 配置结构体 ====================
struct Config
{
    int64_t n = 1; // Batch size
    int64_t c = 64; // Input channels
    int64_t outH = 270; // Output height (dy)
    int64_t outW = 480; // Output width (dy)
    int64_t k = 32; // Output channels (filters)
    int64_t r = 3; // Kernel height
    int64_t s = 3; // Kernel width
    int64_t strideH = 2; // Height stride
    int64_t strideW = 2; // Width stride
    int64_t padH = 0; // Height padding
    int64_t padW = 0; // Width padding
    int64_t dilH = 1; // Height dilation
    int64_t dilW = 1; // Width dilation
    int64_t outputPadH = 1; // Output height padding
    int64_t outputPadW = 1; // Output width padding
    std::string dataType = "fp16";
    std::string layout = "NHWC";
    bool cpuValidation = false; // CPU验证开关
    bool useRandomData = true; // 使用随机数据还是固定数据
};

// ==================== 命令行解析 ====================
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        std::string arg = argv[i];
        if(arg == "-n" && i + 1 < argc)
            config.n = std::stoll(argv[++i]);
        else if(arg == "-c" && i + 1 < argc)
            config.c = std::stoll(argv[++i]);
        else if(arg == "-H" && i + 1 < argc)
            config.outH = std::stoll(argv[++i]);
        else if(arg == "-W" && i + 1 < argc)
            config.outW = std::stoll(argv[++i]);
        else if(arg == "-k" && i + 1 < argc)
            config.k = std::stoll(argv[++i]);
        else if(arg == "-y" && i + 1 < argc)
            config.r = std::stoll(argv[++i]);
        else if(arg == "-x" && i + 1 < argc)
            config.s = std::stoll(argv[++i]);
        else if(arg == "-p" && i + 1 < argc)
            config.padH = std::stoll(argv[++i]);
        else if(arg == "-q" && i + 1 < argc)
            config.padW = std::stoll(argv[++i]);
        else if(arg == "-u" && i + 1 < argc)
            config.strideH = std::stoll(argv[++i]);
        else if(arg == "-v" && i + 1 < argc)
            config.strideW = std::stoll(argv[++i]);
        else if(arg == "-l" && i + 1 < argc)
            config.dilH = std::stoll(argv[++i]);
        else if(arg == "-j" && i + 1 < argc)
            config.dilW = std::stoll(argv[++i]);
        else if(arg == "--output-pad-h" && i + 1 < argc)
            config.outputPadH = std::stoll(argv[++i]);
        else if(arg == "--output-pad-w" && i + 1 < argc)
            config.outputPadW = std::stoll(argv[++i]);
        else if(arg == "-d" && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(arg == "-L" && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(arg == "--cpu-validation")
            config.cpuValidation = true;
        else if(arg == "--use-random-data")
            config.useRandomData = true;
        else if(arg == "-h" || arg == "--help")
        {
            std::cout << "Conv Backward + Bias + ReLU Test\n";
            std::cout << "Usage: " << argv[0] << " [options]\n";
            std::cout << "Options:\n";
            std::cout << "  -n <int>               Batch size (default: 1)\n";
            std::cout << "  -c <int>               Input channels (default: 64)\n";
            std::cout << "  -H <int>               Output height (dy) (default: 270)\n";
            std::cout << "  -W <int>               Output width (dy) (default: 480)\n";
            std::cout << "  -k <int>               Output channels (filters) (default: 32)\n";
            std::cout << "  -y <int>               Kernel height (default: 3)\n";
            std::cout << "  -x <int>               Kernel width (default: 3)\n";
            std::cout << "  -p <int>               Height padding (default: 0)\n";
            std::cout << "  -q <int>               Width padding (default: 0)\n";
            std::cout << "  -u <int>               Height stride (default: 2)\n";
            std::cout << "  -v <int>               Width stride (default: 2)\n";
            std::cout << "  -l <int>               Height dilation (default: 1)\n";
            std::cout << "  -j <int>               Width dilation (default: 1)\n";
            std::cout << "  --output-pad-h <int>   Output height padding (default: 1)\n";
            std::cout << "  --output-pad-w <int>   Output width padding (default: 1)\n";
            std::cout << "  -d <string>            Data type (fp32, fp16) (default: fp16)\n";
            std::cout << "  -L <string>            Layout (NHWC, NCHW) (default: NHWC)\n";
            std::cout << "  --cpu-validation       Enable CPU validation\n";
            std::cout << "  --use-random-data      Use random data (default: true)\n";
            std::cout << "  -h, --help             Show this help\n";
            exit(0);
        }
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            std::cerr << "Use -h or --help for usage information" << std::endl;
            exit(1);
        }
    }
    return config;
}

// ==================== 构建和执行图 ====================
template <typename InputType>
void buildAndExecuteGraph(hipdnnHandle_t handle, const Config& config)
{
    // 验证output_padding的合法性
    if((config.strideH == 1 && config.outputPadH != 0)
       || (config.strideW == 1 && config.outputPadW != 0))
    {
        std::cerr << "Error: output_padding must be 0 when stride = 1" << std::endl;
        exit(1);
    }

    if(config.outputPadH >= config.strideH || config.outputPadW >= config.strideW)
    {
        std::cerr << "Error: output_padding must be less than stride" << std::endl;
        exit(1);
    }

    // 计算dx尺寸（用于验证）
    int64_t dxH = (config.outH - 1) * config.strideH - 2 * config.padH
                  + config.dilH * (config.r - 1) + 1 + config.outputPadH;
    int64_t dxW = (config.outW - 1) * config.strideW - 2 * config.padW
                  + config.dilW * (config.s - 1) + 1 + config.outputPadW;

    // 打印配置信息
    std::cout << "\n=== Conv Backward + Bias + ReLU Configuration ===" << std::endl;
    std::cout << "Batch size (n): " << config.n << std::endl;
    std::cout << "Input channels (c): " << config.c << std::endl;
    std::cout << "Output channels (k): " << config.k << std::endl;
    std::cout << "dy size: " << config.outH << "x" << config.outW << std::endl;
    std::cout << "dx size (with output_padding): " << dxH << "x" << dxW << std::endl;
    std::cout << "Kernel size: " << config.r << "x" << config.s << std::endl;
    std::cout << "Padding: " << config.padH << "x" << config.padW << std::endl;
    std::cout << "Stride: " << config.strideH << "x" << config.strideW << std::endl;
    std::cout << "Dilation: " << config.dilH << "x" << config.dilW << std::endl;
    std::cout << "Output padding: " << config.outputPadH << "x" << config.outputPadW << std::endl;
    std::cout << "Data type: " << config.dataType << std::endl;
    std::cout << "Layout: " << config.layout << std::endl;
    std::cout << "CPU Validation: " << (config.cpuValidation ? "Enabled" : "Disabled") << std::endl;
    std::cout << "================================================\n" << std::endl;

    // 构建图 - 使用高级API build()
    auto graph = std::make_shared<hipdnn_frontend::graph::Graph>();

    graph->set_name("convbwd_bias_relu_graph")
        .set_io_data_type(hipdnn_frontend::getDataTypeEnumFromType<InputType>())
        .set_intermediate_data_type(hipdnn_frontend::DataType::FLOAT)
        .set_compute_data_type(hipdnn_frontend::DataType::FLOAT);

    // 创建loss张量 (dy): {n, k, outH, outW}
    auto loss = std::make_shared<hipdnn_frontend::graph::TensorAttributes>(
        hipdnn_frontend::graph::Tensor_attributes()
            .set_name("loss")
            .set_dim({config.n, config.k, config.outH, config.outW})
            .set_stride(
                {config.k * config.outH * config.outW, 1, config.k * config.outW, config.k}));

    // 创建filter张量: {k, c, r, s}
    auto filter = std::make_shared<hipdnn_frontend::graph::TensorAttributes>(
        hipdnn_frontend::graph::Tensor_attributes()
            .set_name("filter")
            .set_dim({config.k, config.c, config.r, config.s})
            .set_stride({config.c * config.r * config.s, 1, config.c * config.s, config.c}));

    // 卷积反向传播节点
    auto convDgradAttributes = hipdnn_frontend::graph::ConvDgradAttributes()
                                   .set_name("conv_backward_node")
                                   .set_padding({config.padH, config.padW})
                                   .set_stride({config.strideH, config.strideW})
                                   .set_dilation({config.dilH, config.dilW})
                                   .set_output_padding({config.outputPadH, config.outputPadW});
    auto convOutput = graph->conv_dgrad(loss, filter, convDgradAttributes);
    convOutput->set_dim({config.n, config.c, dxH, dxW});
    // 创建bias节点
    auto biasIn = std::make_shared<hipdnn_frontend::graph::TensorAttributes>(
        hipdnn_frontend::graph::Tensor_attributes()
            .set_name("bias_in")
            .set_dim({1, config.c, 1, 1})
            .set_stride({config.c, 1, config.c, config.c}));
    auto biasAttributes = hipdnn_frontend::graph::PointwiseAttributes()
                              .set_name("bias_node")
                              .set_mode(hipdnn_frontend::PointwiseMode_t::ADD);
    auto biasOutput = graph->pointwise(convOutput, biasIn, biasAttributes);

    // 创建ReLU节点
    auto reluAttributes = hipdnn_frontend::graph::PointwiseAttributes()
                              .set_name("relu_node")
                              .set_mode(hipdnn_frontend::PointwiseMode_t::RELU_FWD);
    auto output = graph->pointwise(biasOutput, reluAttributes);
    output->set_output(true);

    // 使用高级API构建图（这会自动处理维度推导）
    std::cout << "Building graph with high-level API..." << std::endl;
    HIPDNN_FE_CHECK(graph->build(handle));
    std::cout << "Graph built successfully!" << std::endl;

    // 获取输出张量的实际维度
    auto outputDim = output->get_dim();
    std::cout << "Output (dx) shape: [" << outputDim[0] << ", " << outputDim[1] << ", "
              << outputDim[2] << ", " << outputDim[3] << "]" << std::endl;

    // 计算元素总数
    size_t lossTotalElems = static_cast<size_t>(config.n * config.k * config.outH * config.outW);
    size_t wTotalElems = static_cast<size_t>(config.k * config.c * config.r * config.s);
    size_t biasTotalElems = static_cast<size_t>(1 * config.c * 1 * 1);
    size_t outTotalElems = static_cast<size_t>(config.n * config.c * dxH * dxW);

    // 分配DCU内存
    std::cout << "Allocating memory..." << std::endl;
    hipdnn_data_sdk::utilities::Tensor<InputType> lossTensor(loss->get_dim(), loss->get_stride());
    hipdnn_data_sdk::utilities::Tensor<InputType> wTensor(filter->get_dim(), filter->get_stride());
    hipdnn_data_sdk::utilities::Tensor<InputType> biasTensor(biasIn->get_dim(),
                                                             biasIn->get_stride());
    hipdnn_data_sdk::utilities::Tensor<InputType> outTensor(output->get_dim(),
                                                            output->get_stride());

    // 分配CPU参考张量（用于验证）
    hipdnn_data_sdk::utilities::Tensor<InputType> refOutTensor(output->get_dim(),
                                                               output->get_stride());

    // 数据初始化
    if(config.useRandomData)
    {
        std::cout << "Generating random input data..." << std::endl;
        lossTensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));
        wTensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));
        biasTensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));
    }
    else
    {
        std::cout << "Using fixed data (all ones)..." << std::endl;
        lossTensor.fillWithValue(static_cast<InputType>(1.0f));
        wTensor.fillWithValue(static_cast<InputType>(1.0f));
        biasTensor.fillWithValue(static_cast<InputType>(1.0f));
    }

    // 拷贝数据到设备
    lossTensor.memory().markHostModified();
    wTensor.memory().markHostModified();
    biasTensor.memory().markHostModified();

    // 绑定设备内存
    std::unordered_map<int64_t, void*> variantPack;
    variantPack[loss->get_uid()] = lossTensor.memory().deviceData();
    variantPack[filter->get_uid()] = wTensor.memory().deviceData();
    variantPack[biasIn->get_uid()] = biasTensor.memory().deviceData();
    variantPack[output->get_uid()] = outTensor.memory().deviceData();

    // 获取workspace
    int64_t workspaceSize = 0;
    HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
    std::cout << "Workspace size: " << workspaceSize << " bytes" << std::endl;
    const hipdnn_data_sdk::utilities::Workspace workspace(static_cast<size_t>(workspaceSize));

    // 执行图
    std::cout << "Executing graph..." << std::endl;
    HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));

    // GPU同步
    HIP_CHECK(hipDeviceSynchronize());

    std::cout << "Conv Backward + Bias + ReLU graph execution completed successfully!" << std::endl;

    // ==================== CPU验证 ====================
    if(config.cpuValidation)
    {
        std::cout << "\n=== CPU Validation ===" << std::endl;
        std::cout << "Running CPU reference implementation..." << std::endl;

        // 构建用于CPU验证的图，使用从GPU图获取的实际输出维度
        std::cout << "Building graph for CPU validation..." << std::endl;

        auto cpuGraph = std::make_shared<hipdnn_frontend::graph::Graph>();
        cpuGraph->set_name("convbwd_bias_relu_graph_cpu")
            .set_io_data_type(hipdnn_frontend::getDataTypeEnumFromType<InputType>())
            .set_intermediate_data_type(hipdnn_frontend::DataType::FLOAT)
            .set_compute_data_type(hipdnn_frontend::DataType::FLOAT);

        // 创建loss张量
        auto cpuLoss = std::make_shared<hipdnn_frontend::graph::TensorAttributes>(
            hipdnn_frontend::graph::Tensor_attributes()
                .set_name("loss")
                .set_dim({config.n, config.k, config.outH, config.outW})
                .set_stride(
                    {config.k * config.outH * config.outW, 1, config.k * config.outW, config.k}));

        // 创建filter张量
        auto cpuFilter = std::make_shared<hipdnn_frontend::graph::TensorAttributes>(
            hipdnn_frontend::graph::Tensor_attributes()
                .set_name("filter")
                .set_dim({config.k, config.c, config.r, config.s})
                .set_stride({config.c * config.r * config.s, 1, config.c * config.s, config.c}));

        // 创建conv_dgrad节点
        auto cpuConvOutput = cpuGraph->conv_dgrad(cpuLoss, cpuFilter, convDgradAttributes);

        // 显式设置conv输出的维度（使用从GPU图获取的实际维度）
        // cpuConvOutput->set_dim(outputDim);

        // 创建bias节点
        auto cpuBiasIn = std::make_shared<hipdnn_frontend::graph::TensorAttributes>(
            hipdnn_frontend::graph::Tensor_attributes()
                .set_name("bias_in")
                .set_dim({1, config.c, 1, 1})
                .set_stride({config.c, 1, config.c, config.c}));

        auto cpuBiasOutput = cpuGraph->pointwise(cpuConvOutput, cpuBiasIn, biasAttributes);
        auto cpuOutput = cpuGraph->pointwise(cpuBiasOutput, reluAttributes);
        cpuOutput->set_output(true);

        // 使用分步构建以支持序列化
        HIPDNN_FE_CHECK(cpuGraph->validate());
        HIPDNN_FE_CHECK(cpuGraph->build_operation_graph(handle));
        HIPDNN_FE_CHECK(cpuGraph->create_execution_plans());
        HIPDNN_FE_CHECK(cpuGraph->check_support());
        HIPDNN_FE_CHECK(cpuGraph->build_plans());

        // 准备CPU验证的variant pack
        std::unordered_map<int64_t, void*> cpuVariantPack;
        cpuVariantPack[cpuLoss->get_uid()] = lossTensor.memory().hostData();
        cpuVariantPack[cpuFilter->get_uid()] = wTensor.memory().hostData();
        cpuVariantPack[cpuBiasIn->get_uid()] = biasTensor.memory().hostData();
        cpuVariantPack[cpuOutput->get_uid()] = refOutTensor.memory().hostData();

        // 序列化图并在CPU上执行
        auto serializedGraph = cpuGraph->to_binary().first;
        CpuReferenceGraphExecutor cpuExecutor;
        cpuExecutor.execute(serializedGraph.data(), serializedGraph.size(), cpuVariantPack);

        // 比较GPU和CPU结果
        float tolerance = (config.dataType == "fp32") ? 1e-5f : 1e-2f;
        CpuFpReferenceValidation<InputType> validator(tolerance, tolerance);
        bool validationPassed = validator.allClose(outTensor, refOutTensor);

        std::cout << "Validation tolerance (rtol/atol): " << tolerance << std::endl;
        std::cout << "CPU validation result: " << (validationPassed ? "PASSED" : "FAILED")
                  << std::endl;

        // 打印一些统计信息用于调试
        if(!validationPassed)
        {
            // 计算最大绝对误差和相对误差
            const InputType* gpuData = outTensor.memory().hostData();
            const InputType* cpuData = refOutTensor.memory().hostData();
            float maxAbsDiff = 0.0f;
            float maxRelDiff = 0.0f;

            for(size_t i = 0; i < outTotalElems && i < 100; ++i)
            {
                float gpuVal = static_cast<float>(gpuData[i]);
                float cpuVal = static_cast<float>(cpuData[i]);
                float absDiff = std::abs(gpuVal - cpuVal);
                float relDiff = absDiff / (std::abs(cpuVal) + 1e-6f);
                maxAbsDiff = std::max(maxAbsDiff, absDiff);
                maxRelDiff = std::max(maxRelDiff, relDiff);
            }

            std::cout << "Sample comparison (first 10 elements):" << std::endl;
            for(size_t i = 0; i < std::min(size_t(10), outTotalElems); ++i)
            {
                std::cout << "  [" << i << "] GPU: " << static_cast<float>(gpuData[i])
                          << " | CPU: " << static_cast<float>(cpuData[i]) << std::endl;
            }
            std::cout << "Max absolute difference: " << maxAbsDiff << std::endl;
            std::cout << "Max relative difference: " << maxRelDiff << std::endl;

            std::cerr << "ERROR: CPU validation failed!" << std::endl;
            exit(1);
        }
        else
        {
            std::cout << "CPU validation PASSED! GPU and CPU results match within tolerance."
                      << std::endl;
        }
    }
}

// ==================== 运行函数 ====================
void run(hipdnnHandle_t handle, const Config& config)
{
    if(config.dataType == "fp32")
    {
        buildAndExecuteGraph<float>(handle, config);
    }
    else if(config.dataType == "fp16")
    {
        buildAndExecuteGraph<hipdnn_data_sdk::types::half>(handle, config);
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

// ==================== 主函数 ====================
int main(int argc, char* argv[])
{
    // 打印命令行参数
    for(int i = 0; i < argc; ++i)
        std::cout << argv[i] << " ";
    std::cout << std::endl;

    // 解析命令行参数
    auto config = parseCommandLineArgs(argc, argv);

    // 初始化前端日志
    initializeFrontendLogging();

    // 创建后端和句柄
    auto backend = hipdnn_frontend::detail::hipdnnBackend();
    if(!backend)
    {
        std::cout << "Create backend failed!" << std::endl;
        return 1;
    }

    hipdnnHandle_t handle;
    HIPDNN_CHECK(backend->create(&handle));

    // 运行测试
    try
    {
        run(handle, config);
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error: " << e.what() << std::endl;
        HIPDNN_CHECK(backend->destroy(handle));
        return 1;
    }

    // 清理资源
    HIPDNN_CHECK(backend->destroy(handle));

    return 0;
}
