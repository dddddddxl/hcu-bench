#include <algorithm>
#include <cstring>
#include <iostream>
#include <string>
#include <unordered_map>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_frontend/Graph.hpp>
#include <hipdnn_frontend/attributes/LayernormAttributes.hpp>
#include <hipdnn_frontend/attributes/PointwiseAttributes.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>

#include "../utils.hpp"
#include "hipdnn_frontend/Types.hpp"

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// 配置结构体
struct Config
{
    int64_t n = 16;
    int64_t c = 16;
    int64_t h = 16;
    int64_t w = 16;
    int64_t mode = 0;
    std::string dataType = "fp16";
    std::string layout = "NCHW";
    bool cpuValidation = false;
    float epsilon = 1e-5f;
    int fileIndex = 0;
    std::string filePath = ".";
};

// 命令行解析
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "-m") == 0 && i + 1 < argc)
        {
            config.mode = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "--epsilon") == 0 && i + 1 < argc)
        {
            config.epsilon = std::stof(argv[++i]);
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

class AddLnRunner
{
public:
    AddLnRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType, typename IntermediateType>
    void addlayernorm(const TensorLayout& layout)
    {
        auto inputType = getDataTypeEnumFromType<InputType>();
        auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        // 计算总元素数
        size_t xTotalElems = static_cast<size_t>(config_.n * config_.c * config_.h * config_.w);
        size_t scaleTotalElems = static_cast<size_t>(config_.w);
        size_t biasTotalElems = static_cast<size_t>(config_.w);
        size_t yTotalElems = xTotalElems; // 输出尺寸与输入相同
        size_t addOutputTotalElems = xTotalElems; // add输出尺寸与输入相同

        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_intermediate_data_type(intermediateType)
            .set_compute_data_type(DataType::FLOAT);

        // 创建输入张量
        auto x1 = createTensor(
            {config_.n, config_.c, config_.h, config_.w}, inputType, layout.strideOrder);
        auto x2 = createTensor(
            {config_.n, config_.c, config_.h, config_.w}, inputType, layout.strideOrder);
        auto scale = createTensor({config_.w}, inputType, layout.strideOrder);
        auto bias = createTensor({config_.w}, inputType, layout.strideOrder);

        // add操作
        graph::PointwiseAttributes addAttributes;
        addAttributes.set_name("add_node").set_mode(PointwiseMode_t::ADD);

        auto addOutput = graph->pointwise(x1, x2, addAttributes);
        addOutput->set_output(true).set_data_type(inputType);

        // LayerNorm操作
        auto epsilonTensor = createTensor({1}, DataType::FLOAT);
        epsilonTensor->set_value(config_.epsilon);

        auto layernormAttributes = graph::LayernormAttributes();
        layernormAttributes.set_name("layernorm_node")
            .set_epsilon(epsilonTensor)
            .set_forward_phase(NormFwdPhase_t::INFERENCE);

        auto [y, mean, inv_variance]
            = graph->layernorm(addOutput, scale, bias, layernormAttributes);
        y->set_output(true).set_data_type(inputType);

        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful.\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        // 创建Tensor对象
        Tensor<InputType> x1Tensor(x1->get_dim(), x1->get_stride());
        Tensor<InputType> x2Tensor(x2->get_dim(), x2->get_stride());
        Tensor<InputType> scaleTensor(scale->get_dim(), scale->get_stride());
        Tensor<InputType> biasTensor(bias->get_dim(), bias->get_stride());
        Tensor<InputType> yTensor(y->get_dim(), y->get_stride());
        Tensor<InputType> addOutputTensor(addOutput->get_dim(), addOutput->get_stride());

        // 读取参考数据或生成随机数据
        bool readSuccess = false;
        std::vector<InputType> refX1Data, refX2Data, refScaleData, refBiasData;
        std::vector<InputType> refYData, refAddOutputData;
        Tensor<InputType> refYTensor(y->get_dim(), y->get_stride());
        Tensor<InputType> refAddOutputTensor(addOutput->get_dim(), addOutput->get_stride());

        if(config_.fileIndex > 0)
        {
            const std::string x1Filename
                = config_.filePath + std::to_string(config_.fileIndex) + "_input1.bin";
            const std::string x2Filename
                = config_.filePath + std::to_string(config_.fileIndex) + "_input2.bin";
            const std::string scaleFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_scale.bin";
            const std::string biasFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bias.bin";
            const std::string yFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_output.bin";
            const std::string addOutputFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_add_output.bin";

            readSuccess = readRawTensor<InputType>(x1Filename, refX1Data, xTotalElems)
                          && readRawTensor<InputType>(x2Filename, refX2Data, xTotalElems)
                          && readRawTensor<InputType>(scaleFilename, refScaleData, scaleTotalElems)
                          && readRawTensor<InputType>(biasFilename, refBiasData, biasTotalElems)
                          && readRawTensor<InputType>(yFilename, refYData, yTotalElems)
                          && readRawTensor<InputType>(
                              addOutputFilename, refAddOutputData, addOutputTotalElems);

            if(readSuccess)
            {
                std::cout << "Successfully read add-layernorm reference files.\n";

                // 将数据复制到张量
                std::copy(refX1Data.begin(), refX1Data.end(), x1Tensor.memory().hostData());
                x1Tensor.memory().markHostModified();

                std::copy(refX2Data.begin(), refX2Data.end(), x2Tensor.memory().hostData());
                x2Tensor.memory().markHostModified();

                std::copy(
                    refScaleData.begin(), refScaleData.end(), scaleTensor.memory().hostData());
                scaleTensor.memory().markHostModified();

                std::copy(refBiasData.begin(), refBiasData.end(), biasTensor.memory().hostData());
                biasTensor.memory().markHostModified();

                // 初始化参考张量用于比较
                std::copy(refYData.begin(), refYData.end(), refYTensor.memory().hostData());
                refYTensor.memory().markHostModified();

                std::copy(refAddOutputData.begin(),
                          refAddOutputData.end(),
                          refAddOutputTensor.memory().hostData());
                refAddOutputTensor.memory().markHostModified();
            }
            else
            {
                std::cerr << "[WARN] Failed to read add-layernorm reference files. "
                             "Using random "
                             "values.\n";

                // 使用随机值初始化
                x1Tensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                              static_cast<InputType>(1.0f));
                x2Tensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                              static_cast<InputType>(1.0f));
                if(config_.mode)
                {
                    scaleTensor.fillWithValue(static_cast<InputType>(1.0f));
                    biasTensor.fillWithValue(static_cast<InputType>(0.0f));
                }
                else
                {
                    scaleTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                     static_cast<InputType>(1.0f));
                    biasTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                    static_cast<InputType>(1.0f));
                }
            }
        }
        else
        {
            // 使用随机值初始化
            x1Tensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                          static_cast<InputType>(1.0f));
            x2Tensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                          static_cast<InputType>(1.0f));
            if(config_.mode)
            {
                scaleTensor.fillWithValue(static_cast<InputType>(1.0f));
                biasTensor.fillWithValue(static_cast<InputType>(0.0f));
            }
            else
            {
                scaleTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                 static_cast<InputType>(1.0f));
                biasTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                                static_cast<InputType>(1.0f));
            }
        }

        // 获取工作空间
        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 绑定变体包
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[x1->get_uid()] = x1Tensor.memory().deviceData();
        variantPack[x2->get_uid()] = x2Tensor.memory().deviceData();
        variantPack[scale->get_uid()] = scaleTensor.memory().deviceData();
        variantPack[bias->get_uid()] = biasTensor.memory().deviceData();
        variantPack[y->get_uid()] = yTensor.memory().deviceData();
        variantPack[addOutput->get_uid()] = addOutputTensor.memory().deviceData();

        // 执行图
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

        yTensor.memory().markDeviceModified();
        addOutputTensor.memory().markDeviceModified();

        // 计时执行
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "add-layernorm avg times: " << time / 100 << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // 文件验证
        if(config_.fileIndex > 0 && readSuccess)
        {
            auto tolerance = layernorm::getTolerance<InputType>();
            auto validator = CpuFpReferenceValidation<InputType>(tolerance, tolerance);

            bool yMatch = validator.allClose(refYTensor, yTensor);
            bool addOutputMatch = validator.allClose(refAddOutputTensor, addOutputTensor);

            std::cout << "File validation result:\n";
            std::cout << "  y: " << (yMatch ? "successful" : "failed") << "\n";
            std::cout << "  add output: " << (addOutputMatch ? "successful" : "failed") << "\n";

            if(!yMatch || !addOutputMatch)
            {
                // 打印前几个元素对比
                const size_t printCount = std::min(yTotalElems, static_cast<size_t>(10));
                const InputType* refYDataPtr = refYTensor.memory().hostData();
                const InputType* currYDataPtr = yTensor.memory().hostData();
                const InputType* refAddDataPtr = refAddOutputTensor.memory().hostData();
                const InputType* currAddDataPtr = addOutputTensor.memory().hostData();

                std::cout << "前" << printCount << "个元素对比：" << std::endl;

                std::cout << "y (ref): ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<float>(refYDataPtr[i]) << " ";
                }
                std::cout << std::endl;

                std::cout << "y (curr): ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<float>(currYDataPtr[i]) << " ";
                }
                std::cout << std::endl;

                std::cout << "add output (ref): ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<float>(refAddDataPtr[i]) << " ";
                }
                std::cout << std::endl;

                std::cout << "add output (curr): ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<float>(currAddDataPtr[i]) << " ";
                }
                std::cout << std::endl;
            }
        }

        if(config_.cpuValidation)
        {
            std::cout << "Running CPU reference validation...\n";
            std::unordered_map<int64_t, void*> cpuVariantPack;
            cpuVariantPack[x1->get_uid()] = x1Tensor.memory().hostData();
            cpuVariantPack[x2->get_uid()] = x2Tensor.memory().hostData();
            cpuVariantPack[scale->get_uid()] = scaleTensor.memory().hostData();
            cpuVariantPack[bias->get_uid()] = biasTensor.memory().hostData();
            cpuVariantPack[y->get_uid()] = refYTensor.memory().hostData();
            cpuVariantPack[addOutput->get_uid()] = refAddOutputTensor.memory().hostData();

            // Execute on CPU using graph executor
            auto serializedGraph = graph->to_binary().first;
            CpuReferenceGraphExecutor cpuExecutor;
            cpuExecutor.execute(serializedGraph.data(), serializedGraph.size(), cpuVariantPack);

            auto tolerance = layernorm::getTolerance<InputType>();
            auto validator = CpuFpReferenceValidation<InputType>(tolerance, tolerance);

            bool yValid = validator.allClose(refYTensor, yTensor);
            bool addOutputValid = validator.allClose(refAddOutputTensor, addOutputTensor);

            std::cout << "CPU reference validation:\n";
            std::cout << "  y: " << (yValid ? "successful" : "failed") << "\n";
            std::cout << "  addoutput: " << (addOutputValid ? "successful" : "failed") << "\n";
        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;
};

// 运行不同数据类型的模板函数
template <typename F>
void runLayernorm(F&& f, const Config& config)
{
    TensorLayout layout = (config.layout == "NHWC") ? TensorLayout::NHWC : TensorLayout::NCHW;

    if(config.dataType == "fp32")
    {
        f.template addlayernorm<float, float>(layout);
    }
    else if(config.dataType == "fp16")
    {
        f.template addlayernorm<half, float>(layout);
    }
    else if(config.dataType == "bf16")
    {
        f.template addlayernorm<bfloat16, float>(layout);
    }
    else
    {
        std::cerr << "Unsupported data type for layernorm: " << config.dataType << std::endl;
        std::cerr << "Supported types: fp32, fp16, bf16" << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));

    runLayernorm(AddLnRunner{handle, config}, config);

    HIPDNN_CHECK(hipdnnDestroy(handle));
    std::cout << "All add layernorm fusion run completed.\n";
    return 0;
}
