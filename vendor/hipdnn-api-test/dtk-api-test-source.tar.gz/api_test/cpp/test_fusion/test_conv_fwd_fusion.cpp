#include "../utils.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>
#include <iostream>
#include <string>
#include <type_traits>
#include <unordered_map>
#include <vector>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// ==================== 枚举定义 ====================
enum class ActivationType
{
    RELU,
    PRELU,
    LEAKYRELU,
    CLIPPEDRELU,
    SWISH,
    SIGMOID,
    ELU,
    TANH,
    GELU,
    GELU_APPROX_TANH
};

enum class FusionMode
{
    CONV_BIAS, // conv + bias
    CONV_BIAS_ADD, // conv + bias + add
    CONV_BIAS_ACT, // conv + bias + activation
    CONV_BIAS_ACT_ADD, // conv + bias + activation + add
    CONV_BIAS_ADD_ACT // conv + bias + add + activation
};

enum class LayoutType
{
    NHWC,
    NCHW,
    NCHWc32,
    NCHWc16
};

struct Config
{
    int64_t n = 1, c = 128, h = 28, w = 28, k = 128, r = 3, s = 3;
    int64_t padH = 1, padW = 1;
    int64_t prePadH = 1, postPadH = 1;
    int64_t prePadW = 1, postPadW = 1;
    int64_t u = 1, v = 1, dilH = 1, dilW = 1;
    int64_t groups = 1;
    std::string dataType = "fp16";
    LayoutType layout = LayoutType::NHWC;
    LayoutType outputLayout = LayoutType::NHWC;
    bool cpuValidation = false;
    int fileIndex = 0;
    std::string filePath = ".";
    FusionMode fusionMode = FusionMode::CONV_BIAS_ADD_ACT;
    ActivationType actType = ActivationType::RELU;
    float reluAlpha = 0.25f;
    float inputScale = 1.0f;
    int32_t inputZeroPoint = 0;
    float addScale = 1.0f;
    int32_t addZeroPoint = 0;
    float outputScale = 1.0f;
    int32_t outputZeroPoint = 0;
    bool useAsymPad = false;
};

std::unordered_map<std::string, ActivationType> activationMap
    = {{"relu", ActivationType::RELU},
       {"prelu", ActivationType::PRELU},
       {"leakyrelu", ActivationType::LEAKYRELU},
       {"clippedrelu", ActivationType::CLIPPEDRELU},
       {"swish", ActivationType::SWISH},
       {"sigmoid", ActivationType::SIGMOID},
       {"elu", ActivationType::ELU},
       {"tanh", ActivationType::TANH},
       {"gelu", ActivationType::GELU},
       {"gelu_approx_tanh", ActivationType::GELU_APPROX_TANH}};

std::unordered_map<std::string, FusionMode> fusionModeMap
    = {{"conv_bias", FusionMode::CONV_BIAS},
       {"conv_bias_add", FusionMode::CONV_BIAS_ADD},
       {"conv_bias_act", FusionMode::CONV_BIAS_ACT},
       {"conv_bias_act_add", FusionMode::CONV_BIAS_ACT_ADD},
       {"conv_bias_add_act", FusionMode::CONV_BIAS_ADD_ACT}};

std::unordered_map<std::string, LayoutType> layoutMap = {{"NHWC", LayoutType::NHWC},
                                                         {"NCHW", LayoutType::NCHW},
                                                         {"NCHWC32", LayoutType::NCHWc32},
                                                         {"NCHWC16", LayoutType::NCHWc16}};

std::string fusionModeToString(FusionMode mode)
{
    for(const auto& pair : fusionModeMap)
        if(pair.second == mode)
            return pair.first;
    return "unknown";
}

Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    bool hasPrePostArg = false;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
            config.n = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
            config.c = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
            config.h = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
            config.w = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-k") == 0 && i + 1 < argc)
            config.k = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-y") == 0 && i + 1 < argc)
            config.r = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-x") == 0 && i + 1 < argc)
            config.s = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-p") == 0 && i + 1 < argc)
            config.padH = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc)
            config.padW = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "--pre-pad-h") == 0 && i + 1 < argc)
        {
            config.prePadH = std::stoll(argv[++i]);
            hasPrePostArg = true;
        }
        else if(strcmp(argv[i], "--post-pad-h") == 0 && i + 1 < argc)
        {
            config.postPadH = std::stoll(argv[++i]);
            hasPrePostArg = true;
        }
        else if(strcmp(argv[i], "--pre-pad-w") == 0 && i + 1 < argc)
        {
            config.prePadW = std::stoll(argv[++i]);
            hasPrePostArg = true;
        }
        else if(strcmp(argv[i], "--post-pad-w") == 0 && i + 1 < argc)
        {
            config.postPadW = std::stoll(argv[++i]);
            hasPrePostArg = true;
        }
        else if(strcmp(argv[i], "-u") == 0 && i + 1 < argc)
            config.u = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-v") == 0 && i + 1 < argc)
            config.v = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-l") == 0 && i + 1 < argc)
            config.dilH = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-j") == 0 && i + 1 < argc)
            config.dilW = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "-g") == 0 && i + 1 < argc)
            config.groups = std::stoll(argv[++i]);
        else if(strcmp(argv[i], "--relu-alpha") == 0 && i + 1 < argc)
            config.reluAlpha = std::stof(argv[++i]);
        else if(strcmp(argv[i], "--input-scale") == 0 && i + 1 < argc)
            config.inputScale = std::stof(argv[++i]);
        else if(strcmp(argv[i], "--input-zero-point") == 0 && i + 1 < argc)
            config.inputZeroPoint = std::stoi(argv[++i]);
        else if(strcmp(argv[i], "--add-scale") == 0 && i + 1 < argc)
            config.addScale = std::stof(argv[++i]);
        else if(strcmp(argv[i], "--add-zero-point") == 0 && i + 1 < argc)
            config.addZeroPoint = std::stoi(argv[++i]);
        else if(strcmp(argv[i], "--output-scale") == 0 && i + 1 < argc)
            config.outputScale = std::stof(argv[++i]);
        else if(strcmp(argv[i], "--output-zero-point") == 0 && i + 1 < argc)
            config.outputZeroPoint = std::stoi(argv[++i]);
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            std::string layoutStr = argv[++i];
            std::transform(layoutStr.begin(), layoutStr.end(), layoutStr.begin(), ::toupper);
            if(layoutMap.find(layoutStr) != layoutMap.end())
                config.layout = layoutMap[layoutStr];
            else
            {
                std::cerr << "Unsupported layout: " << layoutStr << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "--output-layout") == 0 && i + 1 < argc)
        {
            std::string layoutStr = argv[++i];
            std::transform(layoutStr.begin(), layoutStr.end(), layoutStr.begin(), ::toupper);
            if(layoutMap.find(layoutStr) != layoutMap.end())
                config.outputLayout = layoutMap[layoutStr];
            else
            {
                std::cerr << "Unsupported output layout: " << layoutStr << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "--op-mode") == 0 && i + 1 < argc)
        {
            std::string modeStr = argv[++i];
            std::transform(modeStr.begin(), modeStr.end(), modeStr.begin(), ::tolower);
            if(fusionModeMap.find(modeStr) != fusionModeMap.end())
                config.fusionMode = fusionModeMap[modeStr];
            else
            {
                std::cerr << "Unknown op-mode: " << modeStr << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "--activation") == 0 && i + 1 < argc)
        {
            std::string actStr = argv[++i];
            std::transform(actStr.begin(), actStr.end(), actStr.begin(), ::tolower);
            if(activationMap.find(actStr) != activationMap.end())
                config.actType = activationMap[actStr];
            else
            {
                std::cerr << "Unknown activation: " << actStr << std::endl;
                exit(1);
            }
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
            config.cpuValidation = true;
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
            config.fileIndex = std::stoi(argv[++i]);
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
                config.filePath += "/";
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }

    // 参数优先级逻辑
    config.useAsymPad = hasPrePostArg;
    if(!hasPrePostArg)
    {
        config.prePadH = config.padH;
        config.postPadH = config.padH;
        config.prePadW = config.padW;
        config.postPadW = config.padW;
    }
    else
    {
        std::cout << "[INFO] Detected asymmetric pad args (--pre/--post-pad), ignore -p/-q\n";
    }

    if(config.outputLayout == LayoutType::NHWC && config.layout != LayoutType::NHWC)
        config.outputLayout = config.layout;
    return config;
}

// ==================== 根据布局生成 dims, strides, vector_count ====================
void getTensorProperties(LayoutType layout,
                         int64_t n,
                         int64_t c,
                         int64_t h,
                         int64_t w,
                         std::vector<int64_t>& dims,
                         std::vector<int64_t>& stride,
                         int64_t& outVectorCount)
{
    dims = {n, c, h, w};
    if(layout == LayoutType::NHWC)
    {
        stride = {c * h * w, 1, c * w, c};
        outVectorCount = 1;
    }
    else if(layout == LayoutType::NCHW)
    {
        stride = {c * h * w, h * w, w, 1};
        outVectorCount = 1;
    }
    else if(layout == LayoutType::NCHWc32)
    {
        stride = {c * h * w, h * w, w, 1};
        outVectorCount = 32;
    }
    else if(layout == LayoutType::NCHWc16)
    {
        stride = {c * h * w, h * w, w, 1};
        outVectorCount = 16;
    }
    else
    {
        throw std::runtime_error("Unsupported layout");
    }
}

std::shared_ptr<graph::Tensor_attributes> makeTensorAttr(const std::string& name,
                                                         const std::vector<int64_t>& dims,
                                                         const std::vector<int64_t>& stride,
                                                         int64_t vectorCount,
                                                         DataType dataType = DataType::FLOAT,
                                                         bool isVirtual = false)
{
    auto attr = std::make_shared<graph::Tensor_attributes>(graph::Tensor_attributes()
                                                               .set_name(name)
                                                               .set_dim(dims)
                                                               .set_stride(stride)
                                                               .set_vector_count(vectorCount)
                                                               .set_data_type(dataType));
    attr->set_is_virtual(isVirtual);
    return attr;
}

// ==================== 向图中添加激活节点 ====================
std::shared_ptr<graph::Tensor_attributes>
    addActivationToGraph(std::shared_ptr<graph::Graph>& graph,
                         const std::shared_ptr<graph::Tensor_attributes>& input,
                         ActivationType actType,
                         float alpha,
                         const std::string& nodeName)
{
    graph::PointwiseAttributes attr;
    attr.set_name(nodeName);
    switch(actType)
    {
    case ActivationType::RELU:
        attr.set_mode(PointwiseMode_t::RELU_FWD);
        break;
    case ActivationType::PRELU:
        attr.set_mode(PointwiseMode_t::PRELU_FWD);
        attr.set_relu_lower_clip_slope(alpha);
        break;
    case ActivationType::LEAKYRELU:
        attr.set_mode(PointwiseMode_t::RELU_FWD);
        attr.set_relu_lower_clip_slope(alpha);
        break;
    case ActivationType::CLIPPEDRELU:
        attr.set_mode(PointwiseMode_t::RELU_FWD);
        attr.set_relu_upper_clip(alpha);
        break;
    case ActivationType::SWISH:
        attr.set_mode(PointwiseMode_t::SWISH_FWD);
        break;
    case ActivationType::SIGMOID:
        attr.set_mode(PointwiseMode_t::SIGMOID_FWD);
        break;
    case ActivationType::ELU:
        attr.set_mode(PointwiseMode_t::ELU_FWD);
        attr.set_elu_alpha(alpha);
        break;
    case ActivationType::TANH:
        attr.set_mode(PointwiseMode_t::TANH_FWD);
        break;
    case ActivationType::GELU:
        attr.set_mode(PointwiseMode_t::GELU_FWD);
        break;
    case ActivationType::GELU_APPROX_TANH:
        attr.set_mode(PointwiseMode_t::GELU_APPROX_TANH_FWD);
        break;
    default:
        return input;
    }
    return graph->pointwise(input, attr);
}

template <typename InputType, typename IntermediateType>
void runFwdFusion(hipdnnHandle_t handle, const Config& config)
{
    const auto inputType = getDataTypeEnumFromType<InputType>();
    const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();
    using OutputType = InputType;

    using BiasType =
        typename std::conditional<std::is_same_v<InputType, int8_t>, float, InputType>::type;
    using AddTensorType = InputType;
    const auto biasDataType = std::is_same_v<InputType, int8_t> ? DataType::FLOAT : inputType;

    int64_t c_per_group = config.c / config.groups;
    int64_t oh, ow;
    if(config.useAsymPad)
    {
        oh = (config.h + config.prePadH + config.postPadH - config.dilH * (config.r - 1) - 1)
                 / config.u
             + 1;
        ow = (config.w + config.prePadW + config.postPadW - config.dilW * (config.s - 1) - 1)
                 / config.v
             + 1;
    }
    else
    {
        oh = (config.h + 2 * config.padH - config.dilH * (config.r - 1) - 1) / config.u + 1;
        ow = (config.w + 2 * config.padW - config.dilW * (config.s - 1) - 1) / config.v + 1;
    }

    std::vector<int64_t> xDims, xStride, wDims, wStride, bDims, bStride;
    std::vector<int64_t> addDims, addStride, yDims, yStride;
    int64_t xVectorCount = 1, wVectorCount = 1, yVectorCount = 1, addVectorCount = 1;

    getTensorProperties(
        config.layout, config.n, config.c, config.h, config.w, xDims, xStride, xVectorCount);
    getTensorProperties(
        config.layout, config.k, c_per_group, config.r, config.s, wDims, wStride, wVectorCount);
    bDims = {1, config.k, 1, 1};
    bStride = {config.k, 1, config.k, config.k};
    getTensorProperties(
        config.outputLayout, config.n, config.k, oh, ow, yDims, yStride, yVectorCount);
    getTensorProperties(
        config.outputLayout, config.n, config.k, oh, ow, addDims, addStride, addVectorCount);

    auto graph = std::make_shared<graph::Graph>();
    graph->set_io_data_type(inputType)
        .set_compute_data_type(DataType::FLOAT)
        .set_intermediate_data_type(intermediateType);

    auto xAttr = makeTensorAttr("input", xDims, xStride, xVectorCount, inputType, false);
    auto wAttr = makeTensorAttr("filter", wDims, wStride, wVectorCount, inputType, false);
    auto biasAttr = makeTensorAttr("bias", bDims, bStride, 1, biasDataType, false);

    graph::ConvFpropAttributes convAttr;
    convAttr.set_name("conv_node")
        .set_stride({config.u, config.v})
        .set_dilation({config.dilH, config.dilW});

    if(config.useAsymPad)
    {
        convAttr.set_pre_padding({config.prePadH, config.prePadW});
        convAttr.set_post_padding({config.postPadH, config.postPadW});
    }
    else
    {
        convAttr.set_padding({config.padH, config.padW});
    }
    auto convOut = graph->conv_fprop(xAttr, wAttr, convAttr);
    convOut->set_is_virtual(true).set_data_type(inputType).set_vector_count(yVectorCount);

    std::shared_ptr<graph::Tensor_attributes> zeroPointDqAttr, scaleDqAttr, scaleQAttr,
        zeroPointQAttr;
    std::unique_ptr<Tensor<int32_t>> zeroPointDqTensor;
    std::unique_ptr<Tensor<float>> scaleDqTensor;
    std::unique_ptr<Tensor<float>> scaleQTensor;
    std::unique_ptr<Tensor<int32_t>> zeroPointQTensor;

    std::shared_ptr<graph::Tensor_attributes> dequantOut = convOut;
    if constexpr(std::is_same_v<InputType, int8_t>)
    {
        auto zpDq = graph::Tensor_attributes()
                        .set_name("zero_point_dq")
                        .set_dim({1, 1, 1, 1})
                        .set_stride({1, 1, 1, 1})
                        .set_data_type(DataType::INT32);
        zpDq.set_value(static_cast<int32_t>(config.inputZeroPoint));
        zeroPointDqAttr = std::make_shared<graph::Tensor_attributes>(std::move(zpDq));
        auto scDq = graph::Tensor_attributes()
                        .set_name("scale_dq")
                        .set_dim({1, 1, 1, 1})
                        .set_stride({1, 1, 1, 1})
                        .set_data_type(DataType::FLOAT);
        scDq.set_value(config.inputScale);
        scaleDqAttr = std::make_shared<graph::Tensor_attributes>(std::move(scDq));

        auto subAttr
            = graph::PointwiseAttributes().set_name("dequant_sub").set_mode(PointwiseMode_t::SUB);
        auto subOut = graph->pointwise(convOut, zeroPointDqAttr, subAttr);
        subOut->set_is_virtual(true).set_data_type(DataType::FLOAT);
        auto mulAttr
            = graph::PointwiseAttributes().set_name("dequant_mul").set_mode(PointwiseMode_t::MUL);
        dequantOut = graph->pointwise(subOut, scaleDqAttr, mulAttr);
        dequantOut->set_is_virtual(true).set_data_type(DataType::FLOAT);
    }

    auto biasAddAttr
        = graph::PointwiseAttributes().set_name("bias_node").set_mode(PointwiseMode_t::ADD);
    auto biasOut = graph->pointwise(dequantOut, biasAttr, biasAddAttr);
    biasOut->set_is_virtual(true).set_data_type(biasDataType);

    bool needAdd = false, needAct = false, actBeforeAdd = false;
    switch(config.fusionMode)
    {
    case FusionMode::CONV_BIAS:
        break;
    case FusionMode::CONV_BIAS_ADD:
        needAdd = true;
        break;
    case FusionMode::CONV_BIAS_ACT:
        needAct = true;
        break;
    case FusionMode::CONV_BIAS_ACT_ADD:
        needAct = true;
        needAdd = true;
        actBeforeAdd = true;
        break;
    case FusionMode::CONV_BIAS_ADD_ACT:
        needAdd = true;
        needAct = true;
        actBeforeAdd = false;
        break;
    default:
        break;
    }

    std::shared_ptr<graph::Tensor_attributes> addAttr = nullptr;
    if(needAdd)
    {
        auto addDataType = inputType;
        addAttr
            = makeTensorAttr("add_tensor", addDims, addStride, addVectorCount, addDataType, false);
    }

    std::shared_ptr<graph::Tensor_attributes> addDequantOut = nullptr;
    std::shared_ptr<graph::Tensor_attributes> addZeroPointDqAttr, addScaleDqAttr;
    std::unique_ptr<Tensor<int32_t>> addZeroPointDqTensor;
    std::unique_ptr<Tensor<float>> addScaleDqTensor;
    std::unique_ptr<Tensor<float>> addDequantTensor;

    if(needAdd)
    {
        if constexpr(std::is_same_v<InputType, int8_t>)
        {
            auto addZpDq = graph::Tensor_attributes()
                               .set_name("add_zero_point_dq")
                               .set_dim({1, 1, 1, 1})
                               .set_stride({1, 1, 1, 1})
                               .set_data_type(DataType::INT32);
            addZpDq.set_value(static_cast<int32_t>(config.addZeroPoint));
            addZeroPointDqAttr = std::make_shared<graph::Tensor_attributes>(std::move(addZpDq));
            auto addScDq = graph::Tensor_attributes()
                               .set_name("add_scale_dq")
                               .set_dim({1, 1, 1, 1})
                               .set_stride({1, 1, 1, 1})
                               .set_data_type(DataType::FLOAT);
            addScDq.set_value(config.addScale);
            addScaleDqAttr = std::make_shared<graph::Tensor_attributes>(std::move(addScDq));

            auto subAttrAdd = graph::PointwiseAttributes()
                                  .set_name("add_dequant_sub")
                                  .set_mode(PointwiseMode_t::SUB);
            auto subOutAdd = graph->pointwise(addAttr, addZeroPointDqAttr, subAttrAdd);
            subOutAdd->set_is_virtual(true).set_data_type(DataType::FLOAT);
            auto mulAttrAdd = graph::PointwiseAttributes()
                                  .set_name("add_dequant_mul")
                                  .set_mode(PointwiseMode_t::MUL);
            addDequantOut = graph->pointwise(subOutAdd, addScaleDqAttr, mulAttrAdd);
            addDequantOut->set_output(true).set_vector_count(addVectorCount);
            addDequantTensor = std::make_unique<Tensor<float>>(addDims, addStride);
        }
        else
        {
            addDequantOut = addAttr;
        }
    }

    auto current = biasOut;
    if(needAct && actBeforeAdd)
    {
        current = addActivationToGraph(
            graph, current, config.actType, config.reluAlpha, "activation_node");
        current->set_is_virtual(true).set_data_type(biasDataType);
    }
    if(needAdd)
    {
        auto addPointwiseAttr
            = graph::PointwiseAttributes().set_name("add_node").set_mode(PointwiseMode_t::ADD);
        current = graph->pointwise(current, addDequantOut, addPointwiseAttr);
        current->set_is_virtual(true).set_data_type(biasDataType);
    }
    if(needAct && !actBeforeAdd)
    {
        current = addActivationToGraph(
            graph, current, config.actType, config.reluAlpha, "activation_node");
        current->set_is_virtual(true).set_data_type(biasDataType);
    }

    std::shared_ptr<graph::Tensor_attributes> finalOut = current;
    if constexpr(std::is_same_v<InputType, int8_t>)
    {
        auto scQ = graph::Tensor_attributes()
                       .set_name("scale_q")
                       .set_dim({1, 1, 1, 1})
                       .set_stride({1, 1, 1, 1})
                       .set_data_type(DataType::FLOAT);
        scQ.set_value(config.outputScale);
        scaleQAttr = std::make_shared<graph::Tensor_attributes>(std::move(scQ));
        auto zpQ = graph::Tensor_attributes()
                       .set_name("zero_point_q")
                       .set_dim({1, 1, 1, 1})
                       .set_stride({1, 1, 1, 1})
                       .set_data_type(DataType::INT32);
        zpQ.set_value(static_cast<int32_t>(config.outputZeroPoint));
        zeroPointQAttr = std::make_shared<graph::Tensor_attributes>(std::move(zpQ));

        auto divAttr
            = graph::PointwiseAttributes().set_name("quantize_div").set_mode(PointwiseMode_t::DIV);
        auto divOut = graph->pointwise(current, scaleQAttr, divAttr);
        divOut->set_is_virtual(true).set_data_type(DataType::FLOAT);
        auto addAttrQ
            = graph::PointwiseAttributes().set_name("quantize_add").set_mode(PointwiseMode_t::ADD);
        finalOut = graph->pointwise(divOut, zeroPointQAttr, addAttrQ);
        finalOut->set_is_virtual(true).set_data_type(inputType);
    }

    finalOut->set_output(true).set_vector_count(yVectorCount);
    finalOut->set_is_virtual(false);

    HIPDNN_FE_CHECK(graph->build(handle));
    std::cout << "Graph build successful. Fusion mode: " << fusionModeToString(config.fusionMode)
              << ", activation: "
              << (needAct ? std::to_string(static_cast<int>(config.actType)) : "none")
              << ", AsymmetricPadMode: " << (config.useAsymPad ? "ON" : "OFF(symmetric -p/-q)")
              << "\n";

    Tensor<InputType> xTensor(xDims, xStride);
    Tensor<InputType> wTensor(wDims, wStride);
    Tensor<BiasType> bTensor(bDims, bStride);
    Tensor<OutputType> yTensor(yDims, yStride);
    Tensor<AddTensorType>* addTensorPtr = nullptr;
    if(needAdd)
        addTensorPtr = new Tensor<AddTensorType>(addDims, addStride);

    if constexpr(std::is_same_v<InputType, int8_t>)
    {
        zeroPointDqTensor = std::make_unique<Tensor<int32_t>>(std::vector<int64_t>{1, 1, 1, 1},
                                                              std::vector<int64_t>{1, 1, 1, 1});
        scaleDqTensor = std::make_unique<Tensor<float>>(std::vector<int64_t>{1, 1, 1, 1},
                                                        std::vector<int64_t>{1, 1, 1, 1});
        scaleQTensor = std::make_unique<Tensor<float>>(std::vector<int64_t>{1, 1, 1, 1},
                                                       std::vector<int64_t>{1, 1, 1, 1});
        zeroPointQTensor = std::make_unique<Tensor<int32_t>>(std::vector<int64_t>{1, 1, 1, 1},
                                                             std::vector<int64_t>{1, 1, 1, 1});
        zeroPointDqTensor->fillWithValue(config.inputZeroPoint);
        scaleDqTensor->fillWithValue(config.inputScale);
        scaleQTensor->fillWithValue(config.outputScale);
        zeroPointQTensor->fillWithValue(config.outputZeroPoint);

        if(needAdd)
        {
            addZeroPointDqTensor = std::make_unique<Tensor<int32_t>>(
                std::vector<int64_t>{1, 1, 1, 1}, std::vector<int64_t>{1, 1, 1, 1});
            addScaleDqTensor = std::make_unique<Tensor<float>>(std::vector<int64_t>{1, 1, 1, 1},
                                                               std::vector<int64_t>{1, 1, 1, 1});
            addZeroPointDqTensor->fillWithValue(config.addZeroPoint);
            addScaleDqTensor->fillWithValue(config.addScale);
        }
    }

    size_t yTotalElems = 1;
    for(auto d : yDims)
        yTotalElems *= static_cast<size_t>(d);
    size_t xTotalElems = 1, wTotalElems = 1, bTotalElems = 1, addTotalElems = 0;
    for(auto d : xDims)
        xTotalElems *= static_cast<size_t>(d);
    for(auto d : wDims)
        wTotalElems *= static_cast<size_t>(d);
    for(auto d : bDims)
        bTotalElems *= static_cast<size_t>(d);
    if(addTensorPtr)
        for(auto d : addDims)
            addTotalElems *= static_cast<size_t>(d);

    bool readSuccess = false;
    std::vector<InputType> refXData, refWData;
    std::vector<BiasType> refBData;
    std::vector<AddTensorType> refAddData;
    std::vector<OutputType> refYData;
    Tensor<OutputType> refYTensor(yDims, yStride);

    if(config.fileIndex > 0)
    {
        std::string xFilename = config.filePath + std::to_string(config.fileIndex) + "_input.bin";
        std::string wFilename = config.filePath + std::to_string(config.fileIndex) + "_weight.bin";
        std::string bFilename = config.filePath + std::to_string(config.fileIndex) + "_bias.bin";
        std::string yFilename = config.filePath + std::to_string(config.fileIndex) + "_output.bin";
        readSuccess = readRawTensor<InputType>(xFilename, refXData, xTotalElems)
                      && readRawTensor<InputType>(wFilename, refWData, wTotalElems)
                      && readRawTensor<BiasType>(bFilename, refBData, bTotalElems)
                      && readRawTensor<OutputType>(yFilename, refYData, yTotalElems);
        if(readSuccess && addTensorPtr)
        {
            std::string addFilename
                = config.filePath + std::to_string(config.fileIndex) + "_add.bin";
            if(!readRawTensor<AddTensorType>(addFilename, refAddData, addTotalElems))
            {
                std::cerr << " [WARN] Failed to read add tensor file. Using random.\n";
                if constexpr(std::is_same_v<AddTensorType, int8_t>)
                    addTensorPtr->fillWithRandomValues(static_cast<int8_t>(-127),
                                                       static_cast<int8_t>(127));
                else
                    addTensorPtr->fillWithRandomValues(static_cast<AddTensorType>(0.0f),
                                                       static_cast<AddTensorType>(1.0f));
            }
            else
            {
                std::copy(refAddData.begin(), refAddData.end(), addTensorPtr->memory().hostData());
                addTensorPtr->memory().markHostModified();
            }
        }
        if(readSuccess)
        {
            std::cout << "Successfully read reference files.\n";
            std::copy(refXData.begin(), refXData.end(), xTensor.memory().hostData());
            xTensor.memory().markHostModified();
            std::copy(refWData.begin(), refWData.end(), wTensor.memory().hostData());
            wTensor.memory().markHostModified();
            std::copy(refBData.begin(), refBData.end(), bTensor.memory().hostData());
            bTensor.memory().markHostModified();
            std::copy(refYData.begin(), refYData.end(), refYTensor.memory().hostData());
            refYTensor.memory().markHostModified();
        }
        else
            std::cerr << " [WARN] Failed to read reference files. Using random values.\n";
    }

    if(!readSuccess)
    {
        if constexpr(std::is_same_v<InputType, int8_t>)
        {
            xTensor.fillWithRandomValues(static_cast<InputType>(-2), static_cast<InputType>(2));
            wTensor.fillWithRandomValues(static_cast<InputType>(-2), static_cast<InputType>(2));
            bTensor.fillWithRandomValues(static_cast<BiasType>(0.0f), static_cast<BiasType>(1.0f));
            if(addTensorPtr)
                addTensorPtr->fillWithRandomValues(static_cast<AddTensorType>(-2),
                                                   static_cast<AddTensorType>(2));
        }
        else
        {
            xTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                         static_cast<InputType>(1.0f));
            wTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                         static_cast<InputType>(1.0f));
            bTensor.fillWithRandomValues(static_cast<BiasType>(0.0f), static_cast<BiasType>(1.0f));
            if(addTensorPtr)
                addTensorPtr->fillWithRandomValues(static_cast<AddTensorType>(0.0f),
                                                   static_cast<AddTensorType>(1.0f));
        }
    }

    std::unordered_map<int64_t, void*> variantPack;
    variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
    variantPack[wAttr->get_uid()] = wTensor.memory().deviceData();
    variantPack[biasAttr->get_uid()] = bTensor.memory().deviceData();
    variantPack[finalOut->get_uid()] = yTensor.memory().deviceData();

    if(needAdd)
    {
        variantPack[addAttr->get_uid()] = addTensorPtr->memory().deviceData();
    }

    int64_t workspaceSize;
    HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
    Workspace workspace(static_cast<size_t>(workspaceSize));

    HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
    yTensor.memory().markDeviceModified();

    hipEvent_t start, stop;
    float time;
    HIP_CHECK(hipDeviceSynchronize());
    HIP_CHECK(hipEventCreate(&start));
    HIP_CHECK(hipEventCreate(&stop));
    HIP_CHECK(hipEventRecord(start, nullptr));
    const int iterations = 100;
    for(int i = 0; i < iterations; ++i)
        HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
    HIP_CHECK(hipEventRecord(stop, nullptr));
    HIP_CHECK(hipEventSynchronize(stop));
    HIP_CHECK(hipEventElapsedTime(&time, start, stop));
    std::cout << "Average execution time: " << time / iterations << " ms" << std::endl;
    HIP_CHECK(hipEventDestroy(start));
    HIP_CHECK(hipEventDestroy(stop));

    if(config.fileIndex > 0 && readSuccess)
    {
        bool isMatch = false;
        if constexpr(std::is_same_v<InputType, int8_t>)
        {
            const auto* ref = refYTensor.memory().hostData();
            const auto* cur = yTensor.memory().hostData();
            isMatch = true;
            for(size_t i = 0; i < yTotalElems; ++i)
                if(cur[i] != ref[i])
                {
                    isMatch = false;
                    break;
                }
        }
        else
        {
            float tolerance
                = (config.dataType == "tf32") ? 1e-2f : conv::getToleranceFwd<InputType>();
            CpuFpReferenceValidation<OutputType> validator(tolerance, tolerance);
            isMatch = validator.allClose(refYTensor, yTensor);
        }
        std::cout << "File validation result: " << (isMatch ? "successful" : "failed") << std::endl;
    }

    if(config.cpuValidation)
    {
        std::unordered_map<int64_t, void*> cpuVariantPack;
        cpuVariantPack[xAttr->get_uid()] = xTensor.memory().hostData();
        cpuVariantPack[wAttr->get_uid()] = wTensor.memory().hostData();
        cpuVariantPack[biasAttr->get_uid()] = bTensor.memory().hostData();
        if(addTensorPtr)
            cpuVariantPack[addAttr->get_uid()] = addTensorPtr->memory().hostData();
        cpuVariantPack[finalOut->get_uid()] = refYTensor.memory().hostData();

        if constexpr(std::is_same_v<InputType, int8_t>)
        {
            cpuVariantPack[zeroPointDqAttr->get_uid()] = zeroPointDqTensor->memory().hostData();
            cpuVariantPack[scaleDqAttr->get_uid()] = scaleDqTensor->memory().hostData();
            cpuVariantPack[scaleQAttr->get_uid()] = scaleQTensor->memory().hostData();
            cpuVariantPack[zeroPointQAttr->get_uid()] = zeroPointQTensor->memory().hostData();
            if(needAdd)
            {
                cpuVariantPack[addZeroPointDqAttr->get_uid()]
                    = addZeroPointDqTensor->memory().hostData();
                cpuVariantPack[addScaleDqAttr->get_uid()] = addScaleDqTensor->memory().hostData();
                cpuVariantPack[addDequantOut->get_uid()] = addTensorPtr->memory().hostData();
            }
        }

        auto serializedGraph = graph->to_binary().first;
        CpuReferenceGraphExecutor cpuExecutor;
        cpuExecutor.execute(serializedGraph.data(), serializedGraph.size(), cpuVariantPack);

        bool cpuMatch = false;
        if constexpr(std::is_same_v<OutputType, int8_t>)
        {
            const int8_t* refData = static_cast<const int8_t*>(refYTensor.memory().hostData());
            const int8_t* implData = static_cast<const int8_t*>(yTensor.memory().hostData());

            int maxDiff = 0;
            for(size_t i = 0; i < yTotalElems; ++i)
                maxDiff = std::max(
                    maxDiff,
                    std::abs(static_cast<int>(refData[i]) - static_cast<int>(implData[i])));
            cpuMatch = (maxDiff <= 2);
            std::cout << "int8 CPU validation result: " << (cpuMatch ? "successful" : "failed")
                      << ", max diff = " << maxDiff << std::endl;
        }
        else
        {
            float tolerance
                = (config.dataType == "tf32") ? 1e-2f : conv::getToleranceFwd<OutputType>();
            CpuFpReferenceValidation<OutputType> validator(tolerance, tolerance);
            cpuMatch = validator.allClose(refYTensor, yTensor);
            std::cout << "CPU validation result: " << (cpuMatch ? "successful" : "failed")
                      << std::endl;
        }
    }

    if(addTensorPtr)
        delete addTensorPtr;
}

void run(hipdnnHandle_t handle, const Config& config)
{
    if(config.dataType == "fp32" || config.dataType == "tf32")
        runFwdFusion<float, float>(handle, config);
    else if(config.dataType == "fp16")
        runFwdFusion<half, float>(handle, config);
    else if(config.dataType == "int8")
        runFwdFusion<int8_t, int8_t>(handle, config);
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
        std::cout << argv[i] << " ";
    std::cout << std::endl;

    auto config = parseCommandLineArgs(argc, argv);
    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));
    run(handle, config);
    HIPDNN_CHECK(hipdnnDestroy(handle));
    return 0;
}
