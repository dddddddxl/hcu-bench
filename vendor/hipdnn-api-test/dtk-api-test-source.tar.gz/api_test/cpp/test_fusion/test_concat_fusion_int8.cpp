#include <algorithm>
#include <cstring>
#include <iostream>
#include <memory>
#include <random>
#include <tuple>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>

#include "../utils.hpp"
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

enum class ActivationType
{
    RELU,
    PRELU,
    LEAKYRELU,
    CLIPPEDRELU,
    SWISH,
    SIGMOID,
    ELU,
    TANH,
    GELU,
    GELU_APPROX_TANH
};

enum class FusionMode
{
    CONCAT_CONV,
    CONCAT_CONV_BIAS,
    CONCAT_CONV_BIAS_ADD,
    CONCAT_CONV_BIAS_ACT,
    CONCAT_CONV_BIAS_ACT_ADD,
    CONCAT_CONV_BIAS_ADD_ACT
};

std::unordered_map<std::string, ActivationType> activationMap
    = {{"relu", ActivationType::RELU},
       {"prelu", ActivationType::PRELU},
       {"leakyrelu", ActivationType::LEAKYRELU},
       {"clippedrelu", ActivationType::CLIPPEDRELU},
       {"swish", ActivationType::SWISH},
       {"sigmoid", ActivationType::SIGMOID},
       {"elu", ActivationType::ELU},
       {"tanh", ActivationType::TANH},
       {"gelu", ActivationType::GELU},
       {"gelu_approx_tanh", ActivationType::GELU_APPROX_TANH}};

std::unordered_map<std::string, FusionMode> fusionModeMap
    = {{"concat_conv", FusionMode::CONCAT_CONV},
       {"concat_conv_bias", FusionMode::CONCAT_CONV_BIAS},
       {"concat_conv_bias_add", FusionMode::CONCAT_CONV_BIAS_ADD},
       {"concat_conv_bias_act", FusionMode::CONCAT_CONV_BIAS_ACT},
       {"concat_conv_bias_act_add", FusionMode::CONCAT_CONV_BIAS_ACT_ADD},
       {"concat_conv_bias_add_act", FusionMode::CONCAT_CONV_BIAS_ADD_ACT}};

std::string fusionModeToString(FusionMode mode)
{
    for(const auto& pair : fusionModeMap)
        if(pair.second == mode)
            return pair.first;
    return "unknown";
}

std::string activationToString(ActivationType act)
{
    for(const auto& pair : activationMap)
        if(pair.second == act)
            return pair.first;
    return "unknown";
}

struct Config
{
    int64_t n = 8;
    int64_t c = 64;
    int64_t h = 36;
    int64_t w = 16;
    int64_t k = 64;
    int64_t r = 1;
    int64_t s = 1;
    int64_t padH = 0, padW = 0;
    int64_t u = 1, v = 1;
    int64_t dilH = 1, dilW = 1;
    int64_t axis = 1;
    int64_t concatX = 64;
    std::string layout = "NHWC";
    bool cpuValidation = false;
    int iterations = 100;
    FusionMode fusionMode = FusionMode::CONCAT_CONV_BIAS_ACT_ADD;
    ActivationType actType = ActivationType::RELU;
    float reluAlpha = 0.2f;
    float scaleDq = 1.0f;
    int zeroPointDq = 0;
    float scaleQ = 1.0f;
    int zeroPointQ = 0;
    float scaleDqAdd = 1.0f;
    int zeroPointDqAdd = 0;
};

Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        std::string arg = argv[i];
        if(arg == "-n" && i + 1 < argc)
            config.n = std::stoll(argv[++i]);
        else if(arg == "-c" && i + 1 < argc)
            config.c = std::stoll(argv[++i]);
        else if(arg == "-H" && i + 1 < argc)
            config.h = std::stoll(argv[++i]);
        else if(arg == "-W" && i + 1 < argc)
            config.w = std::stoll(argv[++i]);
        else if(arg == "-k" && i + 1 < argc)
            config.k = std::stoll(argv[++i]);
        else if(arg == "-y" && i + 1 < argc)
            config.r = std::stoll(argv[++i]);
        else if(arg == "-x" && i + 1 < argc)
            config.s = std::stoll(argv[++i]);
        else if(arg == "-p" && i + 1 < argc)
            config.padH = std::stoll(argv[++i]);
        else if(arg == "-q" && i + 1 < argc)
            config.padW = std::stoll(argv[++i]);
        else if(arg == "-u" && i + 1 < argc)
            config.u = std::stoll(argv[++i]);
        else if(arg == "-v" && i + 1 < argc)
            config.v = std::stoll(argv[++i]);
        else if(arg == "-l" && i + 1 < argc)
            config.dilH = std::stoll(argv[++i]);
        else if(arg == "-j" && i + 1 < argc)
            config.dilW = std::stoll(argv[++i]);
        else if(arg == "-axis" && i + 1 < argc)
            config.axis = std::stoll(argv[++i]);
        else if(arg == "-concatX" && i + 1 < argc)
            config.concatX = std::stoll(argv[++i]);
        else if(arg == "--relu-alpha" && i + 1 < argc)
            config.reluAlpha = std::stof(argv[++i]);
        else if(arg == "-L" && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
            if(config.layout != "NHWC")
            {
                std::cerr << "Warning: int8 quantized example only works with NHWC. Forcing NHWC."
                          << std::endl;
                config.layout = "NHWC";
            }
        }
        else if(arg == "--op-mode" && i + 1 < argc)
        {
            std::string modeStr = argv[++i];
            std::transform(modeStr.begin(), modeStr.end(), modeStr.begin(), ::tolower);
            if(fusionModeMap.find(modeStr) != fusionModeMap.end())
                config.fusionMode = fusionModeMap[modeStr];
            else
            {
                std::cerr << "Unknown op-mode: " << modeStr << std::endl;
                exit(1);
            }
        }
        else if(arg == "--activation" && i + 1 < argc)
        {
            std::string actStr = argv[++i];
            std::transform(actStr.begin(), actStr.end(), actStr.begin(), ::tolower);
            if(activationMap.find(actStr) != activationMap.end())
                config.actType = activationMap[actStr];
            else
            {
                std::cerr << "Unknown activation: " << actStr << std::endl;
                exit(1);
            }
        }
        else if(arg == "--scale-dq" && i + 1 < argc)
            config.scaleDq = std::stof(argv[++i]);
        else if(arg == "--zero-point-dq" && i + 1 < argc)
            config.zeroPointDq = std::stoi(argv[++i]);
        else if(arg == "--scale-q" && i + 1 < argc)
            config.scaleQ = std::stof(argv[++i]);
        else if(arg == "--zero-point-q" && i + 1 < argc)
            config.zeroPointQ = std::stoi(argv[++i]);
        else if(arg == "--scale-dq-add" && i + 1 < argc)
            config.scaleDqAdd = std::stof(argv[++i]);
        else if(arg == "--zero-point-dq-add" && i + 1 < argc)
            config.zeroPointDqAdd = std::stoi(argv[++i]);
        else if(arg == "--cpu-validation")
            config.cpuValidation = true;
        else if(arg == "--iterations" && i + 1 < argc)
            config.iterations = std::stoi(argv[++i]);
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

std::tuple<std::vector<int64_t>, std::vector<int64_t>>
    getTensorShapeAndStrideNHWC(int64_t n, int64_t c, int64_t h, int64_t w)
{
    std::vector<int64_t> dims = {n, c, h, w};
    std::vector<int64_t> strides = {c * h * w, 1, c * w, c};
    return {dims, strides};
}

std::tuple<std::vector<int64_t>, std::vector<int64_t>>
    getFilterShapeAndStrideNHWC(int64_t k, int64_t c, int64_t r, int64_t s)
{
    std::vector<int64_t> dims = {k, c, r, s};
    std::vector<int64_t> strides = {c * r * s, 1, c * s, c};
    return {dims, strides};
}

std::tuple<int64_t, int64_t> convOutputSize(int64_t h,
                                            int64_t w,
                                            int64_t r,
                                            int64_t s,
                                            int64_t padH,
                                            int64_t padW,
                                            int64_t u,
                                            int64_t v,
                                            int64_t dilH,
                                            int64_t dilW)
{
    int64_t oh = (h + 2 * padH - dilH * (r - 1) - 1) / u + 1;
    int64_t ow = (w + 2 * padW - dilW * (s - 1) - 1) / v + 1;
    return {oh, ow};
}

void setupActivationAttributes(ActivationType act, graph::PointwiseAttributes& attrs, float alpha)
{
    switch(act)
    {
    case ActivationType::RELU:
        attrs.set_mode(PointwiseMode_t::RELU_FWD);
        break;
    case ActivationType::LEAKYRELU:
        attrs.set_mode(PointwiseMode_t::RELU_FWD);
        attrs.set_relu_lower_clip_slope(alpha);
        break;
    case ActivationType::CLIPPEDRELU:
        attrs.set_mode(PointwiseMode_t::RELU_FWD);
        attrs.set_relu_upper_clip(alpha);
        break;
    case ActivationType::SWISH:
        attrs.set_mode(PointwiseMode_t::SWISH_FWD);
        break;
    case ActivationType::SIGMOID:
        attrs.set_mode(PointwiseMode_t::SIGMOID_FWD);
        break;
    case ActivationType::ELU:
        attrs.set_mode(PointwiseMode_t::ELU_FWD);
        attrs.set_elu_alpha(alpha);
        break;
    case ActivationType::TANH:
        attrs.set_mode(PointwiseMode_t::TANH_FWD);
        break;
    case ActivationType::GELU:
        attrs.set_mode(PointwiseMode_t::GELU_FWD);
        break;
    case ActivationType::GELU_APPROX_TANH:
        attrs.set_mode(PointwiseMode_t::GELU_APPROX_TANH_FWD);
        break;
    case ActivationType::PRELU:
        attrs.set_mode(PointwiseMode_t::PRELU_FWD);
        attrs.set_relu_lower_clip_slope(alpha);
        break;
    default:
        break;
    }
}

class ConcatConvQuantRunner
{
private:
    Config config_;

    bool hasBias() const
    {
        return (config_.fusionMode != FusionMode::CONCAT_CONV);
    }
    bool hasActivation() const
    {
        return (config_.fusionMode == FusionMode::CONCAT_CONV_BIAS_ACT
                || config_.fusionMode == FusionMode::CONCAT_CONV_BIAS_ACT_ADD
                || config_.fusionMode == FusionMode::CONCAT_CONV_BIAS_ADD_ACT);
    }
    bool hasAdd() const
    {
        return (config_.fusionMode == FusionMode::CONCAT_CONV_BIAS_ADD
                || config_.fusionMode == FusionMode::CONCAT_CONV_BIAS_ACT_ADD
                || config_.fusionMode == FusionMode::CONCAT_CONV_BIAS_ADD_ACT);
    }

    auto buildGraph(hipdnnHandle_t handle, int64_t oh, int64_t ow)
    {
        using InputType = int8_t;
        using FloatType = float;

        auto graph = std::make_shared<graph::Graph>();
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto floatType = getDataTypeEnumFromType<FloatType>();

        graph->set_name("int8_concat_conv_fusion")
            .set_io_data_type(inputType)
            .set_intermediate_data_type(inputType)
            .set_compute_data_type(floatType);

        // ----- 输入 x1, x2 (int8) -----
        auto [x1_dims, x1_strides]
            = getTensorShapeAndStrideNHWC(config_.n, config_.c, config_.h, config_.w);
        auto [x2_dims, x2_strides]
            = getTensorShapeAndStrideNHWC(config_.n, config_.concatX, config_.h, config_.w);

        auto x1 = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                .set_name("x1")
                                                                .set_dim(x1_dims)
                                                                .set_stride(x1_strides)
                                                                .set_data_type(inputType));
        auto x2 = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                .set_name("x2")
                                                                .set_dim(x2_dims)
                                                                .set_stride(x2_strides)
                                                                .set_data_type(inputType));

        // ----- Concat -----
        auto concatAttrs = graph::ConcatenateAttributes().set_axis(config_.axis);
        auto concatOut = graph->concatenate({x1, x2}, concatAttrs);
        concatOut->set_is_virtual(true).set_data_type(inputType);

        int64_t c_concat = config_.c + config_.concatX;

        // ----- 卷积滤波器 (int8) -----
        auto [filter_dims, filter_strides]
            = getFilterShapeAndStrideNHWC(config_.k, c_concat, config_.r, config_.s);
        auto filter = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                    .set_name("filter")
                                                                    .set_dim(filter_dims)
                                                                    .set_stride(filter_strides)
                                                                    .set_data_type(inputType));

        // ----- 卷积 (int8 输出) -----
        auto convAttrs = graph::ConvFpropAttributes()
                             .set_name("conv_fprop")
                             .set_padding({config_.padH, config_.padW})
                             .set_stride({config_.u, config_.v})
                             .set_dilation({config_.dilH, config_.dilW});
        auto convOut = graph->conv_fprop(concatOut, filter, convAttrs);
        convOut->set_is_virtual(true).set_data_type(inputType);

        // ----- 反量化：减零点 (int8 -> float) -----
        auto zeroPointDq = std::make_shared<graph::TensorAttributes>(
            graph::Tensor_attributes()
                .set_name("zero_point_dq")
                .set_value(static_cast<float>(config_.zeroPointDq)));
        auto deqSubAttrs
            = graph::PointwiseAttributes().set_name("deq_sub").set_mode(PointwiseMode_t::SUB);
        auto deqSubOut = graph->pointwise(convOut, zeroPointDq, deqSubAttrs);
        deqSubOut->set_is_virtual(true).set_data_type(floatType);

        // ----- 反量化：乘尺度 (float) -----
        auto scaleDq = std::make_shared<graph::TensorAttributes>(
            graph::Tensor_attributes().set_name("scale_dq").set_value(config_.scaleDq));
        auto deqMulAttrs
            = graph::PointwiseAttributes().set_name("deq_mul").set_mode(PointwiseMode_t::MUL);
        auto deqMulOut = graph->pointwise(deqSubOut, scaleDq, deqMulAttrs);
        deqMulOut->set_is_virtual(true).set_data_type(floatType);

        // 当前浮点张量
        auto current = deqMulOut;

        // ----- Bias (float) -----
        std::shared_ptr<graph::TensorAttributes> biasAttr = nullptr;
        if(hasBias())
        {
            std::vector<int64_t> bias_dims = {1, config_.k, 1, 1};
            std::vector<int64_t> bias_strides = {config_.k, 1, config_.k, config_.k};
            biasAttr = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                     .set_name("bias")
                                                                     .set_dim(bias_dims)
                                                                     .set_stride(bias_strides)
                                                                     .set_data_type(floatType));
            biasAttr->set_is_virtual(false);
            graph::PointwiseAttributes addBiasAttrs;
            addBiasAttrs.set_name("add_bias").set_mode(PointwiseMode_t::ADD);
            current = graph->pointwise(current, biasAttr, addBiasAttrs);
            current->set_is_virtual(true).set_data_type(floatType);
        }

        std::shared_ptr<graph::TensorAttributes> addTensorAttr = nullptr;

        // ----- 根据 FusionMode 决定 Add 和 Activation 的顺序 -----
        bool addBeforeAct = (config_.fusionMode == FusionMode::CONCAT_CONV_BIAS_ADD_ACT);

        if(addBeforeAct)
        {
            // 先执行 Add（若存在）
            if(hasAdd())
            {
                std::vector<int64_t> add_dims = {config_.n, config_.k, oh, ow};
                std::vector<int64_t> add_strides
                    = {oh * ow * config_.k, 1, config_.k * ow, config_.k};
                addTensorAttr
                    = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                    .set_name("add_tensor")
                                                                    .set_dim(add_dims)
                                                                    .set_stride(add_strides)
                                                                    .set_data_type(inputType));
                addTensorAttr->set_is_virtual(false);

                // 反量化 add 输入
                auto zeroPointDqAdd = std::make_shared<graph::TensorAttributes>(
                    graph::Tensor_attributes()
                        .set_name("zero_point_dq_add")
                        .set_value(static_cast<float>(config_.zeroPointDqAdd)));
                auto addDeqSubAttrs = graph::PointwiseAttributes()
                                          .set_name("add_deq_sub")
                                          .set_mode(PointwiseMode_t::SUB);
                auto addDeqSubOut = graph->pointwise(addTensorAttr, zeroPointDqAdd, addDeqSubAttrs);
                addDeqSubOut->set_is_virtual(true).set_data_type(floatType);

                auto scaleDqAdd
                    = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                    .set_name("scale_dq_add")
                                                                    .set_value(config_.scaleDqAdd));
                auto addDeqMulAttrs = graph::PointwiseAttributes()
                                          .set_name("add_deq_mul")
                                          .set_mode(PointwiseMode_t::MUL);
                auto addDeqMulOut = graph->pointwise(addDeqSubOut, scaleDqAdd, addDeqMulAttrs);
                addDeqMulOut->set_is_virtual(true).set_data_type(floatType);

                // 加法 (float)
                graph::PointwiseAttributes addOpAttrs;
                addOpAttrs.set_name("add_op").set_mode(PointwiseMode_t::ADD);
                current = graph->pointwise(current, addDeqMulOut, addOpAttrs);
                current->set_is_virtual(true).set_data_type(floatType);
            }

            // 后执行 Activation（若存在）
            if(hasActivation())
            {
                graph::PointwiseAttributes actAttrs;
                actAttrs.set_name("activation");
                setupActivationAttributes(config_.actType, actAttrs, config_.reluAlpha);
                current = graph->pointwise(current, actAttrs);
                current->set_is_virtual(true).set_data_type(floatType);
            }
        }
        else
        {
            if(hasActivation())
            {
                graph::PointwiseAttributes actAttrs;
                actAttrs.set_name("activation");
                setupActivationAttributes(config_.actType, actAttrs, config_.reluAlpha);
                current = graph->pointwise(current, actAttrs);
                current->set_is_virtual(true).set_data_type(floatType);
            }

            if(hasAdd())
            {
                std::vector<int64_t> add_dims = {config_.n, config_.k, oh, ow};
                std::vector<int64_t> add_strides
                    = {oh * ow * config_.k, 1, config_.k * ow, config_.k};
                addTensorAttr
                    = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                    .set_name("add_tensor")
                                                                    .set_dim(add_dims)
                                                                    .set_stride(add_strides)
                                                                    .set_data_type(inputType));
                addTensorAttr->set_is_virtual(false);

                // 反量化 add 输入
                auto zeroPointDqAdd = std::make_shared<graph::TensorAttributes>(
                    graph::Tensor_attributes()
                        .set_name("zero_point_dq_add")
                        .set_value(static_cast<float>(config_.zeroPointDqAdd)));
                auto addDeqSubAttrs = graph::PointwiseAttributes()
                                          .set_name("add_deq_sub")
                                          .set_mode(PointwiseMode_t::SUB);
                auto addDeqSubOut = graph->pointwise(addTensorAttr, zeroPointDqAdd, addDeqSubAttrs);
                addDeqSubOut->set_is_virtual(true).set_data_type(floatType);

                auto scaleDqAdd
                    = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                    .set_name("scale_dq_add")
                                                                    .set_value(config_.scaleDqAdd));
                auto addDeqMulAttrs = graph::PointwiseAttributes()
                                          .set_name("add_deq_mul")
                                          .set_mode(PointwiseMode_t::MUL);
                auto addDeqMulOut = graph->pointwise(addDeqSubOut, scaleDqAdd, addDeqMulAttrs);
                addDeqMulOut->set_is_virtual(true).set_data_type(floatType);

                // 加法 (float)
                graph::PointwiseAttributes addOpAttrs;
                addOpAttrs.set_name("add_op").set_mode(PointwiseMode_t::ADD);
                current = graph->pointwise(current, addDeqMulOut, addOpAttrs);
                current->set_is_virtual(true).set_data_type(floatType);
            }
        }

        // ----- 量化 (float -> int8) -----
        auto scaleQ = std::make_shared<graph::TensorAttributes>(
            graph::Tensor_attributes().set_name("scale_q").set_value(config_.scaleQ));
        auto quantDivAttrs
            = graph::PointwiseAttributes().set_name("quant_div").set_mode(PointwiseMode_t::DIV);
        auto quantDivOut = graph->pointwise(current, scaleQ, quantDivAttrs);
        quantDivOut->set_is_virtual(true).set_data_type(floatType);

        auto zeroPointQ = std::make_shared<graph::TensorAttributes>(
            graph::Tensor_attributes()
                .set_name("zero_point_q")
                .set_value(static_cast<float>(config_.zeroPointQ)));
        auto quantAddAttrs
            = graph::PointwiseAttributes().set_name("quant_add").set_mode(PointwiseMode_t::ADD);
        auto quantOut = graph->pointwise(quantDivOut, zeroPointQ, quantAddAttrs);
        quantOut->set_is_virtual(true).set_data_type(inputType);

        // 标记输出
        quantOut->set_output(true).set_is_virtual(false);

        // 构建图
        HIPDNN_FE_CHECK(graph->validate());
        HIPDNN_FE_CHECK(graph->build_operation_graph(handle));
        HIPDNN_FE_CHECK(graph->create_execution_plans());
        HIPDNN_FE_CHECK(graph->check_support());
        HIPDNN_FE_CHECK(graph->build_plans());

        return std::make_tuple(graph, x1, x2, filter, biasAttr, addTensorAttr, quantOut);
    }

public:
    explicit ConcatConvQuantRunner(const Config& config)
        : config_(config)
    {
    }

    void run()
    {
        int64_t oh, ow;
        std::tie(oh, ow) = convOutputSize(config_.h,
                                          config_.w,
                                          config_.r,
                                          config_.s,
                                          config_.padH,
                                          config_.padW,
                                          config_.u,
                                          config_.v,
                                          config_.dilH,
                                          config_.dilW);

        auto backend = hipdnn_frontend::detail::hipdnnBackend();
        if(!backend)
        {
            std::cerr << "Failed to create backend." << std::endl;
            return;
        }
        hipdnnHandle_t handle;
        HIPDNN_CHECK(backend->create(&handle));

        auto [graph, x1, x2, filter, biasAttr, addTensorAttr, output] = buildGraph(handle, oh, ow);

        using InputType = int8_t;
        using FloatType = float;

        // 分配 GPU 内存
        Tensor<InputType> x1Tensor(x1->get_dim(), x1->get_stride());
        Tensor<InputType> x2Tensor(x2->get_dim(), x2->get_stride());
        Tensor<InputType> filterTensor(filter->get_dim(), filter->get_stride());
        Tensor<InputType> outTensor(output->get_dim(), output->get_stride());

        std::unique_ptr<Tensor<FloatType>> biasTensorPtr = nullptr;
        std::unique_ptr<Tensor<InputType>> addTensorPtr = nullptr;

        if(biasAttr)
            biasTensorPtr
                = std::make_unique<Tensor<FloatType>>(biasAttr->get_dim(), biasAttr->get_stride());
        if(addTensorAttr)
            addTensorPtr = std::make_unique<Tensor<InputType>>(addTensorAttr->get_dim(),
                                                               addTensorAttr->get_stride());

        auto fillRandomInt8 = [](auto& t) {
            t.fillWithRandomValues(static_cast<InputType>(-1), static_cast<InputType>(1));
        };
        auto fillRandomFloat = [](auto& t) { t.fillWithRandomValues(-1.0f, 1.0f); };

        fillRandomInt8(x1Tensor);
        fillRandomInt8(x2Tensor);
        fillRandomInt8(filterTensor);
        if(biasTensorPtr)
            fillRandomFloat(*biasTensorPtr);
        if(addTensorPtr)
            fillRandomInt8(*addTensorPtr);
        outTensor.fillWithValue(static_cast<InputType>(0));

        std::unordered_map<int64_t, void*> variantPack;
        variantPack[x1->get_uid()] = x1Tensor.memory().deviceData();
        variantPack[x2->get_uid()] = x2Tensor.memory().deviceData();
        variantPack[filter->get_uid()] = filterTensor.memory().deviceData();
        if(biasTensorPtr)
            variantPack[biasAttr->get_uid()] = biasTensorPtr->memory().deviceData();
        if(addTensorPtr)
            variantPack[addTensorAttr->get_uid()] = addTensorPtr->memory().deviceData();
        variantPack[output->get_uid()] = outTensor.memory().deviceData();

        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 预热
        HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
        outTensor.memory().markDeviceModified();

        // 性能测试
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int i = 0; i < config_.iterations; ++i)
        {
            HIPDNN_FE_CHECK(graph->execute(handle, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        std::cout << "Forward time (avg over " << config_.iterations
                  << " runs): " << time / config_.iterations << " ms" << std::endl;

        // CPU 验证
        if(config_.cpuValidation)
        {
            std::cout << "Running CPU reference validation..." << std::endl;
            Tensor<InputType> refOutTensor(output->get_dim(), output->get_stride());
            std::unordered_map<int64_t, void*> cpuPack;
            cpuPack[x1->get_uid()] = x1Tensor.memory().hostData();
            cpuPack[x2->get_uid()] = x2Tensor.memory().hostData();
            cpuPack[filter->get_uid()] = filterTensor.memory().hostData();
            if(biasTensorPtr)
                cpuPack[biasAttr->get_uid()] = biasTensorPtr->memory().hostData();
            if(addTensorPtr)
                cpuPack[addTensorAttr->get_uid()] = addTensorPtr->memory().hostData();
            cpuPack[output->get_uid()] = refOutTensor.memory().hostData();

            auto serialized = graph->to_binary().first;
            CpuReferenceGraphExecutor cpuExec;
            cpuExec.execute(serialized.data(), serialized.size(), cpuPack);

            const int8_t* refData = static_cast<const int8_t*>(refOutTensor.memory().hostData());
            const int8_t* implData = static_cast<const int8_t*>(outTensor.memory().hostData());

            auto outDims = output->get_dim();
            size_t yTotalElems = 1;
            for(auto dim : outDims)
            {
                yTotalElems *= dim;
            }

            int maxDiff = 0;
            for(size_t i = 0; i < yTotalElems; ++i)
            {
                maxDiff = std::max(
                    maxDiff,
                    std::abs(static_cast<int>(refData[i]) - static_cast<int>(implData[i])));
            }
            bool cpuMatch = (maxDiff <= 2);
            std::cout << "int8 CPU validation result: " << (cpuMatch ? "successful" : "failed")
                      << ", max diff = " << maxDiff << std::endl;
        }

        HIPDNN_CHECK(backend->destroy(handle));
    }
};

int main(int argc, char* argv[])
{
    // 打印命令行
    for(int i = 0; i < argc; ++i)
        std::cout << argv[i] << " ";
    std::cout << std::endl;

    auto config = parseCommandLineArgs(argc, argv);
    initializeFrontendLogging();

    ConcatConvQuantRunner runner(config);
    runner.run();

    return 0;
}
