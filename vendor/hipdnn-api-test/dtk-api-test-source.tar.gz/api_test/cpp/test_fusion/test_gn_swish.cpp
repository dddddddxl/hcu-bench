#include <algorithm>
#include <cstring>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_frontend/Graph.hpp>
#include <hipdnn_frontend/attributes/GroupnormFwdAttributes.hpp>
#include <hipdnn_frontend/attributes/PointwiseAttributes.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/CpuReferenceGraphExecutor.hpp>
#include <iostream>
#include <memory>
#include <string>
#include <unordered_map>

#include "../utils.hpp"
#include "hipdnn_frontend/Types.hpp"

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// 配置结构体
struct Config
{
    int64_t n = 16;
    int64_t c = 16;
    int64_t h = 16;
    int64_t w = 16;
    std::string dataType = "fp16";
    std::string layout = "NCHW";
    bool cpuValidation = false;
    float epsilon = 1e-5f;
    int numGroups = 2;
    int fileIndex = 0;
    std::string phase = "training"; // "training" 或 "inference"
};

// 命令行解析
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;
    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "--epsilon") == 0 && i + 1 < argc)
        {
            config.epsilon = std::stof(argv[++i]);
        }
        else if(strcmp(argv[i], "-g") == 0 && i + 1 < argc)
        {
            config.numGroups = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "--phase") == 0 && i + 1 < argc)
        {
            config.phase = argv[++i];
            std::transform(
                config.phase.begin(), config.phase.end(), config.phase.begin(), ::tolower);
            if(config.phase != "training" && config.phase != "inference")
            {
                std::cerr << "Error: Invalid phase. Must be 'training' or 'inference'" << std::endl;
                exit(1);
            }
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            exit(1);
        }
    }
    return config;
}

class GroupNormSwishRunner
{
public:
    GroupNormSwishRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType, typename IntermediateType>
    void groupnormswish(const TensorLayout& layout)
    {
        auto inputType = getDataTypeEnumFromType<InputType>();
        auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_intermediate_data_type(intermediateType)
            .set_compute_data_type(DataType::FLOAT);

        // 创建输入张量
        auto x = createTensor(
            {config_.n, config_.c, config_.h, config_.w}, inputType, layout.strideOrder);
        auto scale = createTensor({config_.c}, inputType, layout.strideOrder);
        auto bias = createTensor({config_.c}, inputType, layout.strideOrder);

        // 创建epsilon和groups张量
        auto epsilonTensor = createTensor({1}, DataType::FLOAT);
        auto groupsTensor = createTensor({1}, DataType::INT32);
        epsilonTensor->set_value(config_.epsilon);
        groupsTensor->set_value(config_.numGroups);

        // 根据phase设置训练或推理模式
        NormFwdPhase_t normPhase;
        if(config_.phase == "training")
        {
            normPhase = NormFwdPhase_t::TRAINING;
        }
        else // inference
        {
            normPhase = NormFwdPhase_t::INFERENCE;
        }

        // GroupNorm操作
        auto groupnormFwdAttributes = graph::GroupnormFwdAttributes();
        groupnormFwdAttributes.set_name("groupnorm_forward_node")
            .set_epsilon(epsilonTensor)
            .set_groups(groupsTensor)
            .set_forward_phase(normPhase);

        auto [y, mean, inv_variance] = graph->groupnorm(x, scale, bias, groupnormFwdAttributes);
        y->set_data_type(inputType).set_is_virtual(true);

        if(config_.phase == "training")
        {
            mean->set_output(true).set_data_type(intermediateType);
            inv_variance->set_output(true).set_data_type(intermediateType);
        }

        // Swish激活函数操作
        graph::PointwiseAttributes swishAttributes;
        swishAttributes.set_name("swish_node").set_mode(PointwiseMode_t::SWISH_FWD);

        auto out = graph->pointwise(y, swishAttributes);
        out->set_output(true).set_data_type(inputType);

        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful.\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        // 创建Tensor对象
        Tensor<InputType> xTensor(x->get_dim(), x->get_stride());
        Tensor<InputType> scaleTensor(scale->get_dim(), scale->get_stride());
        Tensor<InputType> biasTensor(bias->get_dim(), bias->get_stride());

        // 智能指针来避免默认构造函数问题
        std::unique_ptr<Tensor<IntermediateType>> meanTensorPtr;
        std::unique_ptr<Tensor<IntermediateType>> invVarianceTensorPtr;

        if(config_.phase == "training")
        {
            meanTensorPtr
                = std::make_unique<Tensor<IntermediateType>>(mean->get_dim(), mean->get_stride());
            invVarianceTensorPtr = std::make_unique<Tensor<IntermediateType>>(
                inv_variance->get_dim(), inv_variance->get_stride());
        }

        Tensor<InputType> outTensor(out->get_dim(), out->get_stride());

        // 初始化Tensor数据
        xTensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));
        scaleTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                         static_cast<InputType>(1.0f));
        biasTensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));

        // 获取工作空间
        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 绑定变体包
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[x->get_uid()] = xTensor.memory().deviceData();
        variantPack[scale->get_uid()] = scaleTensor.memory().deviceData();
        variantPack[bias->get_uid()] = biasTensor.memory().deviceData();
        variantPack[out->get_uid()] = outTensor.memory().deviceData();

        if(config_.phase == "training")
        {
            variantPack[mean->get_uid()] = meanTensorPtr->memory().deviceData();
            variantPack[inv_variance->get_uid()] = invVarianceTensorPtr->memory().deviceData();
        }

        // 执行图
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

        // 标记设备数据已修改，确保主机可以获取最新数据
        outTensor.memory().markDeviceModified();
        if(config_.phase == "training")
        {
            meanTensorPtr->memory().markDeviceModified();
            invVarianceTensorPtr->memory().markDeviceModified();
        }

        // 计时执行
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "groupnorm-swish " << config_.phase << " avg time: " << time / 100 << " ms"
                  << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        if(config_.cpuValidation)
        {
            std::cout << "Running CPU reference validation...\n";
            Tensor<InputType> yRefTensor(out->get_dim(), out->get_stride());

            std::unique_ptr<Tensor<IntermediateType>> meanRefTensor;
            std::unique_ptr<Tensor<IntermediateType>> invVarianceRefTensor;
            if(config_.phase == "training")
            {
                meanRefTensor = std::make_unique<Tensor<IntermediateType>>(mean->get_dim(),
                                                                           mean->get_stride());
                invVarianceRefTensor = std::make_unique<Tensor<IntermediateType>>(
                    inv_variance->get_dim(), inv_variance->get_stride());
            }

            std::unordered_map<int64_t, void*> cpuVariantPack;
            cpuVariantPack[x->get_uid()] = xTensor.memory().hostData();
            cpuVariantPack[scale->get_uid()] = scaleTensor.memory().hostData();
            cpuVariantPack[bias->get_uid()] = biasTensor.memory().hostData();
            cpuVariantPack[out->get_uid()] = yRefTensor.memory().hostData();
            if(config_.phase == "training")
            {
                cpuVariantPack[mean->get_uid()] = meanRefTensor->memory().hostData();
                cpuVariantPack[inv_variance->get_uid()] = invVarianceRefTensor->memory().hostData();
            }

            // Execute on CPU using graph executor
            auto serializedGraph = graph->to_binary().first;
            CpuReferenceGraphExecutor cpuExecutor;
            cpuExecutor.execute(serializedGraph.data(), serializedGraph.size(), cpuVariantPack);

            // 设置容差并验证
            auto tolerance = groupnorm::getTolerance<InputType>();
            auto validator = CpuFpReferenceValidation<InputType>(tolerance, tolerance);
            bool yValid = validator.allClose(yRefTensor, outTensor);

            std::cout << "CPU reference validation (" << config_.phase << " mode):\n";
            std::cout << "  y: " << (yValid ? "successful" : "failed") << "\n";

            // 只有在训练模式下才验证mean和inv_variance
            if(config_.phase == "training")
            {
                auto toleranceMean = groupnorm::getTolerance<IntermediateType>();
                auto validatorMean
                    = CpuFpReferenceValidation<IntermediateType>(toleranceMean, toleranceMean);
                bool meanValid = validatorMean.allClose(*meanRefTensor, *meanTensorPtr);
                bool invVarianceValid
                    = validatorMean.allClose(*invVarianceRefTensor, *invVarianceTensorPtr);

                std::cout << "  mean: " << (meanValid ? "successful" : "failed") << "\n";
                std::cout << "  invVariance: " << (invVarianceValid ? "successful" : "failed")
                          << "\n";
            }
        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;
};

// 运行不同数据类型的模板函数
template <typename F>
void runGroupNormSwish(F&& f, const Config& config)
{
    TensorLayout layout = (config.layout == "NHWC") ? TensorLayout::NHWC : TensorLayout::NCHW;

    if(config.dataType == "fp32")
    {
        f.template groupnormswish<float, float>(layout);
    }
    else if(config.dataType == "fp16")
    {
        f.template groupnormswish<half, float>(layout);
    }
    else
    {
        std::cerr << "Unsupported data type for groupnorm swish: " << config.dataType << std::endl;
        std::cerr << "Supported types: fp32, fp16" << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));

    runGroupNormSwish(GroupNormSwishRunner{handle, config}, config);

    HIPDNN_CHECK(hipdnnDestroy(handle));
    std::cout << "All groupnorm swish fusion run completed.\n";
    return 0;
}
