#include <algorithm>
#include <cmath>
#include <cstring>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/detail/GatherPlan.hpp>

#include "../utils.hpp"

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;
using namespace hipdnn_test_sdk::detail;

struct Config
{
    int64_t n = 2; // batch size
    int64_t c = 3; // channels
    int64_t h = 4; // height
    int64_t axis = 1; // axis for gather operation
    std::string dataType = "fp32";
    std::vector<int64_t> indices = {0, 2};
    bool cpuValidation = false;
};

Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--axis") == 0 && i + 1 < argc)
        {
            config.axis = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "--indices") == 0 && i + 1 < argc)
        {
            config.indices.clear();
            char* token = std::strtok(argv[++i], ",");
            while(token != nullptr)
            {
                config.indices.push_back(std::stoll(token));
                token = std::strtok(nullptr, ",");
            }
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            std::cerr << "-n <batch> -c <channels> -H <height> --axis <axis> "
                      << "-d <data_type> --indices <idx1,idx2,...> [--cpu-validation]\n";
            exit(1);
        }
    }

    return config;
}

template <typename InputType, typename IndicesType>
class GatherRunner
{
public:
    GatherRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    void run()
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto indicesType = getDataTypeEnumFromType<IndicesType>();

        const int64_t n = config_.n;
        const int64_t c = config_.c;
        const int64_t h = config_.h;
        const int64_t axis = config_.axis;
        const std::vector<int64_t> indices = config_.indices;
        const int64_t indicesLen = static_cast<int64_t>(indices.size());

        // 计算输出维度
        std::vector<int64_t> outputDim;
        if(axis == 0)
        {
            outputDim = {indicesLen, c, h};
        }
        else if(axis == 1)
        {
            outputDim = {n, indicesLen, h};
        }
        else if(axis == 2)
        {
            outputDim = {n, c, indicesLen};
        }
        else
        {
            throw std::runtime_error("Unsupported axis");
        }

        size_t outputTotalElems = static_cast<size_t>(outputDim[0] * outputDim[1] * outputDim[2]);

        // 创建计算图
        auto graph = std::make_shared<graph::Graph>();
        graph->set_name("gather_test")
            .set_io_data_type(inputType)
            .set_compute_data_type(DataType::FLOAT)
            .set_intermediate_data_type(inputType);

        // 定义输入张量
        auto dataAttr = std::make_shared<graph::TensorAttributes>(
            graph::Tensor_attributes().set_name("data").set_dim({n, c, h}).set_stride(
                {c * h, h, 1}));

        auto indicesAttr
            = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                            .set_name("indices")
                                                            .set_dim({indicesLen})
                                                            .set_stride({1})
                                                            .set_data_type(indicesType));

        // 配置gather属性
        auto gatherAttributes = graph::GatherAttributes().set_name("gather_node").set_axis(axis);

        // 创建输出张量
        auto outputAttr = graph->gather(dataAttr, indicesAttr, gatherAttributes);
        outputAttr->set_output(true).set_data_type(inputType);

        // 图验证与构建
        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful.\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        // 初始化张量
        Tensor<InputType> dataTensor(dataAttr->get_dim(), dataAttr->get_stride());
        Tensor<IndicesType> indicesTensor(indicesAttr->get_dim(), indicesAttr->get_stride());
        Tensor<InputType> outputTensor(outputAttr->get_dim(), outputAttr->get_stride());

        // 生成随机数据
        fillTensorWithRandomValues(dataTensor);

        // 填充indices
        indicesTensor.fillWithData(indices.data(), indices.size() * sizeof(IndicesType));

        std::unordered_map<int64_t, void*> variantPack;
        variantPack[dataAttr->get_uid()] = dataTensor.memory().deviceData();
        variantPack[indicesAttr->get_uid()] = indicesTensor.memory().deviceData();
        variantPack[outputAttr->get_uid()] = outputTensor.memory().deviceData();

        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 执行
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        outputTensor.memory().markDeviceModified();

        // 计时执行
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "Gather avg times: " << time / 100 << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // 打印部分输出
        const InputType* outputData = outputTensor.memory().hostData();
        std::cout << "Gather first 10 values: ";
        for(int i = 0; i < std::min(10, static_cast<int>(outputTotalElems)); ++i)
        {
            std::cout << static_cast<float>(outputData[i]) << " ";
        }
        std::cout << '\n';

        // ========== CPU 验证 ==========
        if(config_.cpuValidation)
        {
            std::cout << "\n=== CPU Validation ===\n";

            // 创建参考输出张量
            Tensor<InputType> refOutputTensor(outputAttr->get_dim(), outputAttr->get_stride());

            // 使用 hipdnn_test_sdk 提供的迭代工具
            const InputType* dataPtr = dataTensor.memory().hostData();
            const IndicesType* indicesPtr = indicesTensor.memory().hostData();
            InputType* refPtr = refOutputTensor.memory().hostData();

            auto dataDims = dataTensor.dims();
            auto outputDims = outputDim;

            int64_t dim0 = dataDims[0];
            int64_t dim1 = dataDims[1];
            int64_t dim2 = dataDims[2];

            // 使用 hipdnn_data_sdk::utilities::iterateAlongDimensions
            // 这是 hipdnn 提供的标准迭代工具
            hipdnn_data_sdk::utilities::iterateAlongDimensions(
                outputDims, [&](const std::vector<int64_t>& outIdx) {
                    int64_t i = outIdx[0];
                    int64_t j = outIdx[1];
                    int64_t k = outIdx[2];

                    int64_t dataIdx0, dataIdx1, dataIdx2;
                    int64_t idxValue;

                    if(axis == 0)
                    {
                        idxValue = static_cast<int64_t>(indicesPtr[i]);
                        dataIdx0 = idxValue;
                        dataIdx1 = j;
                        dataIdx2 = k;
                    }
                    else if(axis == 1)
                    {
                        idxValue = static_cast<int64_t>(indicesPtr[j]);
                        dataIdx0 = i;
                        dataIdx1 = idxValue;
                        dataIdx2 = k;
                    }
                    else if(axis == 2)
                    {
                        idxValue = static_cast<int64_t>(indicesPtr[k]);
                        dataIdx0 = i;
                        dataIdx1 = j;
                        dataIdx2 = idxValue;
                    }
                    else
                    {
                        throw std::runtime_error("Unsupported axis");
                    }

                    // 使用 hipdnn 提供的边界检查
                    if(dataIdx0 < 0 || dataIdx0 >= dim0 || dataIdx1 < 0 || dataIdx1 >= dim1
                       || dataIdx2 < 0 || dataIdx2 >= dim2)
                    {
                        throw std::out_of_range("Gather index out of bounds");
                    }

                    int64_t outOffset = i * outputDims[1] * outputDims[2] + j * outputDims[2] + k;
                    int64_t dataOffset = dataIdx0 * dim1 * dim2 + dataIdx1 * dim2 + dataIdx2;

                    refPtr[outOffset] = dataPtr[dataOffset];
                    return true;
                });

            refOutputTensor.memory().markHostModified();

            // 使用 hipdnn 提供的验证工具
            float tolerance = getTolerance<InputType>();
            std::cout << "Tolerance: " << tolerance << std::endl;

            CpuFpReferenceValidation<InputType> validator(tolerance, tolerance);
            bool isMatch = validator.allClose(refOutputTensor, outputTensor);
            std::cout << "CPU validation result: " << (isMatch ? "✓ successful" : "✗ failed")
                      << "\n";
        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    template <typename T>
    float getTolerance()
    {
        if(config_.dataType == "tf32")
        {
            return static_cast<float>(1e-2f);
        }
        else
        {
            return conv::getToleranceFwd<T>();
        }
    }

    template <typename T>
    void fillTensorWithRandomValues(Tensor<T>& tensor)
    {
        if constexpr(std::is_same_v<T, int8_t>)
        {
            tensor.fillWithRandomValues(static_cast<T>(-127), static_cast<T>(127));
        }
        else
        {
            tensor.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
        }
    }
};

void runGather(hipdnnHandle_t handle, const Config& config)
{
    GatherRunner<float, int64_t> runner(handle, config);

    if(config.dataType == "fp32" || config.dataType == "tf32")
    {
        runner.run();
    }
    else if(config.dataType == "fp16")
    {
        GatherRunner<half, int64_t> runnerHalf(handle, config);
        runnerHalf.run();
    }
    else if(config.dataType == "bfp16")
    {
        GatherRunner<bfloat16, int64_t> runnerBf16(handle, config);
        runnerBf16.run();
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));
    runGather(handle, config);
    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
