#include <algorithm>
#include <cmath>
#include <cstring>
#include <iostream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
#include <hipdnn_test_sdk/utilities/cpu_graph_executor/detail/ScatterNDPlan.hpp>

#include "../utils.hpp"

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;
using namespace hipdnn_test_sdk::detail;

struct Config
{
    std::vector<int64_t> dataDims = {4, 4};
    std::vector<int64_t> dataStrides = {4, 1};
    std::vector<int64_t> indicesDims = {2, 2};
    std::vector<int64_t> indicesStrides = {2, 1};
    std::vector<int64_t> updatesDims = {2};
    std::vector<int64_t> updatesStrides = {1};
    std::string dataType = "fp32";
    std::string reduction = "none";
    std::vector<std::vector<int64_t>> indices = {{0, 0}, {2, 3}};
    std::vector<float> updates = {1.5f, 2.5f};
    bool cpuValidation = false;
};

Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "--data-dims") == 0 && i + 1 < argc)
        {
            config.dataDims.clear();
            char* token = std::strtok(argv[++i], ",");
            while(token != nullptr)
            {
                config.dataDims.push_back(std::stoll(token));
                token = std::strtok(nullptr, ",");
            }
            // 自动计算 strides
            config.dataStrides.clear();
            int64_t stride = 1;
            for(auto it = config.dataDims.rbegin(); it != config.dataDims.rend(); ++it)
            {
                config.dataStrides.insert(config.dataStrides.begin(), stride);
                stride *= *it;
            }
        }
        else if(strcmp(argv[i], "--indices-dims") == 0 && i + 1 < argc)
        {
            config.indicesDims.clear();
            char* token = std::strtok(argv[++i], ",");
            while(token != nullptr)
            {
                config.indicesDims.push_back(std::stoll(token));
                token = std::strtok(nullptr, ",");
            }
            // 自动计算 strides
            config.indicesStrides.clear();
            int64_t stride = 1;
            for(auto it = config.indicesDims.rbegin(); it != config.indicesDims.rend(); ++it)
            {
                config.indicesStrides.insert(config.indicesStrides.begin(), stride);
                stride *= *it;
            }
        }
        else if(strcmp(argv[i], "--updates-dims") == 0 && i + 1 < argc)
        {
            config.updatesDims.clear();
            char* token = std::strtok(argv[++i], ",");
            while(token != nullptr)
            {
                config.updatesDims.push_back(std::stoll(token));
                token = std::strtok(nullptr, ",");
            }
            // 自动计算 strides
            config.updatesStrides.clear();
            int64_t stride = 1;
            for(auto it = config.updatesDims.rbegin(); it != config.updatesDims.rend(); ++it)
            {
                config.updatesStrides.insert(config.updatesStrides.begin(), stride);
                stride *= *it;
            }
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "--reduction") == 0 && i + 1 < argc)
        {
            config.reduction = argv[++i];
            std::transform(config.reduction.begin(),
                           config.reduction.end(),
                           config.reduction.begin(),
                           ::tolower);
        }
        else if(strcmp(argv[i], "--indices") == 0 && i + 1 < argc)
        {
            config.indices.clear();
            std::string indicesStr = argv[++i];
            std::stringstream ss(indicesStr);
            std::string rowStr;

            while(std::getline(ss, rowStr, ';'))
            {
                rowStr.erase(0, rowStr.find_first_not_of(" \t"));
                rowStr.erase(rowStr.find_last_not_of(" \t") + 1);
                if(rowStr.empty())
                    continue;

                std::vector<int64_t> row;
                std::stringstream rowSs(rowStr);
                std::string valStr;

                while(std::getline(rowSs, valStr, ','))
                {
                    valStr.erase(0, valStr.find_first_not_of(" \t"));
                    valStr.erase(valStr.find_last_not_of(" \t") + 1);
                    if(!valStr.empty())
                    {
                        row.push_back(std::stoll(valStr));
                    }
                }

                if(!row.empty())
                {
                    config.indices.push_back(row);
                }
            }

            if(config.indices.empty())
            {
                std::stringstream ss2(indicesStr);
                std::string rowStr2;

                while(std::getline(ss2, rowStr2, ' '))
                {
                    rowStr2.erase(0, rowStr2.find_first_not_of(" \t"));
                    rowStr2.erase(rowStr2.find_last_not_of(" \t") + 1);
                    if(rowStr2.empty())
                        continue;

                    std::vector<int64_t> row;
                    std::stringstream rowSs2(rowStr2);
                    std::string valStr2;

                    while(std::getline(rowSs2, valStr2, ','))
                    {
                        valStr2.erase(0, valStr2.find_first_not_of(" \t"));
                        valStr2.erase(valStr2.find_last_not_of(" \t") + 1);
                        if(!valStr2.empty())
                        {
                            row.push_back(std::stoll(valStr2));
                        }
                    }

                    if(!row.empty())
                    {
                        config.indices.push_back(row);
                    }
                }
            }
        }
        else if(strcmp(argv[i], "--updates") == 0 && i + 1 < argc)
        {
            config.updates.clear();
            char* token = std::strtok(argv[++i], ",");
            while(token != nullptr)
            {
                config.updates.push_back(std::stof(token));
                token = std::strtok(nullptr, ",");
            }
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            std::cerr << "--data-dims <d0,d1,...> --indices-dims <d0,d1,...> "
                      << "--updates-dims <d0,d1,...> -d <data_type> "
                      << "--reduction <none/add/mul/max/min> "
                      << "--indices <row1_col1,row1_col2;row2_col1,row2_col2> "
                      << "--updates <val1,val2,...> [--cpu-validation]\n";
            exit(1);
        }
    }

    return config;
}

template <typename InputType, typename IndicesType, typename UpdateType>
class ScatterNDRunner
{
public:
    ScatterNDRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    void run()
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto indicesType = getDataTypeEnumFromType<IndicesType>();

        const auto& dataDims = config_.dataDims;
        const auto& dataStrides = config_.dataStrides;
        const auto& indicesDims = config_.indicesDims;
        const auto& indicesStrides = config_.indicesStrides;
        const auto& updatesDims = config_.updatesDims;
        const auto& updatesStrides = config_.updatesStrides;
        const auto& indicesData = config_.indices;
        const auto& updatesData = config_.updates;

        std::vector<int64_t> outputDims = dataDims;

        size_t outputTotalElems = 1;
        for(int64_t dim : outputDims)
        {
            outputTotalElems *= static_cast<size_t>(dim);
        }

        auto graph = std::make_shared<graph::Graph>();
        graph->set_name("scatter_nd_test")
            .set_io_data_type(inputType)
            .set_compute_data_type(DataType::FLOAT)
            .set_intermediate_data_type(inputType);

        auto dataAttr = std::make_shared<graph::TensorAttributes>(
            graph::Tensor_attributes().set_name("data").set_dim(dataDims).set_stride(dataStrides));

        auto indicesAttr
            = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                            .set_name("indices")
                                                            .set_dim(indicesDims)
                                                            .set_stride(indicesStrides)
                                                            .set_data_type(indicesType));

        auto updatesAttr
            = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                            .set_name("updates")
                                                            .set_dim(updatesDims)
                                                            .set_stride(updatesStrides));

        auto scatterNDAttributes = graph::ScatterNDAttributes()
                                       .set_name("scatter_nd_node")
                                       .set_reduction(getReductionMode(config_.reduction));

        auto outputAttr
            = graph->scatter_nd(dataAttr, indicesAttr, updatesAttr, scatterNDAttributes);
        outputAttr->set_output(true).set_data_type(inputType);

        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful.\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        Tensor<InputType> dataTensor(dataDims, dataStrides);
        Tensor<IndicesType> indicesTensor(indicesDims, indicesStrides);
        Tensor<UpdateType> updatesTensor(updatesDims, updatesStrides);
        Tensor<InputType> outputTensor(outputDims, dataStrides);

        fillTensorWithRandomValues(dataTensor);

        std::vector<IndicesType> flatIndices;
        for(const auto& row : indicesData)
        {
            for(int64_t val : row)
            {
                flatIndices.push_back(static_cast<IndicesType>(val));
            }
        }
        indicesTensor.fillWithData(flatIndices.data(), flatIndices.size() * sizeof(IndicesType));

        std::vector<UpdateType> flatUpdates;
        for(float val : updatesData)
        {
            flatUpdates.push_back(static_cast<UpdateType>(val));
        }
        updatesTensor.fillWithData(flatUpdates.data(), flatUpdates.size() * sizeof(UpdateType));

        std::unordered_map<int64_t, void*> variantPack;
        variantPack[dataAttr->get_uid()] = dataTensor.memory().deviceData();
        variantPack[indicesAttr->get_uid()] = indicesTensor.memory().deviceData();
        variantPack[updatesAttr->get_uid()] = updatesTensor.memory().deviceData();
        variantPack[outputAttr->get_uid()] = outputTensor.memory().deviceData();

        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        outputTensor.memory().markDeviceModified();

        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "ScatterND avg times: " << time / 100 << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        const InputType* outputData = outputTensor.memory().hostData();
        std::cout << "ScatterND first 10 values: ";
        for(int i = 0; i < std::min(10, static_cast<int>(outputTotalElems)); ++i)
        {
            std::cout << static_cast<float>(outputData[i]) << " ";
        }
        std::cout << '\n';

        // ========== CPU 验证 ==========
        if(config_.cpuValidation)
        {
            std::cout << "\n=== CPU Validation ===\n";

            // 创建参考输出张量
            Tensor<InputType> refOutputTensor(outputDims, dataStrides);

            // 获取数据指针
            const InputType* dataPtr = dataTensor.memory().hostData();
            const IndicesType* indicesPtr = indicesTensor.memory().hostData();
            const UpdateType* updatesPtr = updatesTensor.memory().hostData();
            InputType* refPtr = refOutputTensor.memory().hostData();

            // 复制 data 到 ref
            size_t totalElems = 1;
            for(int64_t dim : dataDims)
            {
                totalElems *= static_cast<size_t>(dim);
            }
            std::copy(dataPtr, dataPtr + totalElems, refPtr);

            // 获取维度信息
            int64_t k = indicesDims.back(); // 索引深度
            int64_t q = static_cast<int64_t>(indicesDims.size()) - 1; // batch 维度数
            int64_t dataRank = static_cast<int64_t>(dataDims.size());
            int64_t trailingRank = dataRank - k;

            // 计算 batch size
            int64_t batchSize = 1;
            for(int64_t i = 0; i < q; ++i)
            {
                batchSize *= indicesDims[static_cast<size_t>(i)];
            }

            // 计算 trailing slice size
            int64_t sliceSize = 1;
            for(int64_t i = k; i < dataRank; ++i)
            {
                sliceSize *= dataDims[static_cast<size_t>(i)];
            }

            // 遍历每个 batch
            for(int64_t batchIdx = 0; batchIdx < batchSize; ++batchIdx)
            {
                // 读取目标索引
                std::vector<int64_t> targetIndex;
                int64_t indicesOffset = batchIdx * k;
                for(int64_t i = 0; i < k; ++i)
                {
                    targetIndex.push_back(static_cast<int64_t>(indicesPtr[indicesOffset + i]));
                }

                // 处理 trailing 维度
                if(trailingRank == 0)
                {
                    // 标量更新
                    int64_t offset = getLinearOffset(targetIndex, dataDims);
                    applyReduction(refPtr[offset],
                                   static_cast<InputType>(updatesPtr[batchIdx]),
                                   config_.reduction);
                }
                else
                {
                    // 切片更新
                    for(int64_t sliceIdx = 0; sliceIdx < sliceSize; ++sliceIdx)
                    {
                        std::vector<int64_t> targetPos = targetIndex;
                        int64_t temp = sliceIdx;
                        for(int64_t i = dataRank - 1; i >= k; --i)
                        {
                            int64_t dimSize = dataDims[static_cast<size_t>(i)];
                            targetPos.insert(targetPos.begin() + static_cast<int>(i),
                                             temp % dimSize);
                            temp /= dimSize;
                        }

                        int64_t offset = getLinearOffset(targetPos, dataDims);
                        int64_t updateOffset = batchIdx * sliceSize + sliceIdx;
                        applyReduction(refPtr[offset],
                                       static_cast<InputType>(updatesPtr[updateOffset]),
                                       config_.reduction);
                    }
                }
            }

            refOutputTensor.memory().markHostModified();

            // 获取容差
            float tolerance = getTolerance<InputType>();
            std::cout << "Tolerance: " << tolerance << std::endl;

            // 验证
            CpuFpReferenceValidation<InputType> validator(tolerance, tolerance);
            bool isMatch = validator.allClose(refOutputTensor, outputTensor);
            std::cout << "CPU validation result: " << (isMatch ? "✓ successful" : "✗ failed")
                      << "\n";
        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    ReductionMode getReductionMode(const std::string& reductionStr)
    {
        if(reductionStr == "none")
            return ReductionMode::NONE;
        else if(reductionStr == "add")
            return ReductionMode::ADD;
        else if(reductionStr == "mul")
            return ReductionMode::MUL;
        else if(reductionStr == "max")
            return ReductionMode::MAX;
        else if(reductionStr == "min")
            return ReductionMode::MIN;
        else
        {
            std::cerr << "Unsupported reduction mode: " << reductionStr << std::endl;
            exit(1);
        }
    }

    template <typename T>
    float getTolerance()
    {
        if(config_.dataType == "tf32")
        {
            return static_cast<float>(1e-2f);
        }
        else
        {
            return conv::getToleranceFwd<T>();
        }
    }

    template <typename T>
    void fillTensorWithRandomValues(Tensor<T>& tensor)
    {
        if constexpr(std::is_same_v<T, int8_t>)
        {
            tensor.fillWithRandomValues(static_cast<T>(-127), static_cast<T>(127));
        }
        else
        {
            tensor.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
        }
    }

    // 辅助函数：将多维索引转换为线性偏移
    int64_t getLinearOffset(const std::vector<int64_t>& indices, const std::vector<int64_t>& dims)
    {
        int64_t offset = 0;
        int64_t stride = 1;
        for(int64_t i = static_cast<int64_t>(dims.size()) - 1; i >= 0; --i)
        {
            offset += indices[static_cast<size_t>(i)] * stride;
            stride *= dims[static_cast<size_t>(i)];
        }
        return offset;
    }

    // 应用 reduction 操作
    template <typename T>
    void applyReduction(T& current, T update, const std::string& reduction)
    {
        if(reduction == "none")
        {
            current = update;
        }
        else if(reduction == "add")
        {
            current += update;
        }
        else if(reduction == "mul")
        {
            current *= update;
        }
        else if(reduction == "max")
        {
            current = std::max(current, update);
        }
        else if(reduction == "min")
        {
            current = std::min(current, update);
        }
    }
};

void runScatterND(hipdnnHandle_t handle, const Config& config)
{
    ScatterNDRunner<float, int32_t, float> runner(handle, config);

    if(config.dataType == "fp32" || config.dataType == "tf32")
    {
        runner.run();
    }
    else if(config.dataType == "fp16")
    {
        ScatterNDRunner<half, int32_t, half> runnerHalf(handle, config);
        runnerHalf.run();
    }
    else if(config.dataType == "bfp16")
    {
        ScatterNDRunner<bfloat16, int32_t, bfloat16> runnerBf16(handle, config);
        runnerBf16.run();
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));
    runScatterND(handle, config);
    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
