#include <algorithm>
#include <cmath>
#include <cstring>
#include <iostream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceGatherElements.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>

#include "../utils.hpp"

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

struct Config
{
    int64_t dim0 = 2;
    int64_t dim1 = 3;
    int64_t axis = 1;
    std::string dataType = "fp32";
    std::vector<std::vector<int64_t>> indices = {{0, 2, 1}, {2, 0, 1}};
    bool cpuValidation = false;
};

Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "--dim0") == 0 && i + 1 < argc)
        {
            config.dim0 = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--dim1") == 0 && i + 1 < argc)
        {
            config.dim1 = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "--axis") == 0 && i + 1 < argc)
        {
            config.axis = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "--indices") == 0 && i + 1 < argc)
        {
            config.indices.clear();
            std::string indicesStr = argv[++i];

            std::stringstream ss(indicesStr);
            std::string rowStr;

            while(std::getline(ss, rowStr, ';'))
            {
                rowStr.erase(0, rowStr.find_first_not_of(" \t"));
                rowStr.erase(rowStr.find_last_not_of(" \t") + 1);

                if(rowStr.empty())
                    continue;

                std::vector<int64_t> row;
                std::stringstream rowSs(rowStr);
                std::string valStr;

                while(std::getline(rowSs, valStr, ','))
                {
                    valStr.erase(0, valStr.find_first_not_of(" \t"));
                    valStr.erase(valStr.find_last_not_of(" \t") + 1);
                    if(!valStr.empty())
                    {
                        row.push_back(std::stoll(valStr));
                    }
                }

                if(!row.empty())
                {
                    config.indices.push_back(row);
                }
            }

            if(config.indices.empty())
            {
                std::stringstream ss2(indicesStr);
                std::string rowStr2;

                while(std::getline(ss2, rowStr2, ' '))
                {
                    rowStr2.erase(0, rowStr2.find_first_not_of(" \t"));
                    rowStr2.erase(rowStr2.find_last_not_of(" \t") + 1);

                    if(rowStr2.empty())
                        continue;

                    std::vector<int64_t> row;
                    std::stringstream rowSs2(rowStr2);
                    std::string valStr2;

                    while(std::getline(rowSs2, valStr2, ','))
                    {
                        valStr2.erase(0, valStr2.find_first_not_of(" \t"));
                        valStr2.erase(valStr2.find_last_not_of(" \t") + 1);
                        if(!valStr2.empty())
                        {
                            row.push_back(std::stoll(valStr2));
                        }
                    }

                    if(!row.empty())
                    {
                        config.indices.push_back(row);
                    }
                }
            }
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            std::cerr << "--dim0 <dim0> --dim1 <dim1> --axis <axis> "
                      << "-d <data_type> --indices <row1_col1,row1_col2;row2_col1,row2_col2> "
                      << "[--cpu-validation]\n";
            exit(1);
        }
    }

    return config;
}

template <typename InputType, typename IndicesType>
class GatherElementsRunner
{
public:
    GatherElementsRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    void run()
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto indicesType = getDataTypeEnumFromType<IndicesType>();

        const int64_t dim0 = config_.dim0;
        const int64_t dim1 = config_.dim1;
        const int64_t axis = config_.axis;
        const auto& indicesData = config_.indices;

        std::cout << "Parsed indices: ";
        for(const auto& row : indicesData)
        {
            std::cout << "[";
            for(size_t i = 0; i < row.size(); ++i)
            {
                std::cout << row[i];
                if(i < row.size() - 1)
                    std::cout << ",";
            }
            std::cout << "] ";
        }
        std::cout << std::endl;

        if(indicesData.empty())
        {
            throw std::runtime_error("Indices cannot be empty");
        }

        int64_t indicesDim0 = static_cast<int64_t>(indicesData.size());
        int64_t indicesDim1 = static_cast<int64_t>(indicesData[0].size());

        for(const auto& row : indicesData)
        {
            if(static_cast<int64_t>(row.size()) != indicesDim1)
            {
                std::cerr << "Row size: " << row.size() << ", expected: " << indicesDim1
                          << std::endl;
                throw std::runtime_error("All rows in indices must have the same length");
            }
        }

        std::vector<int64_t> outputDim = {indicesDim0, indicesDim1};

        size_t outputTotalElems = static_cast<size_t>(outputDim[0] * outputDim[1]);

        auto graph = std::make_shared<graph::Graph>();
        graph->set_name("gather_elements_test")
            .set_io_data_type(inputType)
            .set_compute_data_type(DataType::FLOAT)
            .set_intermediate_data_type(inputType);

        auto dataAttr = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                                      .set_name("data")
                                                                      .set_dim({dim0, dim1})
                                                                      .set_stride({dim1, 1}));

        auto indicesAttr
            = std::make_shared<graph::TensorAttributes>(graph::Tensor_attributes()
                                                            .set_name("indices")
                                                            .set_dim({indicesDim0, indicesDim1})
                                                            .set_stride({indicesDim1, 1})
                                                            .set_data_type(indicesType));

        auto gatherAttributes
            = graph::GatherElementsAttributes().set_name("gather_elements_node").set_axis(axis);

        auto outputAttr = graph->gather_elements(dataAttr, indicesAttr, gatherAttributes);
        outputAttr->set_output(true).set_data_type(inputType);

        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful.\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        Tensor<InputType> dataTensor(dataAttr->get_dim(), dataAttr->get_stride());
        Tensor<IndicesType> indicesTensor(indicesAttr->get_dim(), indicesAttr->get_stride());
        Tensor<InputType> outputTensor(outputAttr->get_dim(), outputAttr->get_stride());

        fillTensorWithRandomValues(dataTensor);

        std::vector<IndicesType> flatIndices;
        for(const auto& row : indicesData)
        {
            for(int64_t val : row)
            {
                int64_t clampedVal = val;
                if(axis == 0)
                {
                    clampedVal = std::min(val, dim0 - 1);
                }
                else if(axis == 1)
                {
                    clampedVal = std::min(val, dim1 - 1);
                }
                flatIndices.push_back(static_cast<IndicesType>(clampedVal));
            }
        }
        indicesTensor.fillWithData(flatIndices.data(), flatIndices.size() * sizeof(IndicesType));

        std::unordered_map<int64_t, void*> variantPack;
        variantPack[dataAttr->get_uid()] = dataTensor.memory().deviceData();
        variantPack[indicesAttr->get_uid()] = indicesTensor.memory().deviceData();
        variantPack[outputAttr->get_uid()] = outputTensor.memory().deviceData();

        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        outputTensor.memory().markDeviceModified();

        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "GatherElements avg times: " << time / 100 << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        const InputType* outputData = outputTensor.memory().hostData();
        std::cout << "GatherElements first 10 values: ";
        for(int i = 0; i < std::min(10, static_cast<int>(outputTotalElems)); ++i)
        {
            std::cout << static_cast<float>(outputData[i]) << " ";
        }
        std::cout << '\n';

        // ========== CPU 验证 ==========
        if(config_.cpuValidation)
        {
            std::cout << "\n=== CPU Validation ===\n";

            // 创建参考输出张量
            Tensor<InputType> refOutputTensor(outputAttr->get_dim(), outputAttr->get_stride());

            // 关键修复：确保数据同步到host
            // 先标记device数据已修改，然后通过hostData()触发同步
            dataTensor.memory().markDeviceModified();
            indicesTensor.memory().markDeviceModified();

            // 强制同步数据到host
            (void)dataTensor.memory().hostData();
            (void)indicesTensor.memory().hostData();

            // 执行CPU参考实现
            try
            {
                CpuFpReferenceGatherElements::gatherElements(
                    dataTensor, indicesTensor, refOutputTensor, axis);
                std::cout << "CPU reference execution successful.\n";
            }
            catch(const std::exception& e)
            {
                std::cerr << "CPU reference execution failed: " << e.what() << std::endl;
                exit(1);
            }

            float tolerance = getTolerance<InputType>();
            std::cout << "Tolerance: " << tolerance << std::endl;

            CpuFpReferenceValidation<InputType> validator(tolerance, tolerance);
            bool isMatch = validator.allClose(refOutputTensor, outputTensor);
            std::cout << "CPU validation result: " << (isMatch ? "✓ successful" : "✗ failed")
                      << "\n";

            if(!isMatch)
            {
                const InputType* refData = refOutputTensor.memory().hostData();
                const InputType* currData = outputTensor.memory().hostData();
                size_t printCount = std::min(size_t(10), outputTotalElems);

                std::cout << "First " << printCount << " values comparison:\n";
                std::cout << "Ref:  ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<float>(refData[i]) << " ";
                }
                std::cout << "\nCurr: ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<float>(currData[i]) << " ";
                }
                std::cout << "\n";
            }
        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    template <typename T>
    float getTolerance()
    {
        if(config_.dataType == "tf32")
        {
            return static_cast<float>(1e-2f);
        }
        else
        {
            return conv::getToleranceFwd<T>();
        }
    }

    template <typename T>
    void fillTensorWithRandomValues(Tensor<T>& tensor)
    {
        if constexpr(std::is_same_v<T, int8_t>)
        {
            tensor.fillWithRandomValues(static_cast<T>(-127), static_cast<T>(127));
        }
        else
        {
            tensor.fillWithRandomValues(static_cast<T>(0.0f), static_cast<T>(1.0f));
        }
    }
};

void runGatherElements(hipdnnHandle_t handle, const Config& config)
{
    GatherElementsRunner<float, int32_t> runner(handle, config);

    if(config.dataType == "fp32" || config.dataType == "tf32")
    {
        runner.run();
    }
    else if(config.dataType == "fp16")
    {
        GatherElementsRunner<half, int32_t> runnerHalf(handle, config);
        runnerHalf.run();
    }
    else if(config.dataType == "bfp16")
    {
        GatherElementsRunner<bfloat16, int32_t> runnerBf16(handle, config);
        runnerBf16.run();
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));
    runGatherElements(handle, config);
    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
