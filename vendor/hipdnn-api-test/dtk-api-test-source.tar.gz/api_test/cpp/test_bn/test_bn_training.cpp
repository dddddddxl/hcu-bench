#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include <hipdnn_data_sdk/utilities/Constants.hpp>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceBatchnorm.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>

#include "../utils.hpp"
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>
using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// 配置结构
struct Config
{
    int64_t n = 16; // Batch size
    int64_t c = 16; // Number of channels
    int64_t h = 16; // Input height
    int64_t w = 16; // Input width
    int mode = 1; // Normalization mode: 0=per-activation, 1=spatial (default=0)
    std::string dataType = "fp32"; // Data type (fp32/fp16)
    std::string layout = "NCHW"; // Tensor layout (NCHW/NHWC)
    bool cpuValidation = true; // Enable CPU validation (default=false)
    int fileIndex = 0; // Reference file index (0 = no file reading)
    std::string filePath = "."; // Path to reference files
};

// 解析命令行参数以填充配置结构
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-m") == 0 && i + 1 < argc)
        {
            config.mode = std::stoi(argv[++i]);
            if(config.mode != 0 && config.mode != 1)
            {
                std::cerr << "Invalid mode: " << config.mode
                          << ", must be 0 (per-activation) or 1 (spatial)\n";
                exit(1);
            }
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            std::cerr << "Usage: bn_training -n <batch> -c <channels> -H <height> -W <width> "
                      << "-m <mode(0/1)> -d <data_type> -L <layout> "
                      << "-i <file_index> [--cpu-validation] -path <path>\n";
            exit(1);
        }
    }

    return config;
}

class BnRunner
{
public:
    BnRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType, typename IntermediateType>
    void operator()(const TensorLayout& layout)
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        std::cout << "Running batch normalization training graph " << inputType << " [" << layout
                  << "]" << (config_.cpuValidation ? " (with CPU validation)" : "") << "...\n";

        // 读取配置参数
        const int64_t n = config_.n;
        const int64_t c = config_.c;
        const int64_t h = config_.h;
        const int64_t w = config_.w;
        const int mode = config_.mode;

        // 根据模式计算总元素和参数尺寸
        const size_t xTotalElems = static_cast<size_t>(n * c * h * w);
        size_t bnParamElems;
        std::vector<int64_t> bnParamDims;

        if(mode == 0)
        { // per-activation mode: 参数具有形状[n, c, 1, 1]
            bnParamDims = {n, c, 1, 1};
            bnParamElems = static_cast<size_t>(n * c);
        }
        else
        { // spatial mode: 参数具有形状[1, c, 1, 1]
            bnParamDims = {1, c, 1, 1};
            bnParamElems = static_cast<size_t>(c);
        }

        // 构建批量规范化推理图
        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_intermediate_data_type(intermediateType)
            .set_compute_data_type(DataType::FLOAT);

        // 创建输入/输出张量
        auto x = createTensor({n, c, h, w}, inputType, layout.strideOrder);
        auto scale = createTensor(bnParamDims, intermediateType, layout.strideOrder);
        auto bias = createTensor(bnParamDims, intermediateType, layout.strideOrder);
        auto prevRunningMean = createTensor(bnParamDims, intermediateType, layout.strideOrder);
        auto prevRunningVar = createTensor(bnParamDims, intermediateType, layout.strideOrder);
        auto momentum = createTensor({1, 1, 1, 1}, intermediateType, layout.strideOrder);
        auto epsilon = createTensor({1, 1, 1, 1}, intermediateType, layout.strideOrder);

        epsilon->set_value(BATCHNORM_DEFAULT_EPSILON);
        momentum->set_value(0.1);

        // 配置bnorm属性
        auto bnAttributes = graph::BatchnormAttributes();
        bnAttributes.set_name("bn_training_node");
        bnAttributes.set_previous_running_stats(prevRunningMean, prevRunningVar, momentum)
            .set_epsilon(epsilon);

        // 在图中添加bnorm推理节点
        auto [y, savedMean, savedInvVariance, nextRunningMean, nextRunningVar]
            = graph->batchnorm(x, scale, bias, bnAttributes);

        y->set_output(true);
        nextRunningMean->set_output(true);
        nextRunningVar->set_output(true);
        savedMean->set_output(true);
        savedInvVariance->set_output(true);

        // 验证并构建图形
        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful.\n";
        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";
        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";
        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";
        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        // 初始化张量
        Tensor<InputType> xTensor(x->get_dim(), x->get_stride());
        Tensor<IntermediateType> scaleTensor(scale->get_dim(), scale->get_stride());
        Tensor<IntermediateType> biasTensor(bias->get_dim(), bias->get_stride());
        Tensor<IntermediateType> prevMeanTensor(prevRunningMean->get_dim(),
                                                prevRunningMean->get_stride());
        Tensor<IntermediateType> prevVarTensor(prevRunningVar->get_dim(),
                                               prevRunningVar->get_stride());
        Tensor<IntermediateType> momentumTensor(momentum->get_dim(), momentum->get_stride());
        Tensor<IntermediateType> epsilonTensor(epsilon->get_dim(), epsilon->get_stride());

        // 初始化值
        Tensor<InputType> yTensor(y->get_dim(), y->get_stride());
        Tensor<IntermediateType> savedMeanTensor(savedMean->get_dim(), savedMean->get_stride());
        Tensor<IntermediateType> savedInvVarTensor(savedInvVariance->get_dim(),
                                                   savedInvVariance->get_stride());

        fillTensorWithRandomValues(xTensor);
        fillTensorWithRandomValues(scaleTensor);
        fillTensorWithRandomValues(biasTensor);
        fillTensorWithRandomValues(prevMeanTensor);
        fillTensorWithRandomValues(prevVarTensor);

        // 读取参考数据或生成随机数据
        bool readSuccess = false;
        std::vector<InputType> refXData, refYData;
        std::vector<IntermediateType> refScaleData, refBiasData, refMeanData, refInvVarianceData;
        Tensor<InputType>* refYTensorPtr = nullptr;

        if(config_.fileIndex > 0)
        {
            const std::string xFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bn_input.bin";
            const std::string scaleFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bn_scale.bin";
            const std::string biasFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bn_bias.bin";
            const std::string meanFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bn_mean.bin";
            const std::string invVarFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bn_invVariance.bin";
            const std::string yFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bn_output.bin";

            // 读取所有参考数据
            readSuccess
                = readRawTensor<InputType>(xFilename, refXData, xTotalElems)
                  && readRawTensor<IntermediateType>(scaleFilename, refScaleData, bnParamElems)
                  && readRawTensor<IntermediateType>(biasFilename, refBiasData, bnParamElems)
                  && readRawTensor<IntermediateType>(meanFilename, refMeanData, bnParamElems)
                  && readRawTensor<IntermediateType>(
                      invVarFilename, refInvVarianceData, bnParamElems)
                  && readRawTensor<InputType>(yFilename, refYData, xTotalElems);

            if(readSuccess)
            {
                std::cout << "Successfully read BN reference files (mode " << mode << ")\n";
                // 将参考数据复制到张量
                std::copy(refXData.begin(), refXData.end(), xTensor.memory().hostData());
                xTensor.memory().markHostModified();
                std::copy(
                    refScaleData.begin(), refScaleData.end(), scaleTensor.memory().hostData());
                scaleTensor.memory().markHostModified();
                std::copy(refBiasData.begin(), refBiasData.end(), biasTensor.memory().hostData());
                biasTensor.memory().markHostModified();
                std::copy(
                    refMeanData.begin(), refMeanData.end(), prevMeanTensor.memory().hostData());
                prevMeanTensor.memory().markHostModified();
                std::copy(refInvVarianceData.begin(),
                          refInvVarianceData.end(),
                          prevVarTensor.memory().hostData());
                prevVarTensor.memory().markHostModified();

                // 初始化参考输出张量
                refYTensorPtr = new Tensor<InputType>(y->get_dim(), y->get_stride());
                std::copy(refYData.begin(), refYData.end(), refYTensorPtr->memory().hostData());
                refYTensorPtr->memory().markHostModified();
                std::cout << "First 10 reference output y values: ";
                for(size_t i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(refYData[i]) << " ";
                }
                std::cout << "\n";
            }
            else
            {
                std::cerr << "[WARN] Failed to read BN reference files, initializing with default "
                             "values (mode "
                          << mode << ")\n";
                fillTensorWithRandomValues(xTensor);
                scaleTensor.fillWithValue(static_cast<IntermediateType>(1.0f));
                biasTensor.fillWithValue(static_cast<IntermediateType>(0.0f));
                prevMeanTensor.fillWithValue(static_cast<IntermediateType>(0.5f));
                prevVarTensor.fillWithValue(static_cast<IntermediateType>(1.0f));
            }
        }
        else
        {
            // 当没有参考文件时，使用随机值初始化
            fillTensorWithRandomValues(xTensor);
            scaleTensor.fillWithValue(static_cast<IntermediateType>(1.0f));
            biasTensor.fillWithValue(static_cast<IntermediateType>(0.0f));
            prevMeanTensor.fillWithValue(static_cast<IntermediateType>(0.5f));
            prevVarTensor.fillWithValue(static_cast<IntermediateType>(1.0f));
        }

        momentumTensor.memory().hostData()[0] = 0.1f;
        epsilonTensor.memory().hostData()[0]
            = static_cast<IntermediateType>(BATCHNORM_DEFAULT_EPSILON);

        auto preMeanPtr = static_cast<IntermediateType*>(prevMeanTensor.memory().hostData());
        auto preVarPtr = static_cast<IntermediateType*>(prevVarTensor.memory().hostData());

        Tensor<IntermediateType> prevMeanCpuTensor(prevRunningMean->get_dim());
        Tensor<IntermediateType> prevVarCpuTensor(prevRunningVar->get_dim());

        auto meanElemCount = static_cast<size_t>(prevRunningMean->get_volume());
        size_t meanDataSize = meanElemCount * sizeof(IntermediateType);

        auto varElemCount = static_cast<size_t>(prevRunningVar->get_volume());
        size_t varDataSize = varElemCount * sizeof(IntermediateType);

        prevMeanCpuTensor.fillWithData(preMeanPtr, meanDataSize);
        prevVarCpuTensor.fillWithData(preVarPtr, varDataSize);

        // 准备变量包以执行bnorm推理和计时
        std::unordered_map<int64_t, void*> variantPack;

        // 内存管理
        variantPack[x->get_uid()] = xTensor.memory().deviceData();
        variantPack[scale->get_uid()] = scaleTensor.memory().deviceData();
        variantPack[bias->get_uid()] = biasTensor.memory().deviceData();
        variantPack[prevRunningMean->get_uid()] = prevMeanTensor.memory().deviceData();
        variantPack[prevRunningVar->get_uid()] = prevVarTensor.memory().deviceData();
        variantPack[momentum->get_uid()] = momentumTensor.memory().deviceData();
        variantPack[epsilon->get_uid()] = epsilonTensor.memory().deviceData();
        variantPack[y->get_uid()] = yTensor.memory().deviceData();

        // hipDNN使用两个单独的内存块来存储更新前后的统计数据，而MIOpen只使用一个内存块来保存它们。
        // 为了适应这种差异，hipDNN接口中的prev和next统计数据都指向相同的内存地址，插件层将此地址传递给MIOpen。
        variantPack[nextRunningMean->get_uid()] = prevMeanTensor.memory().deviceData();
        variantPack[nextRunningVar->get_uid()] = prevVarTensor.memory().deviceData();
        variantPack[savedMean->get_uid()] = savedMeanTensor.memory().deviceData();
        variantPack[savedInvVariance->get_uid()] = savedInvVarTensor.memory().deviceData();

        // 分配工作空间
        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 用100次迭代来衡量执行时间
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        //        for (int exec_idx = 0; exec_idx < 100; ++exec_idx) {
        //            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        //        }
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        //        std::cout << "Average execution time (mode " << mode << "): " << time / 100 << " ms\n";
        std::cout << "Average execution time (mode " << mode << "): " << time << " ms\n";
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        yTensor.memory().markDeviceModified();
        prevMeanTensor.memory().markDeviceModified();
        prevVarTensor.memory().markDeviceModified();
        savedMeanTensor.memory().markDeviceModified();
        savedInvVarTensor.memory().markDeviceModified();

        const InputType* yHostPtr = yTensor.memory().hostData();
        float* prevMeanHostPtr = prevMeanTensor.memory().hostData();
        float* prevVarHostPtr = prevVarTensor.memory().hostData();

        std::cout << "First 10 BN training output y values: ";
        for(int i = 0; i < 10; ++i)
        {
            std::cout << static_cast<float>(yHostPtr[i]) << " ";
        }
        std::cout << "\n";
        std::cout << "First 10 BN training output prevMean values: ";
        for(int i = 0; i < 10; ++i)
        {
            std::cout << static_cast<float>(prevMeanHostPtr[i]) << " ";
        }
        std::cout << "\n";
        std::cout << "First 10 BN training output prevVar values: ";
        for(int i = 0; i < 10; ++i)
        {
            std::cout << static_cast<float>(prevVarHostPtr[i]) << " ";
        }
        std::cout << "\n";

        // 结果比较
        // 与参考文件进行比较
        if(config_.fileIndex > 0 && readSuccess && refYTensorPtr != nullptr)
        {
            auto tolerance = batchnorm::getToleranceTraining<InputType>();
            CpuFpReferenceValidation<InputType> fileValidator(tolerance, tolerance);
            bool isMatch = fileValidator.allClose(*refYTensorPtr, yTensor);
            std::cout << "cudnn validation result: " << (isMatch ? "successful" : "failed") << "\n";
        }

        // CPU validation
        if(config_.cpuValidation)
        {
            std::cout << "Running CPU reference validation (mode " << mode << ")...\n";

            // 创建参考输出张量
            Tensor<InputType> yRefTensor(y->get_dim(), y->get_stride());
            Tensor<IntermediateType> nextMeanRefTensor(nextRunningMean->get_dim(),
                                                       nextRunningMean->get_stride());
            Tensor<IntermediateType> nextVarRefTensor(nextRunningVar->get_dim(),
                                                      nextRunningVar->get_stride());
            Tensor<IntermediateType> savedMeanRefTensor(savedMean->get_dim(),
                                                        savedMean->get_stride());
            Tensor<IntermediateType> savedInvVarRefTensor(savedInvVariance->get_dim(),
                                                          savedInvVariance->get_stride());

            // 执行 CPU 参考计算
            CpuFpReferenceBatchnorm::fwdTraining(xTensor,
                                                 scaleTensor,
                                                 biasTensor,
                                                 yRefTensor,
                                                 BATCHNORM_DEFAULT_EPSILON,
                                                 0.1,
                                                 &savedMeanRefTensor,
                                                 &savedInvVarRefTensor,
                                                 &prevMeanCpuTensor,
                                                 &prevVarCpuTensor,
                                                 &nextMeanRefTensor,
                                                 &nextVarRefTensor);

            const InputType* yRefHostPtr = yRefTensor.memory().hostData();
            float* nextMeanRefHostPtr = nextMeanRefTensor.memory().hostData();
            float* nextVarRefHostPtr = nextVarRefTensor.memory().hostData();

            std::cout << "First 10 BN training output y values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(yRefHostPtr[i]) << " ";
            }
            std::cout << "\n";
            std::cout << "First 10 BN training output nextMean values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(nextMeanRefHostPtr[i]) << " ";
            }
            std::cout << "\n";
            std::cout << "First 10 BN training output nextVar values: ";
            for(int i = 0; i < 10; ++i)
            {
                std::cout << static_cast<float>(nextVarRefHostPtr[i]) << " ";
            }
            std::cout << "\n";

            // Validate results
            // 容差设置
            auto tolerance = batchnorm::getToleranceTraining<InputType>();

            // 创建验证器
            auto yValidator = CpuFpReferenceValidation<InputType>(tolerance, tolerance);
            auto statsValidator = CpuFpReferenceValidation<IntermediateType>(
                static_cast<IntermediateType>(tolerance), static_cast<IntermediateType>(tolerance));

            // allClose用来比较两个张量是否在容差范围内相等
            bool yValid = yValidator.allClose(yRefTensor, yTensor);
            bool nextMeanValid = statsValidator.allClose(nextMeanRefTensor, prevMeanTensor);
            bool nextVarValid = statsValidator.allClose(nextVarRefTensor, prevVarTensor);

            std::cout << "CPU reference validation:\n";
            std::cout << "y: " << (yValid ? "successful" : "failed") << "\n";
            std::cout << "  next_running_mean: " << (nextMeanValid ? "successful" : "failed")
                      << "\n";
            std::cout << "  next_running_var: " << (nextVarValid ? "successful" : "failed") << "\n";
        }

        // Free reference tensor memory
        if(refYTensorPtr != nullptr)
        {
            delete refYTensorPtr;
            refYTensorPtr = nullptr;
        }
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    template <typename InputType>
    void fillTensorWithRandomValues(Tensor<InputType>& tensor)
    {
        if constexpr(std::is_same_v<InputType, int8_t>)
        {
            tensor.fillWithRandomValues(static_cast<InputType>(-127), static_cast<InputType>(127));
        }
        else
        {
            tensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));
        }
    }
};

// Dispatch function: selects appropriate data type implementation
void run(hipdnnHandle_t handle, const Config& config)
{
    TensorLayout layout = (config.layout == "NHWC") ? TensorLayout::NHWC : TensorLayout::NCHW;

    if(config.dataType == "fp32")
    {
        BnRunner runner(handle, config);
        runner.template operator()<float, float>(layout);
    }
    else if(config.dataType == "fp16")
    {
        BnRunner runner(handle, config);
        runner.template operator()<half, float>(layout);
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    // 打印参数
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << "\n";

    // 解析配置
    auto config = parseCommandLineArgs(argc, argv);

    // 初始化日志
    initializeFrontendLogging();

    // 使用RAII管理句柄
    hipdnnHandle_t handle;

    HIPDNN_CHECK(hipdnnCreate(&handle));
    // 执行BN
    run(handle, config);

    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
