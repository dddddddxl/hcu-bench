#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include "../utils.hpp"
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceBatchnorm.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>
#include <hipdnn_test_sdk/utilities/TestTolerances.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;
using namespace hipdnn_test_sdk::utilities;

// bnorm反向传播参数的配置结构
struct Config
{
    int64_t n = 1; // Batch size
    int64_t c = 16; // Number of channels
    int64_t h = 16; // Input height
    int64_t w = 16; // Input width
    int mode = 0; // 0=per-activation, 1=spatial
    std::string dataType = "float"; // Data type (fp32/fp16)
    std::string layout = "NCHW"; // Tensor layout
    bool cpuValidation = false; // Enable CPU validation
    int fileIndex = 0; // Reference file index (0 = no read)
    std::string filePath = "."; // Path to reference files
};

// 将命令行参数解析为Config结构
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-m") == 0 && i + 1 < argc)
        {
            config.mode = std::stoi(argv[++i]);
            if(config.mode != 0 && config.mode != 1)
            {
                std::cerr << "Invalid mode: " << config.mode << ", must be 0 or 1\n";
                exit(1);
            }
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-L") == 0 && i + 1 < argc)
        {
            config.layout = argv[++i];
            std::transform(
                config.layout.begin(), config.layout.end(), config.layout.begin(), ::toupper);
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else
        {
            std::cerr << "Unknown parameter: " << argv[i] << std::endl;
            std::cerr << "Usage: bn_backward -n <batch> -c <channels> -H <height> -W <width> "
                      << "-m <mode> -d <data_type> -L <layout> -i <file_index> [--cpu-validation] "
                         "-path <path>\n";
            exit(1);
        }
    }

    return config;
}

class BnBwdRunner
{
public:
    BnBwdRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    template <typename InputType, typename IntermediateType>
    void operator()(const TensorLayout& layout)
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        // 提取配置参数
        const int64_t n = config_.n;
        const int64_t c = config_.c;
        const int64_t h = config_.h;
        const int64_t w = config_.w;
        const int mode = config_.mode;

        // 计算张量维度和元素计数
        const size_t totalElems = static_cast<size_t>(n * c * h * w);
        size_t bnParamElems;
        std::vector<int64_t> bnParamDims;

        if(mode == 0)
        { // per-activation mode: 参数具有形状[n, c, 1, 1]
            bnParamDims = {n, c, 1, 1};
            bnParamElems = static_cast<size_t>(n * c);
        }
        else
        { // spatial mode: 参数具有形状[1, c, 1, 1]
            bnParamDims = {1, c, 1, 1};
            bnParamElems = static_cast<size_t>(c);
        }

        // 创建和配置批规范倒排图
        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_intermediate_data_type(intermediateType)
            .set_compute_data_type(intermediateType);

        // 创建输入/输出张量
        auto dyAttr = createTensor({n, c, h, w}, inputType, layout.strideOrder);
        auto xAttr = createTensor({n, c, h, w}, inputType, layout.strideOrder);
        auto scaleAttr = createTensor(bnParamDims, intermediateType, layout.strideOrder);
        auto savedMeanAttr = createTensor(bnParamDims, intermediateType, layout.strideOrder);
        auto savedInvVarianceAttr = createTensor(bnParamDims, intermediateType, layout.strideOrder);

        // 配置bnorm反向属性
        graph::BatchnormBackwardAttributes bnAttributes;
        bnAttributes.set_name("bn_backward_node");
        bnAttributes.set_saved_mean_and_inv_variance(savedMeanAttr, savedInvVarianceAttr);

        // 在图中添加bnorm反向节点
        auto [dxAttr, dscaleAttr, dbiasAttr]
            = graph->batchnorm_backward(dyAttr, xAttr, scaleAttr, bnAttributes);
        dxAttr->set_output(true);
        dscaleAttr->set_output(true);
        dbiasAttr->set_output(true);

        // 验证并构建图形
        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful.\n";
        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful.\n";
        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully.\n";
        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful.\n";
        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful.\n";

        // 张量初始化
        Tensor<InputType> dyTensor(dyAttr->get_dim(), dyAttr->get_stride());
        Tensor<InputType> xTensor(xAttr->get_dim(), xAttr->get_stride());
        Tensor<IntermediateType> scaleTensor(scaleAttr->get_dim(), scaleAttr->get_stride());
        Tensor<IntermediateType> savedMeanTensor(savedMeanAttr->get_dim(),
                                                 savedMeanAttr->get_stride());
        Tensor<IntermediateType> savedInvVarianceTensor(savedInvVarianceAttr->get_dim(),
                                                        savedInvVarianceAttr->get_stride());

        Tensor<InputType> dxTensor(dxAttr->get_dim(), dxAttr->get_stride());
        Tensor<IntermediateType> dscaleTensor(dscaleAttr->get_dim(), dscaleAttr->get_stride());
        Tensor<IntermediateType> dbiasTensor(dbiasAttr->get_dim(), dbiasAttr->get_stride());

        dxTensor.fillWithValue(static_cast<InputType>(0.0f));
        dscaleTensor.fillWithValue(static_cast<IntermediateType>(0.0f));
        dbiasTensor.fillWithValue(static_cast<IntermediateType>(0.0f));

        // 如果提供了文件索引，则读取参考数据
        bool readSuccess = false;
        std::vector<InputType> refDyData, refXData, refDxData;
        std::vector<IntermediateType> refScaleData, refMeanData, refInvVarianceData;
        std::vector<IntermediateType> refDscaleData, refDbiasData;
        Tensor<InputType>* refDxTensorPtr = nullptr;
        Tensor<IntermediateType>* refDscaleTensorPtr = nullptr;
        Tensor<IntermediateType>* refDbiasTensorPtr = nullptr;

        if(config_.fileIndex > 0)
        {
            const std::string dyFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bn_dy.bin";
            const std::string xFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bn_x.bin";
            const std::string scaleFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bn_scale.bin";
            const std::string meanFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bn_mean.bin";
            const std::string invVarFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bn_invVariance.bin";
            const std::string dxFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bn_dx.bin";
            const std::string dscaleFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bn_dscale.bin";
            const std::string dbiasFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_bn_dbias.bin";

            // 读取所有参考数据
            readSuccess
                = readRawTensor<InputType>(dyFilename, refDyData, totalElems)
                  && readRawTensor<InputType>(xFilename, refXData, totalElems)
                  && readRawTensor<IntermediateType>(scaleFilename, refScaleData, bnParamElems)
                  && readRawTensor<IntermediateType>(meanFilename, refMeanData, bnParamElems)
                  && readRawTensor<IntermediateType>(
                      invVarFilename, refInvVarianceData, bnParamElems)
                  && readRawTensor<InputType>(dxFilename, refDxData, totalElems)
                  && readRawTensor<IntermediateType>(dscaleFilename, refDscaleData, bnParamElems)
                  && readRawTensor<IntermediateType>(dbiasFilename, refDbiasData, bnParamElems);

            if(readSuccess)
            {
                std::cout << "Successfully read BN backward reference files (mode " << mode
                          << ")\n";
                // 将参考数据复制到张量
                std::copy(refDyData.begin(), refDyData.end(), dyTensor.memory().hostData());
                dyTensor.memory().markHostModified();
                std::copy(refXData.begin(), refXData.end(), xTensor.memory().hostData());
                xTensor.memory().markHostModified();
                std::copy(
                    refScaleData.begin(), refScaleData.end(), scaleTensor.memory().hostData());
                scaleTensor.memory().markHostModified();
                std::copy(
                    refMeanData.begin(), refMeanData.end(), savedMeanTensor.memory().hostData());
                savedMeanTensor.memory().markHostModified();
                std::copy(refInvVarianceData.begin(),
                          refInvVarianceData.end(),
                          savedInvVarianceTensor.memory().hostData());
                savedInvVarianceTensor.memory().markHostModified();

                // 初始化参考输出张量
                refDxTensorPtr = new Tensor<InputType>(dxAttr->get_dim(), dxAttr->get_stride());
                std::copy(refDxData.begin(), refDxData.end(), refDxTensorPtr->memory().hostData());
                refDxTensorPtr->memory().markHostModified();

                refDscaleTensorPtr
                    = new Tensor<IntermediateType>(dscaleAttr->get_dim(), dscaleAttr->get_stride());
                std::copy(refDscaleData.begin(),
                          refDscaleData.end(),
                          refDscaleTensorPtr->memory().hostData());
                refDscaleTensorPtr->memory().markHostModified();

                refDbiasTensorPtr
                    = new Tensor<IntermediateType>(dbiasAttr->get_dim(), dbiasAttr->get_stride());
                std::copy(refDbiasData.begin(),
                          refDbiasData.end(),
                          refDbiasTensorPtr->memory().hostData());
                refDbiasTensorPtr->memory().markHostModified();

                std::cout << "First 10 reference dx values: ";
                for(size_t i = 0; i < 10; ++i)
                {
                    std::cout << static_cast<float>(refDxData[i]) << " ";
                }
                std::cout << "\n";
            }
            else
            {
                std::cerr
                    << "[WARN] Failed to read reference files, using random initialization (mode "
                    << mode << ")\n";
                dyTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                              static_cast<InputType>(1.0f));
                xTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                             static_cast<InputType>(1.0f));
                scaleTensor.fillWithValue(static_cast<IntermediateType>(1.0f));
                savedMeanTensor.fillWithValue(static_cast<IntermediateType>(0.5f));
                savedInvVarianceTensor.fillWithRandomValues(static_cast<IntermediateType>(0.1f),
                                                            static_cast<IntermediateType>(1.0f));
            }
        }
        else
        {
            // 当没有参考文件时，使用随机值初始化
            dyTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                          static_cast<InputType>(1.0f));
            xTensor.fillWithRandomValues(static_cast<InputType>(0.0f),
                                         static_cast<InputType>(1.0f));
            scaleTensor.fillWithRandomValues(static_cast<IntermediateType>(0.0f),
                                             static_cast<IntermediateType>(1.0f));
            savedMeanTensor.fillWithRandomValues(static_cast<IntermediateType>(0.0f),
                                                 static_cast<IntermediateType>(1.0f));
            savedInvVarianceTensor.fillWithRandomValues(static_cast<IntermediateType>(0.1f),
                                                        static_cast<IntermediateType>(1.0f));
        }
        // 准备变量包以执行bnorm反向和计时
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[dyAttr->get_uid()] = dyTensor.memory().deviceData();
        variantPack[xAttr->get_uid()] = xTensor.memory().deviceData();
        variantPack[scaleAttr->get_uid()] = scaleTensor.memory().deviceData();
        variantPack[savedMeanAttr->get_uid()] = savedMeanTensor.memory().deviceData();
        variantPack[savedInvVarianceAttr->get_uid()] = savedInvVarianceTensor.memory().deviceData();
        variantPack[dxAttr->get_uid()] = dxTensor.memory().deviceData();
        variantPack[dscaleAttr->get_uid()] = dscaleTensor.memory().deviceData();
        variantPack[dbiasAttr->get_uid()] = dbiasTensor.memory().deviceData();

        // 分配工作空间
        int64_t workspaceSize;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 用100次迭代来衡量执行时间
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        for(int exec_idx = 0; exec_idx < 100; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));
        std::cout << "Average execution time (mode " << mode << "): " << time / 100 << " ms\n";
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        // Retrieve results from device
        dxTensor.memory().markDeviceModified();
        dscaleTensor.memory().markDeviceModified();
        dbiasTensor.memory().markDeviceModified();

        const InputType* currDxData = dxTensor.memory().hostData();
        const IntermediateType* currDscaleData = dscaleTensor.memory().hostData();
        const IntermediateType* currDbiasData = dbiasTensor.memory().hostData();

        // Print first 10 results for verification
        std::cout << "First 10 dx values: ";
        for(int i = 0; i < 10; ++i)
        {
            std::cout << static_cast<float>(currDxData[i]) << " ";
        }
        std::cout << "\n";

        std::cout << "First 10 dscale values: ";
        for(int i = 0; i < 10; ++i)
        {
            std::cout << static_cast<float>(currDscaleData[i]) << " ";
        }
        std::cout << "\n";

        std::cout << "First 10 dbias values: ";
        for(int i = 0; i < 10; ++i)
        {
            std::cout << static_cast<float>(currDbiasData[i]) << " ";
        }
        std::cout << "\n";

        // Validate against reference files if available
        if(config_.fileIndex > 0 && readSuccess)
        {
            auto tolerance = test::batchnorm::getToleranceBackward<InputType>();
            CpuFpReferenceValidation<InputType> dxValidator(tolerance, tolerance);
            CpuFpReferenceValidation<IntermediateType> paramValidator(
                static_cast<IntermediateType>(tolerance), static_cast<IntermediateType>(tolerance));

            bool dxMatch = refDxTensorPtr
                               ? dxValidator.allClose(refDxTensorPtr->memory(), dxTensor.memory())
                               : false;
            bool dscaleMatch
                = refDscaleTensorPtr
                      ? paramValidator.allClose(refDscaleTensorPtr->memory(), dscaleTensor.memory())
                      : false;
            bool dbiasMatch
                = refDbiasTensorPtr
                      ? paramValidator.allClose(refDbiasTensorPtr->memory(), dbiasTensor.memory())
                      : false;

            std::cout << "cudnn validation results:\n";
            std::cout << "  dx: " << (dxMatch ? "successful" : "failed") << "\n";
            std::cout << "  dscale: " << (dscaleMatch ? "successful" : "failed") << "\n";
            std::cout << "  dbias: " << (dbiasMatch ? "successful" : "failed") << "\n";
        }

        // Run CPU validation if enabled
        if(config_.cpuValidation)
        {
            std::cout << "Running CPU reference validation (mode " << mode << ")...\n";
            Tensor<InputType> dxRefTensor(dxAttr->get_dim(), dxAttr->get_stride());
            Tensor<IntermediateType> dscaleRefTensor(dscaleAttr->get_dim(),
                                                     dscaleAttr->get_stride());
            Tensor<IntermediateType> dbiasRefTensor(dbiasAttr->get_dim(), dbiasAttr->get_stride());

            CpuFpReferenceBatchnormImpl<InputType, IntermediateType>::batchnormBwd(
                dyTensor,
                xTensor,
                savedMeanTensor,
                savedInvVarianceTensor,
                scaleTensor,
                dxRefTensor,
                dscaleRefTensor,
                dbiasRefTensor);

            // Validate results against CPU reference
            auto tolerance = test::batchnorm::getToleranceBackward<InputType>();
            CpuFpReferenceValidation<InputType> dxValidator(tolerance, tolerance);
            CpuFpReferenceValidation<IntermediateType> paramValidator(
                static_cast<IntermediateType>(tolerance), static_cast<IntermediateType>(tolerance));

            bool dxValid = dxValidator.allClose(dxRefTensor.memory(), dxTensor.memory());
            bool dscaleValid
                = paramValidator.allClose(dscaleRefTensor.memory(), dscaleTensor.memory());
            bool dbiasValid
                = paramValidator.allClose(dbiasRefTensor.memory(), dbiasTensor.memory());

            std::cout << "CPU validation results:\n";
            std::cout << "  dx: " << (dxValid ? "successful" : "failed") << "\n";
            std::cout << "  dscale: " << (dscaleValid ? "successful" : "failed") << "\n";
            std::cout << "  dbias: " << (dbiasValid ? "successful" : "failed") << "\n";
        }

        // Cleanup reference tensors
        delete refDxTensorPtr;
        delete refDscaleTensorPtr;
        delete refDbiasTensorPtr;
    }

private:
    hipdnnHandle_t handle_;
    Config config_;
};

// Dispatch to appropriate data type implementation
void run(hipdnnHandle_t handle, const Config& config)
{
    TensorLayout layout = (config.layout == "NHWC") ? TensorLayout::NHWC : TensorLayout::NCHW;

    if(config.dataType == "fp32")
    {
        BnBwdRunner runner(handle, config);
        runner.template operator()<float, float>(layout);
    }
    else if(config.dataType == "fp16")
    {
        BnBwdRunner runner(handle, config);
        runner.template operator()<half, float>(layout);
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

int main(int argc, char* argv[])
{
    // Print command line for debugging
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << "\n";

    auto config = parseCommandLineArgs(argc, argv);

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));
    run(handle, config);
    HIPDNN_CHECK(hipdnnDestroy(handle));

    return 0;
}
