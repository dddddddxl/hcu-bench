// Copyright © Advanced Micro Devices, Inc., or its affiliates.
// SPDX-License-Identifier:  MIT

#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include <hip/hip_runtime.h>
#include <hipdnn_data_sdk/utilities/Tensor.hpp>
#include <hipdnn_data_sdk/utilities/Workspace.hpp>
#include <hipdnn_frontend.hpp>
#include <hipdnn_test_sdk/utilities/CpuFpReferenceValidation.hpp>

using namespace hipdnn_frontend;
using namespace hipdnn_data_sdk::utilities;

// ==================== 工具宏定义 ====================
#define HIP_CHECK(status)                                                                      \
    do                                                                                         \
    {                                                                                          \
        if(status != hipSuccess)                                                               \
        {                                                                                      \
            std::cerr << "HIP Error: " << hipGetErrorString(status) << " in file " << __FILE__ \
                      << " at line " << __LINE__ << "\n";                                      \
            exit(EXIT_FAILURE);                                                                \
        }                                                                                      \
    } while(0)

#define HIPDNN_CHECK(status)                                                             \
    do                                                                                   \
    {                                                                                    \
        if(status != HIPDNN_STATUS_SUCCESS)                                              \
        {                                                                                \
            std::cerr << "hipDNN Error: " << hipdnnGetErrorString(status) << " in file " \
                      << __FILE__ << " at line " << __LINE__ << "\n";                    \
            exit(EXIT_FAILURE);                                                          \
        }                                                                                \
    } while(0)

#define HIPDNN_FE_CHECK(statusObj)                                                        \
    do                                                                                    \
    {                                                                                     \
        auto const& status = statusObj;                                                   \
        if(!status.is_good())                                                             \
        {                                                                                 \
            std::cerr << "hipDNN Frontend Error: " << status.get_message() << " in file " \
                      << __FILE__ << " at line " << __LINE__ << "\n";                     \
            exit(EXIT_FAILURE);                                                           \
        }                                                                                 \
    } while(0)

// ==================== 配置结构体 ====================
struct Config
{
    int64_t n = 2; // 批量大小
    int64_t c = 64; // 通道数
    int64_t h = 4; // 高度
    int64_t w = 5; // 宽度
    std::string dataType = "fp16"; // 数据类型
    std::vector<int64_t> permuteOrder = {0, 2, 3, 1}; // 维度变换顺序
    bool cpuValidation = false; // 是否进行CPU验证
    int fileIndex = 0; // 文件索引，0表示不使用文件
    std::string filePath = "."; // 文件路径
    int transformType = 1; // 变换类型: 1=前向推理
    int64_t vectorCount = 1; // 向量计数
    int64_t vectorDimension = 1; // 向量维度
};

// ==================== 命令行解析 ====================
Config parseCommandLineArgs(int argc, char* argv[])
{
    Config config;

    for(int i = 1; i < argc; ++i)
    {
        if(strcmp(argv[i], "-n") == 0 && i + 1 < argc)
        {
            config.n = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-c") == 0 && i + 1 < argc)
        {
            config.c = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-H") == 0 && i + 1 < argc)
        {
            config.h = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-W") == 0 && i + 1 < argc)
        {
            config.w = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc)
        {
            config.dataType = argv[++i];
            std::transform(
                config.dataType.begin(), config.dataType.end(), config.dataType.begin(), ::tolower);
        }
        else if(strcmp(argv[i], "-permute") == 0 && i + 1 < argc)
        {
            // 格式: 0,2,3,1
            std::string permuteStr = argv[++i];
            config.permuteOrder.clear();
            size_t pos = 0;
            std::string token;
            while((pos = permuteStr.find(',')) != std::string::npos)
            {
                token = permuteStr.substr(0, pos);
                config.permuteOrder.push_back(std::stoll(token));
                permuteStr.erase(0, pos + 1);
            }
            config.permuteOrder.push_back(std::stoll(permuteStr));
        }
        else if(strcmp(argv[i], "--cpu-validation") == 0)
        {
            config.cpuValidation = true;
        }
        else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc)
        {
            config.fileIndex = std::stoi(argv[++i]);
        }
        else if(strcmp(argv[i], "-path") == 0 && i + 1 < argc)
        {
            config.filePath = argv[++i];
            if(!config.filePath.empty() && config.filePath.back() != '/')
            {
                config.filePath += "/";
            }
        }
        else if(strcmp(argv[i], "-F") == 0 && i + 1 < argc)
        {
            int type = std::stoi(argv[++i]);
            if(type != 1)
            {
                std::cerr << "Invalid Transpose type: " << type << std::endl;
                std::cerr << "Currently only supports: 1(inference)" << std::endl;
                exit(1);
            }
            config.transformType = type;
        }
        else if(strcmp(argv[i], "-vc") == 0 && i + 1 < argc)
        {
            config.vectorCount = std::stoll(argv[++i]);
        }
        else if(strcmp(argv[i], "-vd") == 0 && i + 1 < argc)
        {
            config.vectorDimension = std::stoll(argv[++i]);
        }
        else
        {
            std::cerr << "unknown parameter: " << argv[i] << std::endl;
            std::cerr << "Usage: " << argv[0] << " -n <batch> -c <channels> -H <height> -W <width> "
                      << "-d <data_type> -permute <order> -F <transpose_type> "
                      << "-i <file_index> -path <path> -vc <vector_count> -vd <vector_dimension> "
                      << "[--cpu-validation]\n";
            exit(1);
        }
    }

    // 验证permute顺序
    if(config.permuteOrder.size() != 4)
    {
        std::cerr << "Permute order must have exactly 4 elements" << std::endl;
        exit(1);
    }

    std::vector<bool> seen(4, false);
    for(size_t i = 0; i < 4; ++i)
    {
        if(config.permuteOrder[i] < 0 || config.permuteOrder[i] >= 4)
        {
            std::cerr << "Invalid permute value: " << config.permuteOrder[i]
                      << ". Must be between 0 and 3." << std::endl;
            exit(1);
        }
        if(seen[static_cast<size_t>(config.permuteOrder[i])])
        {
            std::cerr << "Duplicate permute value: " << config.permuteOrder[i] << std::endl;
            exit(1);
        }
        seen[static_cast<size_t>(config.permuteOrder[i])] = true;
    }

    return config;
}

// ==================== TransposeRunner 类 ====================
class TransposeRunner
{
public:
    TransposeRunner(hipdnnHandle_t handle, const Config& config)
        : handle_(handle)
        , config_(config)
    {
    }

    // 根据步长顺序创建张量属性
    std::shared_ptr<graph::Tensor_attributes> createTensor(const std::vector<int64_t>& dims,
                                                           DataType data_type,
                                                           const std::string& layout
                                                           = "NCHW") // 支持 NCHW 或 NHWC
    {
        auto tensor = std::make_shared<graph::Tensor_attributes>();
        tensor->set_dim(dims).set_data_type(data_type);

        // 根据布局计算步长
        std::vector<int64_t> strides(4);

        if(layout == "NCHW")
        {
            // NCHW 布局: 维度顺序 [N, C, H, W]
            // 步长: C*H*W, H*W, W, 1
            int64_t c = dims[1];
            int64_t h = dims[2];
            int64_t w = dims[3];

            strides[0] = c * h * w; // N
            strides[1] = h * w; // C
            strides[2] = w; // H
            strides[3] = 1; // W
        }
        else if(layout == "NHWC")
        {
            // NHWC 布局: 维度顺序 [N, H, W, C]
            // 步长: H*W*C, W*C, C, 1
            int64_t h = dims[1];
            int64_t w = dims[2];
            int64_t c = dims[3];

            strides[0] = h * w * c; // N
            strides[1] = w * c; // H
            strides[2] = c; // W
            strides[3] = 1; // C
        }
        else
        {
            std::cerr << "Unsupported layout: " << layout << std::endl;
            exit(1);
        }

        tensor->set_stride(strides);
        return tensor;
    }

    // 前向推理实现
    template <typename InputType, typename IntermediateType>
    void inference()
    {
        const auto inputType = getDataTypeEnumFromType<InputType>();
        const auto intermediateType = getDataTypeEnumFromType<IntermediateType>();

        std::cout << "Running Transpose graph " << inputType << " with permute order ["
                  << config_.permuteOrder[0] << "," << config_.permuteOrder[1] << ","
                  << config_.permuteOrder[2] << "," << config_.permuteOrder[3] << "]"
                  << (config_.cpuValidation ? " (with CPU validation)" : "") << "...\n";

        // 计算张量元素总数
        std::vector<int64_t> inputDims = {config_.n, config_.c, config_.h, config_.w};
        size_t totalElems = 1;
        for(auto dim : inputDims)
        {
            totalElems *= static_cast<size_t>(dim);
        }

        auto graph = std::make_shared<graph::Graph>();
        graph->set_io_data_type(inputType)
            .set_intermediate_data_type(intermediateType)
            .set_compute_data_type(DataType::FLOAT);

        // 创建输入张量 - 使用NCHW布局
        auto x = createTensor(inputDims, inputType, "NCHW");

        // 配置Transpose属性
        auto transposeAttributes = graph::TransposeAttributes();
        transposeAttributes.set_name("transpose_node").set_permutation(config_.permuteOrder);

        // 添加Transpose操作到图中
        auto y = graph->transpose(x, transposeAttributes);
        y->set_output(true).set_data_type(inputType);

        HIPDNN_FE_CHECK(graph->validate());
        std::cout << "Graph validation successful (Transpose).\n";

        HIPDNN_FE_CHECK(graph->build_operation_graph(handle_));
        std::cout << "Operation graph build successful (Transpose).\n";

        HIPDNN_FE_CHECK(graph->create_execution_plans());
        std::cout << "Execution plans created successfully (Transpose).\n";

        HIPDNN_FE_CHECK(graph->check_support());
        std::cout << "Graph support check successful (Transpose).\n";

        HIPDNN_FE_CHECK(graph->build_plans());
        std::cout << "Plans build successful (Transpose).\n";

        // 初始化张量
        Tensor<InputType> xTensor(x->get_dim(), x->get_stride());
        Tensor<InputType> yTensor(y->get_dim(), y->get_stride());
        xTensor.fillWithRandomValues(static_cast<InputType>(0.0f), static_cast<InputType>(1.0f));

        // 读取参考文件
        bool readSuccess = false;
        std::vector<InputType> refXData, refYData;
        Tensor<InputType> refYTensor(y->get_dim(), y->get_stride());

        if(config_.fileIndex > 0)
        {
            const std::string xFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_X.bin";
            const std::string yFilename
                = config_.filePath + std::to_string(config_.fileIndex) + "_Y.bin";

            readSuccess = readRawTensor<InputType>(xFilename, refXData, totalElems)
                          && readRawTensor<InputType>(yFilename, refYData, totalElems);

            if(readSuccess)
            {
                std::cout << "Successfully read Transpose reference files.\n";
                std::copy(refXData.begin(), refXData.end(), xTensor.memory().hostData());
                xTensor.memory().markHostModified();

                std::copy(refYData.begin(), refYData.end(), refYTensor.memory().hostData());
                refYTensor.memory().markHostModified();
            }
            else
            {
                std::cerr
                    << " [WARN] Failed to read Transpose reference files. Using random values.\n";
            }
        }

        // 准备执行数据
        std::unordered_map<int64_t, void*> variantPack;
        variantPack[x->get_uid()] = xTensor.memory().deviceData();
        variantPack[y->get_uid()] = yTensor.memory().deviceData();

        // 获取工作空间并执行
        int64_t workspaceSize = 0;
        HIPDNN_FE_CHECK(graph->get_workspace_size(workspaceSize));
        Workspace workspace(static_cast<size_t>(workspaceSize));

        // 首次执行
        HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        yTensor.memory().markDeviceModified();

        // 计时运行
        hipEvent_t start, stop;
        float time;
        HIP_CHECK(hipDeviceSynchronize());
        HIP_CHECK(hipEventCreate(&start));
        HIP_CHECK(hipEventCreate(&stop));
        HIP_CHECK(hipEventRecord(start, nullptr));

        const int warmupRuns = 10;
        const int timedRuns = 100;

        // 预热运行
        for(int exec_idx = 0; exec_idx < warmupRuns; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }

        HIP_CHECK(hipEventRecord(start, nullptr));
        for(int exec_idx = 0; exec_idx < timedRuns; ++exec_idx)
        {
            HIPDNN_FE_CHECK(graph->execute(handle_, variantPack, workspace.get()));
        }
        HIP_CHECK(hipEventRecord(stop, nullptr));
        HIP_CHECK(hipEventSynchronize(stop));
        HIP_CHECK(hipEventElapsedTime(&time, start, stop));

        std::cout << "Transpose inference avg time: " << time / timedRuns << " ms" << std::endl;
        HIP_CHECK(hipEventDestroy(start));
        HIP_CHECK(hipEventDestroy(stop));

        auto yHostPtr = yTensor.memory().hostData();

        // 文件验证
        if(config_.fileIndex > 0 && readSuccess)
        {
            // 对于int8类型使用特殊的验证方式
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                const InputType* refData = refYTensor.memory().hostData();
                const InputType* currData = yTensor.memory().hostData();
                bool isMatch = true;

                // 打印前10个元素对比
                const size_t printCount = std::min(totalElems, static_cast<size_t>(10));
                std::cout << "First " << printCount << " elements comparison:" << std::endl;
                std::cout << "Reference: ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<int>(refData[i]) << " ";
                }
                std::cout << std::endl;

                std::cout << "Current:   ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<int>(currData[i]) << " ";
                }
                std::cout << std::endl;

                // 检查所有元素是否匹配
                for(size_t i = 0; i < totalElems; ++i)
                {
                    if(currData[i] != refData[i])
                    {
                        std::cout << "Mismatch at index " << i
                                  << ": ref=" << static_cast<int>(refData[i])
                                  << ", curr=" << static_cast<int>(currData[i]) << std::endl;
                        isMatch = false;
                        break;
                    }
                }
                std::cout << "File validation result: " << (isMatch ? "successful" : "failed")
                          << "\n";
            }
            else
            {
                // 浮点类型的正常验证
                float tolerance = static_cast<float>(getTolerance<InputType>());
                hipdnn_test_sdk::utilities::CpuFpReferenceValidation<InputType> fileValidator(
                    tolerance, tolerance);
                bool isMatch = fileValidator.allClose(refYTensor, yTensor);

                std::cout << "File validation result: " << (isMatch ? "successful" : "failed")
                          << "\n";

                // 打印前10个元素对比
                const size_t printCount = std::min(totalElems, static_cast<size_t>(10));
                const InputType* refData = refYTensor.memory().hostData();
                const InputType* currData = yTensor.memory().hostData();

                std::cout << "First " << printCount << " elements comparison:" << std::endl;
                std::cout << "Reference: ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<float>(refData[i]) << " ";
                }
                std::cout << std::endl;

                std::cout << "Current:   ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    std::cout << static_cast<float>(currData[i]) << " ";
                }
                std::cout << std::endl;
            }
        }

        // CPU验证
        if(config_.cpuValidation)
        {
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                std::cout << "CPU validation is not supported for int8 input type.\n";
            }
            else
            {
                std::cout << "Running CPU reference validation...\n";
                runCpuReference(xTensor, refYTensor, config_.permuteOrder);

                float tolerance = static_cast<float>(getTolerance<InputType>());
                auto validator = hipdnn_test_sdk::utilities::CpuFpReferenceValidation<InputType>(
                    tolerance, tolerance);

                bool yValid = validator.allClose(refYTensor, yTensor);

                std::cout << "CPU reference validation: " << (yValid ? "successful" : "failed")
                          << "\n";

                // 添加CPU验证的前10个数据打印
                const size_t printCount = std::min(totalElems, static_cast<size_t>(10));

                const InputType* cpuRefData = refYTensor.memory().hostData();
                const InputType* gpuData = yTensor.memory().hostData();

                std::cout << "CPU validation - First " << printCount
                          << " elements comparison:" << std::endl;
                std::cout << "CPU Reference: ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    if constexpr(std::is_same_v<InputType, half>
                                 || std::is_same_v<InputType, bfloat16>)
                    {
                        std::cout << static_cast<float>(cpuRefData[i]) << " ";
                    }
                    else
                    {
                        std::cout << cpuRefData[i] << " ";
                    }
                }
                std::cout << std::endl;

                std::cout << "GPU Output:    ";
                for(size_t i = 0; i < printCount; ++i)
                {
                    if constexpr(std::is_same_v<InputType, half>
                                 || std::is_same_v<InputType, bfloat16>)
                    {
                        std::cout << static_cast<float>(gpuData[i]) << " ";
                    }
                    else
                    {
                        std::cout << gpuData[i] << " ";
                    }
                }
                std::cout << std::endl;
            }
        }

        // 打印前10个输出值
        std::cout << "First 10 y values: ";
        for(int i = 0; i < 10; ++i)
        {
            if constexpr(std::is_same_v<InputType, int8_t>)
            {
                std::cout << static_cast<int>(yHostPtr[i]) << " ";
            }
            else if constexpr(std::is_same_v<InputType, half>
                              || std::is_same_v<InputType, bfloat16>)
            {
                std::cout << static_cast<float>(yHostPtr[i]) << " ";
            }
            else
            {
                std::cout << yHostPtr[i] << " ";
            }
        }
        std::cout << "\n";

        std::cout << "Transpose graph execution complete for " << inputType << ".\n\n";
    }

private:
    hipdnnHandle_t handle_;
    Config config_;

    // 读取原始张量数据
    template <typename T>
    bool readRawTensor(const std::string& filename, std::vector<T>& data, size_t totalElems)
    {
        std::ifstream file(filename, std::ios::binary);
        if(!file.is_open())
        {
            std::cerr << "Failed to open file: " << filename << std::endl;
            return false;
        }

        file.seekg(0, std::ios::end);
        std::streampos fileSize = file.tellg();
        file.seekg(0, std::ios::beg);

        size_t expectedBytes = totalElems * sizeof(T);
        if(static_cast<size_t>(fileSize) != expectedBytes)
        {
            std::cerr << "File size mismatch: expected " << expectedBytes << " bytes, got "
                      << fileSize << " bytes" << std::endl;
            return false;
        }

        data.resize(totalElems);
        file.read(reinterpret_cast<char*>(data.data()), static_cast<std::streamsize>(fileSize));
        file.close();

        return true;
    }

    // 获取容差值
    template <typename InputType>
    InputType getTolerance()
    {
        if constexpr(std::is_same_v<InputType, float>)
        {
            return static_cast<InputType>(1e-5f);
        }
        else if constexpr(std::is_same_v<InputType, half>)
        {
            return static_cast<InputType>(1e-2f);
        }
        else if constexpr(std::is_same_v<InputType, bfloat16>)
        {
            return static_cast<InputType>(1e-2f);
        }
        else if constexpr(std::is_same_v<InputType, int8_t>)
        {
            return static_cast<InputType>(1); // int8允许1的差异
        }
        else
        {
            return static_cast<InputType>(1e-5f);
        }
    }

    // CPU参考实现 - 修复版：使用连续布局索引，不依赖步长，并修复符号转换警告
    template <typename InputType>
    void runCpuReference(const Tensor<InputType>& inputTensor,
                         Tensor<InputType>& outputTensor,
                         const std::vector<int64_t>& permuteOrder)
    {
        const InputType* inputData = inputTensor.memory().hostData();
        InputType* outputData = outputTensor.memory().hostData();

        auto inputDims = inputTensor.dims(); // [N, C, H, W]
        auto outputDims = outputTensor.dims(); // 根据 permute 决定

        int64_t n = inputDims[0];
        int64_t c = inputDims[1];
        int64_t h = inputDims[2];
        int64_t w = inputDims[3];

        // 连续布局下的索引计算
        for(int64_t i0 = 0; i0 < n; ++i0)
        {
            for(int64_t i1 = 0; i1 < c; ++i1)
            {
                for(int64_t i2 = 0; i2 < h; ++i2)
                {
                    for(int64_t i3 = 0; i3 < w; ++i3)
                    {
                        // 输入索引 (NCHW 连续)
                        int64_t inputIdx = ((i0 * c + i1) * h + i2) * w + i3;

                        // 原始坐标
                        std::vector<int64_t> coord = {i0, i1, i2, i3};
                        // 输出坐标
                        std::vector<int64_t> outCoord(4);
                        for(size_t i = 0; i < 4; ++i)
                        {
                            // 修复：显式转换为 size_t，消除符号转换警告
                            outCoord[i] = coord[static_cast<size_t>(permuteOrder[i])];
                        }

                        // 输出索引（连续布局）
                        int64_t outputIdx
                            = (((outCoord[0] * outputDims[1] + outCoord[1]) * outputDims[2]
                                + outCoord[2])
                                   * outputDims[3]
                               + outCoord[3]);

                        outputData[outputIdx] = inputData[inputIdx];
                    }
                }
            }
        }

        outputTensor.memory().markHostModified();
    }
};

// ==================== 根据参数选择执行类型 ====================
void run(hipdnnHandle_t handle, const Config& config)
{
    if(config.dataType == "fp32")
    {
        TransposeRunner runner(handle, config);
        if(config.transformType == 1)
        { // inference
            runner.template inference<float, float>();
        }
    }
    else if(config.dataType == "fp16")
    {
        TransposeRunner runner(handle, config);
        if(config.transformType == 1)
        {
            runner.template inference<half, float>();
        }
    }
    else if(config.dataType == "bfp16")
    {
        TransposeRunner runner(handle, config);
        if(config.transformType == 1)
        {
            runner.template inference<bfloat16, float>();
        }
    }
    else if(config.dataType == "int8")
    {
        TransposeRunner runner(handle, config);
        if(config.transformType == 1)
        {
            runner.template inference<int8_t, int32_t>();
        }
    }
    else
    {
        std::cerr << "Unsupported data type: " << config.dataType << std::endl;
        exit(1);
    }
}

// ==================== 主函数 ====================
int main(int argc, char* argv[])
{
    // 打印命令行参数
    for(int i = 0; i < argc; ++i)
    {
        std::cout << argv[i] << " ";
    }
    std::cout << '\n';

    auto config = parseCommandLineArgs(argc, argv);

    // 初始化前端日志
    initializeFrontendLogging();

    hipdnnHandle_t handle;
    HIPDNN_CHECK(hipdnnCreate(&handle));

    run(handle, config);

    HIPDNN_CHECK(hipdnnDestroy(handle));
    std::cout << "All Transpose inference runs completed.\n";
    return 0;
}
