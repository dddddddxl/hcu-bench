### api_test
## c++接口测试 
# 编译
hipdnn/api_test/目录下

source dtk/env.sh

mkdir build

cd build

cmake ..(默认使用dtk中的hipdnn, 自定义路径 cmake -DCMAKE_PREFIX_PATH=/root/hipdnn/hipdnn/build/lib/cmake ..)

ninja -j32

编译出来的文件在bin文件夹下

# 执行示例
参考 hipdnn/api_test/cpp/test_case

# python目录下是python接口测试代码
python目录下直接执行

pytest test_conv.py -v -s
